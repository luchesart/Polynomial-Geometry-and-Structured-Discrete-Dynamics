#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ -x "$project_root/runtime/lean-4.24.0-linux/bin/lake" ]]; then
  export PATH="$project_root/runtime/lean-4.24.0-linux/bin:$PATH"
fi
cd "$project_root"
exec lake "$@"
