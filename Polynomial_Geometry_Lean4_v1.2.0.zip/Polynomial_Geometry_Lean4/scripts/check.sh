#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
./scripts/lake.sh build
./scripts/lake.sh env lean Audit.lean
python3 scripts/verify_audit.py
