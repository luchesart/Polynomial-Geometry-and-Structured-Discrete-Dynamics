"""Check the D.3 browser fixture using an independent 50-digit nonlinear solve.

Run with Python, mpmath and Node from any directory. This is a numerical cross-check.
"""
import json
from pathlib import Path
import subprocess

import mpmath as mp

mp.mp.dps = 50
# Decimal centers from the degree-nine example in Appendix D.
w = mp.mpc('-0.48492562995803556129707245262998660816221629238294', '0.02901557281090164337217076497451623696961039031589')
a = mp.mpc('-0.93587724676485513122462027678534072382387788867435', '0.30035603021366926628027536665121167104054563135329')
v = mp.mpc('-0.56087338453133205084981550936692143474454258438609', '-0.06890689486027940082147155686841112313021325932329')
poles = [1, 1j, 1j, 1j, -1j, -1j, -1j]
q, g = w-a, v-a
s1 = sum(1/(w-pole) for pole in poles)
s2 = sum(1/(w-pole)**2 for pole in poles)
linear = -2*s1/(s1**2+s2)
constant = 2/(s1**2+s2)
start = (linear-2*w, w*w-linear*w+constant, a, v)

def objective(block, split, free=0):
    split, free = mp.mpf(split), mp.mpf(free)
    theta = [mp.mpf(0)]*7
    theta[0] = free
    other = 1 if block == 2 else 4
    theta[other:other+3] = [mp.mpf(k)*free for k in ('-.12','.06','.06')]
    y = [mp.mpf('.16')*free]*2
    if block == 0:
        y = [y[0]+split, y[1]-split]
    else:
        offset = 1 if block == 1 else 4
        theta[offset] += split
        theta[offset+1] -= split
    beta = [pole*mp.exp(1j*angle) for pole, angle in zip(poles,theta)]

    def equations(b, c, marked, critical):
        def factor(t): return t*t+b*t+c
        def reduced_derivative(t):
            return 2*t+b+factor(t)*sum(1/(t-pole) for pole in beta)
        def slope(t):
            return 2+(2*t+b)*sum(1/(t-pole) for pole in beta)-factor(t)*sum(1/(t-pole)**2 for pole in beta)
        z1,z2 = [marked+q*(critical-marked)/g*mp.exp(1j*angle) for angle in y]
        divided = slope(z1) if y[0] == y[1] else (reduced_derivative(z1)-reduced_derivative(z2))/(z1-z2)
        return factor(marked), reduced_derivative(critical), reduced_derivative(z1), divided

    _, _, marked, critical = mp.findroot(equations,start,tol=mp.mpf('1e-40'))
    return mp.log(abs((critical-marked)/g))

source = Path(__file__).resolve().parent/'experiments'/'variation.js'
node = """
global.PGExperiments={};
require(process.argv[1]);
for(let block=0; block<3; block++) {
  const {metrics} = PGExperiments['D.3'].run({block,split:3,free:1});
  console.log(JSON.stringify([block,metrics[0].value,metrics[2].value]));
}
"""
for row in subprocess.check_output(['node','-e',node,str(source)],text=True).splitlines():
    block, browser_curvature, browser_gain = json.loads(row)
    step = mp.mpf('.00035')
    curvature = (objective(block,step)+objective(block,-step)-2*objective(block,0))/(2*step**2)
    gain = objective(block,0,'.001')-objective(block,'.003','.001')
    dc, dg = abs(curvature-browser_curvature), abs(gain-browser_gain)
    assert dc < mp.mpf('2e-7') and dg < mp.mpf('2e-11'), (block,dc,dg)
    print(f"Block {block}: curvature discrepancy {float(dc):.3g}, gain discrepancy {float(dg):.3g}")
