/* Source-metric energy, finite observation and the coordinate bridge.
   Complex entries are [real, imaginary]. Matrix rank uses complete pivoting. */
(() => {
  "use strict";
  const zero = () => [0, 0];
  const real = x => [x, 0];
  const plus = (z, w) => [z[0] + w[0], z[1] + w[1]];
  const minus = (z, w) => [z[0] - w[0], z[1] - w[1]];
  const times = (z, w) => [z[0]*w[0] - z[1]*w[1], z[1]*w[0] + z[0]*w[1]];
  const scaleZ = (s, z) => [s*z[0], s*z[1]];
  const conj = z => [z[0], -z[1]];
  const length = z => Math.hypot(z[0], z[1]);
  const div = (z, w) => scaleZ(1/(w[0]*w[0]+w[1]*w[1]), times(z,conj(w)));
  const polar = (r, t) => [r*Math.cos(t), r*Math.sin(t)];
  const range = n => Array.from({length:n}, (_,j) => j);
  const mat = (n,m,entry) => range(n).map(j=>range(m).map(k=>entry(j,k)));
  const adj = A => mat(A[0].length,A.length,(j,k)=>conj(A[k][j]));
  const eye = n => mat(n,n,(j,k)=>real(Number(j===k)));
  const diag = xs => mat(xs.length,xs.length,(i,j)=>i===j ? xs[i] : zero());
  const col = xs => xs.map(z=>[z]);
  const add = (A,B) => mat(A.length,A[0].length,(j,k)=>plus(A[j][k],B[j][k]));
  const sub = (A,B) => mat(A.length,A[0].length,(j,k)=>minus(A[j][k],B[j][k]));
  const scale = (s,A) => A.map(row=>row.map(z=>scaleZ(s,z)));
  const mul = (A,B) => mat(A.length,B[0].length,(j,k)=>
    A[j].reduce((z,a,i)=>plus(z,times(a,B[i][k])),zero()));
  const gram = A => mul(adj(A),A);
  const congr = (E,T) => mul(adj(T),mul(E,T));
  const maxEntry = A => Math.max(...A.flat().map(length));
  const relativeError = (A,B) => maxEntry(sub(A,B))/Math.max(1,maxEntry(A),maxEntry(B));
  const energy = (E,x) => congr(E,x)[0][0][0];
  const sizeSq = A => gram(A)[0][0][0];
  function inverse(A) {
    const n=A.length, I=eye(n), H=A.map((row,i)=>[...row,...I[i]]);
    for(let k=0;k<n;k++){
      let p=k;
      for(let i=k+1;i<n;i++) if(length(H[i][k])>length(H[p][k])) p=i;
      if(length(H[p][k])<1e-15) throw new Error('Singular matrix in the selected example.');
      [H[k],H[p]]=[H[p],H[k]];
      const piv=H[k][k];
      H[k]=H[k].map(z=>div(z,piv));
      for(let i=0;i<n;i++){
        if(i===k) continue;
        const t=H[i][k]; H[i]=H[i].map((z,j)=>minus(z,times(t,H[k][j])));
      }
    }
    return H.map(row=>row.slice(n));
  }
  const rankTolerance=1e-9;
  function rank(A) {
    const H=A.map(row=>row.slice()), n=H.length, m=H[0].length;
    const threshold=maxEntry(H)*rankTolerance;
    for(let k=0;k<Math.min(n,m);k++){
      let best=0, r=k, c=k;
      for(let i=k;i<n;i++) for(let j=k;j<m;j++){
        const v=length(H[i][j]); if(v>best){best=v;r=i;c=j;}
      }
      if(best<=threshold) return k;
      [H[k],H[r]]=[H[r],H[k]];
      for(const row of H) [row[c],row[k]]=[row[k],row[c]];
      for(let i=k+1;i<n;i++){
        const t=div(H[i][k],H[k][k]);
        for(let j=k+1;j<m;j++) H[i][j]=minus(H[i][j],times(t,H[k][j]));
      }
    }
    return Math.min(n,m);
  }
  const numericCheck = (label,left,right,tol=1e-9,detail='') =>
    ({label,left,right,tol,state:Math.abs(left-right)<=tol?'pass':'fail',detail});
  const residual = (label,A,B) => numericCheck(label,relativeError(A,B),0,1e-9,'Maximum entrywise difference divided by max(1, ‖left‖max, ‖right‖max).');
  const metric = (label,value) => ({label,value});
  const control = (key,label,min,max,step,value)=>({key,label,min,max,step,value});
  const boundaries = control('boundary','Distinct boundary sources b',0,5,1,5);
  const marked = control('a','Marked root a',0,0.7,0.05,0);
  const modeControl = control('mode','Initial Fourier mode ℓ',0,4,1,1);
  const rankNote='Numerical ranks use complete pivoting with a cutoff of 10⁻⁹ times the largest entry of each matrix.';
  function source(a,nodes,masses) {
    const d=nodes.length, I=eye(d), c=1-a*a, n=1+masses.reduce((t,x)=>t+x,0);
    const u=col(masses.map(x=>real(Math.sqrt(x)))), U=mul(u,adj(u));
    const diff=nodes.map(z=>minus(real(a),z)), X=diag(diff.map(v=>div(real(1),v)));
    const E=sub(I,scale(1/n,U)), R=mul(add(I,U),X), S=add(scale(a,I),scale(c,R)), T=inverse(S);
    const kappa=nodes.map((z,j)=>Math.max(0,1-length(z)**2)/(length(diff[j])**2));
    // An explicit rectangular loss output; boundary zeros are exact geometric inputs.
    const rows=diag(kappa.map(k=>real(Math.sqrt(c*k))))
      .concat(scale(Math.sqrt(c/n),adj(u)),scale(c,mul(adj(u),X)));
    const C=mul(rows,T), D=sub(E,congr(E,T));
    return {d,c,n,u,U,E,R,S,T,X,D,C,rows,kappa,I};
  }
  function five(b,a) {
    const nodes=range(5).map(j=>j<b ? polar(1,2*Math.PI*j/5)
      : polar(0.48+0.045*(j-b),2*Math.PI*j/5+0.27));
    const masses=range(5).map(j=>j<b?2:1);
    const data=source(a,nodes,masses);
    // cos²+sin² is exact geometrically, up to rounding in the coordinates.
    for(let j=0;j<b;j++){ data.kappa[j]=0; data.rows[j]=data.rows[j].map(z=>zero()); }
    data.C=mul(data.rows,data.T);
    return data;
  }
  const fourier = k => col(range(5).map(j=>polar(1/Math.sqrt(5),2*Math.PI*j*k/5)));
  function records(model,h) {
    const {I,T,E,C}=model, stack=[], defects=[], ranks=[];
    let P=I;
    for(let k=1;k<=h;k++){
      stack.push(...mul(C,P));
      P=mul(T,P);
      const W=sub(E,congr(E,P)); defects.push(W); ranks.push(rank(W));
    }
    return {W:defects[h-1],O:stack,P,ranks};
  }
  PGExperiments['2.3']={
    question:'How many vector measurements distinguish every grouped source state?',
    idea:'Compute Wₕ = E − (Tʰ)* E Tʰ directly from the disk sources and compare its numerical rank with i + min(b,h+1). The boundary moment equations form a Vandermonde system. The five sources are equally spaced on the circle when b = 5; lowering b moves individual sources inside.',
    controls:[boundaries,marked,control('h','Observation horizon h',1,7,1,4)],
    presets:[{label:'Pentagon · step 3',values:{boundary:5,a:0,h:3}},{label:'Pentagon · step 4',values:{boundary:5,a:0,h:4}},{label:'Pentagon · step 5',values:{boundary:5,a:0,h:5}},{label:'Mixed sources',values:{boundary:3,a:0.4,h:2}},{label:'Interior only',values:{boundary:0,a:0.25,h:1}}],
    run({boundary:b,a,h}) {
      const model=five(b,a), d=5, i=d-b, history=records(model,7), chosen=records(model,h);
      const first=history.ranks.findIndex(k=>k===d)+1, target=Math.max(1,b-1);
      const predicted=k=>i+Math.min(b,k+1);
      const checks=[numericCheck('Rank of Wₕ against boundary count',chosen.ranks[h-1],predicted(h),0,rankNote),
        numericCheck('Rank of stacked vector-output map',rank(chosen.O),predicted(h),0,rankNote),
        numericCheck('First numerically full rank against h*',first,target,0),
        residual('Direct loss Wₕ against Oₕ* Oₕ',chosen.W,gram(chosen.O))];
      let interpretation=chosen.ranks[h-1]===d?'Every direction is visible in this record.':'The record still misses '+(d-chosen.ranks[h-1])+' state direction(s).';
      const boundaryMomentRank=b===0?0:rank(mat(h+1,b,(k,j)=>polar(Math.sqrt(2),2*Math.PI*j*k/5)));
      checks.push(numericCheck('Zero-loss directions from the boundary moment equations',
        d-chosen.ranks[h-1],b-boundaryMomentRank,0,'Numerical nullity of Wₕ against the nullity of the separately formed weighted Vandermonde matrix.'));
      if(b===5 && a===0){
        checks.push(residual('Pentagon fifth step: W₅ = (120/121) E',records(model,5).W,scale(120/121,model.E)));
        interpretation+=' For the pentagon, four samples observe every direction. Five steps additionally multiply the energy of every state by 1/121.';
      }
      return {metrics:[metric('Measured rank',chosen.ranks[h-1]),metric('Unobserved dimensions',d-chosen.ranks[h-1]),metric('First full horizon',first)],checks,
        plot:{type:'lines',xLabel:'Horizon h',yLabel:'Rank',series:[{name:'Computed Wₕ',points:history.ranks.map((v,j)=>[j+1,v])},{name:'Boundary count',points:range(7).map(j=>[j+1,predicted(j+1)])}]},interpretation};
    }
  };
  PGExperiments['C.1']={
    question:'Which sources dissipate energy in one step?',
    idea:'Expand S* E S − E into a diagonal interior loss and two positive rank-one terms. Evaluate all three on Tx and compare their sum with the observed decrease of x* E x. The spectrum of T is strictly inside the disk under the theorem’s hypotheses.',
    controls:[boundaries,marked,modeControl],
    presets:[{label:'Pentagon · lossless mode',values:{boundary:5,a:0,mode:1}},{label:'Pentagon · lossy mode',values:{boundary:5,a:0,mode:4}},{label:'Mixed sources',values:{boundary:2,a:0.4,mode:2}}],
    run({boundary:b,a,mode}) {
      const m=five(b,a), x=fourier(mode), tx=mul(m.T,x), v0=energy(m.E,x), v1=energy(m.E,tx);
      const out=mul(m.C,x).map(row=>length(row[0])**2);
      const losses=[out.slice(0,5).reduce((s,t)=>s+t,0),out[5],out[6]];
      const gain=losses.reduce((s,t)=>s+t,0);
      const q=5-b+Math.min(2,b);
      return {metrics:[metric('Initial energy',v0),metric('Energy after one step',v1),metric('Dissipation rank',rank(m.D))],
        checks:[residual('S* E S − E against the three source terms',sub(congr(m.E,m.S),m.E),gram(m.rows)),
          residual('T* Dₛ T against direct contractive defect',congr(gram(m.rows),m.T),m.D),
          numericCheck('Energy decrease against squared outputs',v0-v1,gain),
          numericCheck('Dissipation rank against i + min(2,b)',rank(m.D),q,0,rankNote)],
        plot:{type:'bars',xLabel:'0 interior · 1 common mass · 2 reciprocal moment',yLabel:'One-step energy loss',series:[{name:'Loss contribution',points:losses.map((v,i)=>[i,v])}]},
        interpretation:gain<1e-11?'This nonzero state preserves energy for one step. Subsequent outputs can still reveal it.':'The displayed contributions add to the loss in the source metric. Changing the mode redistributes the loss among the three terms.'};
    }
  };
  PGExperiments['C.2']={
    question:'What does the full record of vector outputs reveal about the initial state?',
    idea:'Stack C, CT, … and solve the measurement equations for a known complex test state whenever the stack has full column rank. Separately add the squared norms of the outputs. The unrecovered energy at the end of a finite record accounts exactly for its missing tail.',
    controls:[boundaries,marked,control('h','Vector samples h',1,10,1,4),modeControl],
    presets:[{label:'Three invisible samples',values:{boundary:5,a:0,h:3,mode:1}},{label:'Fourth sample reveals v₁',values:{boundary:5,a:0,h:4,mode:1}},{label:'Two full cycles',values:{boundary:5,a:0,h:10,mode:2}},{label:'Mixed sources',values:{boundary:3,a:0.3,h:5,mode:3}}],
    run({boundary:b,a,h,mode}) {
      const m=five(b,a), x0=fourier(mode), t=records(m,h), measured=mul(t.O,x0), E0=energy(m.E,x0);
      const r=rank(t.O), output=[[0,0]], stored=[[0,E0]];
      let x=x0,total=0;
      for(let k=1;k<=h;k++){total+=sizeSq(mul(m.C,x));x=mul(m.T,x);output.push([k,total]);stored.push([k,energy(m.E,x)]);}
      const checks=[residual('Stacked-output Gramian against Wₕ',gram(t.O),t.W),
        numericCheck('Measured output energy + residual energy',total+energy(m.E,x),E0),
        numericCheck('Observability after d = 5 steps',rank(records(m,5).O),5,0,rankNote)];
      if(r===5){
        const xfit=mul(inverse(gram(t.O)),mul(adj(t.O),measured));
        checks.push(residual('Recovered initial state against the hidden input',xfit,x0));
      } else checks.push({label:'Unique recovery at the selected horizon',state:'inconclusive',detail:'The vector-output stack has a nonzero kernel of dimension '+(5-r)+'. Multiple initial states fit this record.'});
      return {metrics:[metric('Output-map rank',r),metric('Accumulated output energy',total),metric('Remaining energy',energy(m.E,x))],checks,
        plot:{type:'lines',xLabel:'Sample count',yLabel:'Source energy',series:[{name:'Accumulated output energy',points:output},{name:'Remaining state energy',points:stored}]},
        interpretation:(r===5?'The vector outputs recover the chosen initial state.':'The selected record cannot uniquely recover a five-dimensional state.')+' The energy curve uses only squared magnitudes; state reconstruction uses the complete complex outputs.'};
    }
  };
  // Three real source nodes, hence one simple critical point in each gap.
  function criticalPoints(nodes,masses){
    return [0,1].map(j=>{
      let lo=nodes[j],hi=nodes[j+1];
      for(let n=0;n<55;n++){
        const w=(lo+hi)/2;
        if(w===lo||w===hi) break;
        const f=nodes.reduce((s,z,i)=>s+masses[i]/(w-z),0);
        if(f>0)lo=w;else hi=w;
      }
      return (lo+hi)/2;
    });
  }
  PGExperiments['E.1']={
    question:'Does a critical-mode vector carry the same energy in source coordinates?',
    idea:'Use three real sources −0.8, a and 1 with masses 1, 1 and m. Bisection of the logarithmic derivative locates the two simple critical modes. Build their columns Y independently of the source lift W and calculate P = E⁻¹ W*Y.',
    controls:[control('a','Marked source a',0,0.65,0.05,0.2),control('mass','Mass m at +1',1,5,0.25,2),control('angle','Critical-state angle (degrees)',0,180,5,40)],
    presets:[{label:'Polynomial multiplicities',values:{a:0.2,mass:2,angle:40}},{label:'Fractional source mass',values:{a:0.5,mass:3.5,angle:110}},{label:'First critical mode',values:{a:0,mass:1,angle:0}}],
    run({a,mass,angle}){
      const nodes=[a,-0.8,1], weights=[1,1,mass], modes=criticalPoints([-0.8,a,1],[1,1,mass]);
      const m=source(a,nodes.slice(1).map(real),weights.slice(1));
      const B0=scale(-1,adj(m.u)).concat(eye(2)), W=mul(B0,m.E);
      const Y=mat(3,2,(j,k)=>real(Math.sqrt(weights[j])/(modes[k]-nodes[j])));
      const H=gram(Y), A=diag(nodes.map(real)), J=diag(modes.map(real));
      const P=mul(inverse(m.E),mul(adj(W),Y)), AW=mul(inverse(gram(W)),congr(A,W));
      const RaJ=inverse(sub(scale(a,m.I),J));
      const mobius=mul(sub(scale(a,m.I),AW),inverse(sub(m.I,scale(a,AW))));
      const getE=t=>{const x=col([real(Math.cos(t*Math.PI/180)),real(Math.sin(t*Math.PI/180))]);return [energy(H,x),energy(m.E,mul(P,x))];};
      const energies=getE(angle), path=range(37).map(j=>getE(j*5));
      return {metrics:[metric('Left critical point',modes[0]),metric('Right critical point',modes[1]),metric('Energy of selected state',energies[0])],
        checks:[residual('W*W against E',gram(W),m.E),residual('Reconstructed lift WP against Y',mul(W,P),Y),
          residual('H against P* E P',H,congr(m.E,P)),residual('Compression intertwining AᵂP = PJ',mul(AW,P),mul(P,J)),
          residual('Reciprocal in critical coordinates against P⁻¹ Rg P',RaJ,mul(inverse(P),mul(m.R,P))),
          residual('Disk transform of Aᵂ against the source step T',mobius,m.T),
          numericCheck('Energy of the selected state in both bases',energies[0],energies[1])],
        plot:{type:'lines',xLabel:'Critical-state angle (degrees)',yLabel:'Energy',series:[{name:'Critical coordinates',points:path.map((v,j)=>[j*5,v[0]])},{name:'Source coordinates',points:path.map((v,j)=>[j*5,v[1]])}]},
        interpretation:'At '+angle+'° both plotted curves measure the length of the same lifted state. The equality persists as the mass changes, including noninteger positive masses.'};
    }
  };
})();
