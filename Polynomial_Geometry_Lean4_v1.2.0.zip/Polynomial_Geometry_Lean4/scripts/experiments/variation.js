/* Degree-nine polynomial from Appendix D.4. All powers use ascending order. */
(() => {
  'use strict';
  const c = (re, im = 0) => [re, im];
  const plus = (a, b) => c(a[0] + b[0], a[1] + b[1]);
  const minus = (a, b) => c(a[0] - b[0], a[1] - b[1]);
  const scale = (a, x) => c(a[0] * x, a[1] * x);
  const times = (a, b) => c(a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0]);
  const abs = a => Math.hypot(a[0], a[1]);
  const divide = (a,b) => {
    const d = b[0] * b[0] + b[1] * b[1];
    if (!(d > 1e-28)) throw Error('A local denominator was too small to resolve.');
    return c((a[0]*b[0] + a[1]*b[1])/d, (a[1]*b[0] - a[0]*b[1])/d);
  };
  const log = a => c(Math.log(abs(a)), Math.atan2(a[1],a[0]));
  const exp = a => scale(c(Math.cos(a[1]),Math.sin(a[1])),Math.exp(a[0]));
  const zeros = n => Array.from({length:n}, () => c(0));
  const w = c(-.48492562995803556, .029015572810901643);
  const a0 = c(-.9358772467648551, .30035603021366927);
  const v0 = c(-.5608733845313321, -.0689068948602794);
  const u0 = c(.751714121664,-.000215874841);
  const beta = [c(1),c(0,1),c(0,1),c(0,1),c(0,-1),c(0,-1),c(0,-1)];
  const tau = .6736697598780635, q0 = minus(w,a0), g0 = minus(v0,a0), D0 = abs(q0);
  const prodPoly = (p,q) => {
    const h=zeros(p.length+q.length-1);
    p.forEach((b,i)=>q.forEach((d,j)=>{h[i+j]=plus(h[i+j],times(b,d));}));
    return h;
  };
  const derivative = p=>p.slice(1).map((b,i)=>scale(b,i+1));
  const evaluate = (p,t)=>p.reduceRight((v,b)=>plus(times(t,v),b),c(0));
  // Divide by a monic polynomial; use the remainder even when the divisor has a multiple zero.
  const divMod = (p,d)=>{
    const h=p.slice(), n=d.length-1, quotient=zeros(p.length-n);
    for(let i=h.length-1;i>=n;i--) {
      const a=h[i]; quotient[i-n]=a;
      for(let j=0;j<n;j++) h[i-n+j]=minus(h[i-n+j],times(a,d[j]));
    }
    return {quotient,remainder:h.slice(0,n)};
  };
  const solve2=(a,b,y)=>{
    const det=minus(times(a[0],b[1]),times(a[1],b[0]));
    return [divide(minus(times(y[0],b[1]),times(y[1],b[0])),det),
            divide(minus(times(a[0],y[1]),times(a[1],y[0])),det)];
  };
  function rootNear(p,z) {
    const dp=derivative(p);
    for(let i=0;i<15;i++) {
      const step=divide(evaluate(p,z),evaluate(dp,z)); z=minus(z,step);
      if(abs(step)<4e-14) return z;
    }
    throw Error('The selected root continuation did not converge.');
  }
  function translatedCoeffs(p,center) {
    let out=[p[p.length-1]];
    for(let j=p.length-2;j>=0;j--) {
      out=prodPoly(out,[center,c(1)]); out[0]=plus(out[0],p[j]);
    }
    return out;
  }
  function reconstruct(z,boundary=beta,diagnostics=false) {
    // z contains the two labelled critical coordinates measured from w.
    const M=boundary.reduce((p,alpha)=>prodPoly(p,[minus(w,alpha),c(1)]),[c(1)]);
    const Q=[times(z[0],z[1]),scale(plus(z[0],z[1]),-1),c(1)];
    const columns=[0,1,2].map(i=>divMod(derivative([...zeros(i),...M]),Q).remainder);
    const [constant,linear]=solve2(columns[0],columns[1],columns[2].map(v=>scale(v,-1)));
    const A=[constant,linear,c(1)], poly=prodPoly(A,M), dp=derivative(poly);
    const ta=rootNear(A,minus(a0,w)), tv=rootNear(dp,minus(v0,w));
    const a=plus(ta,w), v=plus(tv,w);
    const lv=log(divide(minus(tv,ta),g0));
    const Z=z.map(t=>minus(log(divide(minus(t,ta),q0)),lv));
    const dist=[...z.map(t=>abs(minus(t,ta))),abs(minus(tv,ta))];
    const result={a,v,interiorCoefficients:A,remainderDet:minus(times(columns[0][0],columns[1][1]),times(columns[0][1],columns[1][0])),z:z.map(t=>plus(t,w)),Z,dist,lv,psi:lv[0]+tau*(Z[0][0]+Z[1][0])/2};
    if(diagnostics) {
      const otherA=plus(w,minus(scale(linear,-1),ta));
      const minActive=Math.min(...dist);
      const activeFactor=prodPoly(Q,[scale(tv,-1),c(1)]);
      const division=divMod(dp,activeFactor);
      const remainder=Math.max(...division.remainder.map(abs));
      // In the quotient the five inactive roots are counted inside three disjoint disks:
      // the indicated Taylor term must dominate the sum of the others on each circle.
      const disks=[[u0,1],[c(0,1),2],[c(0,-1),2]];
      const radius=.18;
      const margins=disks.map(([center,order])=>{
        const translated=translatedCoeffs(division.quotient,minus(center,w));
        const bounds=translated.map((coef,k)=>abs(coef)*radius**k);
        return bounds[order]-bounds.reduce((s,v,k)=>s+(k===order?0:v),0);
      });
      const inactiveGap=Math.min(...disks.map(([center])=>abs(minus(center,a))-radius))-Math.max(...dist);
      const activeRes=Math.max(...z.map(t=>abs(evaluate(dp,t))),abs(evaluate(dp,tv)));
      Object.assign(result,{distance: minActive, activeRes, remainder, inactiveMargin:Math.min(...margins),
        inactiveGap, insideMargin:1-Math.max(abs(a),abs(otherA)), boundaryMax:Math.max(...boundary.map(abs)),
        boundaryUnitError:Math.max(...boundary.map(b=>Math.abs(abs(b)-1)))});
    }
    return result;
  }
  function invert(target,boundary=beta,diagnostics=false) {
    let z=[c(0),c(0)];
    for(let it=0;it<12;it++) {
      const data=reconstruct(z,boundary), diff=data.Z.map((v,k)=>minus(v,target[k]));
      const err=Math.max(...diff.map(abs));
      if(err<2e-13) {
        const out=diagnostics?reconstruct(z,boundary,true):data;
        out.ratioResidual=err;out.iterations=it;return out;
      }
      // The branch is holomorphic; one real-direction derivative gives each complex Jacobian column.
      const h=1e-6;
      const cols=z.map((v,k)=>{
        const zp=z.slice(),zm=z.slice(); zp[k]=plus(v,c(h));zm[k]=minus(v,c(h));
        const fp=reconstruct(zp,boundary).Z,fm=reconstruct(zm,boundary).Z;
        return fp.map((f,j)=>scale(minus(f,fm[j]),.5/h));
      });
      const step=solve2(cols[0],cols[1],diff);
      z=z.map((v,j)=>minus(v,step[j]));
      if(Math.max(...z.map(abs))>.07) throw Error('The inverse ratio step left the local branch.');
    }
    throw Error('The inverse ratio solver did not resolve the local chart.');
  }
  function geometry(x,y,rho,theta,details=false) {
    const boundary=beta.map((b,k)=>times(b,exp(c(rho[k],theta[k]))));
    return invert(y.map((yi,k)=>c(x[k],yi)),boundary,details);
  }
  const no7 = () => Array(7).fill(0);
  const checkEq=(label,left,right,tol,detail)=>({label,left,right,tol,state:Math.abs(left-right)<=tol?'pass':'fail',detail});
  const checkPositive=(label,value,detail)=>({label,left:value,right:0,state:value>0?'pass':'fail',detail});
  const inconclusive=message=>({metrics:[],checks:[{label:'Local solver',state:'inconclusive',left:0,right:0,detail:message}],interpretation:'The local branch was not resolved. These parameters do not supply a numerical verdict.'});
  const ctrl=(key,label,min,max,step,value)=>({key,label,min,max,step,value});
  globalThis.PGDegreeNine={w,a0,v0,beta,tau,reconstruct,invert};
  function splitGeometry(block,h,free,details=false) {
    const y=[.16*free,.16*free], th=no7();
    th[0]=free;th[4]=-.12*free;th[5]=.06*free;th[6]=.06*free;
    // For the selected negative-i block keep the other split at +i, away from its symmetry.
    if(block===2) { th[4]=0;th[5]=0;th[6]=0;th[1]=-.12*free;th[2]=.06*free;th[3]=.06*free; }
    if(block===0) {y[0]+=h;y[1]-=h;}
    else {const k=block===1?1:4; th[k]+=h;th[k+1]-=h;}
    return geometry([0,0],y,no7(),th,details);
  }
  const conditionalGain=(label,gain,changed)=>changed
    ? checkPositive(label,gain,'Measured log-distance after the replacement minus the value before it.')
    : {label,left:gain,right:0,tol:1e-11,state:Math.abs(gain)<1e-11?'pass':'fail',detail:'No replacement was needed; equality is expected.'};
  const rootCheck=(label,models)=>{
    const margin=Math.min(...models.map(r=>Math.min(r.inactiveMargin,r.inactiveGap)));
    return checkPositive(label,margin,'After deflating the three active critical copies, Taylor-term dominance on disjoint radius-0.18 circles resolves the five inactive copies (1, 2, 2). The circles all lie beyond the active distances. Floating-point diagnostic.');
  };
  globalThis.PGExperiments['2.4']={
    question:'How do balancing and moving the boundary roots back to the circle change the nearest critical distance?',
    idea:'Use the degree-nine polynomial with boundary factor (z−1)(z²+1)³. Fix both the critical angle and the tangential splitting while tracing two steps: set the real log ratios to zero (stage 1), then undo an inward displacement of the root near 1 (stage 2). At each stage reconstruct a new monic quadratic and continue its marked root and simple critical point.',
    controls:[
      ctrl('imbalance','Real log-ratio imbalance × 10³',-2,2,.1,1),
      ctrl('inward','Inward log-radius × 10³',0,2,.1,1),
      ctrl('angle','Angular split at +i (mrad)',-5,5,.25,3)
    ],
    presets:[{label:'Both replacements',values:{imbalance:1,inward:1,angle:3}},
      {label:'Already balanced',values:{imbalance:0,inward:1.5,angle:2}},
      {label:'Reduced family',values:{imbalance:0,inward:0,angle:4}}],
    run({imbalance,inward,angle}) {
      try {
        const x=imbalance/1000, radius=inward/1000, t=angle/1000;
        const theta=no7();theta[1]=t;theta[2]=-t;
        const sample=(s,detail=false)=>{
          const rho=no7();rho[0]=-radius*Math.min(1,2-s);
          const amount=x*Math.max(0,1-s);
          return geometry([amount,-.35*amount],[.3*t,-.3*t],rho,theta,detail);
        };
        const [raw,balanced,reduced]=[0,1,2].map(s=>sample(s,true));
        const models=[raw,balanced,reduced], logD=r=>Math.log(Math.min(...r.dist)/D0);
        const expected=raw.psi+Math.min(0,x,-.35*x)-tau*(x-.35*x)/2;
        const balanceGain=logD(balanced)-logD(raw), radialGain=logD(reduced)-logD(balanced);
        const series=Array.from({length:17},(_,i)=>{
          const s=i/8;
          return [s,logD(s===0?raw:s===1?balanced:s===2?reduced:sample(s))];
        });
        return {metrics:[
          {label:'D₀',value:D0},{label:'Original D',value:raw.distance},
          {label:'Balanced D',value:balanced.distance},{label:'Reduced D',value:reduced.distance},
          {label:'Reduced Ψ',value:reduced.psi}],
          checks:[
            checkEq('Exact log-distance decomposition',logD(raw),expected,5e-11,'Left: minimum of the active critical distances. Right: Re H + min(0,x₁,x₂) − τ(x₁+x₂)/2.'),
            conditionalGain('Balancing gain',balanceGain,x!==0),
            conditionalGain('Radial replacement gain',radialGain,radius!==0),
            checkEq('Active distance spread on reduced slice',Math.max(...reduced.dist)-Math.min(...reduced.dist),0,5e-11,'All three labelled active distances should coincide.'),
            checkEq('Reduced log gain equals Ψ',logD(reduced),reduced.psi,5e-11,'D and Ψ are evaluated from their defining expressions.'),
            checkEq('Final boundary unit-circle residual',reduced.boundaryUnitError,0,3e-14,'Maximum of ||α| − 1| over all seven former boundary copies.'),
            rootCheck('Inactive roots separated',models),
            checkEq('Largest critical-equation / deflation residual',Math.max(...models.map(r=>Math.max(r.activeRes,r.remainder))),0,2e-10,'Evaluated on the derivative of the reconstructed degree-nine polynomial.'),
            checkEq('Largest inverse-chart residual',Math.max(...models.map(r=>r.ratioResidual)),0,5e-11,'Recompute both logarithmic ratios and compare to the two inputs.'),
            checkPositive('Interior-source margin',Math.min(...models.map(r=>r.insideMargin)),'One minus the larger interior root modulus, minimized over the three stages.')
          ],
          plot:{type:'lines',xLabel:'Replacement stage (1 = balanced, 2 = on circle)',yLabel:'log(D/D₀)',series:[{name:'Reconstructed polynomial',points:series}]},
          interpretation:'Stage 1 equalizes the active distances. Stage 2 restores the moved boundary copy to modulus one. A positive final Ψ means that this particular balanced polynomial increases the marked distance over D₀; the graph samples one local path.'};
      } catch(e){return inconclusive(e.message);}
    }
  };

  globalThis.PGExperiments['D.3']={
    question:'Which centered splittings can actually be removed from the reduced polynomial objective?',
    idea:'In the degree-nine fixture swap two critical copies or two boundary copies within the same group. The centered direction is (h,−h), with squared norm 2h². Compute Ψ from the inverse ratio chart, then compare opposite splittings. Estimate the block curvature at the base from two centered second differences, independently of the displayed gain at the selected free angle.',
    controls:[
      ctrl('block','Copy group (0 = critical, 1 = +i, 2 = −i)',0,2,1,0),
      ctrl('split','Centered split h (mrad)',0,5,.25,3),
      ctrl('free','Free angle at the root near 1 (mrad)',-3,3,.25,1)
    ],
    presets:[{label:'Critical copies',values:{block:0,split:3,free:1}},
      {label:'Boundary copies at +i',values:{block:1,split:3,free:1}},
      {label:'Boundary copies at −i',values:{block:2,split:3,free:1}},
      {label:'At the collision',values:{block:0,split:0,free:0}}],
    run({block,split,free}) {
      try {
        const b=Math.round(block), h=split/1000,q=free/1000;
        const sample=(u,g,detail=false)=>splitGeometry(b,u,g,detail);
        const base=sample(0,0).psi;
        const curvature=(d)=>(sample(d,0).psi+sample(-d,0).psi-2*base)/(2*d*d);
        const fine=curvature(.00035),coarse=curvature(.0007);
        const err=Math.abs(fine-coarse)+2e-6;
        const grouped=sample(0,q,true),plusH=sample(h,q,true),minusH=sample(-h,q,true);
        const gain=grouped.psi-plusH.psi, expected=-fine/2, squaredNorm=2*h*h;
        const gainCheck=fine+err < 0 && h!==0
          ? {label:'Gain vs. sampled quadratic benchmark',left:gain,right:(-fine/4)*squaredNorm,state:gain>=(-fine/4)*squaredNorm?'pass':'fail',detail:'Compare the observed gain to c·2h², using c = −λ/4. This numerical c is a local benchmark, not a certified uniform constant.'}
          : {label:'Negative-curvature elimination',left:gain,right:0,state:'info',detail:h===0?'Both copies remain at the grouped point: there is no strict gain to test.':fine-err>0?'Positive curvature: D.3 does not authorize eliminating this block.':'Finite differences do not resolve the sign.'};
        const chartSpan=Math.max(h,.0015);
        const actual=[],quadratic=[];
        for(let j=-6;j<=6;j++){
          const z=j*chartSpan/6;
          actual.push([1000*z,sample(z,q).psi-grouped.psi]);quadratic.push([1000*z,fine*z*z]);
        }
        return {metrics:[
          {label:'Base curvature λ',value:fine},{label:'Coarser curvature estimate',value:coarse},
          {label:'Measured gain Ψ(q,0) − Ψ(q,s)',value:gain},
          ...(h!==0?[{label:'Gain / ‖s‖²',value:gain/squaredNorm}]:[]),
          {label:'Quadratic limit at base: −λ/2',value:expected}],
          checks:[
            checkEq('Swapped copies preserve Ψ',plusH.psi,minusH.psi,3e-11,'The two root reconstructions are solved separately. A swap sends h to −h, fixing the free angle.'),
            checkEq('Marked root unchanged after swap',abs(minus(plusH.a,minusH.a)),0,2e-10,'Compare the complex roots obtained by separate continuations.'),
            checkEq('Curvature stable under step refinement',fine,coarse,2e-5,'Central second difference divided by ‖(1,−1)‖² = 2 at the grouped origin.'),
            gainCheck,rootCheck('Inactive roots separated',[grouped,plusH,minusH]),
            checkEq('Inverse-chart residual',Math.max(plusH.ratioResidual,minusH.ratioResidual,grouped.ratioResidual),0,5e-11,'Both labels must realize the requested balanced log-ratio coordinates.')
          ],
          plot:{type:'lines',xLabel:'Centered angle h (mrad)',yLabel:'Ψ(q,s) − Ψ(q,0)',series:[{name:'Reconstructed Ψ',points:actual},{name:'Base quadratic λh²',points:quadratic}]},
          interpretation:fine<0?'For this block the graph curves downward. Returning to zero splitting raises the objective while keeping the other coordinates fixed. The quadratic overlay uses curvature at the unperturbed origin.':'For this boundary group the graph curves upward. Relabelling still preserves Ψ, but the negative-curvature hypothesis fails. The measured gain can have the opposite sign.'};
      } catch(e){return inconclusive(e.message);}
    }
  };
})();
