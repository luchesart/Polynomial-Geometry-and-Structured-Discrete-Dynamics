(() => {
  // Complex pairs keep all determinant, adjoint and Gram computations local to these exhibits.
  const z = (x = 0, y = 0) => [x, y];
  const add = (u, v) => z(u[0] + v[0], u[1] + v[1]);
  const sub = (u, v) => z(u[0] - v[0], u[1] - v[1]);
  const mul = (u, v) => z(u[0] * v[0] - u[1] * v[1], u[0] * v[1] + u[1] * v[0]);
  const scale = (u, f) => z(f * u[0], f * u[1]);
  const conj = u => z(u[0], -u[1]);
  const abs = u => Math.hypot(...u);
  const div = (u, v) => scale(mul(u, conj(v)), 1 / (v[0] * v[0] + v[1] * v[1]));
  const pow = (u, n) => {
    let acc = z(1);
    for (let k = 0; k < n; ++k) acc = mul(acc, u);
    return acc;
  };
  const matrix = (r, c, f) => Array.from({length:r}, (_, i) => Array.from({length:c}, (_, j) => f(i, j)));
  const id = n => matrix(n, n, (i, j) => z(+(i === j)));
  const adj = A => matrix(A[0].length, A.length, (i, j) => conj(A[j][i]));
  const diag = xs => matrix(xs.length, xs.length, (i, j) => i === j ? xs[i] : z());
  const zip = (A, B, f) => matrix(A.length, A[0].length, (i, j) => f(A[i][j], B[i][j]));
  const product = (A, B) => matrix(A.length, B[0].length, (i, j) =>
    A[i].reduce((s, x, k) => add(s, mul(x, B[k][j])), z()));
  const norm = A => Math.sqrt(A.flat().reduce((r, u) => r + abs(u) ** 2, 0));
  const relative = (A, B) => norm(zip(A, B, sub)) / Math.max(1, norm(A), norm(B));
  const sandwich = (A, H) => product(product(adj(A), H), A);
  const choosePivot = (A, k) => {
    let p = k;
    for (let i = k + 1; i < A.length; ++i) if (abs(A[i][k]) > abs(A[p][k])) p = i;
    return p;
  };
  function det(A) {
    const a = A.map(row => row.slice());
    let total = z(1);
    for (let k = 0; k < a.length; ++k) {
      const p = choosePivot(a, k);
      if (abs(a[p][k]) < 1e-15) return z();
      if (p !== k) {
        [a[p], a[k]] = [a[k], a[p]];
        total = scale(total, -1);
      }
      total = mul(total, a[k][k]);
      for (let i = k + 1; i < a.length; ++i) {
        const f = div(a[i][k], a[k][k]);
        for (let j = k + 1; j < a.length; ++j) a[i][j] = sub(a[i][j], mul(f, a[k][j]));
      }
    }
    return total;
  }
  function inverse(A) {
    const n = A.length;
    const units = id(n);
    const a = A.map((row, i) => row.concat(units[i]));
    for (let k = 0; k < n; ++k) {
      const p = choosePivot(a, k);
      if (abs(a[p][k]) < 1e-14) throw new Error('The Gram matrix is numerically singular.');
      [a[p], a[k]] = [a[k], a[p]];
      const pivot = a[k][k];
      a[k] = a[k].map(x => div(x, pivot));
      for (let i = 0; i < n; ++i) {
        if (i === k) continue;
        const f = a[i][k];
        a[i] = a[i].map((x, j) => sub(x, mul(f, a[k][j])));
      }
    }
    return a.map(row => row.slice(n));
  }
  function charAt(A, t) {
    return det(matrix(A.length, A.length, (i, j) => sub(i === j ? t : z(), A[i][j])));
  }
  function compression(sources, weights) {
    const n = weights.reduce((a, b) => a + b, 0);
    // Columns 1,...,K-1 of this Householder matrix are orthonormal and orthogonal to sqrt(weights).
    const u = weights.map(v => Math.sqrt(v / n));
    u[0] += 1;
    const c = 2 / u.reduce((a, v) => a + v * v, 0);
    const Q = matrix(weights.length, weights.length - 1, (i, j) => z(+(i === j + 1) - c * u[i] * u[j + 1]));
    return sandwich(Q, diag(sources));
  }
  const regular = (b, r) => Array.from({length:b}, (_, j) =>
    z(r * Math.cos(2 * Math.PI * j / b), r * Math.sin(2 * Math.PI * j / b)));
  const metric = (label, value) => ({label, value});
  const test = (label, left, right, tol, detail) => ({label, left, right, tol, detail});
  const normDifference = (a, b) => abs(sub(a, b)) / Math.max(1, abs(a), abs(b));
  const fixed = x => Number(x.toPrecision(5)).toString();

  PGExperiments['A.1'] = {
    question: 'Which critical points survive when equal source roots are grouped?',
    idea: 'Place one unit of mass at zero and mass m at each vertex of a regular b-gon of radius R. Project the source matrix onto the directions perpendicular to the square roots of the masses. Compare its determinant with the independently formed weighted numerator G(z).',
    controls: [
      {key:'b', label:'Polygon vertices b', min:2, max:8, step:1, value:5},
      {key:'m', label:'Mass at each vertex m', min:0.5, max:4, step:0.25, value:2},
      {key:'R', label:'Source radius R', min:0.4, max:1, step:0.05, value:1}
    ],
    presets:[
      {label:'Double-root pentagon',values:{b:5,m:2,R:1}},
      {label:'Simple boundary roots',values:{b:5,m:1,R:1}},
      {label:'Fractional charges',values:{b:3,m:1.5,R:0.75}}
    ],
    run({b, m, R}) {
      b = Math.round(b);
      const polygon = regular(b, R);
      const sources = [z(), ...polygon];
      const weights = [1, ...polygon.map(() => m)];
      const n = 1 + b * m;
      const grouped = compression(sources, weights);
      const G = t => scale(sources.reduce((sum, _, j) => {
        const term = sources.reduce((acc, alpha, k) => k === j ? acc : mul(acc, sub(t, alpha)), z(1));
        return add(sum, scale(term, weights[j]));
      }, z()), 1 / n);
      const probes = [z(0.31, 0.47), z(-0.89, 0.24), z(1.07, -0.36)];
      const r = R / n ** (1 / b);
      const critical = regular(b, r);
      const integer = Number.isInteger(m);
      const checks = [
        test('Compression determinant versus weighted G', Math.max(...probes.map(t =>
          normDifference(charAt(grouped, t), G(t)))), 0, 1e-10, 'Maximum relative-scaled error at three off-source complex probes.'),
        test('Predicted critical nodes solve the matrix equation', Math.max(...critical.map(w =>
          abs(charAt(grouped, w)))), 0, 1e-10, 'Each of the b distinct nodes is tested in det(wI − A₀). They account for its full degree.')
      ];
      if (integer) {
        const copies = sources.flatMap((alpha, j) => Array.from({length:weights[j]}, () => alpha));
        const full = compression(copies, copies.map(() => 1));
        checks.push(test('Full-copy determinant versus grouped and inherited factors', Math.max(...probes.map(t => {
          const inherited = polygon.reduce((acc, alpha) => mul(acc, pow(sub(t, alpha), m-1)), z(1));
          return normDifference(charAt(full, t), mul(charAt(grouped, t), inherited));
        })), 0, 2e-10, 'A second compression is built directly from every individual copy. The extra scalar blocks are tested at the same three probes.'));
      }
      const modes = [{name:'Genuine critical points', points:critical}, {name:'Marked source',points:[sources[0]]},
        {name:integer && m > 1 ? 'Sources with inherited critical points' : 'Other sources',points:polygon}];
      const metrics=[metric('Genuine critical points',b), metric('Genuine radius R/(1+bm)^(1/b)',r),metric('Total mass n',n)];
      if (integer) metrics.push(metric('Inherited critical points (all copies)',b*(m-1)));
      return {metrics, checks, plot:{type:'points',xLabel:'Real part',yLabel:'Imaginary part',series:modes},
        interpretation: `The b genuine points lie on an inner polygon of radius ${fixed(r)}. `+
          (integer ? `For p(z) = z(zᵇ − Rᵇ)ᵐ, each outer vertex carries ${m-1} inherited critical copies. The full derivative space has dimension ${b*m}, and grouping retains ${b} directions.` :
          'Fractional masses still produce a stable compression. The grouped rational function has positive residues, while this choice of masses has no polynomial multiplicity interpretation.')};
    }
  };

  PGExperiments['B.1'] = {
    question:'How can one triple critical point encode three independent directions?',
    idea:'Start with source offsets ±1/√m and ±i, carrying masses 1, 1, m, m. Translate their common center to c and scale the offsets by 1−|c| to stay in the disk. The weighted numerator becomes (z−c)³. Form all three inverse-power columns of Y at c and test the Jordan chain against the diagonal source matrix.',
    controls:[
      {key:'m',label:'Mass at conjugate sources m',min:1,max:3,step:0.25,value:1.5},
      {key:'c',label:'Triple critical point c',min:-0.45,max:0.45,step:0.05,value:0},
      {key:'q',label:'Terms retained in the Stein sum',min:0,max:12,step:1,value:3}
    ],
    presets:[
      {label:'Article’s nilpotent fixture',values:{m:1.5,c:0,q:3}},
      {label:'Stop after two terms',values:{m:1.5,c:0,q:2}},
      {label:'Move the triple mode',values:{m:2,c:0.35,q:4}}
    ],
    run({m,c,q}) {
      q=Math.round(q);
      const r=1-Math.abs(c);
      const sources=[z(c+r/Math.sqrt(m)),z(c-r/Math.sqrt(m)),z(c,r),z(c,-r)];
      const weights=[1,1,m,m], n=2+2*m, b=weights.map(Math.sqrt);
      const A=diag(sources);
      const Y=matrix(4,3,(j,h)=>div(z(b[j]),pow(sub(z(c),sources[j]),h+1)));
      const H=product(adj(Y),Y);
      const J=matrix(3,3,(i,j)=>z(i===j?c:j===i+1?-1:0));
      const L=sandwich(Y,diag(sources.map(u=>z(1-abs(u)**2))));
      const sourceLoss=L.map((row,i)=>row.map((x,j)=>i===0 && j===0 ? add(x,z(n)) : x));
      const eRow=matrix(4,3,(j,h)=>z(h===0 ? b[j] : 0));
      const P=matrix(4,4,(i,j)=>z(+(i===j)-b[i]*b[j]/n));
      const hnorm=norm(H);
      const duplicated=matrix(4,3,(i)=>Y[i][0]);
      const minors=[1,2,3].map(k=>det(matrix(k,k,(i,j)=>H[i][j]))[0]);
      let T=id(3), partial=matrix(3,3,()=>z()), tailAt=0, discrepancy=0;
      const tailPoints=[], termPoints=[];
      for(let k=0;k<=12;++k){
        const term=sandwich(T,sourceLoss);
        const directTail=sandwich(T,H);
        const residual=zip(H,partial,sub);
        tailPoints.push([k,norm(residual)/hnorm]);
        termPoints.push([k,norm(term)/hnorm]);
        if(k===q){tailAt=norm(residual)/hnorm;discrepancy=norm(zip(residual,directTail,sub))/hnorm;}
        partial=zip(partial,term,add); T=product(T,J);
      }
      return {
        metrics:[metric('Genuine eigenvalue (multiplicity 3)',c),metric('det(Y*Y), full chain',minors[2]),
          metric('det(Y*Y), ordinary column copied 3 times',abs(det(product(adj(duplicated),duplicated)))),
          metric('Relative tail after '+q+' terms',tailAt)],
        checks:[
          test('All columns have zero source output',norm(product([b.map(x=>z(x))],Y))/(Math.sqrt(n)*norm(Y)),0,1e-11,'Tests b*Y = 0, including both generalized columns.'),
          test('Jordan chain AY = YJ − be*',relative(product(A,Y),zip(product(Y,J),eRow,sub)),0,1e-11,'The minus signs above the diagonal make successive columns depend on the preceding one.'),
          test('Gram projector gives the entire zero-output space',relative(product(product(Y,inverse(H)),adj(Y)),P),0,1e-10,'Independently compare Y(Y*Y)⁻¹Y* with I − bb*/n.'),
          test('Source losses give the Stein identity',relative(zip(H,sandwich(J,H),sub),sourceLoss),0,1e-11,'L is formed from the four source losses 1−|αⱼ|².'),
          test('Truncated series remainder equals (J*)ᑫ H Jᑫ',discrepancy,0,1e-10,'The finite sum and the remainder from the q-step propagation are computed independently.')
        ],
        plot:{type:'lines',xLabel:'Terms retained k',yLabel:'Frobenius norm / ‖H‖',series:[
          {name:'Remaining series tail',points:tailPoints},{name:'Next loss term',points:termPoints}]},
        interpretation:`The three leading Gram determinants are ${minors.map(fixed).join(', ')}. The positive values distinguish a full chain from three copies of its first vector. `+
          (Math.abs(c)<1e-13?'Here J³ = 0, so the three-term Stein sum already recovers the whole metric.':
          'Moving the triple mode off zero preserves the chain. More than three terms are needed to recover the metric to high accuracy.')
      };
    }
  };
})();
