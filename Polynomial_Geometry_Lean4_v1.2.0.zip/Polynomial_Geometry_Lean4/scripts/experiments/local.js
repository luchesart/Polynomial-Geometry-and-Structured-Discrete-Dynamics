/* Local proof mechanisms in Appendix D. The first two labs share the
   reconstructed degree-nine polynomial with the feasible-reduction lab. */
(() => {
  'use strict';
  const C=(a,b=0)=>[a,b];
  const add=(a,b)=>C(a[0]+b[0],a[1]+b[1]);
  const sub=(a,b)=>C(a[0]-b[0],a[1]-b[1]);
  const scale=(a,t)=>C(t*a[0],t*a[1]);
  const mul=(a,b)=>C(a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]);
  const mod=a=>Math.hypot(a[0],a[1]);
  const div=(a,b)=>{const d=b[0]**2+b[1]**2;
    if(d<1e-24) throw new Error('The selected local denominator is too small.');
    return C((a[0]*b[0]+a[1]*b[1])/d,(a[1]*b[0]-a[0]*b[1])/d);
  };
  const inv=z=>div(C(1),z), sq=z=>mul(z,z);
  const sum=terms=>terms.reduce(add,C(0));
  const ctrl=(key,label,min,max,step,value)=>({key,label,min,max,step,value});
  const point=(label,left,right,tol,detail)=>({label,left,right,tol,detail,state:Math.abs(left-right)<=tol?'pass':'fail'});
  const minCheck=(label,value,min,detail)=>({label,left:value,right:min,detail,state:value>min?'pass':'inconclusive'});
  const warning=error=>({metrics:[],checks:[{label:'Local reconstruction',left:0,right:0,state:'inconclusive',detail:error.message}],interpretation:'The local numerical branch could not be resolved at these settings.'});
  function sums(x,beta) {
    const terms=beta.map(b=>inv(sub(x,b)));
    return [sum(terms),sum(terms.map(sq)),sum(terms.map(z=>mul(z,sq(z))))];
  }
  function diagonal(x,beta) {
    const [s1,s2,s3]=sums(x,beta), k=add(sq(s1),s2);
    const kPrime=scale(add(mul(s1,s2),s3),-2);
    const B=div(scale(s1,-2),k), K=div(C(2),k);
    const dB=add(div(scale(s2,2),k),div(scale(mul(s1,kPrime),2),sq(k)));
    const dK=div(scale(kPrime,-2),sq(k));
    return {s1,s2,k,B,K,dB,dK};
  }
  const coeffErr=(A,B)=>Math.max(...A.map((coef,i)=>mod(sub(coef,B[i]))));
  function polynomialA(A,x){return add(add(sq(x),mul(A[1],x)),A[0]);}
  function complexLabel(x) {
    return x[0].toPrecision(5)+(x[1]<0?' − ':' + ')+Math.abs(x[1]).toPrecision(5)+'i';
  }
  PGExperiments['D.1']={
    question:'Can a double critical point be reconstructed without separating its two copies?',
    idea:'Use M(z)=(z−1)(z²+1)³ from the degree-nine example and prescribe the cluster w+h±δ. The two remainder coefficients of (AM)′ modulo the cluster polynomial determine the two unknown coefficients of the monic quadratic A. At δ=0, the normalized Taylor polynomial of 1/M gives an independent reconstruction.',
    controls:[ctrl('h','Common real displacement h',-.003,.003,.00025,0),ctrl('delta','Signed split δ',-.014,.014,.0005,0)],
    presets:[{label:'Double point',values:{h:0,delta:0}},{label:'Split the copies',values:{h:.001,delta:.01}},{label:'Swap labels',values:{h:.001,delta:-.01}}],
    run({h,delta}){try {
      const {w,beta,reconstruct}=globalThis.PGDegreeNine;
      const shifted=add(w,C(h)), t=diagonal(shifted,beta);
      const target=d=>[C(h+d),C(h-d)];
      const evalAt=d=>reconstruct(target(d),beta);
      const diag=evalAt(0), split=evalAt(delta), swap=evalAt(-delta);
      const A=split.interiorCoefficients;
      // Taylor formula at w+h, translated back to the variable z−w.
      const analyticA=[add(sub(C(h*h),scale(t.B,h)),t.K),sub(t.B,C(2*h)),C(1)];
      const M=beta.reduce((p,b)=>mul(p,sub(shifted,b)),C(1));
      const f2=div(t.k,scale(M,2));
      const pAtCenter=mul(polynomialA(diag.interiorCoefficients,C(h)),M);
      const normalized=mod(sub(mul(pAtCenter,f2),C(1)));
      const residual=target(delta).map(x=>{
        const l=sums(add(w,x),beta)[0];
        return mod(add(add(scale(x,2),A[1]),mul(polynomialA(A,x),l)));
      });
      const diagA=diag.interiorCoefficients, x=C(h), aPrime=add(scale(x,2),diagA[1]);
      // At a double point both p′/M and its derivative vanish.
      const doubleResidual=mod(sub(add(C(2),mul(aPrime,t.s1)),mul(polynomialA(diagA,x),t.s2)));
      const thirdMoment=sums(shifted,beta)[2];
      const leading=scale(add(sub(t.s1,mul(aPrime,t.s2)),mul(polynomialA(diagA,x),thirdMoment)),2);
      const ax=sub(split.a,w),vx=sub(split.v,w);
      const simpleResidual=mod(add(add(scale(vx,2),A[1]),mul(polynomialA(A,vx),sums(split.v,beta)[0])));
      const shifts=Array.from({length:23},(_,i)=>-.014+.028*i/22);
      return {
        metrics:[{label:'|det of the two remainder equations|',value:mod(split.remainderDet)},{label:'Coefficient change from the diagonal',value:coeffErr(A,diagA)},{label:'Prescribed cluster diameter',value:2*Math.abs(delta)}],
        checks:[point('Taylor coefficients vs the diagonal linear solve',coeffErr(analyticA,diagA),0,2e-11,'The two constructions are evaluated separately at w+h.'),
          point('Taylor normalization |p(w+h)f₂−1|',normalized,0,2e-11),
          point('Both specified copies are critical',Math.max(...residual),0,2e-11,'Evaluates A′+AM′/M at each requested label.'),
          point('Multiplicity test on the collision slice',doubleResidual,0,3e-10,'Independently differentiate A′+AM′/M at the double point.'),
          minCheck('Exactly double on the collision slice',mod(leading),1e-7,'The next derivative of A′+AM′/M stays nonzero.'),
          point('Continuation of a and v',Math.max(mod(polynomialA(A,ax)),simpleResidual),0,1e-9,'Check the recovered simple branches in A(a) and (p′/M)(v).'),
          point('Swapping the two labels preserves A',coeffErr(A,swap.interiorCoefficients),0,2e-11),
          minCheck('Distance of the remainder determinant from zero',mod(split.remainderDet),1e-9,'Finite-precision nondegeneracy for these two linear equations.')],
        plot:{type:'lines',xLabel:'Signed split δ',yLabel:'Maximum change in a coefficient of A',series:[{name:'Computed coefficient change',points:shifts.map(d=>[d,coeffErr(evalAt(d).interiorCoefficients,diagA)])}]},
        interpretation:delta===0?'At the collision the two labels coincide. Polynomial division still gives two independent equations and agrees with the Taylor inverse.':'Exchanging the split labels leaves the cluster factor and the reconstructed polynomial unchanged. The coefficient-change curve is symmetric about the collision.'};
    }catch(e){return warning(e);}}
  };
  // Differentiate A(z)=(z−w)^2+B(w)(z−w)+K(w) analytically, then
  // use simple-root implicit differentiation for a and for the zero v of p′.
  function analyticMultipliers(data) {
    const {w,a0:a,v0:v,beta}=data,t=diagonal(w,beta);
    const dz=z=>add(scale(sub(z,w),2),t.B);
    const val=z=>add(add(sq(sub(z,w)),mul(t.B,sub(z,w))),t.K);
    const dw=z=>add(sub(mul(sub(t.dB,C(2)),sub(z,w)),t.B),t.dK);
    const aw=div(scale(dw(a),-1),dz(a));
    const [s1,s2]=sums(v,beta);
    const gv=sub(add(C(2),mul(dz(v),s1)),mul(val(v),s2));
    const gw=add(sub(t.dB,C(2)),mul(dw(v),s1));
    const vw=div(scale(gw,-1),gv);
    const center=inv(sub(w,a));
    const common=sub(mul(sub(C(1),aw),center),div(sub(vw,aw),sub(v,a)));
    return {center,common};
  }
  PGExperiments['D.2']={
    question:'How does the log-ratio chart distinguish a common shift from a split?',
    idea:'At the double critical point of the degree-nine polynomial, perturb the two labels in the same direction or in opposite directions. A centered difference of the reconstructed logarithms measures each multiplier. The predictions come separately from 1/(w−a) and implicit differentiation of the diagonal Taylor polynomial.',
    controls:[ctrl('digits','Difference step h = 10⁻ᵏ (k)',3,7,1,5),ctrl('angle','Direction in the complex plane (degrees)',0,180,15,0)],
    presets:[{label:'Real shift',values:{digits:5,angle:0}},{label:'Imaginary shift',values:{digits:5,angle:90}},{label:'Small step',values:{digits:7,angle:45}}],
    run({digits,angle}){try {
      const data=globalThis.PGDegreeNine,{center,common}=analyticMultipliers(data);
      const unit=C(Math.cos(angle*Math.PI/180),Math.sin(angle*Math.PI/180)),h=10**(-digits);
      function difference(step,sign){
        const d=scale(unit,step), e=scale(d,sign);
        const pos=data.reconstruct([d,e],data.beta),neg=data.reconstruct([scale(d,-1),scale(e,-1)],data.beta);
        return pos.Z.map((z,i)=>div(sub(z,neg.Z[i]),scale(d,2)));
      }
      const error=(step,sign,prediction)=>{
        const measured=difference(step,sign);
        return Math.max(mod(sub(measured[0],prediction)),mod(sub(measured[1],scale(prediction,sign))));
      };
      const cError=error(h,-1,center), dError=error(h,1,common);
      const measuredC=difference(h,-1)[0],measuredD=difference(h,1)[0];
      const ex1=scale(unit,h),ex2=scale(unit,-.23*h), forward=data.reconstruct([ex1,ex2],data.beta);
      const backward=data.invert(forward.Z,data.beta);
      const roundtrip=Math.max(mod(sub(forward.z[0],backward.z[0])),mod(sub(forward.z[1],backward.z[1])));
      const ks=[3,3.5,4,4.5,5,5.5,6,6.5,7];
      // Centered differences have an O(h²) truncation term; subtracting
      // nearby logarithms adds rounding error roughly proportional to 1/h.
      const budget=1200*h*h+2e-13/h;
      return {
        metrics:[{label:'Measured centered multiplier',value:complexLabel(measuredC)},{label:'Measured diagonal multiplier',value:complexLabel(measuredD)},{label:'Jacobian determinant magnitude |Z′d/q₀|',value:mod(mul(center,common))}],
        checks:[point('Centered multiplier error',cError,0,budget,'Both log ratios are differentiated along the signed split.'),
          point('Diagonal multiplier error',dError,0,budget,'Both log ratios are differentiated along the common motion.'),
          minCheck('Smaller multiplier magnitude',Math.min(mod(center),mod(common)),1e-9,'The two eigenspaces span the copy coordinates.'),
          point('Inverse chart recovers both prescribed labels',roundtrip,0,5e-11,'A nonsymmetric test perturbation is forwarded then inverted by Newton iteration.')],
        plot:{type:'lines',xLabel:'Difference exponent k, h = 10⁻ᵏ',yLabel:'log₁₀ absolute multiplier error',series:[
          {name:'Centered direction',points:ks.map(k=>[k,Math.log10(Math.max(1e-16,error(10**-k,-1,center)))])},
          {name:'Common direction',points:ks.map(k=>[k,Math.log10(Math.max(1e-16,error(10**-k,1,common)))])}]},
        interpretation:'The centered motion leaves the reconstructed root and simple critical point unchanged to first order. A common shift moves both branches and has a different multiplier. As h decreases, subtraction of nearby floating-point values eventually limits accuracy.'};
    }catch(e){return warning(e);}}
  };
  PGExperiments['D.4']={
    question:'Can a frozen negative quartic acquire an improving direction?',
    idea:'Use the scalar analytic model F(x,s)=b x³−x⁴+γ x²s−P s²/2, with P>0. For each x, fit the s-parabola from three evaluations and follow its maximum. Compare the measured response and the reduced quartic against the fourth-order compensation formula. This is an analytic test model for the lemma.',
    controls:[ctrl('gamma','Coupling γ',-2,2,.1,1.8),ctrl('P','Transverse stiffness P',.5,2.5,.1,1),ctrl('b','Cubic coefficient b',-.4,.4,.05,0)],
    presets:[{label:'Negative quartic',values:{gamma:1,P:1,b:0}},{label:'Positive compensated quartic',values:{gamma:1.8,P:1,b:0}},{label:'Flat response',values:{gamma:2,P:2,b:0}},{label:'Cubic sign change',values:{gamma:1,P:1,b:.2}}],
    run({gamma,P,b}){
      const F=(x,s)=>b*x**3-x**4+gamma*x*x*s-P*s*s/2;
      function maximize(x){
        const k=.25,f0=F(x,0),fp=F(x,k),fm=F(x,-k);
        const linear=(fp-fm)/(2*k), curvature=(fp-2*f0+fm)/(k*k);
        const s=-linear/curvature;
        return {s,value:F(x,s)};
      }
      const compensated=-1+gamma*gamma/(2*P);
      const x=.24,q=maximize(x),mirror=maximize(-x);
      const measuredQuartic=(q.value+mirror.value)/(2*x**4);
      const measuredCubic=(q.value-mirror.value)/(2*x**3);
      const offset=.065;
      const gain=q.value-F(x,q.s+offset);
      const xs=Array.from({length:33},(_,i)=>(i-16)/40);
      const interpretation=Math.abs(b)>1e-12?'The cubic changes sign across the origin. One side improves at arbitrarily small scales, even if the compensated quartic is negative.':
        compensated>1e-12?'The frozen slice decreases, but the fitted optimizing branch has positive quartic growth. Moving s exposes an improving direction.':
        compensated< -1e-12?'The reduced quartic is negative. In this exact model both the reduced curve and the full objective have a strict local maximum at zero.':
        'The compensation cancels the original quartic. In this exact model the optimizing branch is flat, and moving away from it costs quadratic energy. For a general analytic function higher orders would decide the remaining behavior.';
      return {
        metrics:[{label:'Frozen quartic coefficient',value:-1},{label:'Compensated quartic coefficient',value:compensated},{label:'Measured maximizing s at x=0.24',value:q.s}],
        checks:[point('Response from parabola fit vs γx²/P',q.s,gamma*x*x/P,2e-12),
          point('Loss away from the maximizing branch',gain,P*offset*offset/2,2e-12,'Move s by 0.065 and directly evaluate both objective values.'),
          point('Odd part of the numerical optimum vs cubic b',measuredCubic,b,2e-12),
          point('Even part vs compensated quartic',measuredQuartic,compensated,2e-12,'The factor ⅛ times (2γ)²/P adds γ²/(2P) to the frozen coefficient.')],
        plot:{type:'lines',xLabel:'Kernel coordinate x',yLabel:'Objective value',series:[{name:'Frozen F(x,0)',points:xs.map(v=>[v,F(v,0)])},{name:'Optimized G(x)',points:xs.map(v=>[v,maximize(v).value])}]},interpretation};
    }
  };
})();
