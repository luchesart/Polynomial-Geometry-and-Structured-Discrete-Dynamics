/* Interface for the offline proof experiments. All values are recomputed locally. */
(() => {
  'use strict';
  if (typeof window === 'undefined' || !window.addEventListener) return;
  const models = globalThis.PGExperiments;
  const claims = new Map(D.claims.map(claim => [claim.id, claim]));
  const ids = D.claims.map(claim => claim.id).filter(id => models[id]);
  const saved = new Map(), pinned = new Map();
  const palette = ['#126c6a','#a95332','#365d9b','#78528a','#687d2d','#53636b'];
  const names = {pass:'Passed', fail:'Mismatch', inconclusive:'Inconclusive', info:'Observation'};
  let current = ids.includes('2.3') ? '2.3' : ids[0], output, suite = [], busy = false;
  const box = id => document.getElementById(id);
  const fn = value => typeof value === 'number' && Number.isFinite(value);
  const defaults = id => Object.fromEntries(models[id].controls.map(c => [c.key,c.value]));
  const values = id => saved.get(id) || defaults(id);
  function fmt(n) {
    if (n == null || (typeof n === 'number' && !Number.isFinite(n))) return '—';
    if (typeof n !== 'number') return String(n);
    if (n === 0) return '0';
    if (Math.abs(n) < .0001 || Math.abs(n) >= 1000000) return n.toExponential(3);
    return String(Number(n.toPrecision(7)));
  }
  function state(check) {
    if (Object.hasOwn(names, check.state)) return check.state;
    if (!fn(check.left) || !fn(check.right) || !fn(check.tol) || check.tol<0) return 'inconclusive';
    return Math.abs(check.left-check.right)<=check.tol ? 'pass':'fail';
  }
  function evaluate(id, params = defaults(id)) {
    const model = models[id];
    try {
      const raw = model.run({...defaults(id),...params});
      if (!raw || !Array.isArray(raw.checks) || !raw.checks.length) throw Error('No checks were returned.');
      const checks = raw.checks.map(check=>({...check,state:state(check)}));
      return {...raw,metrics:raw.metrics||[],checks};
    } catch(error) {
      return {metrics:[],checks:[{label:'Numerical evaluation',state:'inconclusive',detail:String(error.message||error)}],
        interpretation:'The calculation did not resolve this case with the selected inputs.'};
    }
  }
  function tally(checks) {
    const count = {pass:0,fail:0,inconclusive:0,info:0};
    checks.forEach(c => count[c.state]++);
    return count;
  }
  const overall = count => count.fail ? 'fail' : count.inconclusive ? 'inconclusive' : count.pass ? 'pass' : 'info';
  function countText(count) {
    return [[count.pass,'passed'],[count.fail,'mismatch'],[count.inconclusive,'inconclusive'],[count.info,'observation']]
      .filter(([n]) => n).map(([n,word])=>n+' '+word+(n>1 && word==='observation'?'s':n>1 && word==='mismatch'?'es':'')).join(' · ');
  }
  const badge = s => '<span class="lab-result '+s+'">'+names[s]+'</span>';
  function plotHTML(spec) {
    if (!spec || !Array.isArray(spec.series)) return '';
    const series = spec.series.map((s,i)=>({...s,points:s.points.filter(p=>Array.isArray(p)&&fn(p[0])&&fn(p[1])),color:palette[i%palette.length]})).filter(s=>s.points.length);
    if (!series.length) return '';
    const w=690,h=285,l=76,r=25,t=20,b=57, innerW=w-l-r,innerH=h-t-b;
    const xs=[],ys=[];
    for (const s of series) for(const [x,y] of s.points) { xs.push(x);ys.push(y); }
    if(spec.type==='bars') ys.push(0);
    function limit(nums) {
      let lo=Math.min(...nums),hi=Math.max(...nums);
      if(lo===hi) {const pad=Math.abs(lo)*.12||1;return [lo-pad,hi+pad];}
      const pad=(hi-lo)*.075;return [lo-pad,hi+pad];
    }
    let [xmin,xmax]=limit(xs),[ymin,ymax]=limit(ys);
    if(spec.type==='bars' && ys.every(y=>y>=0)) ymin=0;
    if(spec.type==='bars'){
      const unique=Array.from(new Set(xs)).sort((a,b)=>a-b);
      const half=(unique.length>1?Math.min(...unique.slice(1).map((x,i)=>x-unique[i])):1)*.45;
      xmin=Math.min(xmin,unique[0]-half);xmax=Math.max(xmax,unique.at(-1)+half);
    }
    if(spec.aspect==='equal'||(/real/i.test(spec.xLabel)&&/imaginary/i.test(spec.yLabel))){
      const unit=Math.max((xmax-xmin)/innerW,(ymax-ymin)/innerH);
      const cx=(xmax+xmin)/2,cy=(ymax+ymin)/2;
      xmin=cx-innerW*unit/2;xmax=cx+innerW*unit/2;ymin=cy-innerH*unit/2;ymax=cy+innerH*unit/2;
    }
    const X=x=>l+innerW*(x-xmin)/(xmax-xmin),Y=y=>t+innerH*(1-(y-ymin)/(ymax-ymin));
    const niceTicks=(min,max,target)=>{
      const raw=(max-min)/target,unit=10**Math.floor(Math.log10(raw));
      const step=([1,2,2.5,5,10].find(scale=>scale*unit>=raw-1e-12*raw)||10)*unit;
      const result=[];
      for(let k=Math.ceil(min/step-1e-10);k<=Math.floor(max/step+1e-10)&&result.length<16;k++)result.push(Number((k*step).toPrecision(8)));
      return result;
    };
    const compact=n=>n!==0 && (Math.abs(n)<.001||Math.abs(n)>99999) ? n.toExponential(1).replace('.0e','e').replace('e+','e') : String(Number(n.toPrecision(5)));
    let svg='<svg class="lab-plot-svg" role="img" aria-label="'+esc(spec.yLabel||'Value')+' plotted against '+esc(spec.xLabel||'Input')+'" viewBox="0 0 '+w+' '+h+'"><title>'+esc((spec.yLabel||'Value')+' against '+(spec.xLabel||'Input'))+'</title>';
    const line=(x1,y1,x2,y2)=>'<line class="grid" x1="'+x1+'" y1="'+y1+'" x2="'+x2+'" y2="'+y2+'"/>';
    for(const x of niceTicks(xmin,xmax,6)){const p=X(x);svg+=line(p,t,p,h-b)+'<text x="'+p+'" y="'+(h-b+18)+'" text-anchor="middle">'+esc(compact(x))+'</text>';}
    for(const y of niceTicks(ymin,ymax,4)){const p=Y(y);svg+=line(l,p,w-r,p)+'<text x="'+(l-7)+'" y="'+(p+4)+'" text-anchor="end">'+esc(compact(y))+'</text>';}
    svg+='<path d="M '+l+' '+t+' V '+(h-b)+' H '+(w-r)+'" fill="none" stroke="#8da6ad"/>';
    const labels=(x,y,s)=>esc(s.name+' · '+fmt(x)+', '+fmt(y));
    series.forEach((s,i)=>{
      if(spec.type==='bars') {
        const unique=Array.from(new Set(xs)).sort((a,b)=>a-b);
        const spacing=unique.length>1 ? Math.min(...unique.slice(1).map((x,j)=>X(x)-X(unique[j]))) : innerW;
        const groupWidth=Math.min(spacing*.72,90),bw=groupWidth/series.length;
        for(const [x,y] of s.points) svg+='<rect x="'+(X(x)-groupWidth/2+i*bw)+'" y="'+Math.min(Y(0),Y(y))+'" width="'+Math.max(.6,bw-1)+'" height="'+Math.max(1,Math.abs(Y(y)-Y(0)))+'" fill="'+s.color+'"><title>'+labels(x,y,s)+'</title></rect>';
      } else {
        if(spec.type!=='points' && s.points.length>1) svg+='<polyline points="'+s.points.map(([x,y])=>X(x).toFixed(2)+','+Y(y).toFixed(2)).join(' ')+'" fill="none" stroke="'+s.color+'" stroke-width="2.4" '+(i%2?'stroke-dasharray="6 3"':'')+'/>';
        if(spec.type==='points'||s.points.length<=18) for(const [x,y] of s.points){
          const radius=s.points.length===1?4.5:3;
          svg+='<circle cx="'+X(x)+'" cy="'+Y(y)+'" r="'+radius+'" fill="'+(i%2?'white':s.color)+'" stroke="'+s.color+'" stroke-width="1.8"><title>'+labels(x,y,s)+'</title></circle>';
        }
      }
    });
    svg+='<text class="axis-title" x="'+(l+innerW/2)+'" y="'+(h-10)+'" text-anchor="middle">'+esc(spec.xLabel||'Input')+'</text><text class="axis-title" transform="translate(16,'+(t+innerH/2)+') rotate(-90)" text-anchor="middle">'+esc(spec.yLabel||'Value')+'</text></svg>';
    return '<figure class="lab-figure">'+svg+'<figcaption class="lab-legend">'+series.map(s=>'<span><i style="background:'+s.color+'"></i>'+esc(s.name)+'</span>').join('')+'</figcaption></figure>';
  }
  function paramsText(id,data) {return models[id].controls.map(c=>c.label+' = '+fmt(data[c.key])).join(' · ');}
  function renderComparison(){
    const pin=pinned.get(current), section=box('lab-comparison');
    if(!pin){section.innerHTML='';return;}
    const before=new Map(pin.metrics.map(m=>[m.label,m.value]));
    const now=new Map(output.metrics.map(m=>[m.label,m.value]));
    const labels=Array.from(new Set([...before.keys(),...now.keys()]));
    section.innerHTML='<div class="lab-subtitle"><h3>Comparison</h3><button type="button" class="lab-text-button" id="lab-clear-pin">Clear comparison</button></div><p class="lab-pin-inputs">Pinned inputs · '+esc(paramsText(current,pin.params))+'</p><div class="lab-table-wrap"><table class="lab-table"><thead><tr><th>Measure</th><th>Pinned</th><th>Current</th></tr></thead><tbody>'+labels.map(label=>'<tr><th scope="row">'+esc(label)+'</th><td class="lab-numeric" data-label="Pinned">'+esc(fmt(before.get(label)))+'</td><td class="lab-numeric" data-label="Current">'+esc(fmt(now.get(label)))+'</td></tr>').join('')+'</tbody></table></div>';
    box('lab-clear-pin').onclick=()=>{pinned.delete(current);renderComparison();};
  }
  function renderOutput(){
    const params=values(current);output=evaluate(current,params);
    box('lab-metrics').innerHTML=output.metrics.map(m=>'<div class="lab-metric"><span>'+esc(m.label)+'</span><strong>'+esc(fmt(m.value))+'</strong></div>').join('');
    box('lab-plot').innerHTML=plotHTML(output.plot);
    box('lab-interpretation').textContent=output.interpretation||'';
    box('lab-status').textContent=countText(tally(output.checks));
    box('lab-check-table').innerHTML='<div class="lab-table-wrap"><table class="lab-table"><thead><tr><th>Argument</th><th>Measured</th><th>Reference</th><th>Tolerance</th><th>Outcome</th></tr></thead><tbody>'+output.checks.map(c=>'<tr data-check-state="'+c.state+'"><th scope="row">'+esc(c.label)+(c.detail?'<span class="lab-check-detail">'+esc(c.detail)+'</span>':'')+'</th><td class="lab-numeric" data-label="Measured">'+esc(fmt(c.left))+'</td><td class="lab-numeric" data-label="Reference">'+esc(fmt(c.right))+'</td><td class="lab-numeric" data-label="Tolerance">'+esc(fmt(c.tol))+'</td><td>'+badge(c.state)+'</td></tr>').join('')+'</tbody></table></div>';
    for(const b of box('lab-presets').querySelectorAll('[data-lab-preset]')){
      const preset=models[current].presets[Number(b.dataset.labPreset)];
      const expected={...defaults(current),...preset.values};
      b.setAttribute('aria-pressed',String(Object.keys(expected).every(k=>Math.abs(params[k]-expected[k])<=1e-12*Math.max(1,Math.abs(expected[k])))));
    }
    renderComparison();
  }
  function setParameters(params){
    saved.set(current,{...defaults(current),...params});
    for(const input of box('lab-controls').querySelectorAll('[data-lab-control]'))input.value=values(current)[input.dataset.labControl];
    renderOutput();
  }
  function show(id){
    if(!models[id])return;
    current=id;const model=models[id],claim=claims.get(id),params=values(id);
    tab('experiments');box('lab-select').value=id;
    box('lab-article').dataset.id=id;box('lab-question').textContent=model.question;
    box('lab-idea').textContent=model.idea;
    box('lab-proof-link').textContent='Read '+id+' in the proof map ↗';
    box('lab-proof-link').setAttribute('href','#claim/'+encodeURIComponent(id));
    box('lab-select').setAttribute('aria-label','Choose an experiment. Selected '+id+' '+claim.title);
    box('lab-controls').innerHTML=model.controls.map((c,i)=>{
      const key=esc(c.key),attrs=' min="'+c.min+'" max="'+c.max+'" step="'+c.step+'" value="'+params[c.key]+'" data-lab-control="'+key+'"';
      return '<div class="lab-control"><label id="lab-param-label-'+i+'" for="lab-num-'+i+'">'+esc(c.label)+'</label><div class="lab-control-set"><input type="range" aria-labelledby="lab-param-label-'+i+'"'+attrs+'><input type="number" id="lab-num-'+i+'"'+attrs+'></div><div class="lab-range">'+esc(fmt(c.min))+' to '+esc(fmt(c.max))+'</div></div>';
    }).join('');
    box('lab-controls').querySelectorAll('input').forEach(input=>{
      const isRange=input.type==='range';
      const act=()=>{
        const n=input.valueAsNumber;
        if(!fn(n)||!input.validity.valid){if(!isRange)input.value=values(current)[input.dataset.labControl];return;}
        const key=input.dataset.labControl;
        saved.set(current,{...values(current),[key]:n});
        for(const other of box('lab-controls').querySelectorAll('input'))if(other!==input && other.dataset.labControl===key)other.value=n;
        renderOutput();
      };
      if(isRange) input.oninput=act;
      else input.onchange=act;
    });
    box('lab-presets').innerHTML=(model.presets||[]).length?'<div class="lab-preset-title">Examples</div><div class="lab-presets">'+model.presets.map((p,i)=>'<button type="button" class="lab-preset" data-lab-preset="'+i+'" aria-pressed="false">'+esc(p.label)+'</button>').join('')+'</div>':'';
    box('lab-presets').querySelectorAll('[data-lab-preset]').forEach(b=>b.onclick=()=>setParameters(model.presets[Number(b.dataset.labPreset)].values));
    box('lab-prev').disabled=id===ids[0];box('lab-next').disabled=id===ids.at(-1);
    renderOutput();
  }
  function suiteState(open){
    box('lab-suite').classList.toggle('hide',!open);
    box('lab-suite-toggle').setAttribute('aria-expanded',String(open));
  }
  function suiteTable(){
    const totals=tally(suite.flatMap(row=>row.result.checks));
    box('lab-suite-progress').textContent=suite.length+' cases · '+countText(totals);
    box('lab-suite-list').innerHTML='<table class="lab-table"><thead><tr><th>Statement and inputs</th><th>Checks</th><th>Outcome</th></tr></thead><tbody>'+suite.map((row,i)=>{
      const count=tally(row.result.checks),s=overall(count);
      return '<tr data-suite-state="'+s+'"><th scope="row"><button type="button" class="lp-case" data-lab-case="'+i+'">'+esc(row.id+' · '+row.label)+'</button></th><td>'+esc(countText(count))+'</td><td>'+badge(s)+'</td></tr>';
    }).join('')+'</tbody></table>';
    box('lab-suite-list').querySelectorAll('[data-lab-case]').forEach(b=>b.onclick=()=>{
      const item=suite[Number(b.dataset.labCase)];
      saved.set(item.id,{...item.params});suiteState(false);route.open('experiment',item.id);
    });
  }
  async function runAll(mode='defaults'){
    if(busy)return suite;
    suiteState(true);busy=true;suite=[];box('lab-suite-list').innerHTML='';
    box('lab-suite-run').disabled=true;box('lab-suite-mode').disabled=true;box('lab-suite-mode').value=mode;
    try{
      const cases=[];
      for(const id of ids){
        cases.push({id,label:'Default inputs',params:defaults(id)});
        if(mode==='presets')for(const p of models[id].presets||[])cases.push({id,label:p.label,params:{...defaults(id),...p.values}});
      }
      for(const item of cases){
        box('lab-suite-progress').textContent='Testing '+item.id+' · '+(suite.length+1)+' of '+cases.length;
        await new Promise(resolve=>setTimeout(resolve,0));
        suite.push({...item,result:evaluate(item.id,item.params)});
      }
      suiteTable();return suite;
    }finally{busy=false;box('lab-suite-run').disabled=false;box('lab-suite-mode').disabled=false;}
  }
  const route={
    applying:false,last:null,
    open(view,id){const hash='#'+view+(id?'/'+encodeURIComponent(id):'');
      if(window.location.hash!==hash)window.location.hash=hash;this.apply(true);},
    nav(view){if(view==='experiments')this.open('experiment',current);else if(view==='claims')this.open('claim',selectedClaim);else this.open(view);},
    apply(force=false){
      const hash=window.location.hash;if(!force&&this.last===hash)return;this.last=hash;
      let decoded;try{decoded=decodeURIComponent(hash.slice(1));}catch{decoded='';}
      const sep=decoded.indexOf('/'), view=sep<0?decoded:decoded.slice(0,sep),id=sep<0?'':decoded.slice(sep+1);
      this.applying=true;
      try{
        if(view==='experiment'||view==='experiments')show(models[id]?id:current);
        else if(view==='declaration'&&id)showDecl(id);
        else if(view==='module'&&D.sources[id]){box('moduleSelect').value=id;box('declSearch').value='';declList();tab('catalog');}
        else if(['identities','modules','catalog','audit'].includes(view))tab(view);
        else{tab('claims');showClaim(claims.has(id)?id:(view?selectedClaim:D.claims[0].id));}
      }finally{this.applying=false;}
    }
  };
  window.PGRoute=route;
  window.PGNumericalLab={
    open:id=>route.open('experiment',id),evaluate,runAll,
    results:()=>suite,parameters:()=>({...values(current)}),
    currentId:()=>current,currentResult:()=>output,
    setParameters,defaults
  };
  box('lab-select').innerHTML=ids.map(id=>'<option value="'+esc(id)+'">'+esc(id+' · '+claims.get(id).title)+'</option>').join('');
  box('lab-select').onchange=e=>route.open('experiment',e.target.value);
  box('lab-prev').onclick=()=>route.open('experiment',ids[ids.indexOf(current)-1]);
  box('lab-next').onclick=()=>route.open('experiment',ids[ids.indexOf(current)+1]);
  box('lab-reset').onclick=()=>setParameters(defaults(current));
  box('lab-suite-toggle').onclick=()=>suiteState(box('lab-suite-toggle').getAttribute('aria-expanded')!=='true');
  box('lab-suite-run').onclick=()=>runAll(box('lab-suite-mode').value);
  box('lab-pin').onclick=()=>{pinned.set(current,{params:{...values(current)},metrics:output.metrics.map(m=>({...m}))});renderComparison();};
  document.addEventListener('click',event=>{
    if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
    const link=event.target.closest?.('a[data-experiment],#lab-proof-link');
    if(!link)return;
    event.preventDefault();
    if(link.id==='lab-proof-link')route.open('claim',current);
    else route.open('experiment',link.dataset.experiment);
  });
  window.addEventListener('hashchange',()=>route.apply());
  if(window.location.hash)route.apply();
})();
