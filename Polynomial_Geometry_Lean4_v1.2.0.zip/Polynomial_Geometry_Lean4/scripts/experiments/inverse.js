// Real two-critical-point sections of the inverse realization and contour theorems.
(() => {
  const fmt = x => Math.abs(x) > 0 && Math.abs(x) < 1e-4
    ? x.toExponential(3) : Number(x.toPrecision(7)).toString();
  const metric = (label, value) => ({label, value});
  const preset = (label, values) => ({label, values});
  const control = (key, label, min, max, step, value) => ({key, label, min, max, step, value});
  const absoluteCheck = (label, residual, tol, detail) => ({
    label, left: residual, right: 0, tol, detail, state: Math.abs(residual) <= tol ? 'pass' : 'fail'
  });
  const condition = (label, left, right, test, detail, miss = 'fail') => ({
    label, left, right, state: test ? 'pass' : miss, detail
  });
  const transpose = A => A[0].map((_, j) => A.map(row => row[j]));
  const dot = (x,y) => x.reduce((sum,v,i) => sum + v*y[i],0);
  const multiply = (A,B) => {
    const columns = transpose(B);
    return A.map(row => columns.map(col => dot(row,col)));
  };
  const diff = (A,B) => A.map((row,i) => row.map((x,j) => x-B[i][j]));
  const frob = A => Math.hypot(...A.flat());
  const id3 = [[1,0,0],[0,1,0],[0,0,1]];
  const inverse2 = A => {
    const [[a,b],[c,d]] = A;
    const det = a*d-b*c;
    return [[d/det,-b/det],[-c/det,a/det]];
  };
  // Eigenvalues of a real symmetric 3x3 matrix by Jacobi rotations.
  function symmetricEigen(A) {
    const C = A.map(row => row.slice());
    for (let iter = 0; iter < 36; iter++) {
      let p = 0, q = 1;
      for (const [i,j] of [[0,2],[1,2]]) {
        if (Math.abs(C[i][j]) > Math.abs(C[p][q])) [p,q] = [i,j];
      }
      if (Math.abs(C[p][q]) < 1e-15 * (1 + frob(C))) break;
      const t = 0.5 * Math.atan2(2*C[p][q], C[q][q]-C[p][p]);
      const c = Math.cos(t), s = Math.sin(t), a = C[p][p], b = C[p][q], d = C[q][q];
      C[p][p] = c*c*a - 2*c*s*b + s*s*d;
      C[q][q] = s*s*a + 2*c*s*b + c*c*d;
      C[p][q] = C[q][p] = 0;
      for (let k=0;k<3;k++) if (k!==p && k!==q) {
        const x=C[k][p], y=C[k][q];
        C[k][p] = C[p][k] = c*x-s*y;
        C[k][q] = C[q][k] = s*x+c*y;
      }
    }
    return [C[0][0],C[1][1],C[2][2]].sort((a,b)=>a-b);
  }
  function matrixTest(radius, tilt, scale) {
    // From p=z(z-r)^2(z+4r/5). Tilt is a rank-one metric change orthogonal to v.
    const w=[.4*radius,-.5*radius], v=w.map(x=>-1/x);
    const u=[2/Math.sqrt(10.25),2.5/Math.sqrt(10.25)];
    const f0=[.08,.0625];
    const F=w.map((_,i)=>w.map((__,j)=>radius**2*(
      (i===j ? scale*f0[i] : 0) + tilt*.01*u[i]*u[j])));
    const t=F.map(row=>dot(row,v)), H=inverse2(F);
    const normalizer=dot(v,t), gamma=-4*(t[0]+t[1]);
    const M=[[gamma,-1,-1],[4*w[0]*t[0],w[0],0],[4*w[1]*t[1],0,w[1]]];
    const l=Math.sqrt(H[0][0]), h=H[0][1]/l, k=Math.sqrt(H[1][1]-h*h);
    const R=[[2,0,0],[0,l,h],[0,0,k]], Ri=[[.5,0,0],[0,1/l,-h/(l*k)],[0,0,1/k]];
    const T=multiply(multiply(R,M),Ri), TT=multiply(transpose(T),T);
    const normality=frob(diff(multiply(T,transpose(T)),TT));
    const margin=symmetricEigen(diff(id3,TT))[0];
    const marked=[.25,-t[0],-t[1]];
    const markResidual=Math.hypot(...M.map(row=>dot(row,marked)));
    return {normalizer,normality,margin,markResidual};
  }
  PGExperiments['2.1'] = {
    question: 'Can one bordered matrix rule out a proposed source geometry?',
    idea: 'Start from the three sources 0, r and −4r/5 with masses 1, 2 and 1. The critical data and inverse metric force the border of M. The tilt changes the inverse metric in a direction orthogonal to the marked row, so the normalization and the border can survive even when normality fails. Scaling the whole initial inverse metric tests the normalization independently.',
    controls:[
      control('radius','Positive source r',.5,1.15,.01,.85),
      control('tilt','Inverse-metric tilt (hundredths of r²)',-2.5,2.5,.1,0),
      control('scale','Initial inverse-metric scale',.8,1.2,.01,1)
    ],
    presets:[preset('Interior sources',{radius:.85,tilt:0,scale:1}),preset('Boundary equality',{radius:1,tilt:0,scale:1}),preset('Tilt breaks normality',{radius:.78,tilt:1.5,scale:1}),preset('Source outside disk',{radius:1.1,tilt:0,scale:1}),preset('Wrong normalization',{radius:.8,tilt:0,scale:1.1})],
    run({radius,tilt,scale}) {
      const v=matrixTest(radius,tilt,scale), tol=1e-9;
      const normOk=Math.abs(v.normalizer-.75)<tol, normal=v.normality<tol, contract=v.margin>=-tol;
      const curve=[], commutator=[];
      for(let i=0;i<=40;i++){
        const x=.5+.65*i/40, result=matrixTest(x,tilt,scale);
        curve.push([x,result.margin]);
        commutator.push([x,result.normality]);
      }
      const reason=!normOk?'The marked unit-mass normalization fails, so the proposed data cannot realize these specifications.':
        !normal?'The marked-source equation still holds, but the nonzero commutator rejects this metric.':
        !contract?'The matrix is normal, but its energy defect has a negative direction. At this radius the outer source lies beyond the disk.':
        Math.abs(v.margin)<tol?'The outer source lies on the unit circle. A zero defect eigenvalue is allowed by positive semidefiniteness.':
        'The normalization, normality and disk tests all hold at the displayed tolerance. In this unperturbed family the three source positions can also be read from the polynomial.';
      return {metrics:[metric('First critical coordinate',fmt(.4*radius)),metric('Second critical coordinate',fmt(-.5*radius)),metric('Decision tolerance',tol)],
        checks:[condition('Marked normalization = 1 − 1/4'+(normOk?'':' — candidate rejected'),v.normalizer,.75,normOk,'Computed as vᵀH⁻¹v with v = (aI − J)⁻¹e.','info'),
          absoluteCheck('Marked eigenvector residual ‖Mv − av‖₂',v.markResidual,tol,'Here the bordered vector is (1/4, −H⁻¹(aI−J)⁻¹e) and a = 0.'),
          condition('Weighted normality residual ≤ tolerance'+(normal?'':' — candidate rejected'),v.normality,tol,normal,'Frobenius norm of TTᵀ − TᵀT, where T = RMR⁻¹ and RᵀR = diag(4,H).','info'),
          condition('Smallest defect eigenvalue ≥ 0'+(contract?'':' — candidate rejected'),v.margin,0,contract,'Smallest eigenvalue of I − TᵀT. Negative values below tolerance reject a disk realization.','info')],
        plot:{type:'lines',xLabel:'source radius r',yLabel:'matrix test value',series:[{name:'λmin(I − TᵀT)',points:curve},{name:'normality residual',points:commutator},{name:'zero threshold',points:[[.5,0],[1.15,0]]},{name:'selected radius',points:[[radius,v.margin]]}]},
        interpretation:reason};
    }
  };

  const gNoisy=x=>(x-.4)*(x+.5);
  function enclosure(center, roots, r, eps) {
    // Uniform elementary bounds on the WHOLE circle; plotted point samples are not used here.
    const distances=roots.map(x=>Math.abs(x-center));
    const count=distances.filter(d=>d<r).length;
    const m=distances.reduce((prod,d)=>prod*Math.abs(d-r),1);
    const A=Math.abs(center+.5)+r, B=Math.abs(center-.4)+r;
    const eta=4*eps*(Math.sqrt(41)/2)*Math.hypot(A,B);
    const node=roots[center>0?1:0], other=roots[center>0?0:1];
    const mass=4*gNoisy(node)/(node*(node-other));
    const sep=Math.abs(center)-r;
    const valid=count===1 && distances[center>0?1:0]<r && sep>0 && m>eta;
    if (!valid) return {center,count,m,eta,node,mass,valid,interval:'unavailable',integerCount:null};
    const bound=r*4*A*B*eta/(sep*m*(m-eta));
    const low=mass-bound, high=mass+bound;
    const first=Math.max(1,Math.ceil(low)), last=Math.floor(high);
    const integerCount=Math.max(0,last-first+1);
    return {center,count,m,eta,node,mass,valid,bound,integerCount,first,interval:'['+fmt(low)+', '+fmt(high)+']'};
  }
  PGExperiments['2.2'] = {
    question:'Can a fitted source leave the unit disk while its integer multiplicity is still determined?',
    idea:'For p(z) = z(z−1)²(z+4/5), perturb the first diagonal entry of the inverse metric by δ, with |δ| ≤ ε. Factor the fitted quadratic, then use the entire contour to bound the error of each residue. The plotted samples show how the gap varies around each circle. The bounds use distances to the fitted roots over the entire circle. The given polynomial supplies a realization within the error budget.',
    controls:[control('logError','log₁₀ of inverse-metric error budget ε',-7,-2,.1,-5),
      control('fraction','Signed perturbation δ/ε',-1,1,.1,1),control('contour','Contour radius',.002,.152,.001,.01)],
    presets:[preset('Published quartic',{logError:-5,fraction:1,contour:.01}),preset('Reverse perturbation',{logError:-5,fraction:-1,contour:.01}),preset('Ambiguous integer',{logError:-2.7,fraction:.5,contour:.09}),preset('Contour too small',{logError:-2.3,fraction:1,contour:.003})],
    run({logError,fraction,contour}) {
      const eps=10**logError,delta=eps*fraction;
      // qhat(z) = z² − (0.2+10δ)z − (0.8+5δ).
      const b=.2+10*delta,disc=Math.sqrt(b*b+4*(.8+5*delta));
      const roots=[(b-disc)/2,(b+disc)/2];
      const data=[enclosure(1,roots,contour,eps),enclosure(-.8,roots,contour,eps)];
      const checks=[],metrics=[metric('ε and actual δ',fmt(eps)+' / '+fmt(delta)),
        metric('Fitted roots (positive, negative)',fmt(roots[1])+', '+fmt(roots[0]))];
      const plot=[];
      for(const q of data){
        const tag=q.center>0?'at +1':'at −0.8',truth=q.center>0?2:1;
        const tol=1e-12;
        metrics.push(metric('Fitted mass / mass interval '+tag,fmt(q.mass)+' / '+q.interval));
        checks.push(condition('Fitted zeros inside circle '+tag,q.count,1,q.count===1,'Count obtained from the two fitted roots.','inconclusive'),
          condition('Uniform lower bound m > upper bound η '+tag,q.m,q.eta,q.m>q.eta,'m ≥ ∏ⱼ |r − |α̂ⱼ − center||. The displayed η is bounded by the circle-wide row norm.','inconclusive'));
        if(q.valid){
          checks.push(condition('Observed mass error ≤ bound '+tag,Math.abs(q.mass-truth),q.bound,Math.abs(q.mass-truth)<=q.bound+tol,'Known mass of the original quartic provides an independent error check.'),
            condition('One positive integer in the interval '+tag,q.integerCount,1,q.integerCount===1,
              q.integerCount===1?'Recovered multiplicity '+q.first+'.':'The contour bounds the residue, but leaves multiple positive integer candidates.','inconclusive'));
        } else {
          checks.push({label:'Residue and integer bound '+tag,left:'unavailable',right:'one isolated pole',state:'inconclusive',detail:'Use a contour isolating its fitted root and a strict gap m > η before applying the residue estimate.'});
        }
        const points=[];
        for(let angle=0;angle<=360;angle+=5){
          const x=q.center+contour*Math.cos(angle*Math.PI/180),y=contour*Math.sin(angle*Math.PI/180);
          points.push([angle,Math.hypot(x-roots[0],y)*Math.hypot(x-roots[1],y)-q.eta]);
        }
        plot.push({name:'|Q̂| − η '+tag,points});
      }
      plot.push({name:'zero threshold',points:[[0,0],[360,0]]});
      const summary=data.map(q=>q.valid && q.integerCount===1?String(q.first):'undetermined');
      return {metrics,checks,plot:{type:'lines',xLabel:'contour angle (degrees)',yLabel:'sampled |Q̂| minus uniform error bound',series:plot},
        interpretation:'Recovered multiplicities at +1 and −0.8: '+summary.join(' and ')+'. '+(roots[1]>1+1e-10?'The positive fitted root lies outside the unit disk. ':'')+'A failed sufficient bound only leaves that multiplicity undetermined by this test. Floating-point values display analytical circle bounds.'};
    }
  };

  PGExperiments['B.2'] = {
    question:'Which recovered source masses give multiplicities of an ordinary polynomial?',
    idea:'Use sources −4/5, 0, r and positive masses 3−μ, 1, μ. Form the quadratic numerator G of their logarithmic derivative and its Gram matrix. Recover the two unmarked roots from the kernel polynomial G(z)[1+4κ(z,0)]. Compute each weight independently from a residue and from the reciprocal diagonal kernel value.',
    controls:[control('weight','Positive-source mass μ',.25,2.75,.25,2),control('radius','Positive source r',.4,1,.01,1)],
    presets:[preset('Masses 1, 1, 2',{weight:2,radius:1}),preset('Half-integer masses',{weight:1.5,radius:.8}),preset('Exchange multiplicities',{weight:1,radius:.9})],
    run({weight,radius}) {
      const src=[-.8,0,radius], nu=[3-weight,1,weight];
      // nG arises by clearing the three original simple fractions.
      const A=src.reduce((s,x,i)=>s-nu[i]*(src[(i+1)%3]+src[(i+2)%3])/4,0);
      const B=src.reduce((s,x,i)=>s+nu[i]*src[(i+1)%3]*src[(i+2)%3]/4,0);
      const g=z=>z*z+A*z+B;
      const d=Math.sqrt(A*A-4*B), w=[(-A-d)/2,(-A+d)/2];
      const Y=src.map((x,i)=>w.map(t=>-Math.sqrt(nu[i])/(x-t)));
      const F=inverse2(multiply(transpose(Y),Y));
      const row=z=>w.map(t=>1/(z-t)),v=row(0);
      const t=F.map(rr=>dot(rr,v));
      const qa=A+4*(t[0]+t[1]),qb=B-4*(t[0]*w[1]+t[1]*w[0]);
      const dq=Math.sqrt(qa*qa-4*qb);
      const recovered=[(-qa-dq)/2,0,(-qa+dq)/2];
      const k=(x,y)=>dot(row(x),F.map(rr=>dot(rr,row(y))));
      const residue=recovered.map((x,i)=>4*g(x)/recovered.reduce((prod,y,j)=>i===j?prod:prod*(x-y),1));
      const diagMass=recovered.map(z=>1/(.25+k(z,z)));
      let kernelError=0;
      for(let i=0;i<3;i++) for(let j=0;j<3;j++){
        const expected=(i===j?1/residue[i]:0)-.25;
        kernelError=Math.max(kernelError,Math.abs(k(recovered[i],recovered[j])-expected));
      }
      const massError=Math.max(...nu.map((x,i)=>Math.abs(x-residue[i])));
      const integrality=Math.max(...residue.map(x=>Math.abs(x-Math.round(x))));
      const tol=1e-9;
      return {
        metrics:[metric('G roots (critical positions)', w.map(fmt).join(', ')),metric('Recovered sources',recovered.map(fmt).join(', ')),
          metric('Residues in source order',residue.map(fmt).join(', ')),metric('Kernel-diagonal weights',diagMass.map(fmt).join(', '))],
        checks:[absoluteCheck('Recovered positions versus source positions',Math.max(...src.map((x,i)=>Math.abs(x-recovered[i]))),tol,'Roots of the reconstructed monic support polynomial were computed without supplying the original roots to the quadratic solver.'),
          absoluteCheck('Residues versus original masses',massError,tol,'Residues use 4G(α)/D′(α) at the newly recovered poles.'),
          absoluteCheck('Full kernel matrix identity residual',kernelError,tol,'The diagonal entries satisfy κ(αᵢ,αᵢ) = 1/νᵢ − 1/4. Every off-diagonal entry equals −1/4.'),
          condition('Distance to positive integers'+(integrality<tol?'':' — polynomial criterion not met'),integrality,0,integrality<tol,'Input weights lie exactly on a quarter-integer grid. This comparison checks whether an ordinary polynomial realizes these source masses.','info')],
        plot:{type:'bars',xLabel:'source position',yLabel:'mass',series:[{name:'by residues',points:recovered.map((x,i)=>[x,residue[i]])},{name:'by diagonal kernel',points:recovered.map((x,i)=>[x,diagMass[i]])}]},
        interpretation:Number.isInteger(weight)?'All three recovered residues are positive integers. They are the exponents of the factors (z−α) in the ordinary polynomial.':'The positive real masses still define weighted sources. Their noninteger values rule out interpreting this particular realization as the multiplicities of an ordinary polynomial.'};
    }
  };
})();
