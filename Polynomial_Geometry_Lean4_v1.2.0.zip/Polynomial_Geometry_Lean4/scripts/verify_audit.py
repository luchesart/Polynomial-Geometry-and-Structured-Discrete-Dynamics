#!/usr/bin/env python3
"""Check exported kernel dependencies, source completeness and claim-map references."""
import hashlib, json, re, tomllib
from pathlib import Path
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[1]
ALLOWED={'propext','Classical.choice','Quot.sound'}

def strip_comments(text):
    out=[]; i=0; depth=0
    while i<len(text):
        if text.startswith('/-',i): depth+=1; out.extend('  '); i+=2
        elif depth and text.startswith('-/',i): depth-=1; out.extend('  '); i+=2
        elif depth: out.append('\n' if text[i]=='\n' else ' '); i+=1
        elif text.startswith('--',i):
            j=text.find('\n',i); j=len(text) if j<0 else j
            out.extend(' '*(j-i)); i=j
        else: out.append(text[i]); i+=1
    assert depth==0, 'Unclosed source comment'
    return ''.join(out)

def main():
    data=json.loads((ROOT/'audit/checked_declarations.json').read_text())
    unexpected=set(data['axioms_union'])-ALLOWED
    assert not unexpected, f'Unexpected kernel dependencies: {unexpected}'
    byname={d['name']:d for d in data['declarations']}
    imports=set(re.findall(r'^import (PolynomialGeometry\.\w+)',(ROOT/'PolynomialGeometry.lean').read_text(),re.M))
    explicit=[]; sources={}; source_hashes={}
    rx=re.compile(r'\b(theorem|lemma|def|abbrev)\s+([\w\u0080-\uffff\'.]+)')
    for p in sorted((ROOT/'PolynomialGeometry').glob('*.lean')):
        mod='PolynomialGeometry.'+p.stem
        assert mod in imports, f'Module not included in default build: {mod}'
        source=p.read_text(); clean=strip_comments(source)
        forbidden=re.findall(r'\b(?:sorry|admit|axiom|unsafe|native_decide)\b',clean)
        assert not forbidden, f'Forbidden proof escape in {p.name}: {forbidden}'
        sources[mod]=source
        source_hashes[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
        for m in rx.finditer(clean):
            kind,short=m.groups(); line=clean[:m.start()].count('\n')+1
            matches=[d for d in data['declarations'] if d['module']==mod and
                     (d['name'].split('.')[-1]==short or d['name']==short)]
            if not matches:
                # Private helper declarations are checked transitively by public proofs.
                line_text=clean.splitlines()[line-1]
                assert 'private' in line_text, f'Unmatched declaration {mod}.{short} at {line}'
                continue
            assert len(matches)==1, f'Ambiguous declaration: {mod}.{short}'
            d=dict(matches[0]); d['source_line']=line; d['source_kind']=kind
            explicit.append(d)
    claims=json.loads((ROOT/'docs/claims.json').read_text()) if (ROOT/'docs/claims.json').exists() else []
    identities=json.loads((ROOT/'docs/identities.json').read_text())
    for claim in claims+identities:
        for name in claim['lean']:
            assert name in byname, f'Unresolved claim reference: {claim["id"]}: {name}'
    config=tomllib.loads((ROOT/'lakefile.toml').read_text())
    manifest=json.loads((ROOT/'lake-manifest.json').read_text())
    assert (ROOT/'lean-toolchain').read_text().strip()=='leanprover/lean4:v4.24.0'
    mathlib=next(p for p in manifest['packages'] if p['name']=='mathlib')
    assert mathlib['rev']=='f897ebcf72cd16f89ab4577d0c826cd14afaafc7'
    verification_inputs=['PolynomialGeometry.lean','Audit.lean','lakefile.toml',
                         'lake-manifest.json','lean-toolchain','docs/claims.json','docs/identities.json']
    summary={
        'release_version':config['version'],
        'verification_input_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
                                     for name in verification_inputs},
        'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'lean':'4.24.0','mathlib_commit':'f897ebcf72cd16f89ab4577d0c826cd14afaafc7',
        'additional_identity_groups':len(identities),
        'modules':len(sources),'explicit_theorems':sum(d['source_kind'] in ('theorem','lemma') for d in explicit),
        'explicit_definitions':sum(d['source_kind'] in ('def','abbrev') for d in explicit),
        'kernel_declarations_including_generated':len(data['declarations']),
        'axioms_union':sorted(data['axioms_union']),
        'numbered_claims_complete':bool(claims) and all(c['status']=='complete' for c in claims),
        'coverage_scope':'The numbered mathematical statements listed in docs/claims.json, plus explicitly mapped displayed identities. Numerical illustrations, literature attribution and novelty are not kernel conclusions.',
        'source_sha256':source_hashes,
        'claims_by_status':{status:sum(c['status']==status for c in claims) for status in sorted({c['status'] for c in claims})},
        'scope_note':'Declaration counts are not counts of fully formalized article statements.'}
    (ROOT/'audit/summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    (ROOT/'audit/source_declarations.json').write_text(json.dumps(explicit,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ('source_sha256','verification_input_sha256')},indent=2))
if __name__=='__main__': main()
