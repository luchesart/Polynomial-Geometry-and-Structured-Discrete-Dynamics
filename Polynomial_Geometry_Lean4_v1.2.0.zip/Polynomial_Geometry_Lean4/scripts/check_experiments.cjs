#!/usr/bin/env node
// Reproduce the offline experiments without a browser or npm packages.
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const base = path.resolve(__dirname, '..');
const claims = JSON.parse(fs.readFileSync(path.join(base, 'docs/claims.json'), 'utf8'));
const context = vm.createContext({PGExperiments: {}});
for (const name of ['compression', 'inverse', 'energy', 'variation', 'local']) {
  const source = path.join(__dirname, 'experiments', name + '.js');
  vm.runInContext(fs.readFileSync(source, 'utf8'), context, {filename: source});
}
const labs = context.PGExperiments;
assert.deepEqual(Object.keys(labs).sort(), claims.map(c => c.id).sort());
const report = {claims: {}, runs: 0, comparisons: 0, presets: 0, states: {pass:0, fail:0, info:0, inconclusive:0}};
let seed = 137;
function random() {
  seed = (Math.imul(1664525, seed) + 1013904223) >>> 0;
  return seed / 4294967296;
}
function baseline(e) { return Object.fromEntries(e.controls.map(c => [c.key, c.value])); }
for (const {id} of claims) {
  const e = labs[id], initial = baseline(e);
  const counters = {presets: e.presets.length, runs: 0, comparisons: 0};
  function run(values) {
    const r = e.run(values), tag = id + ' ' + JSON.stringify(values);
    assert.ok(r.checks.length && r.interpretation, tag);
    for (const {value} of r.metrics) assert.ok(typeof value === 'string' ? !/\b(?:NaN|Infinity)\b/.test(value) : Number.isFinite(value), tag);
    for (const s of r.plot?.series || []) for (const pt of s.points) assert.ok(pt.length === 2 && pt.every(Number.isFinite), tag);
    for (const c of r.checks) {
      for (const n of [c.left, c.right, c.tol]) if (typeof n === 'number') assert.ok(Number.isFinite(n), tag);
      const state = c.state ?? (Math.abs(c.left - c.right) <= (c.tol ?? 0) ? 'pass' : 'fail');
      assert.ok(Object.hasOwn(report.states, state), tag);
      assert.notEqual(state, 'fail', tag + ' ' + c.label);
      ++report.states[state];
    }
    counters.comparisons += r.checks.length;
    ++counters.runs;
    return r;
  }
  run(initial);
  for (const p of e.presets) run({...initial,...p.values});
  for (const c of e.controls) for (const v of [c.min, c.max]) run({...initial, [c.key]:v});
  for (let mask=0; mask < 2**e.controls.length; mask++)
    run(Object.fromEntries(e.controls.map((c,i)=>[c.key, mask & (1<<i) ? c.max : c.min])));
  for (let n=0; n<40; n++) {
    const values={};
    for (const c of e.controls) {
      const steps=Math.round((c.max-c.min)/c.step);
      values[c.key]=Number((c.min+c.step*Math.floor(random()*(steps+1))).toPrecision(12));
    }
    run(values);
  }
  report.claims[id]=counters;
  for (const key of ['runs','comparisons','presets']) report[key]+=counters[key];
}
// Trusted landmarks independent of the browser's pass/fail badges.
const evaluate=(id, changes={}) => labs[id].run({...baseline(labs[id]),...changes});
const firstMetric=(id, changes) => evaluate(id,changes).metrics[0].value;
assert.deepEqual([1,2,3,4,5].map(h=>firstMetric('2.3',{boundary:5,a:0,h})),[2,3,4,5,5]);
assert.ok(Math.abs(evaluate('B.1').metrics[1].value-3375/8)<1e-9);
assert.match(evaluate('2.2').interpretation,/2 and 1/);
assert.ok(evaluate('2.2',{logError:-2.3,fraction:1,contour:.003}).checks.some(c=>c.state==='inconclusive'));
const curvature=[0,1,2].map(block=>firstMetric('D.3',{block}));
assert.ok(curvature[0]<-.09 && curvature[1]>.11 && curvature[2]>.16);
const d4=(gamma,P)=>evaluate('D.4',{gamma,P,b:0}).metrics[1].value;
assert.ok(d4(1,1)<0 && d4(1.8,1)>0 && Math.abs(d4(2,2))<1e-13);
const output=JSON.stringify(report,null,2)+'\n';
if (process.argv.includes('--report')) fs.writeFileSync(path.join(base,'audit/experiment_checks.json'),output);
console.log(output);
