#!/usr/bin/env python3
"""Package the audited project, excluding downloaded runtimes and build caches."""
from pathlib import Path
import hashlib
import json
import sys
import tomllib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
summary = json.loads((ROOT / 'audit/summary.json').read_text())
for name, expected in (summary['source_sha256'] | summary['verification_input_sha256']).items():
    actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    assert actual == expected, f'Source changed since audit: {name}'
sources = sorted((ROOT / 'PolynomialGeometry').glob('*.lean'))
assert len(sources) == summary['modules'], 'Module count changed since audit'
version = tomllib.loads((ROOT / 'lakefile.toml').read_text())['version']
target = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT.parent / f'Polynomial_Geometry_Lean4_v{version}.zip'
files = [ROOT / name for name in (
    'README.md', 'PolynomialGeometry.lean', 'Audit.lean', 'lakefile.toml',
    'lake-manifest.json', 'lean-toolchain', '.gitignore')]
files += sources
files += [p for p in (ROOT / 'docs').iterdir() if p.suffix in {'.md', '.json', '.html'}]
files += [p for p in (ROOT / 'scripts').rglob('*')
          if p.is_file() and p.suffix in {'.py', '.sh', '.txt', '.cjs', '.css', '.js'}]
files += [ROOT / 'audit' / name for name in (
    'environment.json', 'summary.json', 'checked_declarations.json',
    'source_declarations.json', 'build_and_check.log', 'map_validation.json',
    'manuscript_reference.json', 'experiment_checks.json')]
files = sorted(set(files))
assert all(p.is_file() for p in files), 'A release file is missing'
checksums = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(ROOT / 'SHA256SUMS').write_text(''.join(f'{h}  {name}\n' for name, h in checksums.items()))
files.append(ROOT / 'SHA256SUMS')
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in files:
        archive.write(p, 'Polynomial_Geometry_Lean4/' + str(p.relative_to(ROOT)))
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for name, expected in checksums.items():
        assert hashlib.sha256(archive.read('Polynomial_Geometry_Lean4/' + name)).hexdigest() == expected
print(json.dumps({'file': str(target.resolve()), 'files': len(files),
                  'bytes': target.stat().st_size,
                  'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}, indent=2))
