import PolynomialGeometry.CriticalReconstruction
import Mathlib.Analysis.Polynomial.CauchyBound
import Mathlib.Topology.Compactness.Compact

/-! # Uniform root margins in coefficient families

No continuous labelling of repeated roots is assumed. Compact nonvanishing
and the monic Cauchy bound prove confinement of every nearby root.
-/
noncomputable section
open Polynomial Filter
open scoped Topology BigOperators
namespace PolynomialGeometry.RootMargins
open PolynomialGeometry.Factorization PolynomialGeometry.CriticalReconstruction

/-- Compact nonvanishing persists uniformly under continuous coefficient changes. -/
theorem compact_nonvanishing {E : Type*} [TopologicalSpace E]
    (n : ℕ) (H : E → Fin n → ℂ) (x : E) (K : Set ℂ)
    (hH : ContinuousAt H x) (hK : IsCompact K)
    (hbase : ∀ z ∈ K, (monicPolynomial n (H x)).eval z ≠ 0) :
    ∀ᶠ y in 𝓝 x, ∀ z ∈ K, (monicPolynomial n (H y)).eval z ≠ 0 := by
  apply hK.eventually_forall_of_forall_eventually
  intro z hz
  have hc : ContinuousAt (fun p : E × ℂ => (H p.1,p.2)) (x,z) :=
    (hH.comp continuousAt_fst).prodMk continuousAt_snd
  exact ((monicPolynomial_eval_analyticAt n (H x,z)).continuousAt.comp_of_eq hc rfl).eventually_ne
    (hbase z hz)

/-- A coefficient sup norm gives one common bound for every root. -/
theorem monic_root_norm_bound (n : ℕ) (a : Fin n → ℂ) (z : ℂ)
    (hz : (monicPolynomial n a).IsRoot z) : ‖z‖ < ‖a‖ + 1 := by
  have h := hz.norm_lt_cauchyBound (monicPolynomial_monic n a).ne_zero
  have hb : (monicPolynomial n a).cauchyBound ≤ ‖a‖₊ + 1 := by
    unfold Polynomial.cauchyBound
    rw [(monicPolynomial_monic n a).leadingCoeff, monicPolynomial_natDegree]
    simp only [nnnorm_one, div_one, add_le_add_iff_right]
    apply Finset.sup_le
    intro k hk
    have hk' : k < n := Finset.mem_range.mp hk
    rw [monicPolynomial_coeff n a ⟨k,hk'⟩]
    exact nnnorm_le_pi_nnnorm a ⟨k,hk'⟩
  exact_mod_cast h.trans_le hb

/-- Every root of a nearby monic polynomial remains in any prescribed open
set containing all base roots, including at multiple roots. -/
theorem roots_stay_in_open_set {E : Type*} [TopologicalSpace E]
    (n : ℕ) (H : E → Fin n → ℂ) (x : E) (U : Set ℂ)
    (hH : ContinuousAt H x) (hU : IsOpen U)
    (hbase : ∀ z, (monicPolynomial n (H x)).IsRoot z → z ∈ U) :
    ∀ᶠ y in 𝓝 x, ∀ z, (monicPolynomial n (H y)).IsRoot z → z ∈ U := by
  let R := ‖H x‖ + 2
  let K := Metric.closedBall (0 : ℂ) R ∩ Uᶜ
  have hK : IsCompact K := (isCompact_closedBall 0 R).inter_right hU.isClosed_compl
  have hnonzero : ∀ z ∈ K, (monicPolynomial n (H x)).eval z ≠ 0 := by
    intro z hz he
    exact hz.2 (hbase z he)
  have hn := compact_nonvanishing n H x K hH hK hnonzero
  have hb : ∀ᶠ y in 𝓝 x, ‖H y‖ < ‖H x‖+1 :=
    hH.norm.eventually (gt_mem_nhds (by linarith : ‖H x‖ < ‖H x‖+1))
  filter_upwards [hn,hb] with y hy hby
  intro z hz
  by_contra hzu
  apply hy z
  · refine ⟨?_,hzu⟩
    have hroot := monic_root_norm_bound n (H y) z hz
    change dist z 0 ≤ R
    simp only [dist_zero_right]
    dsimp [R]
    linarith
  · exact hz

/-- Strictly interior roots remain strictly interior with no root labelling. -/
theorem interior_roots_persist {E : Type*} [TopologicalSpace E]
    (n : ℕ) (H : E → Fin n → ℂ) (x : E)
    (hH : ContinuousAt H x)
    (hbase : ∀ z, (monicPolynomial n (H x)).IsRoot z → ‖z‖ < 1) :
    ∀ᶠ y in 𝓝 x, ∀ z, (monicPolynomial n (H y)).IsRoot z → ‖z‖ < 1 :=
  roots_stay_in_open_set n H x {z | ‖z‖ < 1} hH
    (isOpen_lt continuous_norm continuous_const) hbase


/-- Any jointly open root property persists for all roots. The neighborhood
need only be supplied at actual base roots, not at other evaluation points. -/
theorem root_property_persists {E : Type*} [TopologicalSpace E]
    (n : ℕ) (H : E → Fin n → ℂ) (x : E) (P : E → ℂ → Prop)
    (hH : ContinuousAt H x)
    (hP : ∀ z, (monicPolynomial n (H x)).IsRoot z →
      ∀ᶠ q : E × ℂ in 𝓝 (x,z), P q.1 q.2) :
    ∀ᶠ y in 𝓝 x, ∀ z, (monicPolynomial n (H y)).IsRoot z → P y z := by
  let R := ‖H x‖+2
  have hcompact : IsCompact (Metric.closedBall (0 : ℂ) R) := isCompact_closedBall 0 R
  have hev : ∀ᶠ y in 𝓝 x, ∀ z ∈ Metric.closedBall (0 : ℂ) R,
      (monicPolynomial n (H y)).eval z ≠ 0 ∨ P y z := by
    apply hcompact.eventually_forall_of_forall_eventually
    intro z _
    by_cases hz : (monicPolynomial n (H x)).IsRoot z
    · exact (hP z hz).mono fun _ hp => Or.inr hp
    · have hc : ContinuousAt (fun q : E × ℂ => (H q.1,q.2)) (x,z) :=
        (hH.comp continuousAt_fst).prodMk continuousAt_snd
      have hn := ((monicPolynomial_eval_analyticAt n (H x,z)).continuousAt.comp_of_eq hc rfl).eventually_ne hz
      exact hn.mono fun _ hp => Or.inl hp
  have hb : ∀ᶠ y in 𝓝 x, ‖H y‖ < ‖H x‖+1 :=
    hH.norm.eventually (gt_mem_nhds (by linarith : ‖H x‖ < ‖H x‖+1))
  filter_upwards [hev,hb] with y hy hby
  intro z hz
  have hroot := monic_root_norm_bound n (H y) z hz
  have hzR : z ∈ Metric.closedBall (0 : ℂ) R := by
    change dist z 0 ≤ R
    simp only [dist_zero_right]
    dsimp [R]
    linarith
  exact (hy z hzR).resolve_left (not_not.mpr hz)

/-- The strict inactive gap persists while the marked source and the active
distance vary. Repeated inactive roots need no continuous labels. -/
theorem inactive_gap_persists {E : Type*} [TopologicalSpace E]
    (n : ℕ) (H : E → Fin n → ℂ) (a : E → ℂ) (D : E → ℝ) (x : E)
    (hH : ContinuousAt H x) (ha : ContinuousAt a x) (hD : ContinuousAt D x)
    (hgap : ∀ z, (monicPolynomial n (H x)).IsRoot z → D x < ‖z-a x‖) :
    ∀ᶠ y in 𝓝 x, ∀ z, (monicPolynomial n (H y)).IsRoot z → D y < ‖z-a y‖ := by
  apply root_property_persists n H x (fun y z => D y < ‖z-a y‖) hH
  intro z hz
  have hleft : ContinuousAt (fun q : E × ℂ => D q.1) (x,z) :=
    hD.comp continuousAt_fst
  have hright : ContinuousAt (fun q : E × ℂ => ‖q.2-a q.1‖) (x,z) :=
    (continuousAt_snd.sub (ha.comp continuousAt_fst)).norm
  exact hleft.eventually_lt hright (hgap z hz)


/-- Lower coefficients of the exact quotient after deleting the marked simple root. -/
def quotientCoefficients (n : ℕ) (b : Fin (n+1) → ℂ) (v : ℂ) : Fin n → ℂ :=
  fun k => ((monicPolynomial (n+1) b) /ₘ (X-C v)).coeff k

theorem quotientPolynomial_eq (n : ℕ) (b : Fin (n+1) → ℂ) (v : ℂ) :
    monicPolynomial n (quotientCoefficients n b v) =
      (monicPolynomial (n+1) b) /ₘ (X-C v) := by
  have hdeg : (monicPolynomial (n+1) b).degree ≠ 0 := by
    rw [degree_eq_natDegree (monicPolynomial_monic (n+1) b).ne_zero, monicPolynomial_natDegree]
    exact_mod_cast (Nat.succ_ne_zero n)
  have hm : ((monicPolynomial (n+1) b) /ₘ (X-C v)).Monic := by
    rw [Polynomial.Monic, leadingCoeff_divByMonic_X_sub_C _ hdeg,
      (monicPolynomial_monic (n+1) b).leadingCoeff]
  have hd : ((monicPolynomial (n+1) b) /ₘ (X-C v)).natDegree = n := by
    rw [natDegree_divByMonic _ (monic_X_sub_C v), monicPolynomial_natDegree,
      natDegree_X_sub_C, Nat.add_sub_cancel]
  apply monic_eq_of_low_coeff _ _ n (monicPolynomial_monic _ _) hm
    (monicPolynomial_natDegree _ _) hd
  intro k
  exact monicPolynomial_coeff n _ k

/-- Deleting a specified root is continuous in both its position and every
coefficient, including when other roots collide. -/
theorem quotientCoefficients_continuousAt {E : Type*} [TopologicalSpace E]
    (n : ℕ) (H : E → Fin (n+1) → ℂ) (v : E → ℂ) (x : E)
    (hH : ContinuousAt H x) (hv : ContinuousAt v x) :
    ContinuousAt (fun y => quotientCoefficients n (H y) (v y)) x := by
  apply continuousAt_pi.mpr
  intro k
  simp only [quotientCoefficients, coeff_divByMonic_X_sub_C, monicPolynomial_natDegree]
  apply tendsto_finset_sum
  intro i _
  exact (hv.pow _).mul (((analytic_monic_coefficient (n+1) i (H x)).continuousAt).comp hH)

/-- Exact source factorization after deleting a marked residual root. -/
theorem marked_root_factorization (n : ℕ) (b : Fin (n+1) → ℂ) (v : ℂ)
    (hv : (monicPolynomial (n+1) b).IsRoot v) :
    (X-C v) * monicPolynomial n (quotientCoefficients n b v) = monicPolynomial (n+1) b := by
  rw [quotientPolynomial_eq]
  exact mul_divByMonic_eq_iff_isRoot.mpr hv

/-- The deleted root does not remain a root of the quotient when it is simple. -/
theorem quotient_nonzero_at_simple_root (n : ℕ) (b : Fin (n+1) → ℂ) (v : ℂ)
    (hsimple : (monicPolynomial (n+1) b).derivative.eval v ≠ 0) :
    (monicPolynomial n (quotientCoefficients n b v)).eval v ≠ 0 := by
  rw [quotientPolynomial_eq]
  have he := congrArg (fun p : ℂ[X] => p.eval v)
    (divByMonic_add_X_sub_C_mul_derivative_divByMonic_eq_derivative (monicPolynomial (n+1) b) v)
  simp only [eval_add, eval_mul, eval_sub, eval_X, eval_C, sub_self, zero_mul,
    add_zero] at he
  exact he ▸ hsimple

/-- The complete inactive gap follows from the original residual polynomial,
its marked simple root, and the strict gap at every other base root. -/
theorem inactive_gap_after_marked_root {E : Type*} [TopologicalSpace E]
    (n : ℕ) (H : E → Fin (n+1) → ℂ) (v a : E → ℂ) (D : E → ℝ) (x : E)
    (hH : ContinuousAt H x) (hv : ContinuousAt v x)
    (ha : ContinuousAt a x) (hD : ContinuousAt D x)
    (hroot : (monicPolynomial (n+1) (H x)).IsRoot (v x))
    (hsimple : (monicPolynomial (n+1) (H x)).derivative.eval (v x) ≠ 0)
    (hgap : ∀ z, (monicPolynomial (n+1) (H x)).IsRoot z → z ≠ v x → D x < ‖z-a x‖) :
    ∀ᶠ y in 𝓝 x, ∀ z,
      (monicPolynomial n (quotientCoefficients n (H y) (v y))).IsRoot z → D y < ‖z-a y‖ := by
  apply inactive_gap_persists n (fun y => quotientCoefficients n (H y) (v y)) a D x
    (quotientCoefficients_continuousAt n H v x hH hv) ha hD
  intro z hz
  have hq := marked_root_factorization n (H x) (v x) hroot
  have hzr : (monicPolynomial (n+1) (H x)).IsRoot z := by
    rw [← hq]
    rw [Polynomial.IsRoot, eval_mul]
    exact mul_eq_zero_of_right _ hz
  have hzv : z ≠ v x := by
    intro heq
    subst z
    exact quotient_nonzero_at_simple_root n (H x) (v x) hsimple hz
  exact hgap z hzr hzv

end PolynomialGeometry.RootMargins
