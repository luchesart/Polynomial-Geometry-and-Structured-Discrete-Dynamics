import PolynomialGeometry.PartialMaximum
import Mathlib.Analysis.Calculus.Deriv.MeanValue

noncomputable section
open scoped Topology
open Filter Set

namespace PolynomialGeometry.UniformPartialMaximum

open PartialMaximum

variable {E T : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [FiniteDimensional ℝ E] [NormedAddCommGroup T] [InnerProductSpace ℝ T]
  [FiniteDimensional ℝ T]

/-- Strict positivity in finite dimension is uniform on the unit sphere. -/
theorem positive_hessian_coercive (P : T →L[ℝ] T)
    (hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s)) :
    ∃ μ : ℝ, 0 < μ ∧ ∀ s : T, μ * ‖s‖ ^ 2 ≤ inner ℝ s (P s) := by
  rcases subsingleton_or_nontrivial T with hT | hT
  · exact ⟨1, by norm_num, fun s => by simp [Subsingleton.elim s 0]⟩
  let q : T → ℝ := fun s => inner ℝ s (P s)
  have hq : Continuous q := continuous_id.inner P.continuous
  obtain ⟨y, hy, hmin⟩ := (isCompact_sphere (0 : T) 1).exists_isMinOn
    (NormedSpace.sphere_nonempty.mpr (by norm_num : (0 : ℝ) ≤ 1)) hq.continuousOn
  have hyne : y ≠ 0 := by intro hy0; simp [hy0] at hy
  refine ⟨q y, hP y hyne, ?_⟩
  intro s
  by_cases hs : s = 0
  · simp [hs]
  have hz : (‖s‖⁻¹ : ℝ) • s ∈ Metric.sphere (0 : T) 1 := by
    simpa only [Metric.mem_sphere, dist_zero_right] using norm_smul_inv_norm (𝕜 := ℝ) hs
  have hb := hmin hz
  dsimp [q] at hb ⊢
  rw [map_smul, real_inner_smul_left, real_inner_smul_right] at hb
  have hn : 0 < ‖s‖ := norm_pos_iff.mpr hs
  have hb' := mul_le_mul_of_nonneg_left hb (sq_nonneg ‖s‖)
  field_simp at hb'
  nlinarith

omit [FiniteDimensional ℝ E] in
theorem partialGradient_pairing (F : E × T → ℝ) (p : E × T) (v : T) :
    inner ℝ (partialGradient F p) v = fderiv ℝ F p (0, v) := by
  exact InnerProductSpace.toDual_symm_apply

omit [FiniteDimensional ℝ E] in
/-- Strict differentiability of the actual gradient gives a uniform remainder
estimate on pairs of points, including moving stationary points. -/
theorem gradient_uniform_remainder (F : E × T → ℝ) (hF : AnalyticAt ℝ F 0)
    (P : T →L[ℝ] T)
    (hss : (fderiv ℝ (partialGradient F) 0).comp (ContinuousLinearMap.inr ℝ E T) = -P)
    (ε : ℝ) (hε : 0 < ε) :
    ∃ U : Set (E × T), U ∈ 𝓝 0 ∧
      ∀ p ∈ U, ∀ q ∈ U, p.1 = q.1 →
        ‖partialGradient F p - partialGradient F q + P (p.2 - q.2)‖ ≤
          ε * ‖p.2 - q.2‖ := by
  have hb := (partialGradient_analytic F hF).hasStrictFDerivAt.isLittleO.bound hε
  obtain ⟨U, hUo, hU0, hU⟩ := exists_nhds_square hb
  refine ⟨U, hUo.mem_nhds hU0, ?_⟩
  intro p hp q hq heq
  have hh := hU (mk_mem_prod hp hq)
  change ‖partialGradient F p - partialGradient F q -
    fderiv ℝ (partialGradient F) 0 (p - q)‖ ≤ ε * ‖p - q‖ at hh
  have hdiff : p - q = (0, p.2 - q.2) := by ext <;> simp [heq]
  have hd := congrArg (fun L : T →L[ℝ] T => L (p.2 - q.2)) hss
  change fderiv ℝ (partialGradient F) 0 (0, p.2 - q.2) = -(P (p.2 - q.2)) at hd
  simpa only [hdiff, hd, sub_neg_eq_add, Prod.norm_def, norm_zero,
    max_eq_right (norm_nonneg _)] using hh

omit [FiniteDimensional ℝ E] in
/-- A quantitative maximum follows by integrating the gradient remainder
along the segment from the stationary point. No maximum estimate is assumed. -/
theorem quadratic_domination_on_convex_set
    (F : E × T → ℝ) (P : T →L[ℝ] T) (μ : ℝ)
    (hP : ∀ s : T, μ * ‖s‖ ^ 2 ≤ inner ℝ s (P s))
    (U : Set (E × T)) (hU : Convex ℝ U)
    (hF : ∀ p ∈ U, DifferentiableAt ℝ F p)
    (hr : ∀ p ∈ U, ∀ q ∈ U, p.1 = q.1 →
      ‖partialGradient F p - partialGradient F q + P (p.2 - q.2)‖ ≤
        (μ / 2) * ‖p.2 - q.2‖)
    (x : E) (s t : T) (hs : (x, s) ∈ U) (ht : (x, t) ∈ U)
    (hstat : partialGradient F (x, t) = 0) :
    F (x, s) ≤ F (x, t) - (μ / 4) * ‖s - t‖ ^ 2 := by
  let v := s - t
  let path : ℝ → E × T := fun a => (x, t + a • v)
  have hpath (a : ℝ) (ha : a ∈ Icc (0 : ℝ) 1) : path a ∈ U := by
    have hh := hU.add_smul_sub_mem ht hs ha
    simpa [path, v] using hh
  have hpathD (a : ℝ) : HasDerivAt path (0, v) a := by
    simpa [path] using (hasDerivAt_const a x).prodMk
      ((hasDerivAt_id a).smul_const v |>.const_add t)
  have hgrad (a : ℝ) (ha : a ∈ Icc (0 : ℝ) 1) :
      inner ℝ (partialGradient F (path a)) v ≤ -(μ / 2) * a * ‖v‖ ^ 2 := by
    have hh := hr (path a) (hpath a ha) (x, t) ht rfl
    have hn : ‖partialGradient F (path a) + a • P v‖ ≤ (μ / 2) * (a * ‖v‖) := by
      simpa [path, hstat, map_smul, norm_smul, Real.norm_eq_abs,
        abs_of_nonneg ha.1] using hh
    have hi := (real_inner_le_norm (partialGradient F (path a) + a • P v) v).trans
      (mul_le_mul_of_nonneg_right hn (norm_nonneg v))
    rw [inner_add_left, real_inner_smul_left, real_inner_comm v (P v)] at hi
    have hp := mul_le_mul_of_nonneg_left (hP v) ha.1
    nlinarith
  let f : ℝ → ℝ := fun a => F (path a) + (μ / 4) * a ^ 2 * ‖v‖ ^ 2
  have hfD (a : ℝ) (ha : a ∈ Icc (0 : ℝ) 1) :
      HasDerivAt f (inner ℝ (partialGradient F (path a)) v +
        (μ / 2) * a * ‖v‖ ^ 2) a := by
    have hFD := (hF (path a) (hpath a ha)).hasFDerivAt.comp_hasDerivAt a (hpathD a)
    rw [← partialGradient_pairing] at hFD
    convert hFD.add ((((hasDerivAt_id a).pow 2).const_mul (μ / 4)).mul_const (‖v‖ ^ 2)) using 1
    dsimp [f]
    ring
  have hfcont : ContinuousOn f (Icc (0 : ℝ) 1) :=
    fun a ha => (hfD a ha).continuousAt.continuousWithinAt
  have hfdiff : DifferentiableOn ℝ f (interior (Icc (0 : ℝ) 1)) :=
    fun a ha => (hfD a (interior_subset ha)).differentiableAt.differentiableWithinAt
  have hb := (convex_Icc (0 : ℝ) 1).image_sub_le_mul_sub_of_deriv_le
    hfcont hfdiff (C := 0) (fun a ha => by
      rw [(hfD a (interior_subset ha)).deriv]
      linarith [hgrad a (interior_subset ha)])
    0 (by simp) 1 (by simp) zero_le_one
  simp [f, path, v] at hb
  linarith

omit [FiniteDimensional ℝ E] in
/-- Uniform local quadratic domination for an actual analytic objective.
The response may be any continuous stationary branch through the origin. -/
theorem uniform_local_quadratic_domination (F : E × T → ℝ)
    (hF : AnalyticAt ℝ F 0) (P : T →L[ℝ] T)
    (hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s))
    (hss : (fderiv ℝ (partialGradient F) 0).comp (ContinuousLinearMap.inr ℝ E T) = -P)
    (θ : E → T) (hθ : ContinuousAt θ 0) (hθ0 : θ 0 = 0)
    (hstat : ∀ᶠ x in 𝓝 (0 : E), partialGradient F (x, θ x) = 0) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ p : E × T in 𝓝 0,
      F p ≤ F (p.1, θ p.1) - c * ‖p.2 - θ p.1‖ ^ 2 := by
  obtain ⟨μ, hμ, hcoerc⟩ := positive_hessian_coercive P hP
  obtain ⟨U, hU, hr⟩ := gradient_uniform_remainder F hF P hss (μ / 2) (half_pos hμ)
  have hdiff : ∀ᶠ p in 𝓝 (0 : E × T), DifferentiableAt ℝ F p :=
    hF.eventually_analyticAt.mono fun _ hp => hp.differentiableAt
  obtain ⟨r, hrpos, hrsub⟩ := Metric.mem_nhds_iff.mp (inter_mem hU hdiff)
  have hgraph : ContinuousAt (fun p : E × T => (p.1, θ p.1)) 0 := by
    exact continuousAt_fst.prodMk ((show ContinuousAt θ ((0 : E × T).1) from hθ).comp continuousAt_fst)
  have hgraph0 : ((0 : E × T).1, θ (0 : E × T).1) = 0 := by simp [hθ0]
  have hb := Metric.ball_mem_nhds (0 : E × T) hrpos
  have hg := hgraph.eventually (by simpa only [hgraph0] using hb)
  have hs := (continuousAt_fst : ContinuousAt (Prod.fst : E × T → E) 0).eventually hstat
  refine ⟨μ / 4, by positivity, ?_⟩
  filter_upwards [hb, hg, hs] with p hp hgp hsp
  exact quadratic_domination_on_convex_set F P μ hcoerc (Metric.ball 0 r)
    (convex_ball 0 r) (fun q hq => (hrsub hq).2)
    (fun q hq z hz heq => hr q (hrsub hq).1 z (hrsub hz).1 heq)
    p.1 p.2 (θ p.1) hp hgp hsp

omit [NormedSpace ℝ E] [FiniteDimensional ℝ E] [InnerProductSpace ℝ T] [FiniteDimensional ℝ T] in
/-- Eliminating the strictly negative block preserves positive values
arbitrarily close to the origin. -/
theorem frequently_positive_iff (F : E × T → ℝ) (θ : E → T)
    (hθ : ContinuousAt θ 0) (hθ0 : θ 0 = 0)
    (c : ℝ) (hc : 0 ≤ c)
    (hdom : ∀ᶠ p : E × T in 𝓝 0,
      F p ≤ F (p.1, θ p.1) - c * ‖p.2 - θ p.1‖ ^ 2) :
    (∃ᶠ p : E × T in 𝓝 0, 0 < F p) ↔
      (∃ᶠ x : E in 𝓝 0, 0 < F (x, θ x)) := by
  constructor
  · intro hp
    apply (continuousAt_fst : ContinuousAt (Prod.fst : E × T → E) 0).tendsto.frequently
    exact (hp.and_eventually hdom).mono fun p hp => by
      have hn : 0 ≤ c * ‖p.2 - θ p.1‖ ^ 2 := mul_nonneg hc (sq_nonneg _)
      linarith [hp.1, hp.2]
  · intro hp
    have hgraph : Tendsto (fun x : E => (x, θ x)) (𝓝 0) (𝓝 (0 : E × T)) := by
      simpa [hθ0] using (continuousAt_id.prodMk hθ).tendsto
    exact hgraph.frequently hp

/-- The complete local maximization conclusion, constructed solely from
analyticity, stationarity at zero, and the negative partial Hessian. -/
theorem analytic_partial_maximum (F : E × T → ℝ)
    (hF : AnalyticAt ℝ F 0) (hF0 : fderiv ℝ F 0 = 0)
    (P : T →L[ℝ] T) (hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s))
    (hss : (fderiv ℝ (partialGradient F) 0).comp (ContinuousLinearMap.inr ℝ E T) = -P) :
    ∃ θ : E → T, AnalyticAt ℝ θ 0 ∧ θ 0 = 0 ∧
      HasFDerivAt θ ((positiveHessianEquiv P hP).symm.toContinuousLinearMap.comp
        ((fderiv ℝ (partialGradient F) 0).comp (ContinuousLinearMap.inl ℝ E T))) 0 ∧
      (∀ᶠ x in 𝓝 (0 : E), partialGradient F (x, θ x) = 0) ∧
      (∀ᶠ p : E × T in 𝓝 0, partialGradient F p = 0 → p.2 = θ p.1) ∧
      (∃ c : ℝ, 0 < c ∧ ∀ᶠ p : E × T in 𝓝 0,
        F p ≤ F (p.1, θ p.1) - c * ‖p.2 - θ p.1‖ ^ 2) ∧
      ((∃ᶠ p : E × T in 𝓝 0, 0 < F p) ↔
        (∃ᶠ x : E in 𝓝 0, 0 < F (x, θ x))) := by
  obtain ⟨θ, hθ, hθ0, hθD, hstat, huniq⟩ :=
    analytic_response_of_negative_partial_hessian F hF hF0 P hP hss
  obtain ⟨c, hc, hdom⟩ := uniform_local_quadratic_domination F hF P hP hss θ hθ.continuousAt hθ0 hstat
  exact ⟨θ, hθ, hθ0, hθD, hstat, huniq, ⟨c, hc, hdom⟩,
    frequently_positive_iff F θ hθ.continuousAt hθ0 c hc.le hdom⟩

end PolynomialGeometry.UniformPartialMaximum
