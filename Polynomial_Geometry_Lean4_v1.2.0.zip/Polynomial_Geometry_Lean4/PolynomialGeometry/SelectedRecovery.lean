import PolynomialGeometry.InverseBasisBridge
import Mathlib.LinearAlgebra.Matrix.SchurComplement

/-! # The selected-source recovery polynomial

The expression G(z)(1+n κ(z,a)) is proved to be the evaluation of an
explicit monic characteristic polynomial. Thus polynomiality and the
degree are established without an asymptotic argument.
-/

noncomputable section
open Matrix Polynomial

namespace PolynomialGeometry.SelectedRecovery

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The recovery polynomial is the characteristic polynomial of an
explicit rank-one perturbation of the critical matrix. -/
def selectedPolynomial (J : Matrix ι ι ℂ) (e h : ι → ℂ) (n : ℂ) : ℂ[X] :=
  (J - n • Matrix.vecMulVec h (star e)).charpoly

/-- The selected kernel column; in the paper h=H⁻¹R*e. -/
def selectedKernel (J : Matrix ι ι ℂ) (e h : ι → ℂ) (z : ℂ) : ℂ :=
  star e ⬝ᵥ ((z • (1 : Matrix ι ι ℂ) - J)⁻¹ *ᵥ h)

/-- At the selected source the kernel is exactly the normalization
already used by the inverse-realization theorem. -/
theorem selectedKernel_at_selected (H J : Matrix ι ι ℂ) (e : ι → ℂ) (a : ℂ) :
    selectedKernel J e
      (Inverse.recoveryVector H (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e) a =
      Inverse.normalization H (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e := rfl

theorem selectedPolynomial_monic (J : Matrix ι ι ℂ) (e h : ι → ℂ) (n : ℂ) :
    (selectedPolynomial J e h n).Monic := Matrix.charpoly_monic _

theorem selectedPolynomial_natDegree (J : Matrix ι ι ℂ) (e h : ι → ℂ) (n : ℂ) :
    (selectedPolynomial J e h n).natDegree = Fintype.card ι :=
  Matrix.charpoly_natDegree_eq_dim _

/-- The scalar form of the matrix determinant lemma. -/
theorem det_add_vecMulVec (A : Matrix ι ι ℂ) (u v : ι → ℂ)
    (hA : IsUnit A.det) :
    (A + Matrix.vecMulVec u v).det = A.det * (1 + v ⬝ᵥ (A⁻¹ *ᵥ u)) := by
  rw [Matrix.vecMulVec_eq Unit, Matrix.det_add_replicateCol_mul_replicateRow hA,
    Matrix.mul_assoc, ← Matrix.replicateCol_mulVec]
  congr 1
  rw [Matrix.det_unique]
  simp only [Matrix.add_apply, Matrix.one_apply_eq,
    Matrix.replicateRow_mul_replicateCol_apply]

/-- Exact recovery-kernel identity away from the critical spectrum. -/
theorem selectedPolynomial_eval (J : Matrix ι ι ℂ) (e h : ι → ℂ) (n z : ℂ)
    (hz : IsUnit (z • (1 : Matrix ι ι ℂ) - J)) :
    (selectedPolynomial J e h n).eval z =
      J.charpoly.eval z * (1 + n * selectedKernel J e h z) := by
  have hupdate : z • (1 : Matrix ι ι ℂ) - (J - n • Matrix.vecMulVec h (star e)) =
      (z • (1 : Matrix ι ι ℂ) - J) + Matrix.vecMulVec (n • h) (star e) := by
    rw [Matrix.smul_vecMulVec]
    module
  simp only [selectedPolynomial, Matrix.eval_charpoly, Matrix.scalar_apply,
    ← Matrix.smul_one_eq_diagonal]
  rw [hupdate, det_add_vecMulVec _ _ _ ((Matrix.isUnit_iff_isUnit_det _).mp hz),
    Matrix.mulVec_smul, dotProduct_smul, smul_eq_mul]
  rfl

/-- The selected normalization gives the paper's Q_a(a)=n G(a). -/
theorem selectedPolynomial_selected_value (J : Matrix ι ι ℂ) (e h : ι → ℂ)
    (n a : ℂ) (hn : n ≠ 0) (ha : IsUnit (a • (1 : Matrix ι ι ℂ) - J))
    (hnorm : selectedKernel J e h a = 1 - n⁻¹) :
    (selectedPolynomial J e h n).eval a = n * J.charpoly.eval a := by
  rw [selectedPolynomial_eval J e h n a ha,
    Inverse.selected_recovery_value n (selectedKernel J e h a) hn hnorm, mul_comm]

/-- Each nonselected cross-source kernel value supplies an actual root
of the monic recovery polynomial. -/
theorem selectedPolynomial_root_of_cross_kernel (J : Matrix ι ι ℂ)
    (e h : ι → ℂ) (n z : ℂ) (hn : n ≠ 0)
    (hz : IsUnit (z • (1 : Matrix ι ι ℂ) - J))
    (hcross : selectedKernel J e h z = -n⁻¹) :
    (selectedPolynomial J e h n).IsRoot z := by
  change (selectedPolynomial J e h n).eval z = 0
  rw [selectedPolynomial_eval J e h n z hz, hcross]
  simp [hn]

/-- The cross-source identities determine the whole monic recovery
polynomial once all nonselected sources are present. -/
theorem selectedPolynomial_eq_prod {σ : Type*} [Fintype σ]
    (J : Matrix ι ι ℂ) (e h : ι → ℂ) (n : ℂ) (hn : n ≠ 0)
    (α : σ → ℂ) (hα : Function.Injective α)
    (hsep : ∀ j, IsUnit (α j • (1 : Matrix ι ι ℂ) - J))
    (hcross : ∀ j, selectedKernel J e h (α j) = -n⁻¹)
    (hdim : Fintype.card σ = Fintype.card ι) :
    selectedPolynomial J e h n = ∏ j : σ, (X - C (α j)) := by
  classical
  apply Polynomial.eq_of_monic_of_dvd_of_natDegree_le
    (Polynomial.monic_prod_X_sub_C α Finset.univ) (selectedPolynomial_monic J e h n)
  · apply Fintype.prod_dvd_of_coprime (Polynomial.pairwise_coprime_X_sub_C hα)
    intro j
    exact Polynomial.dvd_iff_isRoot.mpr
      (selectedPolynomial_root_of_cross_kernel J e h n (α j) hn (hsep j) (hcross j))
  · rw [selectedPolynomial_natDegree, Polynomial.natDegree_prod_of_monic Finset.univ
      (fun j => X - C (α j))
      (fun j _ => Polynomial.monic_X_sub_C (α j))]
    simp [hdim]

/-- The displayed nonselected-source formula of Corollary 3.3, obtained
from the complete cross-source kernel identities. -/
theorem recovery_kernel_product {σ : Type*} [Fintype σ]
    (J : Matrix ι ι ℂ) (e h : ι → ℂ) (n : ℂ) (hn : n ≠ 0)
    (α : σ → ℂ) (hα : Function.Injective α)
    (hsep : ∀ j, IsUnit (α j • (1 : Matrix ι ι ℂ) - J))
    (hcross : ∀ j, selectedKernel J e h (α j) = -n⁻¹)
    (hdim : Fintype.card σ = Fintype.card ι) (z : ℂ)
    (hz : IsUnit (z • (1 : Matrix ι ι ℂ) - J)) :
    J.charpoly.eval z * (1 + n * selectedKernel J e h z) =
      ∏ j : σ, (z - α j) := by
  have hh := selectedPolynomial_eval J e h n z hz
  rw [selectedPolynomial_eq_prod J e h n hn α hα hsep hcross hdim,
    Polynomial.eval_prod] at hh
  simpa using hh.symm

end PolynomialGeometry.SelectedRecovery
