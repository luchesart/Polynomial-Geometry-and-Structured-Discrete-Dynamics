import PolynomialGeometry.IndependentCenteredBlocks

/-!
# Derivatives of an invariant function on independent centered blocks

The objective is already expressed in grouped variables and centered
splittings. Extending the Hessian of one centered block to its full copy
space by subtraction of the mean allows the usual permutation calculation
to determine the scalar on that block.
-/

noncomputable section
open Filter
open scoped Topology
namespace PolynomialGeometry.IndependentBlockConsequences
open IndependentCenteredBlocks SymmetricElimination

variable {J : Type*} [Fintype J] [DecidableEq J]
  (ι : J → Type*) [∀ j, Fintype (ι j)] [∀ j, Nonempty (ι j)] [∀ j, DecidableEq (ι j)]
  {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

section Projection
variable {K : Type*} [Fintype K] [Nonempty K]

/-- Subtract the mean of the full list of real copy coordinates. -/
def centerCopies : (K → ℝ) →L[ℝ] centeredSubspace (ι := K) :=
  LinearMap.toContinuousLinearMap {
    toFun := fun x => ⟨WithLp.toLp 2 (fun i => x i - (∑ k, x k) / Fintype.card K), by
      change (∑ i, (x i - (∑ k, x k) / (Fintype.card K : ℝ))) = 0
      rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
      have hc : (Fintype.card K : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
      field_simp [hc]
      ring⟩
    map_add' := by
      intro x y
      ext i
      change x i + y i - (∑ k, (x k + y k)) / (Fintype.card K : ℝ) =
        (x i - (∑ k, x k) / (Fintype.card K : ℝ)) +
        (y i - (∑ k, y k) / (Fintype.card K : ℝ))
      rw [Finset.sum_add_distrib, add_div]
      ring
    map_smul' := by
      intro c x
      ext i
      change c * x i - (∑ k, c * x k) / (Fintype.card K : ℝ) =
        c * (x i - (∑ k, x k) / (Fintype.card K : ℝ))
      rw [← Finset.mul_sum]
      ring }

/-- Centering commutes with every relabeling of a copy group. -/
theorem centerCopies_permute (σ : Equiv.Perm K) (x : K → ℝ) :
    centerCopies (x ∘ σ) = centeredAction σ (centerCopies x) := by
  ext i
  change x (σ i) - (∑ k, x (σ k)) / (Fintype.card K : ℝ) =
    x (σ i) - (∑ k, x k) / (Fintype.card K : ℝ)
  rw [Equiv.sum_comp]

/-- The centering projection fixes every already centered vector. -/
theorem centerCopies_fixed (s : centeredSubspace (ι := K)) :
    centerCopies (fun i => s.1 i) = s := by
  ext i
  change s.1 i - (∑ k, s.1 k) / (Fintype.card K : ℝ) = s.1 i
  simp [show (∑ k, s.1 k) = 0 from s.2]

end Projection

/-- All first- and second-derivative assertions for an independent
collection of centered copy groups, with arbitrary free variables. -/
structure CenteredDerivatives (F : E × Blocks ι → ℝ) : Prop where
  gradient_zero : ∀ s : Blocks ι, fderiv ℝ F 0 (0,s) = 0
  mixed_free : ∀ (q : E) (s : Blocks ι), fderiv ℝ (fderiv ℝ F) 0 (q,0) (0,s) = 0
  mixed_free_flip : ∀ (q : E) (s : Blocks ι), fderiv ℝ (fderiv ℝ F) 0 (0,s) (q,0) = 0
  mixed_blocks : ∀ (j k : J), j ≠ k →
    ∀ (s : centeredSubspace (ι := ι j)) (t : centeredSubspace (ι := ι k)),
      fderiv ℝ (fderiv ℝ F) 0 (0,inclusion ι j s) (0,inclusion ι k t) = 0
  scalar_blocks : ∃ lam : J → ℝ, ∀ (j : J) (s : centeredSubspace (ι := ι j)),
    fderiv ℝ (fderiv ℝ F) 0 (0,inclusion ι j s) (0,inclusion ι j s) = lam j * ‖s‖ ^ 2

/-- The actual scalar curvatures on the centered blocks follow from
function-level symmetry, including when a group has only one copy. -/
theorem independent_scalar_blocks
    (F : E × Blocks ι → ℝ) (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ g : Group ι, (fun p : E × Blocks ι => F (p.1, action ι g p.2)) =ᶠ[𝓝 0] F) :
    ∃ lam : J → ℝ, ∀ (j : J) (s : centeredSubspace (ι := ι j)),
      fderiv ℝ (fderiv ℝ F) 0 (0,inclusion ι j s) (0,inclusion ι j s) = lam j * ‖s‖ ^ 2 := by
  classical
  suffices h : ∀ (j : J), ∃ c : ℝ, ∀ s : centeredSubspace (ι := ι j),
      fderiv ℝ (fderiv ℝ F) 0 (0,inclusion ι j s) (0,inclusion ι j s) = c * ‖s‖^2 by
    exact ⟨fun j => (h j).choose, fun j => (h j).choose_spec⟩
  intro j
  let I : (ι j → ℝ) →L[ℝ] E × Blocks ι :=
    (ContinuousLinearMap.inr ℝ E (Blocks ι)).comp ((inclusion ι j).comp centerCopies)
  let H := fderiv ℝ (fderiv ℝ F) 0
  let B : (ι j → ℝ) →L[ℝ] (ι j → ℝ) →L[ℝ] ℝ :=
    ((ContinuousLinearMap.compL ℝ (ι j → ℝ) (E × Blocks ι) ℝ).flip I).comp (H.comp I)
  have hrel (σ : Equiv.Perm (ι j)) (x : ι j → ℝ) :
      I (x ∘ σ) = liftedAction ι (Pi.mulSingle j σ) (I x) := by
    change ((0 : E), inclusion ι j (centerCopies (x ∘ σ))) =
      (0, action ι (Pi.mulSingle j σ) (inclusion ι j (centerCopies x)))
    rw [action_inclusion, Pi.mulSingle_eq_same, centerCopies_permute]
  have hinv (σ : Equiv.Perm (ι j)) (x y : ι j → ℝ) :
      B (x ∘ σ) (y ∘ σ) = B x y := by
    change H (I (x ∘ σ)) (I (y ∘ σ)) = H (I x) (I y)
    rw [hrel, hrel]
    exact hessian_invariant F (liftedAction ι (Pi.mulSingle j σ)) hF
      (hsym (Pi.mulSingle j σ)) _ _
  obtain ⟨c,hc⟩ := invariant_quadratic_centered
    ((ContinuousLinearMap.coeLM ℝ).comp B.toLinearMap) hinv
  refine ⟨c, ?_⟩
  intro s
  have h := hc (fun i => s.1 i) s.2
  change H (0,inclusion ι j (centerCopies (fun i => s.1 i)))
    (0,inclusion ι j (centerCopies (fun i => s.1 i))) = _ at h
  rw [centerCopies_fixed] at h
  refine h.trans ?_
  congr 1
  change (∑ i, (s.1 i)^2) = ‖s.1‖^2
  rw [EuclideanSpace.norm_sq_eq]
  apply Finset.sum_congr rfl
  intro i _
  rw [Real.norm_eq_abs, sq_abs]

/-- Relabeling symmetry of the objective itself implies all the claimed
differential and Hessian conclusions. -/
theorem independent_centered_derivatives
    (F : E × Blocks ι → ℝ) (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ g : Group ι, (fun p : E × Blocks ι => F (p.1, action ι g p.2)) =ᶠ[𝓝 0] F) :
    CenteredDerivatives ι F := by
  let H := fderiv ℝ (fderiv ℝ F) 0
  let I := ContinuousLinearMap.inr ℝ E (Blocks ι)
  have mixed (q : E) (s : Blocks ι) : H (q,0) (0,s) = 0 := by
    let L := (H (q,0)).comp I
    have hL : L = 0 := by
      apply invariant_covector_zero (action ι) (action_sum_zero ι) L
      intro g
      ext s
      have h := hessian_invariant F (liftedAction ι g) hF (hsym g) (q,0) (0,s)
      simpa only [liftedAction_apply, map_zero] using h
    exact congrArg (fun T : Blocks ι →L[ℝ] ℝ => T s) hL
  constructor
  · let L := (fderiv ℝ F 0).comp I
    have hL : L = 0 := by
      apply invariant_covector_zero (action ι) (action_sum_zero ι) L
      intro g
      ext s
      exact congrArg (fun T : E × Blocks ι →L[ℝ] ℝ => T (0,s))
        (differential_invariant F (liftedAction ι g) hF.differentiableAt (hsym g))
    intro s
    exact congrArg (fun T : Blocks ι →L[ℝ] ℝ => T s) hL
  · exact mixed
  · intro q s
    have hsymm : IsSymmSndFDerivAt ℝ F 0 := hF.contDiffAt.isSymmSndFDerivAt_of_omega
    exact (hsymm (0,s) (q,0)).trans (mixed q s)
  · exact independent_mixed_hessian_zero ι F hF hsym
  · exact independent_scalar_blocks ι F hF hsym

end PolynomialGeometry.IndependentBlockConsequences
