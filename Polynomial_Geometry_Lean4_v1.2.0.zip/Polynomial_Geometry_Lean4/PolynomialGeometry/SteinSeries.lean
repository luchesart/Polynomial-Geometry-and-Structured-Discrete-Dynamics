import PolynomialGeometry.Stability
import PolynomialGeometry.Dynamics
import Mathlib.Analysis.Normed.Group.InfiniteSum

/-!
# The convergent Stein series and uniqueness

The matrix series is proved absolutely summable from the strict spectral
bound. Its convergence is not supplied as an additional hypothesis.
-/

noncomputable section
open scoped Topology Matrix.Norms.Frobenius
open Matrix Filter

namespace PolynomialGeometry.SteinSeries
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Strict spectral radius makes every Stein series absolutely summable. -/
theorem summable_norm_stein (T D : Matrix ι ι ℂ) (hT : spectralRadius ℂ T < 1) :
    Summable (fun k : ℕ => ‖(Tᴴ)^k * D * T^k‖) := by
  obtain ⟨r, hr, hr1, hb⟩ := Stability.power_norm_eventually_geometric T hT
  have hsum : Summable (fun k : ℕ => ‖D‖ * (r^2)^k) :=
    (summable_geometric_of_lt_one (sq_nonneg r) (by nlinarith)).mul_left _
  apply hsum.of_norm_bounded_eventually_nat
  filter_upwards [hb] with k hk
  rw [Real.norm_eq_abs, abs_of_nonneg (norm_nonneg _)]
  calc
    ‖(Tᴴ)^k * D * T^k‖ ≤ (‖(Tᴴ)^k‖ * ‖D‖) * ‖T^k‖ :=
      (norm_mul_le _ _).trans (mul_le_mul_of_nonneg_right (norm_mul_le _ _) (norm_nonneg _))
    _ = (‖T^k‖ * ‖D‖) * ‖T^k‖ := by
      rw [← Matrix.conjTranspose_pow, Matrix.frobenius_norm_conjTranspose]
    _ ≤ (r^k * ‖D‖) * r^k := by gcongr
    _ = ‖D‖ * (r^2)^k := by rw [pow_right_comm r 2 k, pow_two]; ring

/-- A solution of the Stein equation equals its infinite loss Gramian. -/
theorem hasSum_stein (H T D : Matrix ι ι ℂ) (hT : spectralRadius ℂ T < 1)
    (heq : H - Tᴴ * H * T = D) :
    HasSum (fun k : ℕ => (Tᴴ)^k * D * T^k) H := by
  apply (hasSum_iff_tendsto_nat_of_summable_norm (summable_norm_stein T D hT)).mpr
  have hp := Stability.powers_tendsto_zero T hT
  have hpc : Tendsto (fun k : ℕ => (Tᴴ)^k) atTop (𝓝 0) := by
    simpa [Function.comp_def] using
      (continuous_id.matrix_conjTranspose.tendsto (0 : Matrix ι ι ℂ)).comp hp
  have hrem : Tendsto (fun k : ℕ => (Tᴴ)^k * H * T^k) atTop (𝓝 0) := by
    simpa using (hpc.mul_const H).mul hp
  have hs (N : ℕ) : (∑ k ∈ Finset.range N, (Tᴴ)^k * D * T^k) =
      H - (Tᴴ)^N * H * T^N := by
    rw [← heq]
    exact Dynamics.stein_sum H T N
  simp_rw [hs]
  simpa using tendsto_const_nhds.sub hrem

/-- Uniqueness holds among all complex matrix solutions, not only Hermitian ones. -/
theorem solution_unique (H K T D : Matrix ι ι ℂ) (hT : spectralRadius ℂ T < 1)
    (hH : H - Tᴴ * H * T = D) (hK : K - Tᴴ * K * T = D) : H = K :=
  (hasSum_stein H T D hT hH).unique (hasSum_stein K T D hT hK)

/-- The exact infinite series and uniqueness conclusion of Theorem 3.1. -/
theorem series_and_unique (H T D : Matrix ι ι ℂ) (hT : spectralRadius ℂ T < 1)
    (hH : H - Tᴴ * H * T = D) :
    (∑' k : ℕ, (Tᴴ)^k * D * T^k) = H ∧
      ∀ K, K - Tᴴ * K * T = D → K = H :=
  ⟨(hasSum_stein H T D hT hH).tsum_eq, fun K hK => solution_unique K H T D hT hK hH⟩

end PolynomialGeometry.SteinSeries
