import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.Tactic

/-! # A Gram factor with the minimal number of rows

The construction retains only the nonzero eigenvalues of a positive semidefinite
complex matrix. This supplies the attainability part of the minimum loss-channel
count in the energy and observability theorem.
-/

open Matrix
open scoped BigOperators ComplexConjugate ComplexOrder

noncomputable section
namespace PolynomialGeometry.GramFactorization
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- A square-root diagonal factor with its zero rows removed. -/
def diagonalFactor (ev : ι → ℝ) : Matrix {j // ev j ≠ 0} ι ℂ :=
  fun i j => if i.val = j then (Real.sqrt (ev j) : ℂ) else 0

/-- Deleting the zero rows preserves the exact diagonal Gram matrix. -/
theorem diagonalFactor_gram (ev : ι → ℝ) (hev : ∀ j, 0 ≤ ev j) :
    (diagonalFactor ev)ᴴ * diagonalFactor ev = diagonal (fun j => (ev j : ℂ)) := by
  ext i j
  simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, diagonalFactor]
  by_cases hi : ev i ≠ 0
  · rw [Finset.sum_eq_single (⟨i,hi⟩ : {j // ev j ≠ 0})]
    · by_cases hij : i = j
      · subst j
        simp only [↓reduceIte, Complex.star_def, Complex.conj_ofReal,
          Matrix.diagonal_apply_eq]
        rw [← Complex.ofReal_mul, Real.mul_self_sqrt (hev i)]
      · simp [hij]
    · intro k _ hki
      have hne : k.val ≠ i := fun he => hki (Subtype.ext he)
      simp [hne]
    · simp
  · have he : (∑ k : {j // ev j ≠ 0}, star (if k.val = i then
        (Real.sqrt (ev i) : ℂ) else 0) *
        (if k.val = j then (Real.sqrt (ev j) : ℂ) else 0)) = 0 := by
      apply Finset.sum_eq_zero
      intro k _
      have hne : k.val ≠ i := by
        intro he
        exact k.property (he ▸ not_ne_iff.mp hi)
      simp [hne]
    rw [he]
    by_cases hij : i = j
    · subst j; simp [not_ne_iff.mp hi]
    · simp [hij]

/-- The number of nonzero eigenvalues of a positive semidefinite matrix is its rank. -/
theorem rank_eq_eigenvalue_support (D : Matrix ι ι ℂ) (hD : D.PosSemidef) :
    D.rank = Fintype.card {j // hD.isHermitian.eigenvalues j ≠ 0} := by
  classical
  let U := hD.isHermitian.eigenvectorUnitary
  have hU : IsUnit (U : Matrix ι ι ℂ) := ⟨unitary.toUnits U, rfl⟩
  have hsU : IsUnit (star (U : Matrix ι ι ℂ)) := hU.star
  conv_lhs => rw [hD.isHermitian.spectral_theorem]
  rw [Matrix.rank_mul_eq_left_of_isUnit_det _ _ ((Matrix.isUnit_iff_isUnit_det _).mp hsU),
    Matrix.rank_mul_eq_right_of_isUnit_det _ _ ((Matrix.isUnit_iff_isUnit_det _).mp hU)]
  simpa only [Function.comp_apply, RCLike.ofReal_eq_complex_ofReal, Complex.ofReal_ne_zero]
    using Matrix.rank_diagonal (fun j => (hD.isHermitian.eigenvalues j : ℂ))

/-- Every positive semidefinite complex matrix has an exact Gram factor with
precisely its rank many rows. No factorization or eigenbasis is assumed. -/
theorem exists_gram_factor_rank (D : Matrix ι ι ℂ) (hD : D.PosSemidef) :
    ∃ C : Matrix (Fin D.rank) ι ℂ, Cᴴ * C = D := by
  classical
  let ev := hD.isHermitian.eigenvalues
  let U : Matrix ι ι ℂ := hD.isHermitian.eigenvectorUnitary
  let B := diagonalFactor ev * Uᴴ
  have hB : Bᴴ * B = D := by
    dsimp only [B]
    rw [Matrix.conjTranspose_mul, Matrix.conjTranspose_conjTranspose]
    calc
      _ = U * ((diagonalFactor ev)ᴴ * diagonalFactor ev) * Uᴴ := by
        simp only [Matrix.mul_assoc]
      _ = U * diagonal (fun j => (ev j : ℂ)) * Uᴴ := by
        rw [diagonalFactor_gram ev hD.eigenvalues_nonneg]
      _ = D := by
        simpa only [U, ev, Function.comp_apply, Matrix.star_eq_conjTranspose,
          RCLike.ofReal_eq_complex_ofReal] using hD.isHermitian.spectral_theorem.symm
  have hcard : Fintype.card {j // ev j ≠ 0} = D.rank :=
    (rank_eq_eigenvalue_support D hD).symm
  let e := Fintype.equivFinOfCardEq hcard
  refine ⟨B.submatrix e.symm id, ?_⟩
  rw [Matrix.conjTranspose_submatrix, Matrix.submatrix_mul_equiv,
    Matrix.submatrix_id_id, hB]

/-- A positive semidefinite matrix is positive definite exactly when it has full rank. -/
theorem posDef_iff_rank_eq_card (D : Matrix ι ι ℂ) (hD : D.PosSemidef) :
    D.PosDef ↔ D.rank = Fintype.card ι := by
  classical
  constructor
  · intro hp
    exact Matrix.rank_of_isUnit D hp.isUnit
  · intro hr
    apply hD.isHermitian.posDef_iff_eigenvalues_pos.mpr
    intro j
    by_contra hj
    have he : hD.isHermitian.eigenvalues j = 0 :=
      le_antisymm (le_of_not_gt hj) (hD.eigenvalues_nonneg j)
    have hlt : Fintype.card {j // hD.isHermitian.eigenvalues j ≠ 0} <
        Fintype.card ι := by
      apply Fintype.card_lt_of_injective_of_notMem
        (fun k : {j // hD.isHermitian.eigenvalues j ≠ 0} => (k : ι))
        Subtype.coe_injective (b := j)
      rintro ⟨k, hk⟩
      exact k.property (by simpa only [hk] using he)
    rw [← rank_eq_eigenvalue_support D hD, hr] at hlt
    exact Nat.lt_irrefl _ hlt

/-- The rank is exactly the smallest number of channels in any exact Gram factor. -/
theorem rank_isLeast_gram_row_count (D : Matrix ι ι ℂ) (hD : D.PosSemidef) :
    IsLeast {q : ℕ | ∃ C : Matrix (Fin q) ι ℂ, Cᴴ * C = D} D.rank := by
  refine ⟨exists_gram_factor_rank D hD, ?_⟩
  intro q hq
  obtain ⟨C, hC⟩ := hq
  rw [← hC, Matrix.rank_conjTranspose_mul_self]
  simpa only [Fintype.card_fin] using Matrix.rank_le_card_height C

end PolynomialGeometry.GramFactorization
