import PolynomialGeometry.FiniteSourceObservation
import PolynomialGeometry.FiniteHorizonVandermonde
import Mathlib.LinearAlgebra.Matrix.ZPow

/-! # Exact horizon of the grouped polynomial transition
The matrices in the statements below are the metric and the transition of
the source article. No assumed similarity or Blaschke defect-index theorem
is needed for the finite-horizon transfer.
-/

noncomputable section
open Matrix Complex
open scoped BigOperators ComplexOrder
open PolynomialGeometry.Geometry PolynomialGeometry.SourceRank
open PolynomialGeometry.SourceDynamics
namespace PolynomialGeometry.FiniteHorizon
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

private theorem finiteSourceRows_zero (s : Finset ι) (u z x : ι → ℂ) (t : ℕ) :
    finiteSourceRows s (star u) z t *ᵥ x = 0 ↔
      (∀ j ∈ s, x j = 0) ∧ ∀ k < t, sourceMoment u z x k = 0 := by
  have hi (i : s) : (finiteSourceRows s (star u) z t *ᵥ x) (.inl i) = x i := by
    change (∑ j, (if i.val = j then (1 : ℂ) else 0) * x j) = _
    rw [Finset.sum_eq_single i.val]
    · simp
    · intro j _ hji
      simp [Ne.symm hji]
    · simp
  have hk (k : Fin t) : (finiteSourceRows s (star u) z t *ᵥ x) (.inr k) =
      sourceMoment u z x k := rfl
  constructor
  · intro hz
    exact ⟨fun j hj => (hi ⟨j,hj⟩).symm.trans (congrFun hz (.inl ⟨j,hj⟩)),
      fun k hk' => (hk ⟨k,hk'⟩).symm.trans (congrFun hz (.inr ⟨k,hk'⟩))⟩
  · rintro ⟨hv,hm⟩
    funext i
    cases i with
    | inl i => exact (hi i).trans (hv i i.property)
    | inr k => exact (hk k).trans (hm k k.isLt)

private theorem record_rank (a : ℝ) (u α : ι → ℂ) (ha₀ : 0 ≤ a) (ha₁ : a < 1)
    (hu : ∀ j, u j ≠ 0) (hsep : ∀ j, (a : ℂ) ≠ α j)
    (hinj : Function.Injective α) (h : ℕ) :
    (finiteRecord (expansive a u (sourceResolvent a α)) (sourceLossFactor a u α)
      (h+1)).rank = (interiorSet α).card + min (h+2) (interiorSet α)ᶜ.card := by
  let O := finiteRecord (expansive a u (sourceResolvent a α)) (sourceLossFactor a u α) (h+1)
  let V := finiteSourceRows (interiorSet α) (star u) (sourceNode a α) (h+2)
  have hk : LinearMap.ker O.mulVecLin = LinearMap.ker V.mulVecLin := by
    ext x
    change (_ *ᵥ x = 0) ↔ (_ *ᵥ x = 0)
    rw [source_record_zero a u α ha₀ ha₁ hsep, finiteSourceRows_zero]
    simp only [Nat.lt_succ_iff]
  have hr := O.mulVecLin.finrank_range_add_finrank_ker
  have hs := V.mulVecLin.finrank_range_add_finrank_ker
  rw [hk] at hr
  have hrank : O.rank = V.rank := by
    change Module.finrank ℂ (LinearMap.range O.mulVecLin) =
      Module.finrank ℂ (LinearMap.range V.mulVecLin)
    omega
  change O.rank = _
  rw [hrank]
  apply finiteSourceRows_rank
  · intro j _
    exact star_ne_zero.mpr (hu j)
  · intro p _ q _ he
    have hc : (diskCoefficient a : ℂ) ≠ 0 := by exact_mod_cast (diskCoefficient_pos ha₀ ha₁).ne'
    apply hinj
    exact sub_right_injective (inv_injective (mul_left_cancel₀ hc (add_left_cancel he)))

private theorem expansive_gram (a : ℝ) (u α : ι → ℂ) (ha₀ : 0 ≤ a) (ha₁ : a < 1)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1) (h : ℕ) :
    let S := expansive a u (sourceResolvent a α)
    let O := finiteRecord S (sourceLossFactor a u α) h
    Oᴴ * O = (S^h)ᴴ * metric u * S^h - metric u := by
  let S := expansive a u (sourceResolvent a α)
  have hC := sourceLossFactor_gram a u α ha₀ ha₁ hsep hdisk
  have hf : Dynamics.defect (-(metric u)) S =
      (sourceLossFactor a u α)ᴴ * sourceLossFactor a u α := by
    rw [hC, Dynamics.defect]
    dsimp only [S]
    simp only [mul_neg, neg_mul, sub_neg_eq_add]
    abel
  have hg := finiteRecord_gram (-(metric u)) S (sourceLossFactor a u α) hf h
  dsimp only
  rw [hg]
  simp only [mul_neg, neg_mul, sub_neg_eq_add]
  abel

/-- The actual finite source-metric defect, factored at every horizon. -/
theorem source_power_gram (a : ℝ) (u α : ι → ℂ) (ha₀ : 0 ≤ a) (ha₁ : a < 1)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1) (h : ℕ) :
    let O := finiteRecord (expansive a u (sourceResolvent a α)) (sourceLossFactor a u α) h
    let B := transition a u α ^ h
    (O * B)ᴴ * (O * B) = metric u - Bᴴ * metric u * B := by
  let S := expansive a u (sourceResolvent a α)
  let O := finiteRecord S (sourceLossFactor a u α) h
  have hS : IsUnit S := source_expansive_isUnit a u α ha₀ ha₁ hsep hdisk
  change (O * S⁻¹ ^ h)ᴴ * (O * S⁻¹ ^ h) = _
  change _ = metric u - (S⁻¹ ^ h)ᴴ * metric u * S⁻¹ ^ h
  rw [Matrix.inv_pow', inverse_defect _ (S^h) (hS.pow h), Matrix.conjTranspose_mul]
  have hg : Oᴴ * O = (S^h)ᴴ * metric u * S^h - metric u :=
    expansive_gram a u α ha₀ ha₁ hsep hdisk h
  rw [← hg]
  simp only [Matrix.mul_assoc]

/-- Explicit zero-defect states in the source coordinates of the transition.
The moments are evaluated at the preimage under the expansive power. -/
theorem source_power_defect_zero_iff (a : ℝ) (u α x : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hsep : ∀ j, (a : ℂ) ≠ α j)
    (hdisk : ∀ j, normSq (α j) ≤ 1) {h : ℕ} (hh : 0 < h) :
    (metric u - (transition a u α ^ h)ᴴ * metric u * transition a u α ^ h) *ᵥ x = 0 ↔
      (∀ j ∈ interiorSet α, (transition a u α ^ h *ᵥ x) j = 0) ∧
      ∀ k ≤ h, sourceMoment u (sourceNode a α) (transition a u α ^ h *ᵥ x) k = 0 := by
  obtain ⟨k,rfl⟩ := Nat.exists_eq_succ_of_ne_zero hh.ne'
  rw [← source_power_gram a u α ha₀ ha₁ hsep hdisk,
    Matrix.conjTranspose_mul_self_mulVec_eq_zero, ← Matrix.mulVec_mulVec]
  exact source_record_zero a u α ha₀ ha₁ hsep k _

/-- At every positive horizon the rank is the number of interior sources
plus the smaller of the number of boundary sources and the number of moments. -/
theorem source_power_defect_rank (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) {h : ℕ} (hh : 0 < h) :
    (metric u - (transition a u α ^ h)ᴴ * metric u * transition a u α ^ h).rank =
      (interiorSet α).card + min (h+1) (interiorSet α)ᶜ.card := by
  obtain ⟨k,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hh)
  let S := expansive a u (sourceResolvent a α)
  have hs : IsUnit S := source_expansive_isUnit a u α ha₀ ha₁ hsep hdisk
  have hT : IsUnit (transition a u α ^ (k+1)) :=
    (Matrix.isUnit_nonsing_inv_iff.mpr hs).pow _
  rw [← source_power_gram a u α ha₀ ha₁ hsep hdisk, Matrix.rank_conjTranspose_mul_self,
    Matrix.rank_mul_eq_left_of_isUnit_det _ _ ((Matrix.isUnit_iff_isUnit_det _).mp hT)]
  exact record_rank a u α ha₀ ha₁ hu hsep hinj k

/-- Number of state directions still invisible after the prescribed number of steps. -/
theorem source_power_defect_nullity (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) {h : ℕ} (hh : 0 < h) :
    let W := metric u - (transition a u α ^ h)ᴴ * metric u * transition a u α ^ h
    Module.finrank ℂ (LinearMap.ker W.mulVecLin) = (interiorSet α)ᶜ.card - (h+1) := by
  let W := metric u - (transition a u α ^ h)ᴴ * metric u * transition a u α ^ h
  have hd := W.mulVecLin.finrank_range_add_finrank_ker
  change W.rank + Module.finrank ℂ (LinearMap.ker W.mulVecLin) = _ at hd
  have hr : W.rank = _ := source_power_defect_rank a u α ha₀ ha₁ hu hsep hdisk hinj hh
  rw [hr, Module.finrank_fintype_fun_eq_card] at hd
  change Module.finrank ℂ (LinearMap.ker W.mulVecLin) = _
  have hc := Finset.card_add_card_compl (interiorSet α)
  omega

/-- Minimum number of complex scalar measurements in any exact factor
of the source-metric power defect. -/
theorem source_power_minimum_loss_channels (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) {h : ℕ} (hh : 0 < h) :
    IsLeast {q : ℕ | ∃ C : Matrix (Fin q) ι ℂ, Cᴴ * C =
      metric u - (transition a u α ^ h)ᴴ * metric u * transition a u α ^ h}
      ((interiorSet α).card + min (h+1) (interiorSet α)ᶜ.card) := by
  rw [← source_power_defect_rank a u α ha₀ ha₁ hu hsep hdisk hinj hh]
  apply GramFactorization.rank_isLeast_gram_row_count
  rw [← source_power_gram a u α ha₀ ha₁ hsep hdisk]
  exact Matrix.posSemidef_conjTranspose_mul_self _

theorem source_power_defect_posDef_iff (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) {h : ℕ} (hh : 0 < h) :
    (metric u - (transition a u α ^ h)ᴴ * metric u * transition a u α ^ h).PosDef ↔
      (interiorSet α)ᶜ.card ≤ h + 1 := by
  have hps : (metric u - (transition a u α ^ h)ᴴ * metric u *
      transition a u α ^ h).PosSemidef := by
    rw [← source_power_gram a u α ha₀ ha₁ hsep hdisk]
    exact Matrix.posSemidef_conjTranspose_mul_self _
  rw [GramFactorization.posDef_iff_rank_eq_card _ hps,
    source_power_defect_rank a u α ha₀ ha₁ hu hsep hdisk hinj hh]
  have hc := Finset.card_add_card_compl (interiorSet α)
  omega

/-- Exact least strictly positive horizon, including zero or one boundary position. -/
theorem source_least_positive_horizon (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) :
    IsLeast {h : ℕ | 0 < h ∧
      (metric u - (transition a u α ^ h)ᴴ * metric u * transition a u α ^ h).PosDef}
      (max 1 ((interiorSet α)ᶜ.card - 1)) := by
  constructor
  · refine ⟨by omega, ?_⟩
    apply (source_power_defect_posDef_iff a u α ha₀ ha₁ hu hsep hdisk hinj (by omega)).mpr
    omega
  · intro h hh
    obtain ⟨hpos,hpd⟩ := hh
    have := (source_power_defect_posDef_iff a u α ha₀ ha₁ hu hsep hdisk hinj hpos).mp hpd
    omega

/-- The exact rank and least positive horizon with the article's arbitrary
positive real source masses (the selected mass is one). -/
theorem positive_mass_source_horizon (a : ℝ) (ν : ι → ℝ) (α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hν : ∀ j, 0 < ν j)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) :
    let u : ι → ℂ := fun j => (Real.sqrt (ν j) : ℂ)
    (∀ h : ℕ, 0 < h → (metric u - (transition a u α ^ h)ᴴ * metric u *
        transition a u α ^ h).rank =
        (interiorSet α).card + min (h+1) (interiorSet α)ᶜ.card) ∧
    IsLeast {h : ℕ | 0 < h ∧ (metric u - (transition a u α ^ h)ᴴ * metric u *
        transition a u α ^ h).PosDef} (max 1 ((interiorSet α)ᶜ.card - 1)) := by
  let u : ι → ℂ := fun j => (Real.sqrt (ν j) : ℂ)
  have hu (j : ι) : u j ≠ 0 := by
    dsimp [u]
    exact_mod_cast (Real.sqrt_pos.mpr (hν j)).ne'
  exact ⟨fun _ hh => source_power_defect_rank a u α ha₀ ha₁ hu hsep hdisk hinj hh,
    source_least_positive_horizon a u α ha₀ ha₁ hu hsep hdisk hinj⟩

end PolynomialGeometry.FiniteHorizon
