import PolynomialGeometry.Inverse
import PolynomialGeometry.CompressionDet

noncomputable section
open scoped BigOperators Matrix
open Matrix Polynomial

namespace PolynomialGeometry.InverseCofactor

variable {ι R : Type*} [Fintype ι] [DecidableEq ι] [CommRing R]

/-- The distinguished cofactor of an option-indexed matrix is the entire
state-block determinant, for an arbitrary finite state index. -/
theorem adjugate_none_none (A : Matrix (Option ι) (Option ι) R) :
    A.adjugate none none = (A.submatrix Option.some Option.some).det := by
  let f : Fin (Fintype.card ι + 1) ≃ Option ι :=
    (finSuccEquiv (Fintype.card ι)).trans (Equiv.optionCongr (Fintype.equivFin ι).symm)
  have h := Matrix.adjugate_fin_succ_eq_det_submatrix (A.submatrix f f) 0 0
  rw [Matrix.adjugate_submatrix_equiv_self] at h
  simp only [f, Equiv.trans_apply, Matrix.submatrix_apply, finSuccEquiv_zero,
    Fin.val_zero, add_zero, pow_zero, one_mul, Fin.succAbove_zero,
    Matrix.submatrix_submatrix, Function.comp_def, finSuccEquiv_succ] at h
  change A.adjugate none none =
    ((A.submatrix Option.some Option.some).submatrix
      (Fintype.equivFin ι).symm (Fintype.equivFin ι).symm).det at h
  rwa [Matrix.det_submatrix_equiv_self] at h

omit [Fintype ι] in
/-- Deleting the distinguished row and column of a completed resolvent
matrix leaves exactly `zI-J`. -/
theorem completion_resolvent_minor (J : Matrix ι ι ℂ) (e d : ι → ℂ) (γ z : ℂ) :
    ((z • (1 : Matrix (Option ι) (Option ι) ℂ) - BlockMetric.completion J e γ d).submatrix
      Option.some Option.some) = z • (1 : Matrix ι ι ℂ) - J := by
  ext i j
  simp [BlockMetric.completion, Matrix.submatrix_apply, Matrix.one_apply]

/-- Exact scalar cofactor formula for the actual normalized border. The
identity uses Lean's zero-totalized inverse and is valid even at poles. -/
theorem completion_resolvent_entry (J : Matrix ι ι ℂ) (e d : ι → ℂ) (γ z : ℂ) :
    (z • (1 : Matrix (Option ι) (Option ι) ℂ) - BlockMetric.completion J e γ d)⁻¹ none none =
      J.charpoly.eval z / (BlockMetric.completion J e γ d).charpoly.eval z := by
  rw [Matrix.inv_def]
  simp only [Matrix.smul_apply, smul_eq_mul, Ring.inverse_eq_inv]
  rw [adjugate_none_none, completion_resolvent_minor]
  simp only [Matrix.eval_charpoly, Matrix.scalar_apply, ← Matrix.smul_one_eq_diagonal,
    div_eq_mul_inv]
  ring

/-- The arbitrary finite state block has the weighted source numerator as
its characteristic polynomial under any invertible source coordinates. -/
theorem charpoly_source_block (α : Option ι → R)
    (U V : Matrix (Option ι) (Option ι) R)
    (hUV : U * V = 1) (hVU : V * U = 1) :
    ((V * Matrix.diagonal α * U).submatrix Option.some Option.some).charpoly =
      ∑ j, C (V none j * U j none) *
        ∏ k ∈ Finset.univ.erase j, (X - C (α k)) := by
  have hUVc : U.map C * V.map C = (1 : Matrix (Option ι) (Option ι) R[X]) := by
    rw [← Matrix.map_mul]
    simp [hUV]
  have hVUc : V.map C * U.map C = (1 : Matrix (Option ι) (Option ι) R[X]) := by
    rw [← Matrix.map_mul]
    simp [hVU]
  have hminor (M : Matrix (Option ι) (Option ι) R) :
      M.charmatrix.adjugate none none = (M.submatrix Option.some Option.some).charpoly := by
    rw [adjugate_none_none]
    congr 1
    ext i j
    by_cases hij : i = j
    · subst j; simp
    · simp [hij]
  rw [← hminor, CompressionDet.charmatrix_conjugation _ _ _ hVU,
    CompressionDet.adjugate_conjugation _ _ _ hUVc hVUc,
    Matrix.charmatrix_diagonal, Matrix.adjugate_diagonal, Matrix.mul_apply]
  simp only [Matrix.mul_diagonal, Matrix.map_apply]
  apply Finset.sum_congr rfl
  intro j _
  rw [map_mul]
  ring

/-- The scalar source-function identity, with the complete state-block
characteristic polynomial. It holds wherever source denominators are nonzero. -/
theorem source_function_from_similarity (α ν : Option ι → ℂ) (n : ℂ)
    (U V : Matrix (Option ι) (Option ι) ℂ) (J : Matrix ι ι ℂ)
    (hUV : U * V = 1) (hVU : V * U = 1)
    (hstate : (V * Matrix.diagonal α * U).submatrix Option.some Option.some = J)
    (hweights : ∀ j, n * (V none j * U j none) = ν j)
    (z : ℂ) (hsep : ∀ j, z ≠ α j) :
    (∑ j, ν j / (z - α j)) =
      n * J.charpoly.eval z / (∏ j : Option ι, (z - α j)) := by
  have hp := charpoly_source_block α U V hUV hVU
  rw [hstate] at hp
  have heq : Source.rawNumerator Finset.univ α ν = C n * J.charpoly := by
    rw [hp, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j _
    change C (ν j) * Source.support (Finset.univ.erase j) α =
      C n * (C (V none j * U j none) * Source.support (Finset.univ.erase j) α)
    rw [← mul_assoc, ← C_mul, hweights]
  have hf := Source.rawNumerator_eq_support_mul_sourceFunction
    Finset.univ α ν z (fun j _ => hsep j)
  rw [heq, Polynomial.eval_mul, Polynomial.eval_C, Source.support_eval] at hf
  have hprod : (∏ j : Option ι, (z - α j)) ≠ 0 :=
    Finset.prod_ne_zero_iff.mpr (fun j _ => sub_ne_zero.mpr (hsep j))
  apply (eq_div_iff hprod).mpr
  simpa only [Source.sourceFunction, mul_comm] using hf.symm

/-- The actual square source/state coordinate matrix. -/
def sourceBasis (b : Option ι → ℂ) (Y : Matrix (Option ι) ι ℂ) :
    Matrix (Option ι) (Option ι) ℂ := fun j k => k.elim (b j) (Y j)

omit [DecidableEq ι] in
theorem sourceBasis_mulVec (b : Option ι → ℂ) (Y : Matrix (Option ι) ι ℂ)
    (x : Option ι → ℂ) :
    (sourceBasis b Y).mulVec x =
      Confluent.sourceSynthesis b Y (BlockMetric.coordinates x) := by
  funext j
  simp [sourceBasis, Matrix.mulVec, dotProduct, Fintype.sum_option,
    Confluent.sourceSynthesis, BlockMetric.coordinates, mul_comm]

theorem sourceBasis_isUnit (b : Option ι → ℂ) (Y : Matrix (Option ι) ι ℂ)
    (hY : Function.Injective Y.mulVec) (hn : star b ⬝ᵥ b ≠ 0)
    (horth : ∀ x, star b ⬝ᵥ Y.mulVec x = 0) : IsUnit (sourceBasis b Y) := by
  apply Matrix.mulVec_injective_iff_isUnit.mp
  intro x y hxy
  simp only [sourceBasis_mulVec] at hxy
  exact BlockMetric.coordinates.injective
    (Confluent.sourceSynthesis_injective b Y hY hn horth hxy)

theorem sourceBasis_output (b : Option ι → ℂ) (Y : Matrix (Option ι) ι ℂ)
    (horth : star b ᵥ* Y = 0) :
    star b ᵥ* sourceBasis b Y = Pi.single none (star b ⬝ᵥ b) := by
  funext k
  cases k with
  | none => simp [sourceBasis, Matrix.vecMul, dotProduct]
  | some i =>
    have hi := congrFun horth i
    simpa [sourceBasis, Matrix.vecMul, dotProduct] using hi

theorem sourceBasis_inverse_weights (b : Option ι → ℂ) (Y : Matrix (Option ι) ι ℂ)
    (V : Matrix (Option ι) (Option ι) ℂ) (hUV : sourceBasis b Y * V = 1)
    (horth : star b ᵥ* Y = 0) (j : Option ι) :
    (star b ⬝ᵥ b) * (V none j * sourceBasis b Y j none) = star (b j) * b j := by
  have h := Matrix.vecMul_vecMul (star b) (sourceBasis b Y) V
  rw [hUV, Matrix.vecMul_one, sourceBasis_output b Y horth] at h
  have hj := congrFun h j
  simp only [Matrix.vecMul, dotProduct, Pi.single_apply, ite_mul, zero_mul,
    Finset.sum_ite_eq', Finset.mem_univ, ite_true] at hj
  change (star b ⬝ᵥ b) * V none j = star (b j) at hj
  change (star b ⬝ᵥ b) * (V none j * b j) = star (b j) * b j
  rw [← mul_assoc, hj]

end PolynomialGeometry.InverseCofactor
