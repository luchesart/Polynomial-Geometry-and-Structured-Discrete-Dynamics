import PolynomialGeometry.Variations
import PolynomialGeometry.SchurHessian
import Mathlib.Analysis.InnerProductSpace.PiL2

/-!
# Nonlinear permutation symmetry and splitting blocks

Function-level local invariance is differentiated twice. Thus the Hessian
identities below concern the actual objective, rather than an independent
matrix whose exchangeability is assumed.
-/

noncomputable section
open Filter
open scoped Topology

namespace PolynomialGeometry.SymmetricElimination

section Derivatives
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Local invariance under a linear action passes to the actual differential. -/
theorem differential_invariant (f : E → ℝ) (L : E →L[ℝ] E)
    (hf : DifferentiableAt ℝ f 0)
    (hsym : (fun x => f (L x)) =ᶠ[𝓝 0] f) :
    (fderiv ℝ f 0).comp L = fderiv ℝ f 0 := by
  have hfL : HasFDerivAt f (fderiv ℝ f 0) (L 0) := by simpa using hf.hasFDerivAt
  have hd := hfL.comp (0 : E) L.hasFDerivAt
  exact (hd.congr_of_eventuallyEq hsym.symm).unique hf.hasFDerivAt

/-- Differentiating the same local symmetry twice gives Hessian invariance. -/
theorem hessian_invariant (f : E → ℝ) (L : E →L[ℝ] E)
    (hf : AnalyticAt ℝ f 0)
    (hsym : (fun x => f (L x)) =ᶠ[𝓝 0] f) (u v : E) :
    fderiv ℝ (fderiv ℝ f) 0 (L u) (L v) =
      fderiv ℝ (fderiv ℝ f) 0 u v := by
  let P : (E →L[ℝ] ℝ) →L[ℝ] (E →L[ℝ] ℝ) :=
    (ContinuousLinearMap.compL ℝ E E ℝ).flip L
  have hnear : (fun x => P (fderiv ℝ f (L x))) =ᶠ[𝓝 0] fderiv ℝ f := by
    have hdiff : ∀ᶠ x in 𝓝 (0 : E), AnalyticAt ℝ f (L x) := by
      exact L.continuous.continuousAt.eventually (by simpa using hf.eventually_analyticAt)
    have hh := hsym.fderiv (𝕜 := ℝ)
    filter_upwards [hdiff, hh] with x hx he
    change (fderiv ℝ f (L x)).comp L = fderiv ℝ f x
    rw [← (hx.differentiableAt.hasFDerivAt.comp x L.hasFDerivAt).fderiv]
    exact he
  have hD := hf.fderiv.differentiableAt.hasFDerivAt
  have hDL : HasFDerivAt (fun x => fderiv ℝ f (L x))
      ((fderiv ℝ (fderiv ℝ f) 0).comp L) 0 := by
    have hDL0 : HasFDerivAt (fderiv ℝ f) (fderiv ℝ (fderiv ℝ f) 0) (L 0) := by
      simpa using hD
    exact hDL0.comp (0 : E) L.hasFDerivAt
  have hp := P.hasFDerivAt.comp 0 hDL
  have heq := (hp.congr_of_eventuallyEq hnear.symm).unique hD
  exact congrArg (fun B => B u v) heq
end Derivatives

section Copies
variable {ι : Type*} [Fintype ι] [Nonempty ι]

/-- Permutation of real copy coordinates. -/
def permute (σ : Equiv.Perm ι) : (ι → ℝ) →L[ℝ] (ι → ℝ) :=
  ContinuousLinearMap.pi fun i => ContinuousLinearMap.proj (σ i)

omit [Fintype ι] [Nonempty ι] in
@[simp] theorem permute_apply (σ : Equiv.Perm ι) (x : ι → ℝ) :
    permute σ x = x ∘ σ := rfl

/-- At a collision the true gradient vanishes in every centered direction. -/
theorem centered_gradient_zero (f : (ι → ℝ) → ℝ)
    (hf : DifferentiableAt ℝ f 0)
    (hsym : ∀ σ : Equiv.Perm ι, (fun x => f (x ∘ σ)) =ᶠ[𝓝 0] f)
    (x : ι → ℝ) (hx : ∑ i, x i = 0) : fderiv ℝ f 0 x = 0 := by
  apply Variations.invariant_linear_vanishes_centered (fderiv ℝ f 0).toLinearMap _ x hx
  intro σ y
  exact congrArg (fun L : (ι → ℝ) →L[ℝ] ℝ => L y)
    (differential_invariant f (permute σ) hf (hsym σ))

omit [Fintype ι] [Nonempty ι] in
/-- A permutation can move any ordered distinct pair to another. -/
theorem exists_pair_permutation [DecidableEq ι] (i j k l : ι)
    (hij : i ≠ j) (hkl : k ≠ l) :
    ∃ σ : Equiv.Perm ι, σ i = k ∧ σ j = l := by
  let τ := Equiv.swap i k
  let σ := τ.trans (Equiv.swap (τ j) l)
  have hτi : τ i = k := Equiv.swap_apply_left i k
  have hτj : τ j ≠ k := by
    rw [← hτi]
    exact fun h => hij (τ.injective h).symm
  refine ⟨σ, ?_, ?_⟩
  · change Equiv.swap (τ j) l (τ i) = k
    rw [hτi, Equiv.swap_apply_of_ne_of_ne hτj.symm hkl]
  · exact Equiv.swap_apply_left (τ j) l

/-- Every invariant bilinear form has one diagonal and one off-diagonal value. -/
theorem invariant_bilinear_exchangeable [DecidableEq ι]
    (B : (ι → ℝ) →ₗ[ℝ] (ι → ℝ) →ₗ[ℝ] ℝ)
    (hsym : ∀ (σ : Equiv.Perm ι) x y, B (x ∘ σ) (y ∘ σ) = B x y) :
    ∃ d e : ℝ, ∀ i j : ι,
      B (Pi.single i 1) (Pi.single j 1) = if i = j then d else e := by
  classical
  let i₀ : ι := Classical.arbitrary ι
  have hsingle (σ : Equiv.Perm ι) (i : ι) :
      (Pi.single (σ i) (1 : ℝ)) ∘ σ = Pi.single i 1 := by
    ext j
    simp only [Function.comp_apply, Pi.single_apply, Equiv.apply_eq_iff_eq]
  have hentry (σ : Equiv.Perm ι) (i j : ι) :
      B (Pi.single (σ i) 1) (Pi.single (σ j) 1) = B (Pi.single i 1) (Pi.single j 1) := by
    simpa only [hsingle] using (hsym σ (Pi.single (σ i) 1) (Pi.single (σ j) 1)).symm
  have hdiag (i : ι) : B (Pi.single i 1) (Pi.single i 1) =
      B (Pi.single i₀ 1) (Pi.single i₀ 1) := by
    simpa using hentry (Equiv.swap i₀ i) i₀ i₀
  by_cases hex : ∃ i j : ι, i ≠ j
  · obtain ⟨k, l, hkl⟩ := hex
    refine ⟨B (Pi.single i₀ 1) (Pi.single i₀ 1),
      B (Pi.single k 1) (Pi.single l 1), ?_⟩
    intro i j
    split_ifs with hij
    · subst j; exact hdiag i
    · obtain ⟨σ, hσi, hσj⟩ := exists_pair_permutation i j k l hij hkl
      simpa only [hσi, hσj] using (hentry σ i j).symm
  · refine ⟨B (Pi.single i₀ 1) (Pi.single i₀ 1), 0, ?_⟩
    intro i j
    have hij : i = j := by by_contra h; exact hex ⟨i,j,h⟩
    subst j
    simpa using hdiag i

omit [Nonempty ι] in
/-- Coordinate expansion of an arbitrary bilinear form. -/
theorem bilinear_coordinate_expansion [DecidableEq ι]
    (B : (ι → ℝ) →ₗ[ℝ] (ι → ℝ) →ₗ[ℝ] ℝ) (x y : ι → ℝ) :
    B x y = ∑ i, ∑ j, x i * B (Pi.single i 1) (Pi.single j 1) * y j := by
  have hcoord (z : ι → ℝ) : z = ∑ i, z i • (Pi.single i (1 : ℝ) : ι → ℝ) := by
    calc
      z = ∑ i, z i • (fun j => if i = j then (1 : ℝ) else 0) := pi_eq_sum_univ z
      _ = ∑ i, z i • (Pi.single i (1 : ℝ) : ι → ℝ) := by
        apply Finset.sum_congr rfl
        intro i _
        congr 1
        ext j
        simp [Pi.single_apply, eq_comm]
  calc
    B x y = (B (∑ i, x i • (Pi.single i (1 : ℝ) : ι → ℝ))) y := by rw [← hcoord x]
    _ = ∑ i, x i * B (Pi.single i 1) y := by
      simp only [map_sum, map_smul, LinearMap.sum_apply, LinearMap.smul_apply, smul_eq_mul]
    _ = ∑ i, ∑ j, x i * B (Pi.single i 1) (Pi.single j 1) * y j := by
      apply Finset.sum_congr rfl
      intro i _
      conv_lhs => rw [hcoord y]
      simp only [map_sum, map_smul, smul_eq_mul, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro j _
      ring

/-- On the centered subspace a permutation-invariant bilinear form is scalar. -/
theorem invariant_quadratic_centered [DecidableEq ι]
    (B : (ι → ℝ) →ₗ[ℝ] (ι → ℝ) →ₗ[ℝ] ℝ)
    (hsym : ∀ (σ : Equiv.Perm ι) x y, B (x ∘ σ) (y ∘ σ) = B x y) :
    ∃ c : ℝ, ∀ x : ι → ℝ, (∑ i, x i) = 0 → B x x = c * ∑ i, (x i)^2 := by
  obtain ⟨d,e,hde⟩ := invariant_bilinear_exchangeable B hsym
  refine ⟨d-e, ?_⟩
  intro x hx
  rw [bilinear_coordinate_expansion]
  simp_rw [hde]
  exact Variations.exchangeable_quadratic_centered d e x hx

/-- The actual nonlinear Hessian has a scalar centered block. -/
theorem centered_hessian_scalar [DecidableEq ι] (f : (ι → ℝ) → ℝ)
    (hf : AnalyticAt ℝ f 0)
    (hsym : ∀ σ : Equiv.Perm ι, (fun x => f (x ∘ σ)) =ᶠ[𝓝 0] f) :
    ∃ c : ℝ, ∀ x : ι → ℝ, (∑ i, x i) = 0 →
      fderiv ℝ (fderiv ℝ f) 0 x x = c * ∑ i, (x i)^2 := by
  apply invariant_quadratic_centered
    ((ContinuousLinearMap.coeLM ℝ).comp
      (fderiv ℝ (fderiv ℝ f) 0).toLinearMap)
  intro σ x y
  exact hessian_invariant f (permute σ) hf (hsym σ) x y


section Mixed
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Only the selected copy block is permuted. All other blocks stay fixed. -/
def blockPermute (σ : Equiv.Perm ι) : (E × (ι → ℝ)) →L[ℝ] (E × (ι → ℝ)) :=
  (ContinuousLinearMap.fst ℝ E (ι → ℝ)).prod
    ((permute σ).comp (ContinuousLinearMap.snd ℝ E (ι → ℝ)))

omit [Fintype ι] [Nonempty ι] in
@[simp] theorem blockPermute_apply (σ : Equiv.Perm ι) (p : E × (ι → ℝ)) :
    blockPermute σ p = (p.1, p.2 ∘ σ) := rfl

/-- Independent symmetry annihilates the mixed Hessian with every other block.
The vector `q` may itself contain arbitrary grouped and other-copy directions. -/
theorem centered_mixed_hessian_zero (F : E × (ι → ℝ) → ℝ)
    (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ σ : Equiv.Perm ι,
      (fun p : E × (ι → ℝ) => F (p.1, p.2 ∘ σ)) =ᶠ[𝓝 0] F)
    (x : ι → ℝ) (hx : ∑ i, x i = 0) (q : E) :
    fderiv ℝ (fderiv ℝ F) 0 (0,x) (q,0) = 0 := by
  let B := fderiv ℝ (fderiv ℝ F) 0
  let L : (ι → ℝ) →L[ℝ] ℝ :=
    (B.flip (q,0)).comp (ContinuousLinearMap.inr ℝ E (ι → ℝ))
  change L x = 0
  apply Variations.invariant_linear_vanishes_centered L.toLinearMap _ x hx
  intro σ y
  have h := hessian_invariant F (blockPermute σ) hF (hsym σ) (0,y) (q,0)
  simpa only [blockPermute_apply, Function.comp_def, Pi.zero_apply] using h

/-- The opposite mixed block also vanishes, without assuming Hessian symmetry. -/
theorem centered_mixed_hessian_zero_flip (F : E × (ι → ℝ) → ℝ)
    (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ σ : Equiv.Perm ι,
      (fun p : E × (ι → ℝ) => F (p.1, p.2 ∘ σ)) =ᶠ[𝓝 0] F)
    (x : ι → ℝ) (hx : ∑ i, x i = 0) (q : E) :
    fderiv ℝ (fderiv ℝ F) 0 (q,0) (0,x) = 0 := by
  let B := fderiv ℝ (fderiv ℝ F) 0
  let L : (ι → ℝ) →L[ℝ] ℝ :=
    (B (q,0)).comp (ContinuousLinearMap.inr ℝ E (ι → ℝ))
  change L x = 0
  apply Variations.invariant_linear_vanishes_centered L.toLinearMap _ x hx
  intro σ y
  have h := hessian_invariant F (blockPermute σ) hF (hsym σ) (q,0) (0,y)
  simpa only [blockPermute_apply, Function.comp_def, Pi.zero_apply] using h

/-- The scalar centered Hessian is computed from the full objective, with
all other coordinates present. -/
theorem centered_block_hessian_scalar [DecidableEq ι] (F : E × (ι → ℝ) → ℝ)
    (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ σ : Equiv.Perm ι,
      (fun p : E × (ι → ℝ) => F (p.1, p.2 ∘ σ)) =ᶠ[𝓝 0] F) :
    ∃ c : ℝ, ∀ x : ι → ℝ, (∑ i, x i) = 0 →
      fderiv ℝ (fderiv ℝ F) 0 (0,x) (0,x) = c * ∑ i, (x i)^2 := by
  let I := ContinuousLinearMap.inr ℝ E (ι → ℝ)
  let H := fderiv ℝ (fderiv ℝ F) 0
  let B : (ι → ℝ) →L[ℝ] (ι → ℝ) →L[ℝ] ℝ :=
    ((ContinuousLinearMap.compL ℝ (ι → ℝ) (E × (ι → ℝ)) ℝ).flip I).comp (H.comp I)
  apply invariant_quadratic_centered ((ContinuousLinearMap.coeLM ℝ).comp B.toLinearMap)
  intro σ x y
  exact hessian_invariant F (blockPermute σ) hF (hsym σ) (0,x) (0,y)

end Mixed


/-- Averaging all permutations kills a centered real copy vector. -/
theorem permutation_average_zero [DecidableEq ι] (x : ι → ℝ) (hx : ∑ i, x i = 0) :
    (∑ σ : Equiv.Perm ι, x ∘ σ) = 0 := by
  classical
  have hc (i j : ι) : (∑ σ : Equiv.Perm ι, x (σ i)) = ∑ σ : Equiv.Perm ι, x (σ j) := by
    have h := Equiv.sum_comp (Equiv.mulRight (Equiv.swap i j)) (fun σ : Equiv.Perm ι => x (σ i))
    simpa using h.symm
  ext i
  change (∑ σ : Equiv.Perm ι, x ∘ σ) i = 0
  rw [Finset.sum_apply]
  change (∑ σ : Equiv.Perm ι, x (σ i)) = 0
  have hs : (Fintype.card ι : ℝ) * (∑ σ : Equiv.Perm ι, x (σ i)) = 0 := by
    calc
      (Fintype.card ι : ℝ) * (∑ σ : Equiv.Perm ι, x (σ i)) =
          ∑ j : ι, ∑ σ : Equiv.Perm ι, x (σ j) := by
        simp_rw [hc _ i]
        simp
      _ = ∑ σ : Equiv.Perm ι, ∑ j : ι, x (σ j) := Finset.sum_comm
      _ = 0 := by simp only [Equiv.sum_comp, hx, Finset.sum_const_zero]
  exact (mul_eq_zero.mp hs).resolve_left (Nat.cast_ne_zero.mpr Fintype.card_ne_zero)

/-- The Euclidean centered-copy space, with its inherited inner product. -/
def centeredSubspace : Submodule ℝ (EuclideanSpace ℝ ι) where
  carrier := {x | ∑ i, x i = 0}
  zero_mem' := by simp
  add_mem' := by
    intro x y hx hy
    change ∑ i, (x i + y i) = 0
    change ∑ i, x i = 0 at hx
    change ∑ i, y i = 0 at hy
    simp [Finset.sum_add_distrib, hx, hy]
  smul_mem' := by
    intro c x hx
    change ∑ i, c * x i = 0
    change ∑ i, x i = 0 at hx
    rw [← Finset.mul_sum, hx, mul_zero]

/-- Permutations act on the actual centered Euclidean space. -/
def centeredAction (σ : Equiv.Perm ι) :
    centeredSubspace (ι := ι) →L[ℝ] centeredSubspace (ι := ι) :=
  LinearMap.toContinuousLinearMap
    { toFun := fun x => ⟨(EuclideanSpace.equiv ι ℝ).symm (fun i => x.1 (σ i)), by
        change ∑ i, x.1 (σ i) = 0
        simpa only [Equiv.sum_comp] using x.2⟩
      map_add' := by intro x y; ext i; rfl
      map_smul' := by intro c x; ext i; rfl }

omit [Nonempty ι] in
@[simp] theorem centeredAction_apply (σ : Equiv.Perm ι)
    (x : centeredSubspace (ι := ι)) (i : ι) : (centeredAction σ x).1 i = x.1 (σ i) := rfl

/-- The centered representation has zero Reynolds average. -/
theorem centeredAction_sum_zero [DecidableEq ι] (x : centeredSubspace (ι := ι)) :
    (∑ σ : Equiv.Perm ι, centeredAction σ x) = 0 := by
  have h := permutation_average_zero (fun i => x.1 i) x.2
  apply (centeredSubspace (ι := ι)).subtype_injective
  apply (EuclideanSpace.equiv ι ℝ).injective
  change (EuclideanSpace.equiv ι ℝ) ((centeredSubspace (ι := ι)).subtype (∑ σ, centeredAction σ x)) =
    (EuclideanSpace.equiv ι ℝ) ((centeredSubspace (ι := ι)).subtype 0)
  simpa only [map_sum, map_zero] using h

end Copies

section AveragedAction
variable {E G : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [Fintype G] [Nonempty G]

/-- A zero-average finite linear action has no invariant covectors. -/
theorem invariant_covector_zero (A : G → E →L[ℝ] E)
    (hA : ∀ x : E, ∑ g, A g x = 0) (L : E →L[ℝ] ℝ)
    (hL : ∀ g, L.comp (A g) = L) : L = 0 := by
  ext x
  have hz : (Fintype.card G : ℝ) * L x = 0 := by
    calc
      (Fintype.card G : ℝ) * L x = ∑ g : G, L (A g x) := by
        have he (g : G) : L (A g x) = L x := congrArg (fun M : E →L[ℝ] ℝ => M x) (hL g)
        simp_rw [he]
        simp
      _ = L (∑ g : G, A g x) := (map_sum L _ _).symm
      _ = 0 := by rw [hA, map_zero]
  exact (mul_eq_zero.mp hz).resolve_left (Nat.cast_ne_zero.mpr Fintype.card_ne_zero)

/-- Local invariance of the function, plus the action's zero average, forces
its actual derivative to vanish. No stationary point is assumed. -/
theorem symmetry_forces_stationarity (A : G → E →L[ℝ] E)
    (hA : ∀ x : E, ∑ g, A g x = 0) (f : E → ℝ)
    (hf : DifferentiableAt ℝ f 0)
    (hsym : ∀ g, (fun x => f (A g x)) =ᶠ[𝓝 0] f) :
    fderiv ℝ f 0 = 0 :=
  invariant_covector_zero A hA _ (fun g => differential_invariant f (A g) hf (hsym g))
end AveragedAction


section ExactElimination
variable {E T G : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [FiniteDimensional ℝ E] [NormedAddCommGroup T] [InnerProductSpace ℝ T]
  [FiniteDimensional ℝ T] [Fintype G] [Nonempty G]

omit [FiniteDimensional ℝ E] in
/-- Symmetry forces exact stationarity throughout the grouped locus, even
when all the unselected variables move. -/
theorem grouped_partialGradient_zero (A : G → T →L[ℝ] T)
    (hA : ∀ s : T, ∑ g, A g s = 0)
    (F : E × T → ℝ) (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ g, (fun p : E × T => F (p.1, A g p.2)) =ᶠ[𝓝 0] F) :
    ∀ᶠ q : E in 𝓝 0, PartialMaximum.partialGradient F (q,0) = 0 := by
  have hnear : ∀ᶠ p : E × T in 𝓝 0, ∀ g,
      (fun z : E × T => F (z.1, A g z.2)) =ᶠ[𝓝 p] F :=
    eventually_all.mpr (fun g => (hsym g).eventuallyEq_nhds)
  have hinc : ContinuousAt (fun q : E => (q,(0 : T))) 0 :=
    continuousAt_id.prodMk continuousAt_const
  have hn := hinc.eventually hnear
  have hd := hinc.eventually hF.eventually_analyticAt
  filter_upwards [hn,hd] with q hq hFq
  let f : T → ℝ := fun s => F (q,s)
  let D := (fderiv ℝ F (q,0)).comp (ContinuousLinearMap.inr ℝ E T)
  have hD : HasFDerivAt f D 0 := by
    convert hFq.differentiableAt.hasFDerivAt.comp (0 : T)
      ((hasFDerivAt_const q (0 : T)).prodMk (hasFDerivAt_id (0 : T))) using 1
  have hsymf (g : G) : (fun s => f (A g s)) =ᶠ[𝓝 0] f := by
    have hi : ContinuousAt (fun s : T => (q,s)) 0 := continuousAt_const.prodMk continuousAt_id
    exact (hq g).comp_tendsto hi
  have hzero := symmetry_forces_stationarity A hA f hD.differentiableAt hsymf
  have hDz : D = 0 := hD.fderiv.symm.trans hzero
  let v := PartialMaximum.partialGradient F (q,0)
  apply (inner_self_eq_zero (𝕜 := ℝ)).mp
  rw [UniformPartialMaximum.partialGradient_pairing]
  exact congrArg (fun L : T →L[ℝ] ℝ => L v) hDz

omit [FiniteDimensional ℝ E] in
/-- A negative collection of symmetric splitting modes can be set exactly
to zero, with uniform strict quadratic gain. The fixed variables `E` can
contain every unselected centered block. -/
theorem symmetric_blocks_exact_elimination (A : G → T →L[ℝ] T)
    (hA : ∀ s : T, ∑ g, A g s = 0)
    (F : E × T → ℝ) (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ g, (fun p : E × T => F (p.1, A g p.2)) =ᶠ[𝓝 0] F)
    (P : T →L[ℝ] T) (hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s))
    (hss : (fderiv ℝ (PartialMaximum.partialGradient F) 0).comp
      (ContinuousLinearMap.inr ℝ E T) = -P) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ p : E × T in 𝓝 0,
      F p ≤ F (p.1,0) - c * ‖p.2‖^2 := by
  have hstat := grouped_partialGradient_zero A hA F hF hsym
  simpa only [sub_zero] using
    UniformPartialMaximum.uniform_local_quadratic_domination F hF P hP hss
      (fun _ : E => (0 : T)) continuousAt_const rfl hstat


omit [FiniteDimensional ℝ E] in
/-- A scalar quadratic Hessian determines the entire partial Hessian operator.
The off-diagonal information is derived by polarization of the actual Hessian. -/
theorem partial_hessian_of_scalar_quadratic (F : E × T → ℝ)
    (hF : AnalyticAt ℝ F 0) (lam : ℝ)
    (hq : ∀ s : T, fderiv ℝ (fderiv ℝ F) 0 (0,s) (0,s) = lam * ‖s‖^2) :
    (fderiv ℝ (PartialMaximum.partialGradient F) 0).comp
      (ContinuousLinearMap.inr ℝ E T) = lam • ContinuousLinearMap.id ℝ T := by
  have hsym : IsSymmSndFDerivAt ℝ F 0 := hF.contDiffAt.isSymmSndFDerivAt_of_omega
  have hbil (s t : T) : fderiv ℝ (fderiv ℝ F) 0 (0,s) (0,t) = lam * inner ℝ s t := by
    have hh := hq (s+t)
    have he : ((0 : E),s+t) = (0,s)+(0,t) := by simp
    rw [he] at hh
    simp only [map_add, ContinuousLinearMap.add_apply] at hh
    rw [hq s, hq t, hsym (0,t) (0,s), norm_add_sq_real] at hh
    nlinarith
  ext s
  apply ext_inner_right ℝ
  intro t
  change inner ℝ (fderiv ℝ (PartialMaximum.partialGradient F) 0 (0,s)) t =
    inner ℝ (lam • s) t
  rw [SchurHessian.partialGradient_hessian_pairing F hF, hbil, real_inner_smul_left]

omit [FiniteDimensional ℝ E] in
/-- A strictly negative scalar of the actual centered Hessian is sufficient
for exact nonlinear elimination. The positive operator is constructed. -/
theorem negative_scalar_exact_elimination (A : G → T →L[ℝ] T)
    (hA : ∀ s : T, ∑ g, A g s = 0)
    (F : E × T → ℝ) (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ g, (fun p : E × T => F (p.1, A g p.2)) =ᶠ[𝓝 0] F)
    (lam : ℝ) (hlam : lam < 0)
    (hq : ∀ s : T, fderiv ℝ (fderiv ℝ F) 0 (0,s) (0,s) = lam * ‖s‖^2) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ p : E × T in 𝓝 0,
      F p ≤ F (p.1,0) - c * ‖p.2‖^2 := by
  let P : T →L[ℝ] T := (-lam) • ContinuousLinearMap.id ℝ T
  have hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s) := by
    intro s hs
    change 0 < inner ℝ s ((-lam) • s)
    rw [real_inner_smul_right, real_inner_self_eq_norm_sq]
    exact mul_pos (neg_pos.mpr hlam) (sq_pos_of_pos (norm_pos_iff.mpr hs))
  apply symmetric_blocks_exact_elimination A hA F hF hsym P hP
  rw [partial_hessian_of_scalar_quadratic F hF lam hq]
  ext s
  simp [P]

omit [FiniteDimensional ℝ E] in
/-- In particular, the action-average hypothesis is proved for the actual
centered Euclidean copy space. -/
theorem centered_copies_exact_elimination {ι : Type*} [Fintype ι] [Nonempty ι] [DecidableEq ι]
    (F : E × centeredSubspace (ι := ι) → ℝ) (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ σ : Equiv.Perm ι,
      (fun p : E × centeredSubspace (ι := ι) => F (p.1, centeredAction σ p.2)) =ᶠ[𝓝 0] F)
    (P : centeredSubspace (ι := ι) →L[ℝ] centeredSubspace (ι := ι))
    (hP : ∀ s : centeredSubspace (ι := ι), s ≠ 0 → 0 < inner ℝ s (P s))
    (hss : (fderiv ℝ (PartialMaximum.partialGradient F) 0).comp
      (ContinuousLinearMap.inr ℝ E (centeredSubspace (ι := ι))) = -P) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ p : E × centeredSubspace (ι := ι) in 𝓝 0,
      F p ≤ F (p.1,0) - c * ‖p.2‖^2 :=
  symmetric_blocks_exact_elimination centeredAction centeredAction_sum_zero F hF hsym P hP hss

section FromFullCoordinates
variable {ι : Type*} [Fintype ι] [Nonempty ι] [DecidableEq ι]

/-- Inclusion of the centered Euclidean block into the full real copy space. -/
def centeredLift : (E × centeredSubspace (ι := ι)) →L[ℝ] E × (ι → ℝ) :=
  (ContinuousLinearMap.fst ℝ E (centeredSubspace (ι := ι))).prod
    (((EuclideanSpace.equiv ι ℝ).toContinuousLinearMap.comp
      (centeredSubspace (ι := ι)).subtypeL).comp
      (ContinuousLinearMap.snd ℝ E (centeredSubspace (ι := ι))))

omit [FiniteDimensional ℝ E] [Nonempty ι] [DecidableEq ι] in
@[simp] theorem centeredLift_apply (p : E × centeredSubspace (ι := ι)) :
    centeredLift p = (p.1, fun i => p.2.1 i) := rfl

omit [Nonempty ι] [DecidableEq ι] in
/-- Restricting a nonlinear Hessian to the centered space is actual
composition of derivatives with its linear inclusion. -/
theorem centered_restriction_hessian (F : E × (ι → ℝ) → ℝ)
    (hF : AnalyticAt ℝ F 0) (u v : E × centeredSubspace (ι := ι)) :
    fderiv ℝ (fderiv ℝ (fun p => F (centeredLift p))) 0 u v =
      fderiv ℝ (fderiv ℝ F) 0 (centeredLift u) (centeredLift v) := by
  have hf : AnalyticAt ℝ (centeredLift (E := E) (ι := ι)) 0 := (centeredLift (E := E) (ι := ι)).analyticAt 0
  have hg : AnalyticAt ℝ F (centeredLift (0 : E × centeredSubspace (ι := ι))) := by
    simpa using hF
  rw [SchurHessian.second_fderiv_comp _ F 0 hf hg]
  have hD : fderiv ℝ (centeredLift (E := E) (ι := ι)) =
      fun _ => centeredLift (E := E) (ι := ι) := by
    funext x
    exact (centeredLift (E := E) (ι := ι)).fderiv
  rw [hD]
  simp only [map_zero, fderiv_const_apply, ContinuousLinearMap.zero_apply, add_zero]

/-- Full version for one copy block: function symmetry supplies the actual
scalar Hessian and a negative scalar supplies exact nonlinear elimination. -/
theorem nonlinear_centered_block_elimination (F : E × (ι → ℝ) → ℝ)
    (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ σ : Equiv.Perm ι,
      (fun p : E × (ι → ℝ) => F (p.1, p.2 ∘ σ)) =ᶠ[𝓝 0] F) :
    ∃ lam : ℝ,
      (∀ s : centeredSubspace (ι := ι),
        fderiv ℝ (fderiv ℝ (fun p => F (centeredLift p))) 0 (0,s) (0,s) = lam * ‖s‖^2) ∧
      (lam < 0 → ∃ c : ℝ, 0 < c ∧
        ∀ᶠ p : E × centeredSubspace (ι := ι) in 𝓝 0,
          F (centeredLift p) ≤ F (p.1,0) - c * ‖p.2‖^2) := by
  obtain ⟨lam,hquad⟩ := centered_block_hessian_scalar F hF hsym
  let f : E × centeredSubspace (ι := ι) → ℝ := fun p => F (centeredLift p)
  have hf : AnalyticAt ℝ f 0 := by
    exact hF.comp_of_eq' ((centeredLift (E := E) (ι := ι)).analyticAt 0) (map_zero _)
  have hq (s : centeredSubspace (ι := ι)) :
      fderiv ℝ (fderiv ℝ f) 0 (0,s) (0,s) = lam * ‖s‖^2 := by
    rw [centered_restriction_hessian F hF]
    change fderiv ℝ (fderiv ℝ F) 0 (0, fun i => s.1 i) (0, fun i => s.1 i) = _
    rw [hquad (fun i => s.1 i) s.2]
    congr 1
    change (∑ i, (s.1 i)^2) = ‖s.1‖^2
    rw [EuclideanSpace.norm_sq_eq]
    apply Finset.sum_congr rfl
    intro i _
    rw [Real.norm_eq_abs, sq_abs]
  refine ⟨lam,hq,?_⟩
  intro hlam
  have hs : ∀ σ : Equiv.Perm ι,
      (fun p : E × centeredSubspace (ι := ι) => f (p.1, centeredAction σ p.2)) =ᶠ[𝓝 0] f := by
    intro σ
    have ht : Tendsto (centeredLift (E := E) (ι := ι)) (𝓝 0) (𝓝 0) := by
      simpa using (centeredLift (E := E) (ι := ι)).continuous.continuousAt
    exact (hsym σ).comp_tendsto ht
  simpa only [f, centeredLift_apply, Submodule.coe_zero, PiLp.zero_apply] using
    negative_scalar_exact_elimination centeredAction centeredAction_sum_zero f hf hs lam hlam hq
end FromFullCoordinates

end ExactElimination

end PolynomialGeometry.SymmetricElimination
