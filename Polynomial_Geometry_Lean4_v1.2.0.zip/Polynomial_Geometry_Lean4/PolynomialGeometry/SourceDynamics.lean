import PolynomialGeometry.Geometry
import PolynomialGeometry.SourceRank
import PolynomialGeometry.SourceStability
import PolynomialGeometry.SteinSeries

/-!
# Assembled source dynamics

These theorems derive strict stability, the infinite output-energy identity,
finite observability, and a geometric block bound from the original source
positions and nonzero source weights. No state-decay or spectral hypothesis
is imposed on the transformed source matrix.
-/
noncomputable section
open scoped Topology ComplexOrder
open Matrix Complex Filter
open PolynomialGeometry.Geometry PolynomialGeometry.Dynamics
namespace PolynomialGeometry.SourceDynamics
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

def transition (a : ℝ) (u α : ι → ℂ) : Matrix ι ι ℂ :=
  (expansive a u (sourceResolvent a α))⁻¹

theorem compressed_roots_strict (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) (w : ℂ)
    (hw : (compressed (a : ℂ) u (diagonal α)).charpoly.IsRoot w) : ‖w‖ < 1 := by
  obtain ⟨x, hx, he⟩ := Mobius.eigenvector_of_root _ w hw
  obtain ⟨hy, hout, hsource⟩ := compressed_eigenpair_source (a : ℂ) w u α x hx he
  apply SourceStability.source_eigenvector_norm_lt_one
    (Sum.elim (fun _ : Unit => (a : ℂ)) α) (massVector u) (energyBasis u *ᵥ x)
    w ((a - w) * (star u ⬝ᵥ metric u *ᵥ x)) _ _ _ hy hsource hout
  · intro i j hij
    cases i with
    | inl i => cases j with
      | inl j => congr
      | inr j => exact False.elim (hsep j hij)
    | inr i => cases j with
      | inl j => exact False.elim (hsep i hij.symm)
      | inr j => exact congrArg Sum.inr (hinj hij)
  · intro j
    cases j <;> simp [massVector, hu]
  · intro j
    cases j with
    | inl j => simpa [Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg ha₀] using ha₁.le
    | inr j =>
      have hs := hdisk j
      rw [Complex.normSq_eq_norm_sq] at hs
      change ‖α j‖ ≤ 1
      nlinarith [norm_nonneg (α j)]

/-- Strict stability of the actual inverse expansive source transform. -/
theorem transition_roots_strict (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) (w : ℂ)
    (hw : (transition a u α).charpoly.IsRoot w) : ‖w‖ < 1 := by
  apply Mobius.root_norm_lt_one a (compressed a u (diagonal α)) (transition a u α)
    (by nlinarith) (compressed_roots_strict a u α ha₀ ha₁ hu hsep hdisk hinj)
    (source_mobius_relation a u α ha₀ ha₁ hsep hdisk) w hw

theorem transition_spectralRadius_lt_one (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) : spectralRadius ℂ (transition a u α) < 1 :=
  CompressionDet.spectralRadius_lt_one_of_charpoly_roots _
    (transition_roots_strict a u α ha₀ ha₁ hu hsep hdisk hinj)

theorem states_tendsto_zero (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) (x : ι → ℂ) :
    Tendsto (fun k : ℕ => (transition a u α)^k *ᵥ x) atTop (𝓝 0) :=
  Stability.states_tendsto_zero _
    (transition_roots_strict a u α ha₀ ha₁ hu hsep hdisk hinj) x

/-- Source-level energy recovery with its explicit output matrix. -/
theorem infinite_energy_identity (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) (x : ι → ℂ) :
    HasSum (fun k : ℕ => outputEnergy
      (SourceRank.sourceContractiveLossFactor a u α *ᵥ ((transition a u α)^k *ᵥ x)))
      (energy (metric u) x) :=
  Dynamics.hasSum_outputEnergy _ _ _
    (SourceRank.sourceContractiveLossFactor_gram a u α ha₀ ha₁ hsep hdisk).symm x
    (states_tendsto_zero a u α ha₀ ha₁ hu hsep hdisk hinj x)

/-- A uniform geometric block bound for the actual source transform. -/
theorem geometric_energy_bound [Nonempty ι] (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) :
    ∃ θ : ℝ, 0 < θ ∧ θ < 1 ∧ ∀ (x : ι → ℂ) (k : ℕ),
      energy (metric u) ((transition a u α)^k *ᵥ x) ≤
        θ^(k / Fintype.card ι) * energy (metric u) x :=
  Dynamics.exists_geometric_energy_bound _ _ _ (metric_posDef u)
    (SourceRank.sourceContractiveLossFactor_gram a u α ha₀ ha₁ hsep hdisk).symm
    (states_tendsto_zero a u α ha₀ ha₁ hu hsep hdisk hinj)

/-- The complete finite-observability and infinite-energy conclusion for any
exact loss factor, derived from the original source hypotheses. -/
theorem energy_recovery_and_observability {κ : Type*} [Fintype κ] [Nonempty ι]
    (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1)
    (hinj : Function.Injective α) (C : Matrix κ ι ℂ)
    (hC : defect (metric u) (transition a u α) = Cᴴ * C) :
    (∀ x : ι → ℂ, HasSum (fun k : ℕ => outputEnergy
      (C *ᵥ ((transition a u α)^k *ᵥ x))) (energy (metric u) x)) ∧
    (observationMatrix (transition a u α) C).rank = Fintype.card ι ∧
    (observationMatrix (transition a u α) C)ᴴ * observationMatrix (transition a u α) C =
      metric u - ((transition a u α)ᴴ)^Fintype.card ι * metric u *
        (transition a u α)^Fintype.card ι ∧
    (metric u - ((transition a u α)ᴴ)^Fintype.card ι * metric u *
        (transition a u α)^Fintype.card ι).PosDef := by
  have hd := states_tendsto_zero a u α ha₀ ha₁ hu hsep hdisk hinj
  exact ⟨fun x => Dynamics.hasSum_outputEnergy _ _ C hC x (hd x),
    Dynamics.observationMatrix_rank _ _ C (metric_posDef u) hC hd,
    Dynamics.observation_gram_eq_defect _ _ C hC,
    Dynamics.finite_defect_posDef _ _ C (metric_posDef u) hC hd⟩

end PolynomialGeometry.SourceDynamics
