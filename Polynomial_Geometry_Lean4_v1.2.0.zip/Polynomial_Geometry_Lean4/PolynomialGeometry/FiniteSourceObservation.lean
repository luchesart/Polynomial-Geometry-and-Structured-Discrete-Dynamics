import PolynomialGeometry.SourceDynamics

/-! # Finite records of the grouped source dynamics
On the single-step zero-loss space the actual expansive source step acts
diagonally. Consecutive zero outputs therefore give consecutive scalar
moments at an explicit affine resolvent of the source positions.
-/

noncomputable section
open Matrix Complex
open scoped BigOperators ComplexOrder
open PolynomialGeometry.Geometry PolynomialGeometry.SourceRank
namespace PolynomialGeometry.FiniteHorizon

variable {ι κ : Type*} [Fintype ι] [DecidableEq ι]

/-- Observation rows for an arbitrary prescribed number of steps. -/
def finiteRecord (T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) (h : ℕ) :
    Matrix (Fin h × κ) ι ℂ := fun i j => (C * T ^ (i.1 : ℕ)) i.2 j

theorem finiteRecord_zero (T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) (h : ℕ)
    (x : ι → ℂ) :
    finiteRecord T C h *ᵥ x = 0 ↔ ∀ k < h, C *ᵥ (T^k *ᵥ x) = 0 := by
  have atRow (k : Fin h) (j : κ) :
      (finiteRecord T C h *ᵥ x) (k,j) = (C *ᵥ (T^(k : ℕ) *ᵥ x)) j := by
    rw [Matrix.mulVec_mulVec]
    rfl
  constructor
  · intro hz k hk
    funext j
    exact (atRow ⟨k,hk⟩ j).symm.trans (congrFun hz (⟨k,hk⟩,j))
  · intro hz
    funext ⟨k,j⟩
    exact (atRow k j).trans (congrFun (hz k k.isLt) j)

theorem finiteRecord_gram [Fintype κ] (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (hC : Dynamics.defect E T = Cᴴ * C) (h : ℕ) :
    (finiteRecord T C h)ᴴ * finiteRecord T C h = E - (T^h)ᴴ * E * T^h := by
  have hsum : (finiteRecord T C h)ᴴ * finiteRecord T C h =
      ∑ k : Fin h, (C * T ^ (k : ℕ))ᴴ * (C * T ^ (k : ℕ)) := by
    ext i j
    simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, finiteRecord,
      Fintype.sum_prod_type, Matrix.sum_apply]
  rw [hsum, Matrix.conjTranspose_pow]
  simp only [Matrix.conjTranspose_mul, Matrix.conjTranspose_pow]
  have hs : (∑ k : Fin h, (Tᴴ) ^ (k : ℕ) * Cᴴ * (C * T ^ (k : ℕ))) =
      ∑ k ∈ Finset.range h, (Tᴴ) ^ k * Dynamics.defect E T * T ^ k := by
    rw [← Fin.sum_univ_eq_sum_range]
    apply Finset.sum_congr rfl
    intro k _
    rw [hC]
    simp only [Matrix.mul_assoc]
  rw [hs, Dynamics.stein_sum]

/-- The diagonal part of the article's expansive step. -/
def sourceNode (a : ℝ) (α : ι → ℂ) (j : ι) : ℂ :=
  (a : ℂ) + (diskCoefficient a : ℂ) * ((a : ℂ) - α j)⁻¹

def sourceMoment (u z x : ι → ℂ) (k : ℕ) : ℂ :=
  ∑ j, star (u j) * z j ^ k * x j

private def resolventOutput (a : ℝ) (u α x : ι → ℂ) : ℂ :=
  ∑ j, star (u j) * ((a : ℂ) - α j)⁻¹ * x j

omit [DecidableEq ι] in
private theorem moment_one (a : ℝ) (u α x : ι → ℂ) :
    sourceMoment u (sourceNode a α) x 1 =
      (a : ℂ) * sourceMoment u (sourceNode a α) x 0 +
      (diskCoefficient a : ℂ) * resolventOutput a u α x := by
  simp only [sourceMoment, sourceNode, resolventOutput, pow_zero, pow_one,
    mul_one, Finset.mul_sum]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro j _
  ring

private theorem output_coordinates (a : ℝ) (u α x : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) :
    (∀ i : interiorSet α, (sourceLossFactor a u α *ᵥ x) (.inl i) =
        sourceLossDiagonal a α i * x i) ∧
    (sourceLossFactor a u α *ᵥ x) (.inr 0) =
        (sourceScale a u : ℂ) * sourceMoment u (sourceNode a α) x 0 ∧
    (sourceLossFactor a u α *ᵥ x) (.inr 1) =
        (diskCoefficient a : ℂ) * resolventOutput a u α x := by
  refine ⟨?_, ?_, ?_⟩
  · intro i
    change (∑ j, (if i.val = j then sourceLossDiagonal a α j else 0) * x j) = _
    rw [Finset.sum_eq_single i.val]
    · simp
    · intro j _ hji
      simp [Ne.symm hji]
    · simp
  · change (∑ j, sourceLossRow a u j * x j) = _
    simp only [sourceLossRow, sourceMoment, pow_zero, mul_one, Finset.mul_sum, mul_assoc]
  · change (∑ j, (sourceLossRow a u j * sourceLossRatio a u α j) * x j) = _
    simp only [sourceLossRow_ratio u α ha₀ ha₁, resolventOutput, Finset.mul_sum, mul_assoc]

/-- Exactly the interior coordinates and the first two moments vanish
when the source output is zero. -/
theorem sourceLoss_zero (a : ℝ) (u α x : ι → ℂ) (ha₀ : 0 ≤ a) (ha₁ : a < 1)
    (hsep : ∀ j, (a : ℂ) ≠ α j) :
    sourceLossFactor a u α *ᵥ x = 0 ↔
      (∀ j ∈ interiorSet α, x j = 0) ∧
      sourceMoment u (sourceNode a α) x 0 = 0 ∧
      sourceMoment u (sourceNode a α) x 1 = 0 := by
  obtain ⟨hi,h0,h1⟩ := output_coordinates a u α x ha₀ ha₁
  have hs : (sourceScale a u : ℂ) ≠ 0 := by exact_mod_cast (sourceScale_pos u ha₀ ha₁).ne'
  constructor
  · intro hx
    have hm := (mul_eq_zero.mp (h0.symm.trans (congrFun hx (.inr 0)))).resolve_left hs
    have hr := h1.symm.trans (congrFun hx (.inr 1))
    refine ⟨?_, hm, ?_⟩
    · intro j hj
      exact (mul_eq_zero.mp ((hi ⟨j,hj⟩).symm.trans (congrFun hx (.inl ⟨j,hj⟩)))).resolve_left
        (sourceLossDiagonal_ne_zero α ha₀ ha₁ hsep j hj)
    · rw [moment_one, hm, mul_zero, zero_add]
      exact hr
  · rintro ⟨hx,hm,hm'⟩
    rw [moment_one, hm, mul_zero, zero_add] at hm'
    funext i
    rcases i with j | k
    · exact (hi j).trans (by simp [hx j j.property])
    · fin_cases k
      · exact h0.trans (by simp [hm])
      · exact h1.trans hm'

private theorem expansive_action (a : ℝ) (u α x : ι → ℂ) (j : ι) :
    (expansive a u (sourceResolvent a α) *ᵥ x) j =
      sourceNode a α j * x j +
      (diskCoefficient a : ℂ) * u j * resolventOutput a u α x := by
  have dot : star u ⬝ᵥ (sourceResolvent a α *ᵥ x) = resolventOutput a u α x := by
    simp only [dotProduct, sourceResolvent, Matrix.mulVec_diagonal, Pi.star_apply,
      resolventOutput, mul_assoc]
  have hou : outer u *ᵥ (sourceResolvent a α *ᵥ x) = resolventOutput a u α x • u := by
    rw [outer, Matrix.vecMulVec_mulVec, dot, op_smul_eq_smul]
  unfold expansive reciprocal
  rw [Matrix.add_mulVec, Matrix.smul_mulVec, Matrix.one_mulVec, Matrix.smul_mulVec,
    ← Matrix.mulVec_mulVec, Matrix.add_mulVec, Matrix.one_mulVec, hou]
  simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul, sourceResolvent,
    Matrix.mulVec_diagonal, sourceNode]
  ring

theorem source_step_on_null (a : ℝ) (u α x : ι → ℂ) (ha₀ : 0 ≤ a) (ha₁ : a < 1)
    (hx : sourceLossFactor a u α *ᵥ x = 0) :
    expansive a u (sourceResolvent a α) *ᵥ x = fun j => sourceNode a α j * x j := by
  have h1 := (output_coordinates a u α x ha₀ ha₁).2.2
  have hr : (diskCoefficient a : ℂ) * resolventOutput a u α x = 0 :=
    h1.symm.trans (congrFun hx (.inr 1))
  funext j
  rw [expansive_action]
  linear_combination (u j) * hr

omit [DecidableEq ι] in
private theorem moment_shift (u z x : ι → ℂ) (k : ℕ) :
    sourceMoment u z (fun j => z j * x j) k = sourceMoment u z x (k+1) := by
  unfold sourceMoment
  apply Finset.sum_congr rfl
  intro j _
  rw [pow_succ]
  ring

private theorem record_succ (S : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) (m : ℕ)
    (x : ι → ℂ) :
    (∀ k < m+1, C *ᵥ (S^k *ᵥ x) = 0) ↔
      C *ᵥ x = 0 ∧ ∀ k < m, C *ᵥ (S^k *ᵥ (S *ᵥ x)) = 0 := by
  constructor
  · intro hx
    refine ⟨by simpa using hx 0 (Nat.zero_lt_succ m), ?_⟩
    intro k hk
    simpa only [Matrix.mulVec_mulVec, pow_succ] using hx (k+1) (by omega)
  · rintro ⟨h0,h⟩ (_ | k) hk
    · simpa using h0
    · simpa only [Matrix.mulVec_mulVec, pow_succ] using h k (by omega)

/-- Exact zero-output trajectories at every positive observation horizon. -/
theorem source_record_zero (a : ℝ) (u α : ι → ℂ) (ha₀ : 0 ≤ a) (ha₁ : a < 1)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (h : ℕ) (x : ι → ℂ) :
    finiteRecord (expansive a u (sourceResolvent a α)) (sourceLossFactor a u α)
        (h+1) *ᵥ x = 0 ↔
      (∀ j ∈ interiorSet α, x j = 0) ∧
      ∀ k ≤ h+1, sourceMoment u (sourceNode a α) x k = 0 := by
  rw [finiteRecord_zero]
  induction h generalizing x with
  | zero =>
    constructor
    · intro h
      have hz : sourceLossFactor a u α *ᵥ x = 0 := by simpa using h 0 (by decide)
      obtain ⟨hx,h₀,h₁⟩ := (sourceLoss_zero a u α x ha₀ ha₁ hsep).mp hz
      refine ⟨hx, fun k hk => ?_⟩
      have hcases : k = 0 ∨ k = 1 := by omega
      rcases hcases with rfl | rfl <;> assumption
    · rintro ⟨hx,hm⟩ k hk
      have hk0 : k = 0 := by omega
      subst k
      simpa using (sourceLoss_zero a u α x ha₀ ha₁ hsep).mpr
        ⟨hx, hm 0 (by decide), hm 1 (by decide)⟩
  | succ h ih =>
    rw [record_succ, ih]
    constructor
    · rintro ⟨h0,_,hp⟩
      obtain ⟨hx,hm,_⟩ := (sourceLoss_zero a u α x ha₀ ha₁ hsep).mp h0
      refine ⟨hx, ?_⟩
      rintro (_ | k) hk
      · exact hm
      · have hh := hp k (by omega)
        rwa [source_step_on_null a u α x ha₀ ha₁ h0, moment_shift] at hh
    · rintro ⟨hx,hm⟩
      have h0 := (sourceLoss_zero a u α x ha₀ ha₁ hsep).mpr
        ⟨hx, hm 0 (by omega), hm 1 (by omega)⟩
      refine ⟨h0, ?_, ?_⟩
      · intro j hj
        rw [source_step_on_null a u α x ha₀ ha₁ h0]
        simp [hx j hj]
      · intro k hk
        rw [source_step_on_null a u α x ha₀ ha₁ h0, moment_shift]
        exact hm (k+1) (by omega)

end PolynomialGeometry.FiniteHorizon
