import PolynomialGeometry.Source
import Mathlib.Algebra.Polynomial.FieldDivision
import Mathlib.Analysis.Complex.Polynomial.Basic

/-! # Exact integer-mass recovery

Polynomial logarithmic derivatives are represented by their exact cleared
polynomial identity. This avoids limiting residues and makes integrality
a conclusion about the natural-number root multiplicity.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace PolynomialGeometry.PolynomialRecovery

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem derivative_power_factor (a : ℂ) (m : ℕ) (Q : ℂ[X]) :
    ((X - C a) ^ m * Q).derivative * (X - C a) =
      (X - C a) ^ m * (C (m : ℂ) * Q + (X - C a) * Q.derivative) := by
  cases m with
  | zero => simp; ring
  | succ m =>
    simp only [derivative_mul, derivative_pow, derivative_sub, derivative_X,
      derivative_C, sub_zero, mul_one, Nat.add_sub_cancel, Nat.cast_add, Nat.cast_one]
    rw [pow_succ]
    ring

/-- Every source residue of a polynomial logarithmic derivative is exactly
the root's natural-number multiplicity. -/
theorem source_mass_eq_rootMultiplicity (α ν : ι → ℂ) (hα : Function.Injective α)
    (P : ℂ[X]) (hP : P ≠ 0)
    (hlog : P.derivative * Source.support Finset.univ α =
      P * Source.rawNumerator Finset.univ α ν) (i : ι) :
    ν i = (P.rootMultiplicity (α i) : ℂ) := by
  obtain ⟨Q, hPQ, hQ⟩ := P.exists_eq_pow_rootMultiplicity_mul_and_not_dvd hP (α i)
  have hQeval : Q.eval (α i) ≠ 0 := by
    simpa only [Polynomial.dvd_iff_isRoot, Polynomial.IsRoot] using hQ
  let D : ℂ[X] := X - C (α i)
  let B := Source.support (Finset.univ.erase i) α
  let m := P.rootMultiplicity (α i)
  have hsupport : Source.support Finset.univ α = D * B :=
    (Source.support_erase_mul Finset.univ α (Finset.mem_univ i)).symm
  have hcancel : C (m : ℂ) * Q * B + D * Q.derivative * B =
      Q * Source.rawNumerator Finset.univ α ν := by
    have heq := hlog
    rw [hPQ, hsupport] at heq
    rw [← mul_assoc, derivative_power_factor] at heq
    apply mul_left_cancel₀ (pow_ne_zero m (Polynomial.X_sub_C_ne_zero (α i)))
    convert heq using 1 <;> dsimp [D, m] <;> ring
  have heval := congrArg (Polynomial.eval (α i)) hcancel
  simp only [eval_add, eval_mul, eval_C, D, eval_sub, eval_X, sub_self, zero_mul,
    ] at heval
  rw [Source.rawNumerator_eval_at_source Finset.univ α ν (Finset.mem_univ i)] at heval
  have hB : B.eval (α i) ≠ 0 := by
    apply Source.support_eval_nonzero
    intro j hj
    exact fun hij => (Finset.mem_erase.mp hj).1 (hα hij.symm)
  have hprod : (Q.eval (α i) * B.eval (α i)) * ((m : ℂ) - ν i) = 0 := by
    change (m : ℂ) * Q.eval (α i) * B.eval (α i) + 0 =
      Q.eval (α i) * (ν i * B.eval (α i)) at heval
    linear_combination heval
  exact (sub_eq_zero.mp ((mul_eq_zero.mp hprod).resolve_left (mul_ne_zero hQeval hB))).symm

/-- Integer masses construct the claimed monic polynomial and its exact
logarithmic-derivative identity. -/
theorem integer_source_polynomial (α : ι → ℂ) (m : ι → ℕ) (hm : ∀ i, 0 < m i) :
    let P := Source.sourcePolynomial Finset.univ α m
    P.Monic ∧ P.derivative * Source.support Finset.univ α =
      P * Source.rawNumerator Finset.univ α (fun i => (m i : ℂ)) := by
  dsimp only
  constructor
  · exact Polynomial.monic_prod_of_monic _ _ (fun i _ => (Polynomial.monic_X_sub_C (α i)).pow _)
  · rw [Source.derivative_sourcePolynomial _ _ _ (fun i _ => hm i),
      Source.sourcePolynomial_factor _ _ _ (fun i _ => hm i)]
    ring

/-- Exact positive-integer criterion for a monic polynomial realization.
The statement uses equality after clearing the known source denominator. -/
theorem polynomial_realization_iff_integer_masses (α : ι → ℂ) (ν : ι → ℝ)
    (hα : Function.Injective α) (hν : ∀ i, 0 < ν i) :
    (∃ P : ℂ[X], P.Monic ∧
      P.derivative * Source.support Finset.univ α =
        P * Source.rawNumerator Finset.univ α (fun i => (ν i : ℂ))) ↔
      ∃ m : ι → ℕ, (∀ i, 0 < m i) ∧ ∀ i, ν i = (m i : ℝ) := by
  constructor
  · rintro ⟨P, hP, hlog⟩
    refine ⟨fun i => P.rootMultiplicity (α i), ?_, ?_⟩
    · intro i
      have hi := source_mass_eq_rootMultiplicity α (fun i => (ν i : ℂ)) hα P hP.ne_zero hlog i
      have hr : ν i = (P.rootMultiplicity (α i) : ℝ) := by exact_mod_cast hi
      exact_mod_cast hr ▸ hν i
    · intro i
      exact_mod_cast source_mass_eq_rootMultiplicity α (fun i => (ν i : ℂ)) hα P hP.ne_zero hlog i
  · rintro ⟨m, hm, hνm⟩
    refine ⟨Source.sourcePolynomial Finset.univ α m, ?_⟩
    simpa only [hνm, Complex.ofReal_natCast] using integer_source_polynomial α m hm

/-- The cleared identity gives the ordinary logarithmic derivative at every
point where the stated denominators are nonzero. -/
theorem logarithmic_derivative_of_identity (α ν : ι → ℂ) (P : ℂ[X])
    (hlog : P.derivative * Source.support Finset.univ α =
      P * Source.rawNumerator Finset.univ α ν)
    (z : ℂ) (hPz : P.eval z ≠ 0) (hsep : ∀ i, z ≠ α i) :
    P.derivative.eval z / P.eval z = ∑ i, ν i / (z - α i) := by
  have hs := Source.support_eval_nonzero Finset.univ α z (fun i _ => hsep i)
  have heq := congrArg (Polynomial.eval z) hlog
  simp only [eval_mul] at heq
  rw [Source.rawNumerator_eq_support_mul_sourceFunction
    Finset.univ α ν z (fun i _ => hsep i)] at heq
  apply (div_eq_iff hPz).mpr
  apply mul_right_cancel₀ hs
  simpa only [Source.sourceFunction, mul_comm, mul_left_comm, mul_assoc] using heq

/-- Equality of the logarithmic derivatives away from their finitely many
poles is equivalent to the cleared polynomial identity. -/
theorem logarithmic_derivative_iff_identity (α ν : ι → ℂ) (P : ℂ[X]) (hP : P ≠ 0) :
    (∀ z, P.eval z ≠ 0 → (∀ i, z ≠ α i) →
      P.derivative.eval z / P.eval z = ∑ i, ν i / (z - α i)) ↔
      P.derivative * Source.support Finset.univ α =
        P * Source.rawNumerator Finset.univ α ν := by
  constructor
  · intro hlog
    apply Polynomial.eq_of_infinite_eval_eq
    have hbad : ({z : ℂ | P.eval z = 0} ∪ Set.range α).Finite :=
      (Polynomial.finite_setOf_isRoot hP).union (Set.finite_range α)
    apply (Set.infinite_univ.diff hbad).mono
    intro z hz
    have hPz : P.eval z ≠ 0 := by
      intro hzero
      exact hz.2 (Or.inl hzero)
    have hsep : ∀ i, z ≠ α i := by
      intro i hi
      exact hz.2 (Or.inr ⟨i, hi.symm⟩)
    have heq := (div_eq_iff hPz).mp (hlog z hPz hsep)
    simp only [Set.mem_setOf_eq, eval_mul]
    rw [Source.rawNumerator_eq_support_mul_sourceFunction Finset.univ α ν z (fun i _ => hsep i)]
    rw [heq]
    simp only [Source.sourceFunction]
    ring
  · exact fun hlog z hPz hsep => logarithmic_derivative_of_identity α ν P hlog z hPz hsep

/-- Corollary 3.3's integer criterion, stated with the ordinary source
function rather than a cleared-denominator representation. -/
theorem logarithmic_polynomial_iff_integer_masses (α : ι → ℂ) (ν : ι → ℝ)
    (hα : Function.Injective α) (hν : ∀ i, 0 < ν i) :
    (∃ P : ℂ[X], P.Monic ∧ ∀ z, P.eval z ≠ 0 → (∀ i, z ≠ α i) →
      P.derivative.eval z / P.eval z = ∑ i, (ν i : ℂ) / (z - α i)) ↔
      ∃ m : ι → ℕ, (∀ i, 0 < m i) ∧ ∀ i, ν i = (m i : ℝ) := by
  rw [← polynomial_realization_iff_integer_masses α ν hα hν]
  constructor
  · rintro ⟨P, hP, hlog⟩
    exact ⟨P, hP, (logarithmic_derivative_iff_identity α _ P hP.ne_zero).mp hlog⟩
  · rintro ⟨P, hP, hlog⟩
    exact ⟨P, hP, (logarithmic_derivative_iff_identity α _ P hP.ne_zero).mpr hlog⟩

/-- Monicity makes a polynomial realization unique; the proof compares
root multiplicities and excludes every additional root. -/
theorem monic_realization_unique (α ν : ι → ℂ) (hα : Function.Injective α)
    (P Q : ℂ[X]) (hP : P.Monic) (hQ : Q.Monic)
    (hlogP : P.derivative * Source.support Finset.univ α =
      P * Source.rawNumerator Finset.univ α ν)
    (hlogQ : Q.derivative * Source.support Finset.univ α =
      Q * Source.rawNumerator Finset.univ α ν) : P = Q := by
  have houtside (T : ℂ[X]) (hT : T ≠ 0)
      (hlog : T.derivative * Source.support Finset.univ α =
        T * Source.rawNumerator Finset.univ α ν) (z : ℂ)
      (hz : ∀ i, z ≠ α i) : T.rootMultiplicity z = 0 := by
    apply Polynomial.rootMultiplicity_eq_zero
    intro hroot
    have hsroot := Polynomial.isRoot_of_isRoot_of_dvd_derivative_mul hT
      (show T ∣ T.derivative * Source.support Finset.univ α from
        ⟨Source.rawNumerator Finset.univ α ν, hlog⟩) hroot
    exact Source.support_eval_nonzero Finset.univ α z (fun i _ => hz i) hsroot
  have hmult : ∀ z, P.rootMultiplicity z = Q.rootMultiplicity z := by
    intro z
    by_cases hz : ∃ i, z = α i
    · obtain ⟨i, rfl⟩ := hz
      have hp := source_mass_eq_rootMultiplicity α ν hα P hP.ne_zero hlogP i
      have hq := source_mass_eq_rootMultiplicity α ν hα Q hQ.ne_zero hlogQ i
      exact_mod_cast hp.symm.trans hq
    · have hsep : ∀ i, z ≠ α i := by simpa only [not_exists] using hz
      rw [houtside P hP.ne_zero hlogP z hsep, houtside Q hQ.ne_zero hlogQ z hsep]
  have hroots : P.roots = Q.roots := by
    apply Multiset.ext.mpr
    intro z
    simpa only [Polynomial.count_roots] using hmult z
  rw [Polynomial.eq_prod_roots_of_monic_of_splits_id hP (IsAlgClosed.splits P),
    Polynomial.eq_prod_roots_of_monic_of_splits_id hQ (IsAlgClosed.splits Q), hroots]

theorem source_support_derivative_at (α : ι → ℂ) (i : ι) :
    (Source.support Finset.univ α).derivative.eval (α i) =
      (Source.support (Finset.univ.erase i) α).eval (α i) := by
  have hd := Source.derivative_sourcePolynomial Finset.univ α (fun _ => 1)
    (fun _ _ => Nat.zero_lt_one)
  simp only [Source.sourcePolynomial, pow_one, Source.inheritedFactor, Nat.sub_self,
    pow_zero, Finset.prod_const_one, mul_one, Nat.cast_one] at hd
  change (Source.support Finset.univ α).derivative =
    Source.rawNumerator Finset.univ α (fun _ => (1 : ℂ)) at hd
  rw [hd, Source.rawNumerator_eval_at_source Finset.univ α (fun _ => (1 : ℂ))
    (Finset.mem_univ i), one_mul]

/-- The residue quotient is an exact algebraic identity at each simple
source of the support polynomial. -/
theorem source_mass_residue_formula (α ν : ι → ℂ) (hα : Function.Injective α)
    (hn : Source.mass Finset.univ ν ≠ 0) (i : ι) :
    ν i = Source.mass Finset.univ ν *
      (Source.numerator Finset.univ α ν).eval (α i) /
        (Source.support Finset.univ α).derivative.eval (α i) := by
  rw [source_support_derivative_at]
  have hd : (Source.support (Finset.univ.erase i) α).eval (α i) ≠ 0 := by
    apply Source.support_eval_nonzero
    intro j hj hij
    exact (Finset.mem_erase.mp hj).1 (hα hij.symm)
  rw [Source.numerator_eval_at_source _ _ _ (Finset.mem_univ i)]
  rw [Source.support_eval] at hd ⊢
  field_simp

end PolynomialGeometry.PolynomialRecovery
