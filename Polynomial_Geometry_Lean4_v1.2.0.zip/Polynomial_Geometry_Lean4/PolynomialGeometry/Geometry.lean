import Mathlib.Algebra.Group.Pi.Units
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.Data.Matrix.ColumnRowPartitioned
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Abel

/-!
# Source geometry and quadratic storage

This file proves the finite matrix identities underlying equations (4.1)--(4.6)
and the coordinate bridge of the article. All matrices act on a finite complex
space. The precise coverage of the rank and spectral conclusions is recorded
separately in the project correspondence map.
-/

open Matrix Complex
open scoped Matrix ComplexOrder

namespace PolynomialGeometry.Geometry

noncomputable section

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The rank-one matrix `u uᴴ`. -/
def outer (u : ι → ℂ) : Matrix ι ι ℂ := vecMulVec u (star u)

/-- Total source mass, with one unit of mass at the selected source. -/
def totalMass (u : ι → ℂ) : ℝ := 1 + ∑ j, normSq (u j)

/-- The source metric in reciprocal source coordinates. -/
noncomputable def metric (u : ι → ℂ) : Matrix ι ι ℂ := (1 + outer u)⁻¹

/-- Reciprocal source realization for a supplied diagonal resolvent matrix. -/
def reciprocal (u : ι → ℂ) (X : Matrix ι ι ℂ) : Matrix ι ι ℂ :=
  (1 + outer u) * X

omit [DecidableEq ι] in
theorem totalMass_pos (u : ι → ℂ) : 0 < totalMass u := by
  have hs : 0 ≤ ∑ j, normSq (u j) := Finset.sum_nonneg fun j _ => normSq_nonneg _
  dsimp [totalMass]
  linarith

omit [DecidableEq ι] in
theorem totalMass_ne_zero (u : ι → ℂ) : (totalMass u : ℂ) ≠ 0 := by
  exact_mod_cast ne_of_gt (totalMass_pos u)

omit [Fintype ι] [DecidableEq ι] in
theorem outer_hermitian (u : ι → ℂ) : (outer u).IsHermitian := by
  simp [outer, Matrix.IsHermitian, Matrix.conjTranspose_vecMulVec]

omit [DecidableEq ι] in
theorem outer_posSemidef (u : ι → ℂ) : (outer u).PosSemidef :=
  Matrix.posSemidef_vecMulVec_self_star u

theorem one_add_outer_posDef (u : ι → ℂ) : (1 + outer u).PosDef :=
  Matrix.PosDef.one.add_posSemidef (outer_posSemidef u)

theorem metric_posDef (u : ι → ℂ) : (metric u).PosDef :=
  (one_add_outer_posDef u).inv

theorem metric_hermitian (u : ι → ℂ) : (metric u).IsHermitian :=
  (metric_posDef u).isHermitian

omit [DecidableEq ι] in
theorem star_dot_self (u : ι → ℂ) :
    star u ⬝ᵥ u = ((∑ j, normSq (u j) : ℝ) : ℂ) := by
  simp only [dotProduct, Complex.ofReal_sum]
  apply Finset.sum_congr rfl
  intro j _
  exact (Complex.normSq_eq_conj_mul_self).symm

omit [DecidableEq ι] in
theorem outer_sq (u : ι → ℂ) :
    outer u * outer u = ((totalMass u : ℂ) - 1) • outer u := by
  unfold outer
  rw [vecMulVec_mul_vecMulVec, vecMulVec_smul, star_dot_self]
  congr 1
  simp [totalMass]

theorem metric_mul_source (u : ι → ℂ) : metric u * (1 + outer u) = 1 := by
  letI := (one_add_outer_posDef u).isUnit.invertible
  exact Matrix.inv_mul_of_invertible _

theorem source_mul_metric (u : ι → ℂ) : (1 + outer u) * metric u = 1 := by
  letI := (one_add_outer_posDef u).isUnit.invertible
  exact Matrix.mul_inv_of_invertible _

theorem metric_closed_form (u : ι → ℂ) :
    metric u = 1 - (totalMass u : ℂ)⁻¹ • outer u := by
  have hprod : (1 - (totalMass u : ℂ)⁻¹ • outer u) * (1 + outer u) = 1 := by
    rw [sub_mul, one_mul, smul_mul_assoc, mul_add, mul_one, outer_sq,
      smul_add, smul_smul]
    have hc : (totalMass u : ℂ)⁻¹ +
        (totalMass u : ℂ)⁻¹ * ((totalMass u : ℂ) - 1) = 1 := by
      field_simp [totalMass_ne_zero u]
      ring
    rw [← add_smul, hc, one_smul]
    abel
  calc
    metric u = 1 * metric u := by simp
    _ = ((1 - (totalMass u : ℂ)⁻¹ • outer u) * (1 + outer u)) * metric u := by
      rw [hprod]
    _ = (1 - (totalMass u : ℂ)⁻¹ • outer u) *
        ((1 + outer u) * metric u) := by rw [mul_assoc]
    _ = 1 - (totalMass u : ℂ)⁻¹ • outer u := by rw [source_mul_metric]; simp

theorem metric_mul_reciprocal (u : ι → ℂ) (X : Matrix ι ι ℂ) :
    metric u * reciprocal u X = X := by
  rw [reciprocal, ← mul_assoc, metric_mul_source, one_mul]

theorem reciprocal_adjoint_metric (u : ι → ℂ) (X : Matrix ι ι ℂ) :
    (reciprocal u X)ᴴ * metric u = Xᴴ := by
  have h := congrArg Matrix.conjTranspose (metric_mul_reciprocal u X)
  simpa only [conjTranspose_mul, (metric_hermitian u).eq] using h

theorem reciprocal_gram (u : ι → ℂ) (X : Matrix ι ι ℂ) :
    (reciprocal u X)ᴴ * metric u * reciprocal u X =
      Xᴴ * (1 + outer u) * X := by
  rw [reciprocal_adjoint_metric, reciprocal, mul_assoc]

/-- The scalar disk coefficient. -/
def diskCoefficient (a : ℝ) : ℝ := 1 - a ^ 2

/-- The disk inequality in reciprocal matrix coordinates. -/
def diskDefect (a : ℝ) (X : Matrix ι ι ℂ) : Matrix ι ι ℂ :=
  (diskCoefficient a : ℂ) • (Xᴴ * X) + (a : ℂ) • (X + Xᴴ) - 1

/-- The expansive transform whose inverse is the stable step map. -/
def expansive (a : ℝ) (u : ι → ℂ) (X : Matrix ι ι ℂ) : Matrix ι ι ℂ :=
  (a : ℂ) • 1 + (diskCoefficient a : ℂ) • reciprocal u X

/-- Exact source-metric defect identity, equation (4.5). It is an algebraic
identity for every matrix `X`; disk feasibility is used separately for positivity. -/
theorem expansive_defect (a : ℝ) (u : ι → ℂ) (X : Matrix ι ι ℂ) :
    (expansive a u X)ᴴ * metric u * expansive a u X - metric u =
      (diskCoefficient a : ℂ) • diskDefect a X +
      ((diskCoefficient a / totalMass u : ℝ) : ℂ) • outer u +
      ((diskCoefficient a : ℂ) ^ 2) • (Xᴴ * outer u * X) := by
  have hE := (metric_hermitian u).eq
  have hER := metric_mul_reciprocal u X
  have hRE := reciprocal_adjoint_metric u X
  have hRER := reciprocal_gram u X
  unfold expansive
  simp only [conjTranspose_add, conjTranspose_smul, conjTranspose_one,
    Complex.star_def, Complex.conj_ofReal, add_mul, mul_add, smul_mul_assoc,
    mul_smul_comm, one_mul, mul_one]
  rw [hER, hRE]
  simp only [reciprocal, mul_add, add_mul, one_mul, Matrix.mul_assoc]
  rw [metric_closed_form]
  unfold diskDefect
  simp only [smul_add, smul_sub, smul_smul]
  ext i j
  simp only [Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply,
    smul_eq_mul, Complex.ofReal_div, Complex.ofReal_sub, Complex.ofReal_pow,
    Complex.ofReal_one, diskCoefficient]
  ring

/-- Positive source loss follows from the disk inequality, with no strict
one-step definiteness assumed. -/
theorem expansive_defect_posSemidef (a : ℝ) (u : ι → ℂ) (X : Matrix ι ι ℂ)
    (ha : 0 ≤ diskCoefficient a) (hX : (diskDefect a X).PosSemidef) :
    ((expansive a u X)ᴴ * metric u * expansive a u X - metric u).PosSemidef := by
  rw [expansive_defect]
  have hc : (0 : ℂ) ≤ (diskCoefficient a : ℂ) := by exact_mod_cast ha
  have hn : (0 : ℂ) ≤ ((diskCoefficient a / totalMass u : ℝ) : ℂ) := by
    exact_mod_cast div_nonneg ha (le_of_lt (totalMass_pos u))
  have hc2 : (0 : ℂ) ≤ (diskCoefficient a : ℂ) ^ 2 := by
    exact_mod_cast sq_nonneg (diskCoefficient a)
  exact ((hX.smul hc).add ((outer_posSemidef u).smul hn)).add
    (((outer_posSemidef u).conjTranspose_mul_mul_same X).smul hc2)

/-- An expansive quadratic estimate with positive storage forces invertibility. -/
theorem isUnit_of_expansive {E S : Matrix ι ι ℂ} (hE : E.PosDef)
    (hS : (Sᴴ * E * S - E).PosSemidef) : IsUnit S := by
  by_contra h
  obtain ⟨x, hne, hx⟩ : ∃ x ≠ 0, S *ᵥ x = 0 := by
    obtain ⟨a, b, hab⟩ := Function.not_injective_iff.mp <|
      Matrix.mulVec_injective_iff_isUnit.not.mpr h
    exact ⟨a - b, by simp [sub_eq_zero, hab, mulVec_sub]⟩
  have hpos := hE.2 x hne
  have hnonneg := hS.2 x
  simp only [sub_mulVec, ← mulVec_mulVec, hx, mulVec_zero, zero_sub,
    dotProduct_neg] at hnonneg
  exact (not_lt_of_ge hnonneg) (neg_neg_of_pos hpos)

theorem expansive_isUnit (a : ℝ) (u : ι → ℂ) (X : Matrix ι ι ℂ)
    (ha : 0 ≤ diskCoefficient a) (hX : (diskDefect a X).PosSemidef) :
    IsUnit (expansive a u X) :=
  isUnit_of_expansive (metric_posDef u) (expansive_defect_posSemidef a u X ha hX)

/-- Pulling the expansive defect back by the inverse gives the exact
contractive defect, equation (4.6). -/
theorem inverse_defect (E S : Matrix ι ι ℂ) (hS : IsUnit S) :
    E - S⁻¹ᴴ * E * S⁻¹ = S⁻¹ᴴ * (Sᴴ * E * S - E) * S⁻¹ := by
  letI := hS.invertible
  have hleft : S⁻¹ᴴ * Sᴴ = 1 := by
    rw [← conjTranspose_mul, Matrix.mul_inv_of_invertible, conjTranspose_one]
  simp only [mul_sub, sub_mul]
  have hterm : S⁻¹ᴴ * (Sᴴ * E * S) * S⁻¹ = E := by
    calc
      _ = (S⁻¹ᴴ * Sᴴ) * E * (S * S⁻¹) := by simp only [Matrix.mul_assoc]
      _ = E := by rw [hleft, Matrix.mul_inv_of_invertible]; simp
  rw [hterm]

theorem inverse_defect_posSemidef (E S : Matrix ι ι ℂ) (hS : IsUnit S)
    (hD : (Sᴴ * E * S - E).PosSemidef) :
    (E - S⁻¹ᴴ * E * S⁻¹).PosSemidef := by
  rw [inverse_defect E S hS]
  exact hD.conjTranspose_mul_mul_same S⁻¹

/-- The diagonal resolvent determined by the nonselected source positions. -/
noncomputable def sourceResolvent (a : ℝ) (α : ι → ℂ) : Matrix ι ι ℂ :=
  diagonal fun j => ((a : ℂ) - α j)⁻¹

/-- The elementary reciprocal disk identity used in equation (4.4). -/
theorem reciprocal_disk_scalar (a : ℝ) (z : ℂ) (h : (a : ℂ) ≠ z) :
    diskCoefficient a * normSq (((a : ℂ) - z)⁻¹) +
      2 * a * (((a : ℂ) - z)⁻¹).re - 1 =
        (1 - normSq z) / normSq ((a : ℂ) - z) := by
  have hn : normSq ((a : ℂ) - z) ≠ 0 := by
    intro hz
    exact h (sub_eq_zero.mp (normSq_eq_zero.mp hz))
  rw [normSq_inv, inv_re]
  field_simp [hn]
  simp [diskCoefficient, Complex.normSq, Complex.sub_re, Complex.sub_im]
  ring

theorem diskDefect_diagonal (a : ℝ) (α : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j) :
    diskDefect a (sourceResolvent a α) =
      diagonal fun j => (((1 - normSq (α j)) /
        normSq ((a : ℂ) - α j) : ℝ) : ℂ) := by
  unfold diskDefect sourceResolvent
  rw [diagonal_conjTranspose, diagonal_mul_diagonal]
  simp only [diagonal_add, ← diagonal_smul]
  rw [← diagonal_one, diagonal_sub]
  congr 1
  funext j
  have h := congrArg (fun x : ℝ => (x : ℂ)) (reciprocal_disk_scalar a (α j) (hsep j))
  simp only [Pi.smul_apply,
    Pi.star_apply, smul_eq_mul, Complex.normSq_eq_conj_mul_self,
    Complex.ofReal_sub, Complex.ofReal_add, Complex.ofReal_mul, Complex.ofReal_one,
    Complex.ofReal_ofNat, Complex.star_def, Complex.add_conj] at h ⊢
  convert h using 1
  ring

theorem source_diskDefect_posSemidef (a : ℝ) (α : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1) :
    (diskDefect a (sourceResolvent a α)).PosSemidef := by
  rw [diskDefect_diagonal a α hsep]
  apply Matrix.PosSemidef.diagonal
  intro j
  change (0 : ℂ) ≤ (((1 - normSq (α j)) / normSq ((a : ℂ) - α j) : ℝ) : ℂ)
  exact_mod_cast div_nonneg (sub_nonneg.mpr (hdisk j)) (normSq_nonneg ((a : ℂ) - α j))

theorem source_expansive_isUnit (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1) :
    IsUnit (expansive a u (sourceResolvent a α)) := by
  apply expansive_isUnit
  · dsimp [diskCoefficient]
    nlinarith
  · exact source_diskDefect_posSemidef a α hsep hdisk

theorem source_contractivity (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1) :
    (metric u - (expansive a u (sourceResolvent a α))⁻¹ᴴ * metric u *
      (expansive a u (sourceResolvent a α))⁻¹).PosSemidef := by
  apply inverse_defect_posSemidef
  · exact source_expansive_isUnit a u α ha₀ ha₁ hsep hdisk
  · apply expansive_defect_posSemidef
    · dsimp [diskCoefficient]
      nlinarith
    · exact source_diskDefect_posSemidef a α hsep hdisk

/-- The row `-uᴴ`, indexed by a singleton for use in block matrices. -/
def sourceRow (u : ι → ℂ) : Matrix Unit ι ℂ := fun _ j => -star (u j)

/-- The elementary lift `[-uᴴ; I]` from reciprocal coordinates. -/
def sourceLift (u : ι → ℂ) : Matrix (Unit ⊕ ι) ι ℂ :=
  fromRows (sourceRow u) 1

/-- The source energy basis `W = [-uᴴ; I] E_g`. -/
noncomputable def energyBasis (u : ι → ℂ) : Matrix (Unit ⊕ ι) ι ℂ :=
  sourceLift u * metric u

omit [Fintype ι] [DecidableEq ι] in
theorem sourceRow_gram (u : ι → ℂ) : (sourceRow u)ᴴ * sourceRow u = outer u := by
  ext i j
  simp [sourceRow, outer, Matrix.mul_apply, Matrix.conjTranspose_apply,
    Matrix.vecMulVec_apply]

theorem sourceLift_gram (u : ι → ℂ) : (sourceLift u)ᴴ * sourceLift u = 1 + outer u := by
  unfold sourceLift
  rw [conjTranspose_fromRows_eq_fromCols_conjTranspose, fromCols_mul_fromRows,
    sourceRow_gram]
  simp [add_comm]

/-- The first identity of Proposition 6.1: the explicit lifted basis has
precisely the source metric as its Gram matrix. -/
theorem energyBasis_gram (u : ι → ℂ) : (energyBasis u)ᴴ * energyBasis u = metric u := by
  unfold energyBasis
  rw [conjTranspose_mul, (metric_hermitian u).eq]
  calc
    metric u * (sourceLift u)ᴴ * (sourceLift u * metric u) =
        metric u * ((sourceLift u)ᴴ * sourceLift u) * metric u := by simp only [Matrix.mul_assoc]
    _ = metric u := by rw [sourceLift_gram, metric_mul_source, one_mul]

/-- The Gram metric transforms by congruence under a change of source coordinates. -/
theorem coordinate_metric (u : ι → ℂ) (P : Matrix ι ι ℂ) :
    (energyBasis u * P)ᴴ * (energyBasis u * P) = Pᴴ * metric u * P := by
  rw [conjTranspose_mul]
  calc
    Pᴴ * (energyBasis u)ᴴ * (energyBasis u * P) =
        Pᴴ * ((energyBasis u)ᴴ * energyBasis u) * P := by simp only [Matrix.mul_assoc]
    _ = Pᴴ * metric u * P := by rw [energyBasis_gram]

/-- The reciprocal-coordinate formula for the compressed operator. -/
noncomputable def compressed (a : ℂ) (u : ι → ℂ) (D : Matrix ι ι ℂ) :
    Matrix ι ι ℂ := (a • outer u + D) * metric u

theorem compression_difference (a : ℂ) (u : ι → ℂ) (D : Matrix ι ι ℂ) :
    a • 1 - compressed a u D = (a • 1 - D) * metric u := by
  have h := congrArg (fun A : Matrix ι ι ℂ => a • A) (source_mul_metric u)
  simp only [add_mul, one_mul, smul_add] at h
  unfold compressed
  simp only [add_mul, sub_mul, smul_mul_assoc, one_mul]
  rw [← h]
  abel

/-- If `D=aI-X⁻¹`, the compressed-source difference has reciprocal matrix
`(I+u uᴴ)X`. This proves the matrix, not only spectral, correspondence. -/
theorem compression_reciprocal_inverse (a : ℂ) (u : ι → ℂ)
    (X : Matrix ι ι ℂ) :
    a • 1 - compressed a u (a • 1 - X⁻¹) = (reciprocal u X)⁻¹ := by
  rw [compression_difference]
  have hd : a • (1 : Matrix ι ι ℂ) - (a • 1 - X⁻¹) = X⁻¹ := by abel
  rw [hd]
  simp [reciprocal, metric, Matrix.mul_inv_rev]

/-- Congruence by an invertible step preserves the rank of the loss matrix. -/
theorem inverse_defect_rank (E S : Matrix ι ι ℂ) (hS : IsUnit S) :
    (E - S⁻¹ᴴ * E * S⁻¹).rank = (Sᴴ * E * S - E).rank := by
  rw [inverse_defect E S hS]
  have hi : IsUnit S⁻¹ := Matrix.isUnit_nonsing_inv_iff.mpr hS
  have ht : IsUnit S⁻¹ᴴ := by
    simpa only [Matrix.star_eq_conjTranspose] using hi.star
  rw [Matrix.rank_mul_eq_left_of_isUnit_det _ _ ((Matrix.isUnit_iff_isUnit_det _).mp hi),
    Matrix.rank_mul_eq_right_of_isUnit_det _ _ ((Matrix.isUnit_iff_isUnit_det _).mp ht)]

/-- The full square-root mass vector, including the selected unit mass. -/
def massVector (u : ι → ℂ) : Unit ⊕ ι → ℂ := Sum.elim (fun _ => 1) u

theorem sourceLift_mulVec (u x : ι → ℂ) :
    sourceLift u *ᵥ x = Sum.elim (fun _ => -(star u ⬝ᵥ x)) x := by
  rw [sourceLift, fromRows_mulVec]
  congr 1
  · funext i
    simp [sourceRow, Matrix.mulVec, dotProduct, Finset.sum_neg_distrib]
  · exact Matrix.one_mulVec x

/-- The lift is injective because its lower block is the identity. -/
theorem sourceLift_injective (u : ι → ℂ) : Function.Injective (sourceLift u).mulVec := by
  intro x y h
  funext j
  have hj := congrFun h (Sum.inr j)
  simpa only [sourceLift_mulVec, Sum.elim_inr] using hj

/-- Every source vector perpendicular to the mass vector is represented by
the explicit lift. This proves the required range statement without a
dimension assumption. -/
theorem sourceLift_range (u : ι → ℂ) (v : Unit ⊕ ι → ℂ) :
    star (massVector u) ⬝ᵥ v = 0 ↔
      sourceLift u *ᵥ (fun j => v (Sum.inr j)) = v := by
  have he : star (massVector u) ⬝ᵥ v =
      v (Sum.inl ()) + (star u ⬝ᵥ fun j => v (Sum.inr j)) := by
    simp [dotProduct, Fintype.sum_sum_type, massVector]
  rw [he, sourceLift_mulVec]
  constructor
  · intro h
    funext j
    cases j with
    | inl j => cases j; simp only [Sum.elim_inl]; exact (eq_neg_of_add_eq_zero_left h).symm
    | inr j => rfl
  · intro h
    have hj := congrFun h (Sum.inl ())
    simpa only [Sum.elim_inl] using (eq_neg_iff_add_eq_zero.mp hj.symm)

theorem energyBasis_injective (u : ι → ℂ) : Function.Injective (energyBasis u).mulVec := by
  intro x y h
  have hm := Matrix.mulVec_injective_iff_isUnit.mpr (metric_posDef u).isUnit
  apply hm
  apply sourceLift_injective u
  simpa only [energyBasis, ← Matrix.mulVec_mulVec] using h

/-- Explicit coordinates of a column family in the source hyperplane. -/
def sourceCoordinates (u : ι → ℂ) (Y : Matrix (Unit ⊕ ι) ι ℂ) : Matrix ι ι ℂ :=
  (1 + outer u) * (show Matrix ι ι ℂ from fun i j => Y (Sum.inr i) j)

theorem energyBasis_coordinates (u : ι → ℂ) (Y : Matrix (Unit ⊕ ι) ι ℂ)
    (hY : ∀ j, star (massVector u) ⬝ᵥ (fun i => Y i j) = 0) :
    energyBasis u * sourceCoordinates u Y = Y := by
  unfold energyBasis sourceCoordinates
  rw [Matrix.mul_assoc (sourceLift u), ← Matrix.mul_assoc (metric u),
    metric_mul_source, Matrix.one_mul]
  ext i j
  have hj := (sourceLift_range u (fun i => Y i j)).mp (hY j)
  exact congrFun hj i

/-- The coordinate formula using the source Gram matrix is exact. -/
theorem sourceCoordinates_gram_formula (u : ι → ℂ) (Y : Matrix (Unit ⊕ ι) ι ℂ)
    (hY : ∀ j, star (massVector u) ⬝ᵥ (fun i => Y i j) = 0) :
    sourceCoordinates u Y = (metric u)⁻¹ * (energyBasis u)ᴴ * Y := by
  letI := (metric_posDef u).isUnit.invertible
  calc
    sourceCoordinates u Y = (metric u)⁻¹ * metric u * sourceCoordinates u Y := by
      rw [Matrix.inv_mul_of_invertible, one_mul]
    _ = (metric u)⁻¹ * ((energyBasis u)ᴴ * energyBasis u) * sourceCoordinates u Y := by
      rw [energyBasis_gram]
    _ = (metric u)⁻¹ * (energyBasis u)ᴴ * Y := by
      rw [Matrix.mul_assoc (metric u)⁻¹, Matrix.mul_assoc (metric u)⁻¹,
        Matrix.mul_assoc (energyBasis u)ᴴ, energyBasis_coordinates u Y hY]

/-- The change of coordinates is invertible when the second family is a
basis, expressed by positive definiteness of its Gram matrix. -/
theorem sourceCoordinates_isUnit (u : ι → ℂ) (Y : Matrix (Unit ⊕ ι) ι ℂ)
    (hY : ∀ j, star (massVector u) ⬝ᵥ (fun i => Y i j) = 0)
    (hGram : (Yᴴ * Y).PosDef) : IsUnit (sourceCoordinates u Y) := by
  apply Matrix.mulVec_injective_iff_isUnit.mp
  intro x y h
  have hgraminj := Matrix.mulVec_injective_iff_isUnit.mpr hGram.isUnit
  apply hgraminj
  have hy : Y *ᵥ x = Y *ᵥ y := by
    rw [← energyBasis_coordinates u Y hY, ← Matrix.mulVec_mulVec,
      ← Matrix.mulVec_mulVec, h]
  simp only [← Matrix.mulVec_mulVec, hy]

theorem sourceCoordinates_metric (u : ι → ℂ) (Y : Matrix (Unit ⊕ ι) ι ℂ)
    (hY : ∀ j, star (massVector u) ⬝ᵥ (fun i => Y i j) = 0) :
    Yᴴ * Y = (sourceCoordinates u Y)ᴴ * metric u * sourceCoordinates u Y := by
  rw [← coordinate_metric, energyBasis_coordinates u Y hY]

theorem sourceCoordinates_unique (u : ι → ℂ) (Y : Matrix (Unit ⊕ ι) ι ℂ)
    (hY : ∀ j, star (massVector u) ⬝ᵥ (fun i => Y i j) = 0)
    (P : Matrix ι ι ℂ) (hP : energyBasis u * P = Y) :
    P = sourceCoordinates u Y := by
  ext i j
  have hcol : energyBasis u *ᵥ (fun i => P i j) =
      energyBasis u *ᵥ (fun i => sourceCoordinates u Y i j) := by
    have hm := hP.trans (energyBasis_coordinates u Y hY).symm
    exact funext fun k => congrFun (congrFun hm k) j
  exact congrFun (energyBasis_injective u hcol) i

/-- The ambient operator with the selected source separated as the first block. -/
def sourceOperator (a : ℂ) (D : Matrix ι ι ℂ) : Matrix (Unit ⊕ ι) (Unit ⊕ ι) ℂ :=
  fromBlocks (a • 1) 0 0 D

theorem sourceLift_operator_gram (a : ℂ) (u : ι → ℂ) (D : Matrix ι ι ℂ) :
    (sourceLift u)ᴴ * sourceOperator a D * sourceLift u = a • outer u + D := by
  unfold sourceLift sourceOperator
  rw [conjTranspose_fromRows_eq_fromCols_conjTranspose, fromCols_mul_fromBlocks,
    fromCols_mul_fromRows]
  simp [Matrix.mul_smul, sourceRow_gram, Matrix.smul_mul]

/-- The source-coordinate compression is computed by the nonorthonormal
basis formula, including its Gram correction. -/
theorem energyBasis_compression (a : ℂ) (u : ι → ℂ) (D : Matrix ι ι ℂ) :
    (energyBasis u)ᴴ * sourceOperator a D * energyBasis u =
      metric u * compressed a u D := by
  unfold energyBasis compressed
  rw [conjTranspose_mul, (metric_hermitian u).eq]
  calc
    metric u * (sourceLift u)ᴴ * sourceOperator a D * (sourceLift u * metric u) =
      metric u * ((sourceLift u)ᴴ * sourceOperator a D * sourceLift u) * metric u := by
        simp only [Matrix.mul_assoc]
    _ = metric u * ((a • outer u + D) * metric u) := by
      rw [sourceLift_operator_gram, Matrix.mul_assoc]

theorem sourceLift_orthogonal (u : ι → ℂ) :
    (sourceLift u)ᴴ *ᵥ massVector u = 0 := by
  funext j
  simp [sourceLift, sourceRow, massVector, Matrix.mulVec, dotProduct,
    Matrix.conjTranspose_apply, Matrix.fromRows, Fintype.sum_sum_type, Matrix.one_apply]

theorem energyBasis_orthogonal (u : ι → ℂ) :
    (energyBasis u)ᴴ *ᵥ massVector u = 0 := by
  rw [energyBasis, conjTranspose_mul, ← Matrix.mulVec_mulVec, sourceLift_orthogonal,
    Matrix.mulVec_zero]

/-- Any Jordan/source family satisfying the actual source equation yields
an intertwiner for the same compressed operator. The residual is projected
away because it lies along the mass vector. -/
theorem sourceCoordinates_intertwine (a : ℂ) (u : ι → ℂ)
    (D J : Matrix ι ι ℂ) (Y : Matrix (Unit ⊕ ι) ι ℂ) (ℓ : ι → ℂ)
    (hY : ∀ j, star (massVector u) ⬝ᵥ (fun i => Y i j) = 0)
    (hSource : sourceOperator a D * Y = Y * J - vecMulVec (massVector u) ℓ) :
    compressed a u D * sourceCoordinates u Y = sourceCoordinates u Y * J := by
  have h := congrArg (fun M => (energyBasis u)ᴴ * M) hSource
  dsimp only at h
  rw [Matrix.mul_sub, Matrix.mul_vecMulVec, energyBasis_orthogonal,
    Matrix.zero_vecMulVec, sub_zero] at h
  rw [← energyBasis_coordinates u Y hY] at h
  have he : metric u * (compressed a u D * sourceCoordinates u Y) =
      metric u * (sourceCoordinates u Y * J) := by
    simpa only [← Matrix.mul_assoc, energyBasis_compression, energyBasis_gram] using h
  have hi := congrArg (fun M => (metric u)⁻¹ * M) he
  letI := (metric_posDef u).isUnit.invertible
  simpa only [← Matrix.mul_assoc, Matrix.inv_mul_of_invertible, Matrix.one_mul] using hi

/-- Resolvents transform under an invertible intertwiner. -/
theorem resolvent_similarity (a : ℂ) (A J P : Matrix ι ι ℂ)
    (hP : IsUnit P) (hAP : A * P = P * J) :
    (a • 1 - J)⁻¹ = P⁻¹ * (a • 1 - A)⁻¹ * P := by
  letI := hP.invertible
  have hJ : J = P⁻¹ * A * P := by
    have h := congrArg (fun M => P⁻¹ * M) hAP
    simpa only [← Matrix.mul_assoc, Matrix.inv_mul_of_invertible, Matrix.one_mul] using h.symm
  have he : a • 1 - J = P⁻¹ * (a • 1 - A) * P := by
    rw [Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_smul, Matrix.mul_one,
      Matrix.smul_mul, Matrix.inv_mul_of_invertible, hJ]
  rw [he, Matrix.mul_inv_rev, Matrix.mul_inv_rev, Matrix.inv_inv_of_invertible]
  simp only [Matrix.mul_assoc]

/-- The matrix transform is exactly the disk automorphism applied to the
compressed dynamics, whenever its reciprocal matrix is invertible. -/
theorem inverse_expansive_mobius (a : ℝ) (u : ι → ℂ) (X : Matrix ι ι ℂ)
    (hR : IsUnit (reciprocal u X)) :
    (expansive a u X)⁻¹ =
      (((a : ℂ) • 1 - ((a : ℂ) • 1 - (reciprocal u X)⁻¹))) *
        (1 - (a : ℂ) • ((a : ℂ) • 1 - (reciprocal u X)⁻¹))⁻¹ := by
  let R := reciprocal u X
  letI := hR.invertible
  have hS : expansive a u X = (1 - (a : ℂ) • ((a : ℂ) • 1 - R⁻¹)) * R := by
    unfold expansive diskCoefficient
    simp only [Matrix.sub_mul, Matrix.one_mul, smul_sub, Matrix.smul_mul,
      smul_smul, Matrix.inv_mul_of_invertible, Complex.ofReal_sub,
      Complex.ofReal_one, Complex.ofReal_pow, sub_smul, one_smul]
    rw [pow_two]
    module
  rw [hS, Matrix.mul_inv_rev]
  congr 1
  dsimp [R]
  abel

/-- Distinctness from the selected source makes the diagonal resolvent invertible. -/
theorem sourceResolvent_isUnit (a : ℝ) (α : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j) : IsUnit (sourceResolvent a α) := by
  unfold sourceResolvent
  rw [Matrix.isUnit_diagonal, Pi.isUnit_iff]
  intro j
  exact isUnit_iff_ne_zero.mpr (inv_ne_zero (sub_ne_zero.mpr (hsep j)))

theorem sourceResolvent_inverse (a : ℝ) (α : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j) :
    (sourceResolvent a α)⁻¹ = (a : ℂ) • 1 - diagonal α := by
  apply Matrix.inv_eq_left_inv
  unfold sourceResolvent
  rw [← diagonal_one, ← diagonal_smul, diagonal_sub, diagonal_mul_diagonal]
  congr 1
  funext j
  simp [sub_ne_zero.mpr (hsep j)]

theorem source_reciprocal_isUnit (a : ℝ) (u α : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j) :
    IsUnit (reciprocal u (sourceResolvent a α)) :=
  (one_add_outer_posDef u).isUnit.mul (sourceResolvent_isUnit a α hsep)

/-- The direct equality between source compression and reciprocal dynamics. -/
theorem source_compression_reciprocal (a : ℝ) (u α : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j) :
    (a : ℂ) • 1 - compressed a u (diagonal α) =
      (reciprocal u (sourceResolvent a α))⁻¹ := by
  have h := compression_reciprocal_inverse (a : ℂ) u (sourceResolvent a α)
  rw [sourceResolvent_inverse a α hsep] at h
  have he : (a : ℂ) • (1 : Matrix ι ι ℂ) -
      ((a : ℂ) • 1 - diagonal α) = diagonal α := by abel
  simpa only [he] using h

/-- Full metric-and-resolvent bridge for source coordinates. Its hypotheses
are the source equation, zero-output condition and nonsingularity of the
Jordan Gram matrix; none of the asserted bridge identities is assumed. -/
theorem coordinate_bridge (a : ℝ) (u α : ι → ℂ)
    (J : Matrix ι ι ℂ) (Y : Matrix (Unit ⊕ ι) ι ℂ) (ℓ : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j)
    (hY : ∀ j, star (massVector u) ⬝ᵥ (fun i => Y i j) = 0)
    (hGram : (Yᴴ * Y).PosDef)
    (hSource : sourceOperator a (diagonal α) * Y =
      Y * J - vecMulVec (massVector u) ℓ) :
    ∃! P : Matrix ι ι ℂ,
      energyBasis u * P = Y ∧ IsUnit P ∧
      Yᴴ * Y = Pᴴ * metric u * P ∧
      compressed a u (diagonal α) * P = P * J ∧
      ((a : ℂ) • 1 - J)⁻¹ = P⁻¹ * reciprocal u (sourceResolvent a α) * P := by
  let P := sourceCoordinates u Y
  have hP := sourceCoordinates_isUnit u Y hY hGram
  have hPJ := sourceCoordinates_intertwine (a : ℂ) u (diagonal α) J Y ℓ hY hSource
  have hres := resolvent_similarity (a : ℂ) (compressed a u (diagonal α)) J P hP hPJ
  rw [source_compression_reciprocal a u α hsep] at hres
  have hi := source_reciprocal_isUnit a u α hsep
  letI := hi.invertible
  rw [Matrix.inv_inv_of_invertible] at hres
  refine ⟨P, ⟨energyBasis_coordinates u Y hY, hP,
    sourceCoordinates_metric u Y hY, hPJ, hres⟩, ?_⟩
  intro Q hQ
  exact sourceCoordinates_unique u Y hY Q hQ.1

/-- The inverse expansive step is the rational disk map of the source compression. -/
theorem source_mobius_transform (a : ℝ) (u α : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j) :
    (expansive a u (sourceResolvent a α))⁻¹ =
      ((a : ℂ) • 1 - compressed a u (diagonal α)) *
        (1 - (a : ℂ) • compressed a u (diagonal α))⁻¹ := by
  have hc := source_compression_reciprocal a u α hsep
  have he : (a : ℂ) • (1 : Matrix ι ι ℂ) -
      (reciprocal u (sourceResolvent a α))⁻¹ = compressed a u (diagonal α) := by
    rw [← hc]
    abel
  simpa only [he] using inverse_expansive_mobius a u (sourceResolvent a α)
    (source_reciprocal_isUnit a u α hsep)

omit [DecidableEq ι] in
/-- Cauchy--Schwarz in source coordinates, without introducing a separate
coordinate-dependent norm type in the statement. -/
theorem source_cauchy_schwarz (u x : ι → ℂ) :
    normSq (star u ⬝ᵥ x) ≤ (∑ j, normSq (u j)) * (∑ j, normSq (x j)) := by
  have h := inner_mul_inner_self_le (𝕜 := ℂ) (WithLp.toLp 2 u) (WithLp.toLp 2 x)
  rw [norm_inner_symm (WithLp.toLp 2 x) (WithLp.toLp 2 u)] at h
  simp only [EuclideanSpace.inner_toLp_toLp] at h
  rw [dotProduct_comm x (star u), dotProduct_comm u (star u),
    dotProduct_comm x (star x), star_dot_self, star_dot_self] at h
  simpa only [← pow_two, Complex.ofReal_re, ← Complex.normSq_eq_norm_sq] using h

/-- Exact quadratic value in the source metric. -/
theorem metric_quadratic_value (u x : ι → ℂ) :
    (star x ⬝ᵥ metric u *ᵥ x).re =
      (∑ j, normSq (x j)) - normSq (star u ⬝ᵥ x) / totalMass u := by
  rw [metric_closed_form, Matrix.sub_mulVec, Matrix.one_mulVec,
    Matrix.smul_mulVec, dotProduct_sub, dotProduct_smul, star_dot_self]
  have he : star x ⬝ᵥ outer u *ᵥ x = (normSq (star u ⬝ᵥ x) : ℂ) := by
    rw [outer, Matrix.vecMulVec_mulVec, dotProduct_smul, op_smul_eq_mul,
      Complex.normSq_eq_conj_mul_self, ← Complex.star_def]
    rw [← star_dotProduct]
  rw [he]
  simp [Complex.mul_re, ← Complex.ofReal_inv, div_eq_mul_inv, mul_comm]

/-- The exact two-sided source norm bounds from equation (4.2). -/
theorem metric_quadratic_bounds (u x : ι → ℂ) :
    (∑ j, normSq (x j)) / totalMass u ≤ (star x ⬝ᵥ metric u *ᵥ x).re ∧
      (star x ⬝ᵥ metric u *ᵥ x).re ≤ ∑ j, normSq (x j) := by
  rw [metric_quadratic_value]
  have hn := totalMass_pos u
  have hc := source_cauchy_schwarz u x
  constructor
  · apply (div_le_iff₀ hn).mpr
    have h : (∑ j, normSq (x j)) ≤
        ((∑ j, normSq (x j)) - normSq (star u ⬝ᵥ x) / totalMass u) * totalMass u := by
      rw [sub_mul, div_mul_cancel₀ _ (ne_of_gt hn)]
      unfold totalMass
      nlinarith
    exact h
  · exact sub_le_self _ (div_nonneg (normSq_nonneg _) hn.le)

/-- The interior source indices used in the exact rank formula. -/
def interiorSet (α : ι → ℂ) : Finset ι :=
  Finset.univ.filter (fun j => normSq (α j) < 1)

/-- Real normalization of the first dense loss row. -/
def sourceScale (a : ℝ) (u : ι → ℂ) : ℝ :=
  Real.sqrt (diskCoefficient a / totalMass u)

def sourceLossDiagonal (a : ℝ) (α : ι → ℂ) (j : ι) : ℂ :=
  Real.sqrt (diskCoefficient a *
    ((1 - normSq (α j)) / normSq ((a : ℂ) - α j)))

def sourceLossRow (a : ℝ) (u : ι → ℂ) (j : ι) : ℂ :=
  (sourceScale a u : ℂ) * star (u j)

def sourceLossRatio (a : ℝ) (u α : ι → ℂ) (j : ι) : ℂ :=
  ((diskCoefficient a / sourceScale a u : ℝ) : ℂ) * ((a : ℂ) - α j)⁻¹

omit [Fintype ι] [DecidableEq ι] in
theorem diskCoefficient_pos {a : ℝ} (ha₀ : 0 ≤ a) (ha₁ : a < 1) :
    0 < diskCoefficient a := by
  dsimp [diskCoefficient]
  nlinarith

omit [DecidableEq ι] in
theorem sourceScale_pos {a : ℝ} (u : ι → ℂ) (ha₀ : 0 ≤ a) (ha₁ : a < 1) :
    0 < sourceScale a u :=
  Real.sqrt_pos.mpr (div_pos (diskCoefficient_pos ha₀ ha₁) (totalMass_pos u))

omit [DecidableEq ι] in
theorem sourceScale_sq {a : ℝ} (u : ι → ℂ) (ha₀ : 0 ≤ a) (ha₁ : a < 1) :
    (sourceScale a u) ^ 2 = diskCoefficient a / totalMass u :=
  Real.sq_sqrt (div_nonneg (diskCoefficient_pos ha₀ ha₁).le (totalMass_pos u).le)

omit [DecidableEq ι] in
theorem sourceLossDiagonal_ne_zero {a : ℝ} (α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hsep : ∀ j, (a : ℂ) ≠ α j)
    (j : ι) (hj : j ∈ interiorSet α) : sourceLossDiagonal a α j ≠ 0 := by
  have hα : normSq (α j) < 1 := (Finset.mem_filter.mp hj).2
  have hden : 0 < normSq ((a : ℂ) - α j) :=
    Complex.normSq_pos.mpr (sub_ne_zero.mpr (hsep j))
  have hh := Real.sqrt_pos.mpr
    (mul_pos (diskCoefficient_pos ha₀ ha₁) (div_pos (sub_pos.mpr hα) hden))
  dsimp only [sourceLossDiagonal]
  exact_mod_cast ne_of_gt hh

omit [DecidableEq ι] in
theorem sourceLossRow_ne_zero {a : ℝ} (u : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0) (j : ι) :
    sourceLossRow a u j ≠ 0 := by
  apply mul_ne_zero
  · exact_mod_cast ne_of_gt (sourceScale_pos u ha₀ ha₁)
  · exact star_ne_zero.mpr (hu j)

omit [DecidableEq ι] in
theorem sourceLossRatio_injective {a : ℝ} (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hα : Function.Injective α) :
    Function.Injective (sourceLossRatio a u α) := by
  have ht : ((diskCoefficient a / sourceScale a u : ℝ) : ℂ) ≠ 0 := by
    exact_mod_cast ne_of_gt (div_pos (diskCoefficient_pos ha₀ ha₁) (sourceScale_pos u ha₀ ha₁))
  intro i j hij
  apply hα
  have h := mul_left_cancel₀ ht hij
  exact sub_right_injective (inv_injective h)

omit [DecidableEq ι] in
/-- The second dense row reduces to the unnormalized source-resolvent row. -/
theorem sourceLossRow_ratio {a : ℝ} (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (j : ι) :
    sourceLossRow a u j * sourceLossRatio a u α j =
      (diskCoefficient a : ℂ) * star (u j) * ((a : ℂ) - α j)⁻¹ := by
  have ht : (sourceScale a u : ℂ) ≠ 0 := by
    exact_mod_cast ne_of_gt (sourceScale_pos u ha₀ ha₁)
  unfold sourceLossRow sourceLossRatio
  push_cast
  field_simp

omit [Fintype ι] [DecidableEq ι] in
/-- The square-root interior row has precisely the diagonal energy coefficient,
including the vanishing boundary coordinates. -/
theorem sourceLossDiagonal_normSq {a : ℝ} (α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hdisk : ∀ j, normSq (α j) ≤ 1) (j : ι) :
    normSq (sourceLossDiagonal a α j) = diskCoefficient a *
      ((1 - normSq (α j)) / normSq ((a : ℂ) - α j)) := by
  unfold sourceLossDiagonal
  rw [Complex.normSq_ofReal, Real.mul_self_sqrt]
  exact mul_nonneg (diskCoefficient_pos ha₀ ha₁).le
    (div_nonneg (sub_nonneg.mpr (hdisk j)) (normSq_nonneg _))

/-- Gram contribution of the interior coordinate rows. -/
theorem sourceLossDiagonal_gram {a : ℝ} (α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hsep : ∀ j, (a : ℂ) ≠ α j)
    (hdisk : ∀ j, normSq (α j) ≤ 1) :
    diagonal (fun j => if j ∈ interiorSet α then
      star (sourceLossDiagonal a α j) * sourceLossDiagonal a α j else 0) =
      (diskCoefficient a : ℂ) • diskDefect a (sourceResolvent a α) := by
  rw [diskDefect_diagonal a α hsep, ← diagonal_smul]
  congr 1
  funext j
  by_cases hj : j ∈ interiorSet α
  · simp only [hj, if_pos, Pi.smul_apply, smul_eq_mul, Complex.star_def,
      ← Complex.normSq_eq_conj_mul_self, sourceLossDiagonal_normSq α ha₀ ha₁ hdisk]
    push_cast
    rfl
  · have he : normSq (α j) = 1 := by
      have hn : ¬ normSq (α j) < 1 := by simpa [interiorSet] using hj
      exact le_antisymm (hdisk j) (le_of_not_gt hn)
    simp [hj, he]

omit [DecidableEq ι] in
/-- Gram contribution of the first dense source row. -/
theorem sourceLossRow_gram {a : ℝ} (u : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) :
    vecMulVec (star (sourceLossRow a u)) (sourceLossRow a u) =
      ((diskCoefficient a / totalMass u : ℝ) : ℂ) • outer u := by
  have hs : (sourceScale a u : ℂ) ^ 2 =
      ((diskCoefficient a / totalMass u : ℝ) : ℂ) := by
    exact_mod_cast sourceScale_sq u ha₀ ha₁
  ext i j
  simp only [Matrix.vecMulVec_apply, sourceLossRow, Pi.star_apply,
    StarMul.star_mul, Complex.star_def, Complex.conj_ofReal, Complex.conj_conj,
    Matrix.smul_apply, outer, smul_eq_mul]
  rw [← hs]
  ring

/-- Gram contribution of the second dense source row. -/
theorem sourceLossRatio_gram {a : ℝ} (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) :
    vecMulVec (star (fun j => sourceLossRow a u j * sourceLossRatio a u α j))
      (fun j => sourceLossRow a u j * sourceLossRatio a u α j) =
      (diskCoefficient a : ℂ) ^ 2 •
        ((sourceResolvent a α)ᴴ * outer u * sourceResolvent a α) := by
  simp only [sourceLossRow_ratio u α ha₀ ha₁]
  ext i j
  simp [Matrix.vecMulVec_apply, sourceResolvent, diagonal_conjTranspose,
    Matrix.diagonal_mul, Matrix.mul_diagonal, Matrix.smul_apply,
    outer]
  ring

/-- The cross-multiplied Möbius identity used for spectral mapping. -/
theorem source_mobius_relation (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, normSq (α j) ≤ 1) :
    (1 - (a : ℂ) • compressed a u (diagonal α)) *
      (expansive a u (sourceResolvent a α))⁻¹ =
      (a : ℂ) • 1 - compressed a u (diagonal α) := by
  let R := reciprocal u (sourceResolvent a α)
  letI := (source_reciprocal_isUnit a u α hsep).invertible
  letI := (source_expansive_isUnit a u α ha₀ ha₁ hsep hdisk).invertible
  have hc := source_compression_reciprocal a u α hsep
  have hA : compressed a u (diagonal α) = (a : ℂ) • 1 - R⁻¹ := by
    change compressed a u (diagonal α) = (a : ℂ) • 1 -
      (reciprocal u (sourceResolvent a α))⁻¹
    rw [← hc]
    abel
  have hRI : R⁻¹ * R = 1 := Matrix.inv_mul_of_invertible R
  have hN : 1 - (a : ℂ) • compressed a u (diagonal α) =
      R⁻¹ * expansive a u (sourceResolvent a α) := by
    rw [hA]
    unfold expansive diskCoefficient
    change 1 - (a : ℂ) • ((a : ℂ) • 1 - R⁻¹) =
      R⁻¹ * ((a : ℂ) • 1 + ((1 - a ^ 2 : ℝ) : ℂ) • R)
    simp only [Matrix.mul_add, Matrix.mul_sub, Matrix.mul_smul, Matrix.mul_one,
      hRI, smul_sub, smul_smul, Complex.ofReal_sub,
      Complex.ofReal_one, Complex.ofReal_pow, sub_smul, one_smul]
    module
  rw [hN, Matrix.mul_assoc, Matrix.mul_inv_of_invertible, Matrix.mul_one]
  exact hc.symm

/-- Every actual eigenvector of the compressed matrix lifts to the ambient
source equation and the zero-output hyperplane. This is the bridge needed
for strict source spectral localization. -/
theorem compressed_eigenpair_source (a w : ℂ) (u α x : ι → ℂ)
    (hx : x ≠ 0) (he : compressed a u (diagonal α) *ᵥ x = w • x) :
    let y := energyBasis u *ᵥ x
    let c := (a - w) * (star u ⬝ᵥ metric u *ᵥ x)
    y ≠ 0 ∧ (∑ j, star (massVector u j) * y j) = 0 ∧
      ∀ j, Sum.elim (fun _ : Unit => a) α j * y j = w * y j - massVector u j * c := by
  let z := metric u *ᵥ x
  have hxz : x = (1 + outer u) *ᵥ z := by
    dsimp [z]
    rw [Matrix.mulVec_mulVec, source_mul_metric, Matrix.one_mulVec]
  have hU : outer u *ᵥ z = (star u ⬝ᵥ z) • u := by
    rw [outer, Matrix.vecMulVec_mulVec, op_smul_eq_smul]
  have he' : (a • outer u + diagonal α) *ᵥ z = w • ((1 + outer u) *ᵥ z) := by
    rw [← hxz]
    dsimp only [z]
    rw [Matrix.mulVec_mulVec]
    exact he
  rw [Matrix.add_mulVec, Matrix.smul_mulVec, Matrix.add_mulVec,
    Matrix.one_mulVec, hU] at he'
  have hecoord (j : ι) : α j * z j =
      w * z j - u j * ((a - w) * (star u ⬝ᵥ z)) := by
    have hj := congrFun he' j
    simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul, Matrix.mulVec_diagonal] at hj
    linear_combination hj
  dsimp only
  refine ⟨?_, ?_, ?_⟩
  · intro h
    apply hx
    exact energyBasis_injective u (by simpa only [Matrix.mulVec_zero] using h)
  · change star (massVector u) ⬝ᵥ (energyBasis u *ᵥ x) = 0
    rw [energyBasis, ← Matrix.mulVec_mulVec, sourceLift_mulVec]
    simp [dotProduct, massVector, Fintype.sum_sum_type]
  · intro j
    rw [energyBasis, ← Matrix.mulVec_mulVec]
    change Sum.elim (fun _ : Unit => a) α j *
        (sourceLift u *ᵥ z) j = w * (sourceLift u *ᵥ z) j -
        massVector u j * ((a - w) * (star u ⬝ᵥ z))
    rw [sourceLift_mulVec]
    cases j with
    | inl j => simp only [Sum.elim_inl, massVector, one_mul]; ring
    | inr j => simpa only [Sum.elim_inr, massVector] using hecoord j

omit [DecidableEq ι] in
private theorem sourceRow_outer (u : ι → ℂ) :
    sourceRow u * outer u = ((totalMass u : ℂ) - 1) • sourceRow u := by
  rw [outer, Matrix.mul_vecMulVec]
  have he : sourceRow u *ᵥ u = fun _ => -((totalMass u : ℂ) - 1) := by
    funext j
    change (∑ k, -star (u k) * u k) = _
    rw [show (∑ k, -star (u k) * u k) = -(star u ⬝ᵥ u) by
      simp [dotProduct, Finset.sum_neg_distrib]]
    rw [star_dot_self]
    simp [totalMass]
  rw [he]
  ext i j
  simp [sourceRow, Matrix.vecMulVec_apply]
  ring

theorem sourceRow_metric (u : ι → ℂ) :
    sourceRow u * metric u = (totalMass u : ℂ)⁻¹ • sourceRow u := by
  rw [metric_closed_form, Matrix.mul_sub, Matrix.mul_one, Matrix.mul_smul, sourceRow_outer,
    smul_smul]
  have hn := totalMass_ne_zero u
  ext i j
  simp only [Matrix.sub_apply, Matrix.smul_apply, smul_eq_mul]
  field_simp
  ring

theorem metric_sourceRow_adjoint (u : ι → ℂ) :
    metric u * (sourceRow u)ᴴ = (totalMass u : ℂ)⁻¹ • (sourceRow u)ᴴ := by
  have h := congrArg Matrix.conjTranspose (sourceRow_metric u)
  simpa [Matrix.conjTranspose_mul, (metric_hermitian u).eq,
    Matrix.conjTranspose_smul, Complex.star_def] using h

omit [DecidableEq ι] in
private theorem sourceRow_adjoint (u : ι → ℂ) :
    sourceRow u * (sourceRow u)ᴴ = ((totalMass u : ℂ) - 1) • 1 := by
  ext i j
  simp only [Matrix.mul_apply, sourceRow, Matrix.conjTranspose_apply,
    star_neg, star_star, neg_mul_neg, Matrix.smul_apply]
  change (star u ⬝ᵥ u) = _
  rw [star_dot_self]
  simp [totalMass]

/-- Explicit orthogonal projection onto the source zero-output hyperplane. -/
theorem energyBasis_projection (u : ι → ℂ) :
    energyBasis u * (metric u)⁻¹ * (energyBasis u)ᴴ =
      1 - (totalMass u : ℂ)⁻¹ • outer (massVector u) := by
  letI := (metric_posDef u).isUnit.invertible
  have he : energyBasis u * (metric u)⁻¹ * (energyBasis u)ᴴ =
      sourceLift u * metric u * (sourceLift u)ᴴ := by
    unfold energyBasis
    rw [Matrix.conjTranspose_mul, (metric_hermitian u).eq]
    rw [Matrix.mul_assoc (sourceLift u) (metric u) (metric u)⁻¹,
      Matrix.mul_inv_of_invertible, Matrix.mul_one, Matrix.mul_assoc]
  rw [he]
  unfold sourceLift
  rw [Matrix.conjTranspose_fromRows_eq_fromCols_conjTranspose, Matrix.fromRows_mul,
    Matrix.one_mul, sourceRow_metric, Matrix.fromRows_mul_fromCols]
  simp only [Matrix.conjTranspose_one, Matrix.smul_mul, Matrix.mul_one,
    sourceRow_adjoint, smul_smul, metric_sourceRow_adjoint]
  ext i j
  cases i with
  | inl i => cases j with
    | inl j =>
      simp [Matrix.fromBlocks, outer, massVector, Matrix.vecMulVec_apply]
      field_simp [totalMass_ne_zero u]
    | inr j => simp [Matrix.fromBlocks, outer, massVector, Matrix.vecMulVec_apply, sourceRow]
  | inr i => cases j with
    | inl j => simp [Matrix.fromBlocks, outer, massVector,
        Matrix.vecMulVec_apply, sourceRow, Matrix.conjTranspose_apply]
    | inr j =>
      simp [Matrix.fromBlocks, Matrix.one_apply, outer, massVector,
        Matrix.vecMulVec_apply, metric_closed_form]

/-- The projection is independent of the basis chosen in the zero-output
hyperplane, with no projection identity assumed as input. -/
theorem sourceFamily_projection (u : ι → ℂ) (Y : Matrix (Unit ⊕ ι) ι ℂ)
    (hY : ∀ j, star (massVector u) ⬝ᵥ (fun i => Y i j) = 0)
    (hGram : (Yᴴ * Y).PosDef) :
    Y * (Yᴴ * Y)⁻¹ * Yᴴ = 1 - (totalMass u : ℂ)⁻¹ • outer (massVector u) := by
  let P := sourceCoordinates u Y
  letI := (sourceCoordinates_isUnit u Y hY hGram).invertible
  have ht : IsUnit Pᴴ := by
    have hp := (sourceCoordinates_isUnit u Y hY hGram).star
    simpa only [Matrix.star_eq_conjTranspose] using hp
  letI := ht.invertible
  have hgram : Yᴴ * Y = Pᴴ * metric u * P := sourceCoordinates_metric u Y hY
  have hYP : Y = energyBasis u * P := (energyBasis_coordinates u Y hY).symm
  rw [hgram]
  change Y * (Pᴴ * metric u * P)⁻¹ * Yᴴ = _
  rw [hYP, Matrix.mul_inv_rev, Matrix.mul_inv_rev, Matrix.conjTranspose_mul]
  calc
    _ = energyBasis u * (P * P⁻¹) * (metric u)⁻¹ * (Pᴴ⁻¹ * Pᴴ) * (energyBasis u)ᴴ := by
      simp only [Matrix.mul_assoc]
    _ = _ := by
      rw [Matrix.mul_inv_of_invertible, Matrix.inv_mul_of_invertible, Matrix.mul_one,
        Matrix.mul_one, energyBasis_projection]

end

end PolynomialGeometry.Geometry
