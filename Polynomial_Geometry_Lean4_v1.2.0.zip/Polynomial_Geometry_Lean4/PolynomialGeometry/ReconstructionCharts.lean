import PolynomialGeometry.ReciprocalTaylorAnalytic

/-! # The analytic reconstruction chart from original polynomial hypotheses -/

noncomputable section
namespace PolynomialGeometry.ReconstructionCompletion
open Polynomial Filter
open PolynomialGeometry.Factorization PolynomialGeometry.CriticalReconstruction
open PolynomialGeometry.SimpleRoot
open scoped BigOperators Topology

/-- A simple critical point distinct from the multiple cluster is a simple
root of the derived residual factor. -/
theorem residual_simple_root_of_derivative (P U : ℂ[X]) (r s : ℕ) (w v : ℂ)
    (hwv : v ≠ w)
    (hid : P.derivative = C (r + s + 1 : ℂ) * (X - C w) ^ r * U)
    (hv : P.derivative.eval v = 0) (hvs : P.derivative.derivative.eval v ≠ 0) :
    U.eval v = 0 ∧ U.derivative.eval v ≠ 0 := by
  have hN : (r + s + 1 : ℂ) ≠ 0 := by exact_mod_cast (by omega : r + s + 1 ≠ 0)
  have hpow : (v - w) ^ r ≠ 0 := pow_ne_zero _ (sub_ne_zero.mpr hwv)
  have hvU : U.eval v = 0 := by
    rw [hid] at hv
    simp only [eval_mul, eval_C, eval_pow, eval_sub, eval_X] at hv
    exact (mul_eq_zero.mp hv).resolve_left (mul_ne_zero hN hpow)
  refine ⟨hvU, ?_⟩
  intro hz
  apply hvs
  rw [hid, derivative_mul, eval_add, eval_mul, eval_mul, hvU, hz]
  simp

/-- Full labelled-copy chart with local uniqueness, derived directly from
exact multiplicity of the original derivative. Source and critical copies
are parameters, not persistent multiplicity constraints. -/
theorem reconstruction_from_exact_multiplicity (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (A : ℂ[X]) (α : Fin (s + 1) → ℂ) (w : ℂ)
    (hA : A.Monic) (hAd : A.natDegree = r)
    (hvalue : (A * rootPolynomial (s + 1) α).eval w ≠ 0)
    (hmult : (A * rootPolynomial (s + 1) α).derivative.rootMultiplicity w = r) :
    ∃ (a : Unknown r s) (G : Parameter r s → Unknown r s),
      monicPolynomial r a.1 = A ∧ (monicPolynomial s a.2).eval w ≠ 0 ∧
      AnalyticAt ℂ G ((fun _ => w), α) ∧ G ((fun _ => w), α) = a ∧
      (∀ᶠ q in 𝓝 (((fun _ => w), α) : Parameter r s),
        (monicPolynomial r (G q).1 * rootPolynomial (s + 1) q.2).derivative =
          C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s (G q).2) ∧
      (∀ (σ : Equiv.Perm (Fin r)) (π : Equiv.Perm (Fin (s + 1))) q,
        G (q.1 ∘ σ, q.2 ∘ π) = G q) ∧
      (∀ᶠ z : Unknown r s × Parameter r s in 𝓝 (a, ((fun _ => w), α)),
        (monicPolynomial r z.1.1 * rootPolynomial (s + 1) z.2.2).derivative =
          C (r + s + 1 : ℂ) * rootPolynomial r z.2.1 * monicPolynomial s z.1.2 →
        G z.2 = z.1) := by
  obtain ⟨a, haA, haw, hid⟩ := reconstruction_data_from_multiplicity r s A α w hA hAd hmult
  have hM : (rootPolynomial (s + 1) α).eval w ≠ 0 := by
    exact (mul_ne_zero_iff.mp (by simpa only [eval_mul] using hvalue)).2
  let q₀ : Parameter r s := ((fun _ => w), α)
  let T : Parameter r s → Parameter r s :=
    fun q => (rootCoefficients r q.1, rootCoefficients (s + 1) q.2)
  let x : Domain r s := (a, T q₀)
  have hc : monicPolynomial r x.2.1 = (X - C w) ^ r := by simp [x, T, q₀]
  have hm : (monicPolynomial (s + 1) x.2.2).eval w ≠ 0 := by simpa [x, T, q₀] using hM
  have hv : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).eval w ≠ 0 := by
    simpa [x, T, q₀, haA] using hvalue
  have hi : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative =
      C (r + s + 1 : ℂ) * monicPolynomial r x.2.1 * monicPolynomial s x.1.2 := by
    simpa [x, T, q₀] using hid
  obtain ⟨H, hH, hH0, hHpoly, hHuniq⟩ :=
    moving_critical_factor_reconstruction r s hr hs x w hc hm hv hi
  have hT : AnalyticAt ℂ T q₀ :=
    ((rootCoefficients_analyticAt r q₀.1).comp analyticAt_fst).prod
      ((rootCoefficients_analyticAt (s + 1) q₀.2).comp analyticAt_snd)
  have hHa : AnalyticAt ℂ H (T q₀) := hH
  refine ⟨a, H ∘ T, haA, haw, hHa.comp hT, hH0, ?_, ?_, ?_⟩
  · filter_upwards [hT.continuousAt.eventually hHpoly] with q hq
    simpa [T] using hq
  · intro σ π q
    simp [T]
  · have hcont : ContinuousAt (fun z : Unknown r s × Parameter r s => (z.1, T z.2))
        (a, q₀) := by
      apply continuousAt_fst.prodMk
      have ht : Tendsto T (𝓝 q₀) (𝓝 (T q₀)) := hT.continuousAt
      have hsnd : Tendsto (fun z : Unknown r s × Parameter r s => z.2) (𝓝 (a, q₀)) (𝓝 q₀) :=
        continuousAt_snd
      exact ht.comp hsnd
    filter_upwards [hcont.eventually hHuniq] with z hz
    simpa [T] using hz

/-- Actual derivative multiplicity and actual simple marked roots suffice to
construct the polynomial family and both holomorphic marked-root branches. -/
theorem reconstruction_and_marked_roots_from_polynomial (r s : ℕ)
    (hr : 0 < r) (hs : 0 < s) (A : ℂ[X]) (α : Fin (s + 1) → ℂ)
    (w a₀ v₀ : ℂ) (hA : A.Monic) (hAd : A.natDegree = r)
    (hvalue : (A * rootPolynomial (s + 1) α).eval w ≠ 0)
    (hmult : (A * rootPolynomial (s + 1) α).derivative.rootMultiplicity w = r)
    (haRoot : A.eval a₀ = 0) (haSimple : A.derivative.eval a₀ ≠ 0)
    (hwv : v₀ ≠ w)
    (hvRoot : (A * rootPolynomial (s + 1) α).derivative.eval v₀ = 0)
    (hvSimple : (A * rootPolynomial (s + 1) α).derivative.derivative.eval v₀ ≠ 0) :
    ∃ (G : Parameter r s → Unknown r s) (za zv : Parameter r s → ℂ),
      AnalyticAt ℂ G ((fun _ => w), α) ∧
      monicPolynomial r (G ((fun _ => w), α)).1 = A ∧
      AnalyticAt ℂ za ((fun _ => w), α) ∧ za ((fun _ => w), α) = a₀ ∧
      AnalyticAt ℂ zv ((fun _ => w), α) ∧ zv ((fun _ => w), α) = v₀ ∧
      (∀ᶠ q in 𝓝 (((fun _ => w), α) : Parameter r s),
        (reconstructedPolynomial r s G q).derivative =
          C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s (G q).2 ∧
        (reconstructedPolynomial r s G q).eval (za q) = 0 ∧
        (reconstructedPolynomial r s G q).derivative.eval (zv q) = 0) ∧
      (∀ (σ : Equiv.Perm (Fin r)) (π : Equiv.Perm (Fin (s + 1))) q,
        za (q.1 ∘ σ, q.2 ∘ π) = za q ∧ zv (q.1 ∘ σ, q.2 ∘ π) = zv q) := by
  obtain ⟨a, haA, _, hid⟩ := reconstruction_data_from_multiplicity r s A α w hA hAd hmult
  have hM : (rootPolynomial (s + 1) α).eval w ≠ 0 := by
    exact (mul_ne_zero_iff.mp (by simpa only [eval_mul] using hvalue)).2
  have hvr := residual_simple_root_of_derivative (A * rootPolynomial (s + 1) α)
    (monicPolynomial s a.2) r s w v₀ hwv (by simpa only [haA] using hid) hvRoot hvSimple
  obtain ⟨G, za, zv, hG, hG0, hza, hza0, hzv, hzv0, hpoly, _, _, hperm⟩ :=
    splitting_reconstruction_with_marked_roots r s hr hs a α w a₀ v₀ hM
      (by simpa only [haA] using hvalue) hid
      (by simpa only [haA] using haRoot) (by simpa only [haA] using haSimple) hvr.1 hvr.2
  exact ⟨G, za, zv, hG, by simpa only [hG0] using haA,
    hza, hza0, hzv, hzv0, hpoly, hperm⟩

end PolynomialGeometry.ReconstructionCompletion
