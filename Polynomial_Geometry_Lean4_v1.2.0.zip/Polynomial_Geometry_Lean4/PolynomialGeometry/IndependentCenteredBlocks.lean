import PolynomialGeometry.SymmetricElimination

/-!
# Independent collections of centered splitting blocks

The eliminated space is the Euclidean direct sum of the selected centered
copy groups. All permutations act independently. Their average is proved
zero, so nonlinear elimination applies to a whole selected collection.
-/

noncomputable section
open Filter
open scoped Topology
namespace PolynomialGeometry.IndependentCenteredBlocks
open SymmetricElimination

variable {J : Type*} [Fintype J] [DecidableEq J]
  (ι : J → Type*) [∀ j, Fintype (ι j)] [∀ j, Nonempty (ι j)] [∀ j, DecidableEq (ι j)]

/-- Euclidean direct sum of the selected centered copy spaces. -/
abbrev Blocks := PiLp 2 (fun j => centeredSubspace (ι := ι j))

/-- All groups may permute independently. -/
abbrev Group := ∀ j, Equiv.Perm (ι j)

/-- The blockwise permutation representation. -/
def action (g : Group ι) : Blocks ι →L[ℝ] Blocks ι :=
  LinearMap.toContinuousLinearMap
    { toFun := fun s => WithLp.toLp 2 (fun j => centeredAction (g j) (s j))
      map_add' := by intro s t; apply PiLp.ext; intro j; exact map_add (centeredAction (g j)) _ _
      map_smul' := by intro c s; apply PiLp.ext; intro j; exact map_smul (centeredAction (g j)) _ _ }

omit [DecidableEq J] [∀ j, Nonempty (ι j)] [∀ j, DecidableEq (ι j)] in
@[simp] theorem action_apply (g : Group ι) (s : Blocks ι) (j : J) :
    action ι g s j = centeredAction (g j) (s j) := rfl

/-- Precomposition reverses the order of the permutation product. -/
theorem centeredAction_comp {K : Type*} [Fintype K] [Nonempty K]
    (σ τ : Equiv.Perm K) (s : centeredSubspace (ι := K)) :
    centeredAction σ (centeredAction τ s) = centeredAction (τ * σ) s := by
  ext i
  rfl

/-- The centered representation has no nonzero vector fixed by all permutations. -/
theorem centeredAction_fixed_zero {K : Type*} [Fintype K] [Nonempty K] [DecidableEq K]
    (s : centeredSubspace (ι := K)) (hs : ∀ σ : Equiv.Perm K, centeredAction σ s = s) : s = 0 := by
  have h := centeredAction_sum_zero s
  simp_rw [hs] at h
  rw [Finset.sum_const, Finset.card_univ, ← Nat.cast_smul_eq_nsmul ℝ] at h
  exact (smul_eq_zero.mp h).resolve_left (Nat.cast_ne_zero.mpr Fintype.card_ne_zero)

/-- Averaging the full independent group kills every selected centered block. -/
theorem action_sum_zero (s : Blocks ι) : (∑ g : Group ι, action ι g s) = 0 := by
  classical
  apply PiLp.ext
  intro j
  let proj := PiLp.proj 2 (𝕜 := ℝ) (fun k => centeredSubspace (ι := ι k)) j
  change proj (∑ g, action ι g s) = 0
  rw [map_sum]
  apply centeredAction_fixed_zero
  intro σ
  rw [map_sum]
  have hh := Equiv.sum_comp (Equiv.mulRight (Pi.mulSingle j σ : Group ι))
    (fun g : Group ι => centeredAction (g j) (s j))
  convert hh using 1
  apply Finset.sum_congr rfl
  intro g _
  change centeredAction σ (centeredAction (g j) (s j)) =
    centeredAction ((g * (Pi.mulSingle j σ : Group ι)) j) (s j)
  rw [centeredAction_comp]
  congr 1
  simp


/-- Insert one selected centered block into the direct sum. -/
def inclusion (j : J) : centeredSubspace (ι := ι j) →L[ℝ] Blocks ι :=
  (PiLp.continuousLinearEquiv 2 ℝ (fun k => centeredSubspace (ι := ι k))).symm.toContinuousLinearMap.comp
    (ContinuousLinearMap.single ℝ (fun k => centeredSubspace (ι := ι k)) j)

omit [∀ j, Nonempty (ι j)] [∀ j, DecidableEq (ι j)] in
@[simp] theorem inclusion_apply (j : J) (s : centeredSubspace (ι := ι j)) (k : J) :
    inclusion ι j s k = Pi.single (M := fun k => centeredSubspace (ι := ι k)) j s k := rfl

omit [∀ j, Nonempty (ι j)] [∀ j, DecidableEq (ι j)] in
theorem action_inclusion (g : Group ι) (j : J) (s : centeredSubspace (ι := ι j)) :
    action ι g (inclusion ι j s) = inclusion ι j (centeredAction (g j) s) := by
  apply PiLp.ext
  intro k
  by_cases hk : k = j
  · subst k; simp
  · simp [hk]

@[simp] theorem centeredAction_one {K : Type*} [Fintype K]
    (s : centeredSubspace (ι := K)) : centeredAction (1 : Equiv.Perm K) s = s := by
  ext i
  rfl

omit [∀ j, Nonempty (ι j)] [∀ j, DecidableEq (ι j)] in
theorem single_action_inclusion (j : J) (σ : Equiv.Perm (ι j)) (k : J)
    (hk : k ≠ j) (s : centeredSubspace (ι := ι k)) :
    action ι (Pi.mulSingle j σ) (inclusion ι k s) = inclusion ι k s := by
  rw [action_inclusion]
  simp [Pi.mulSingle_eq_of_ne hk]

omit [∀ j, Nonempty (ι j)] [∀ j, DecidableEq (ι j)] in
theorem sum_inclusions (s : Blocks ι) : (∑ j, inclusion ι j (s j)) = s := by
  apply (PiLp.continuousLinearEquiv 2 ℝ (fun j => centeredSubspace (ι := ι j))).injective
  rw [map_sum]
  funext j
  change (∑ k, fun j => inclusion ι k (s k) j) j = s j
  simp only [Finset.sum_apply, inclusion_apply, Finset.sum_pi_single, Finset.mem_univ, ite_true]

section Elimination
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [FiniteDimensional ℝ E]


/-- The full action fixes all unselected variables. -/
def liftedAction (g : Group ι) : (E × Blocks ι) →L[ℝ] E × Blocks ι :=
  (ContinuousLinearMap.fst ℝ E (Blocks ι)).prod
    ((action ι g).comp (ContinuousLinearMap.snd ℝ E (Blocks ι)))

omit [DecidableEq J] [∀ j, Nonempty (ι j)] [∀ j, DecidableEq (ι j)] [FiniteDimensional ℝ E] in
@[simp] theorem liftedAction_apply (g : Group ι) (p : E × Blocks ι) :
    liftedAction ι g p = (p.1, action ι g p.2) := rfl

omit [FiniteDimensional ℝ E] in
/-- Independent function symmetry forces the actual mixed blocks to vanish. -/
theorem independent_mixed_hessian_zero
    (F : E × Blocks ι → ℝ) (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ g : Group ι,
      (fun p : E × Blocks ι => F (p.1, action ι g p.2)) =ᶠ[𝓝 0] F)
    (j k : J) (hjk : j ≠ k)
    (s : centeredSubspace (ι := ι j)) (t : centeredSubspace (ι := ι k)) :
    fderiv ℝ (fderiv ℝ F) 0 (0,inclusion ι j s) (0,inclusion ι k t) = 0 := by
  let H := fderiv ℝ (fderiv ℝ F) 0
  let L : centeredSubspace (ι := ι j) →L[ℝ] ℝ :=
    (H.flip (0,inclusion ι k t)).comp
      ((ContinuousLinearMap.inr ℝ E (Blocks ι)).comp (inclusion ι j))
  have hL : L = 0 := by
    apply invariant_covector_zero centeredAction centeredAction_sum_zero L
    intro σ
    ext v
    have hh := hessian_invariant F (liftedAction ι (Pi.mulSingle j σ)) hF
      (hsym (Pi.mulSingle j σ)) (0,inclusion ι j v) (0,inclusion ι k t)
    simp only [liftedAction_apply, single_action_inclusion ι j σ k hjk.symm,
      action_inclusion, Pi.mulSingle_eq_same] at hh
    exact hh
  exact congrArg (fun M : centeredSubspace (ι := ι j) →L[ℝ] ℝ => M s) hL

omit [FiniteDimensional ℝ E] in
set_option synthInstance.maxHeartbeats 200000 in
/-- The actual Hessian on the direct sum is the sum of its diagonal blocks. -/
theorem independent_hessian_diagonal_sum
    (F : E × Blocks ι → ℝ) (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ g : Group ι,
      (fun p : E × Blocks ι => F (p.1, action ι g p.2)) =ᶠ[𝓝 0] F)
    (s : Blocks ι) :
    fderiv ℝ (fderiv ℝ F) 0 (0,s) (0,s) =
      ∑ j, fderiv ℝ (fderiv ℝ F) 0 (0,inclusion ι j (s j)) (0,inclusion ι j (s j)) := by
  let H := fderiv ℝ (fderiv ℝ F) 0
  have hsplit : ((0 : E),s) = ∑ j, ((0 : E),inclusion ι j (s j)) := by
    have hh := congrArg (ContinuousLinearMap.inr ℝ E (Blocks ι)) (sum_inclusions ι s).symm
    simpa only [map_sum, ContinuousLinearMap.inr_apply] using hh
  change H (0,s) (0,s) = _
  rw [hsplit]
  simp only [map_sum, ContinuousLinearMap.sum_apply]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  apply Finset.sum_eq_single j
  · intro k _ hkj
    exact independent_mixed_hessian_zero ι F hF hsym j k hkj.symm (s j) (s k)
  · simp

omit [FiniteDimensional ℝ E] in
/-- Exact uniform elimination of any selected finite collection. Remaining
blocks are included in `E`; they are never fixed by this conclusion. -/
theorem independent_blocks_exact_elimination
    (F : E × Blocks ι → ℝ) (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ g : Group ι,
      (fun p : E × Blocks ι => F (p.1, action ι g p.2)) =ᶠ[𝓝 0] F)
    (P : Blocks ι →L[ℝ] Blocks ι)
    (hP : ∀ s : Blocks ι, s ≠ 0 → 0 < inner ℝ s (P s))
    (hss : (fderiv ℝ (PartialMaximum.partialGradient F) 0).comp
      (ContinuousLinearMap.inr ℝ E (Blocks ι)) = -P) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ p : E × Blocks ι in 𝓝 0,
      F p ≤ F (p.1,0) - c * ‖p.2‖^2 :=
  symmetric_blocks_exact_elimination (action ι) (action_sum_zero ι) F hF hsym P hP hss

omit [FiniteDimensional ℝ E] in
/-- Negative scalar curvatures in all selected blocks yield exact elimination
of their entire direct sum. Mixed terms are derived to vanish, and the
positive eliminated operator is constructed from the same objective. -/
theorem negative_block_scalars_exact_elimination
    (F : E × Blocks ι → ℝ) (hF : AnalyticAt ℝ F 0)
    (hsym : ∀ g : Group ι,
      (fun p : E × Blocks ι => F (p.1, action ι g p.2)) =ᶠ[𝓝 0] F)
    (lam : J → ℝ) (hlam : ∀ j, lam j < 0)
    (hq : ∀ j (s : centeredSubspace (ι := ι j)),
      fderiv ℝ (fderiv ℝ F) 0 (0,inclusion ι j s) (0,inclusion ι j s) = lam j * ‖s‖^2) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ p : E × Blocks ι in 𝓝 0,
      F p ≤ F (p.1,0) - c * ‖p.2‖^2 := by
  let D := (fderiv ℝ (PartialMaximum.partialGradient F) 0).comp
    (ContinuousLinearMap.inr ℝ E (Blocks ι))
  have hP : ∀ s : Blocks ι, s ≠ 0 → 0 < inner ℝ s ((-D) s) := by
    intro s hs
    rw [ContinuousLinearMap.neg_apply, inner_neg_right, real_inner_comm]
    change 0 < -inner ℝ (fderiv ℝ (PartialMaximum.partialGradient F) 0 (0,s)) s
    rw [SchurHessian.partialGradient_hessian_pairing F hF,
      independent_hessian_diagonal_sum ι F hF hsym]
    simp_rw [hq]
    apply neg_pos.mpr
    apply Finset.sum_neg'
    · intro j _
      exact mul_nonpos_of_nonpos_of_nonneg (hlam j).le (sq_nonneg _)
    · have hex : ∃ j, s j ≠ 0 := by
        by_contra h
        push_neg at h
        apply hs
        exact PiLp.ext h
      obtain ⟨j,hj⟩ := hex
      exact ⟨j, Finset.mem_univ _, mul_neg_of_neg_of_pos (hlam j) (sq_pos_of_pos (norm_pos_iff.mpr hj))⟩
  apply independent_blocks_exact_elimination ι F hF hsym (-D) hP
  simp [D]

end Elimination
end PolynomialGeometry.IndependentCenteredBlocks
