import Mathlib.LinearAlgebra.Matrix.ToLin
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Analysis.Complex.Basic
import Mathlib.Analysis.Complex.Order
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.LinearAlgebra.Eigenspace.Triangularizable
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Abel
import Lean.Elab.Tactic.Omega
import PolynomialGeometry.Source

/-!
# Complete Jordan chains and source-coordinate identities

`jordanMatrix` is the canonical direct sum with one block `w i * I - N`
for each distinct spectral point. A block has length `r i + 1`, so zero
length blocks cannot enter the formalization. The observable-pair theorem
is proved from this concrete definition, not included as an axiom.
-/

open scoped BigOperators Matrix ComplexOrder
open Matrix

namespace PolynomialGeometry.Confluent

variable {σ : Type*} [Fintype σ] [DecidableEq σ]

abbrev ChainIndex (r : σ → ℕ) := Σ i, Fin (r i + 1)

def nextEntry {n : ℕ} (x : Fin (n + 1) → ℂ) (h : Fin (n + 1)) : ℂ :=
  if hh : h.val < n then x ⟨h.val + 1, by omega⟩ else 0

noncomputable def jordanApply (w : σ → ℂ) (r : σ → ℕ)
    (x : ChainIndex r → ℂ) (a : ChainIndex r) : ℂ :=
  w a.1 * x a - nextEntry (fun h => x ⟨a.1, h⟩) a.2

noncomputable def jordanMap (w : σ → ℂ) (r : σ → ℕ) :
    (ChainIndex r → ℂ) →ₗ[ℂ] (ChainIndex r → ℂ) where
  toFun := jordanApply w r
  map_add' x y := by
    funext ⟨i, h⟩
    simp only [jordanApply, Pi.add_apply, nextEntry]
    split_ifs <;> ring
  map_smul' c x := by
    funext ⟨i, h⟩
    simp only [jordanApply, Pi.smul_apply, nextEntry, smul_eq_mul, RingHom.id_apply]
    split_ifs <;> ring

noncomputable def jordanMatrix (w : σ → ℂ) (r : σ → ℕ) :
    Matrix (ChainIndex r) (ChainIndex r) ℂ := (jordanMap w r).toMatrix'

noncomputable def firstOutput (r : σ → ℕ) (x : ChainIndex r → ℂ) : ℂ :=
  ∑ i, x ⟨i, 0⟩

noncomputable def outputVector (r : σ → ℕ) (a : ChainIndex r) : ℂ :=
  if a.2 = 0 then 1 else 0

omit [DecidableEq σ] in
theorem outputVector_dotProduct (r : σ → ℕ) (x : ChainIndex r → ℂ) :
    star (outputVector r) ⬝ᵥ x = firstOutput r x := by
  classical
  simp [dotProduct, outputVector, firstOutput, Fintype.sum_sigma]
  apply Finset.sum_congr rfl
  intro i _
  change (∑ h : Fin (r i + 1), if h = 0 then x ⟨i, h⟩ else 0) = x ⟨i, 0⟩
  rw [Finset.sum_ite_eq']
  simp

@[simp] theorem jordanMatrix_mulVec (w : σ → ℂ) (r : σ → ℕ)
    (x : ChainIndex r → ℂ) : (jordanMatrix w r).mulVec x = jordanApply w r x := by
  exact LinearMap.toMatrix'_mulVec (jordanMap w r) x

theorem chain_zero_of_nonresonant {n : ℕ} (q : ℂ) (hq : q ≠ 0)
    (x : Fin (n + 1) → ℂ)
    (hrec : ∀ h, q * x h = nextEntry x h) : x = 0 := by
  funext h
  induction h using Fin.reverseInduction with
  | last =>
    have hh := hrec (Fin.last n)
    simp only [nextEntry, Fin.val_last, lt_self_iff_false, dite_false] at hh
    exact (mul_eq_zero.mp hh).resolve_left hq
  | @cast h ih =>
    have hh := hrec h.castSucc
    have hlt : h.castSucc.val < n := h.isLt
    simp only [nextEntry, dif_pos hlt] at hh
    have heq : (⟨h.castSucc.val + 1, by omega⟩ : Fin (n + 1)) = h.succ := by rfl
    rw [heq, ih] at hh
    exact (mul_eq_zero.mp hh).resolve_left hq

theorem chain_successors_zero {n : ℕ} (x : Fin (n + 1) → ℂ)
    (hrec : ∀ h, (0 : ℂ) * x h = nextEntry x h) (h : Fin n) : x h.succ = 0 := by
  have hh := hrec h.castSucc
  have hlt : h.castSucc.val < n := h.isLt
  simp only [zero_mul, nextEntry, dif_pos hlt] at hh
  exact hh.symm

theorem jordan_eigenvector_recurrence (w : σ → ℂ) (r : σ → ℕ)
    (μ : ℂ) (x : ChainIndex r → ℂ)
    (hx : (jordanMatrix w r).mulVec x = μ • x) (i : σ) :
    ∀ h, (w i - μ) * x ⟨i, h⟩ = nextEntry (fun h => x ⟨i, h⟩) h := by
  intro h
  have hc := congrFun hx ⟨i, h⟩
  simp only [jordanMatrix_mulVec, jordanApply, Pi.smul_apply, smul_eq_mul] at hc
  linear_combination hc

/-- No nonzero eigenvector of the full canonical Jordan matrix is invisible
to the first-coordinate output. This is the concrete observability fact
used to prove positive masses and a simple completion spectrum in §3.3. -/
theorem canonical_eigenvector_observable (w : σ → ℂ) (r : σ → ℕ)
    (hw : Function.Injective w) (μ : ℂ) (x : ChainIndex r → ℂ)
    (hx : (jordanMatrix w r).mulVec x = μ • x)
    (hout : firstOutput r x = 0) : x = 0 := by
  have hrec := jordan_eigenvector_recurrence w r μ x hx
  have hnon : ∀ i, w i ≠ μ → ∀ h, x ⟨i, h⟩ = 0 := by
    intro i hi h
    exact congrFun (chain_zero_of_nonresonant (w i - μ) (sub_ne_zero.mpr hi)
      (fun h => x ⟨i, h⟩) (hrec i)) h
  funext a
  rcases a with ⟨i, h⟩
  by_cases hi : w i = μ
  · have hfirst : x ⟨i, 0⟩ = 0 := by
      have hs : firstOutput r x = x ⟨i, 0⟩ := by
        unfold firstOutput
        apply Finset.sum_eq_single i
        · intro j _ hji
          exact hnon j (fun hj => hji (hw (hj.trans hi.symm))) 0
        · simp
      exact hs.symm.trans hout
    cases h using Fin.cases with
    | zero => exact hfirst
    | succ h =>
      apply chain_successors_zero (fun h => x ⟨i, h⟩) _ h
      simpa only [hi, sub_self] using hrec i
  · exact hnon i hi h

theorem canonical_eigenvector_observable_dotProduct (w : σ → ℂ) (r : σ → ℕ)
    (hw : Function.Injective w) (μ : ℂ) (x : ChainIndex r → ℂ)
    (hx : (jordanMatrix w r).mulVec x = μ • x)
    (hout : star (outputVector r) ⬝ᵥ x = 0) : x = 0 := by
  apply canonical_eigenvector_observable w r hw μ x hx
  rwa [outputVector_dotProduct] at hout

section ScalarChains

variable (α w b : ℂ)

/-- The first Cauchy column satisfies the source recurrence. -/
theorem cauchy_column_zero (h : w ≠ α) :
    α * (b / (w - α)) = w * (b / (w - α)) - b := by
  field_simp [sub_ne_zero.mpr h]
  ring

/-- Every subsequent power contributes one generalized-eigenvector step. -/
theorem cauchy_column_succ (k : ℕ) (h : w ≠ α) :
    α * (b / (w - α) ^ (k + 2)) =
      w * (b / (w - α) ^ (k + 2)) - b / (w - α) ^ (k + 1) := by
  field_simp [sub_ne_zero.mpr h]
  ring

end ScalarChains

section CauchyCoordinates

theorem weighted_nextEntry_sum {n : ℕ} (y x : Fin (n + 1) → ℂ) :
    (∑ h, y h * nextEntry x h) = ∑ h : Fin n, y h.castSucc * x h.succ := by
  rw [Fin.sum_univ_castSucc]
  have hlast : nextEntry x (Fin.last n) = 0 := by simp [nextEntry]
  rw [hlast, mul_zero, add_zero]
  apply Finset.sum_congr rfl
  intro h _
  have hlt : h.castSucc.val < n := h.isLt
  simp only [nextEntry, dif_pos hlt]
  rfl

/-- Summing the scalar recurrences gives the complete finite Jordan-chain
identity, including the first-column boundary term. -/
theorem cauchy_block_identity {n : ℕ} (α w b : ℂ) (hsep : w ≠ α)
    (x : Fin (n + 1) → ℂ) :
    α * (∑ h, b / (w - α) ^ (h.val + 1) * x h) =
      (∑ h, b / (w - α) ^ (h.val + 1) *
        (w * x h - nextEntry x h)) - b * x 0 := by
  let y : Fin (n + 1) → ℂ := fun h => b / (w - α) ^ (h.val + 1)
  change α * (∑ h, y h * x h) =
    (∑ h, y h * (w * x h - nextEntry x h)) - b * x 0
  have hzero : α * y 0 = w * y 0 - b := by
    simpa only [y, Fin.val_zero, zero_add, pow_one] using cauchy_column_zero α w b hsep
  have hsucc (h : Fin n) : α * y h.succ = w * y h.succ - y h.castSucc := by
    simpa only [y, Fin.val_succ, Fin.coe_castSucc, Nat.add_assoc] using
      cauchy_column_succ α w b h.val hsep
  have hleft : α * (∑ h, y h * x h) =
      (w * y 0 - b) * x 0 +
        ∑ h : Fin n, (w * y h.succ - y h.castSucc) * x h.succ := by
    rw [Fin.sum_univ_succ, mul_add, Finset.mul_sum]
    simp_rw [← mul_assoc]
    rw [hzero]
    congr 1
    exact Finset.sum_congr rfl (fun h _ => by rw [hsucc])
  rw [hleft]
  simp_rw [mul_sub]
  rw [Finset.sum_sub_distrib, weighted_nextEntry_sum]
  have hw : (∑ h, y h * (w * x h)) =
      w * y 0 * x 0 + ∑ h : Fin n, w * y h.succ * x h.succ := by
    rw [Fin.sum_univ_succ]
    congr 1
    · ring
    · exact Finset.sum_congr rfl (fun _ _ => by ring)
  rw [hw]
  simp_rw [sub_mul]
  rw [Finset.sum_sub_distrib]
  ring

variable {s : Type*} [Fintype s] [DecidableEq s]

noncomputable def cauchyMatrix (α b : s → ℂ) (w : σ → ℂ) (r : σ → ℕ) :
    Matrix s (ChainIndex r) ℂ :=
  fun j a => b j / (w a.1 - α j) ^ (a.2.val + 1)

/-- The concrete Cauchy coordinates obey the full source/Jordan relation.
This result needs only separation of spectral and source positions. -/
theorem cauchy_source_identity (α b : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hsep : ∀ i j, w i ≠ α j) (x : ChainIndex r → ℂ) :
    (Matrix.diagonal α).mulVec ((cauchyMatrix α b w r).mulVec x) =
      (cauchyMatrix α b w r).mulVec ((jordanMatrix w r).mulVec x) -
        (firstOutput r x) • b := by
  funext j
  rw [mulVec_diagonal]
  simp only [mulVec, dotProduct, cauchyMatrix,
    jordanMatrix_mulVec, jordanApply, Pi.sub_apply, Pi.smul_apply, smul_eq_mul,
    Fintype.sum_sigma, firstOutput]
  rw [Finset.mul_sum]
  simp_rw [cauchy_block_identity (α j) _ (b j) (hsep _ j)]
  rw [Finset.sum_sub_distrib]
  congr 1
  rw [Finset.sum_mul]
  exact Finset.sum_congr rfl (fun _ _ => by ring)

end CauchyCoordinates

section GramIdentity

variable {s k : Type*} [Fintype s] [DecidableEq s] [Fintype k] [DecidableEq k]

noncomputable def gram (Y : Matrix s k ℂ) : Matrix k k ℂ := Yᴴ * Y

noncomputable def sourceLoss (A : Matrix s s ℂ) (Y : Matrix s k ℂ) : Matrix k k ℂ :=
  Yᴴ * (1 - Aᴴ * A) * Y

omit [DecidableEq k] in
/-- The exact confluent Stein identity follows algebraically from the
source-chain and source-orthogonality identities. These hypotheses are
stated visibly here; this lemma by itself is not the full source theorem. -/
theorem stein_of_source_chain (A : Matrix s s ℂ) (Y : Matrix s k ℂ)
    (J : Matrix k k ℂ) (B : Matrix s Unit ℂ) (E : Matrix k Unit ℂ) (n : ℂ)
    (hchain : A * Y = Y * J - B * Eᴴ)
    (horth : Bᴴ * Y = 0) (hmass : Bᴴ * B = n • (1 : Matrix Unit Unit ℂ)) :
    gram Y - Jᴴ * gram Y * J = sourceLoss A Y + n • (E * Eᴴ) := by
  have horth' : Yᴴ * B = 0 := by
    simpa using congrArg Matrix.conjTranspose horth
  have hc₁ : (Y * J)ᴴ * (B * Eᴴ) = 0 := by
    calc
      _ = Jᴴ * ((Yᴴ * B) * Eᴴ) := by simp [Matrix.mul_assoc]
      _ = 0 := by rw [horth']; simp
  have hc₂ : (B * Eᴴ)ᴴ * (Y * J) = 0 := by
    calc
      _ = E * ((Bᴴ * Y) * J) := by simp [Matrix.mul_assoc]
      _ = 0 := by rw [horth]; simp
  have hb : (B * Eᴴ)ᴴ * (B * Eᴴ) = n • (E * Eᴴ) := by
    calc
      _ = E * ((Bᴴ * B) * Eᴴ) := by simp [Matrix.mul_assoc]
      _ = n • (E * Eᴴ) := by rw [hmass]; simp
  have hn : (A * Y)ᴴ * (A * Y) = Jᴴ * gram Y * J + n • (E * Eᴴ) := by
    rw [hchain, conjTranspose_sub, Matrix.sub_mul, Matrix.mul_sub, Matrix.mul_sub, hc₁, hc₂, hb]
    simp [gram, Matrix.mul_assoc]
  have hl : sourceLoss A Y = gram Y - (A * Y)ᴴ * (A * Y) := by
    simp [sourceLoss, gram, Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_assoc]
  rw [hl, hn]
  abel

omit [DecidableEq s] [DecidableEq k] in
theorem gram_posDef_of_injective (Y : Matrix s k ℂ) (hY : Function.Injective Y.mulVec) :
    (gram Y).PosDef := Matrix.PosDef.conjTranspose_mul_self Y hY

omit [DecidableEq k] in
theorem sourceLoss_posSemidef (A : Matrix s s ℂ) (Y : Matrix s k ℂ)
    (hA : (1 - Aᴴ * A).PosSemidef) : (sourceLoss A Y).PosSemidef :=
  hA.conjTranspose_mul_mul_same Y

end GramIdentity

section KernelObservability

variable {V W : Type*} [AddCommGroup V] [Module ℂ V]
  [AddCommGroup W] [Module ℂ W] [FiniteDimensional ℂ W]

/-- An invariant kernel on which the output vanishes is trivial when the
state/output pair has no invisible eigenvector. -/
theorem injective_of_invariant_kernel (Y : W →ₗ[ℂ] V) (J : Module.End ℂ W)
    (e : W →ₗ[ℂ] ℂ)
    (hinv : ∀ x, Y x = 0 → Y (J x) = 0)
    (houtput : ∀ x, Y x = 0 → e x = 0)
    (hobs : ∀ (μ : ℂ) x, J x = μ • x → e x = 0 → x = 0) :
    Function.Injective Y := by
  apply LinearMap.ker_eq_bot.mp
  by_contra hker
  let K := LinearMap.ker Y
  haveI : Nontrivial K := Submodule.nontrivial_iff_ne_bot.mpr hker
  let Jr : Module.End ℂ K := J.restrict (fun x hx => hinv x hx)
  obtain ⟨μ, hμ⟩ := Module.End.exists_eigenvalue Jr
  obtain ⟨v, hv⟩ := hμ.exists_hasEigenvector
  have heigen : J (v : W) = μ • (v : W) := congrArg Subtype.val hv.apply_eq_smul
  have hz : (v : W) = 0 := hobs μ v heigen (houtput v v.property)
  exact hv.2 (Subtype.ext hz)

/-- The source relation itself forces the kernel to be invariant. Together
with observability, this proves that no confluent coordinates are lost.
Only the source vector's nonzero squared norm is needed. -/
theorem injective_of_source_identity (A : Module.End ℂ V)
    (Y : W →ₗ[ℂ] V) (J : Module.End ℂ W) (b : V)
    (e : W →ₗ[ℂ] ℂ) (ell : V →ₗ[ℂ] ℂ)
    (hchain : ∀ x, A (Y x) = Y (J x) - (e x) • b)
    (horth : ∀ x, ell (Y x) = 0) (hmass : ell b ≠ 0)
    (hobs : ∀ (μ : ℂ) x, J x = μ • x → e x = 0 → x = 0) :
    Function.Injective Y := by
  have hout : ∀ x, Y x = 0 → e x = 0 := by
    intro x hx
    have heq := congrArg ell (hchain x)
    simp only [hx, map_zero, map_sub, horth, map_smul, smul_eq_mul, zero_sub] at heq
    exact (mul_eq_zero.mp (neg_eq_zero.mp heq.symm)).resolve_right hmass
  apply injective_of_invariant_kernel Y J e _ hout hobs
  intro x hx
  have heq := hchain x
  simpa only [hx, map_zero, hout x hx, zero_smul, sub_zero] using heq.symm

end KernelObservability

section SourceRealization

variable {s : Type*} [Fintype s] [DecidableEq s]

noncomputable def columnMatrix (v : s → ℂ) : Matrix s Unit ℂ := fun j _ => v j

omit [Fintype s] [DecidableEq s] in
theorem columnMatrix_mulVec (v : s → ℂ) (x : Unit → ℂ) :
    (columnMatrix v).mulVec x = x () • v := by
  funext j
  simp [columnMatrix, mulVec, dotProduct, mul_comm]

omit [DecidableEq s] in
theorem columnMatrix_adjoint_mulVec (v x : s → ℂ) :
    (columnMatrix v)ᴴ.mulVec x = fun _ => star v ⬝ᵥ x := by
  funext j
  rfl

theorem matrix_ext_mulVec {a c : Type*} [Fintype a] [Fintype c] [DecidableEq c]
    (M N : Matrix a c ℂ) (h : ∀ x, M.mulVec x = N.mulVec x) : M = N := by
  apply Matrix.toLin'.injective
  exact LinearMap.ext h

theorem cauchy_source_matrix_identity (α b : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hsep : ∀ i j, w i ≠ α j) :
    Matrix.diagonal α * cauchyMatrix α b w r =
      cauchyMatrix α b w r * jordanMatrix w r -
        columnMatrix b * (columnMatrix (outputVector r))ᴴ := by
  apply matrix_ext_mulVec
  intro x
  rw [Matrix.sub_mulVec]
  simp only [← Matrix.mulVec_mulVec, columnMatrix_adjoint_mulVec,
    columnMatrix_mulVec, outputVector_dotProduct]
  exact cauchy_source_identity α b w r hsep x

omit [DecidableEq σ] [DecidableEq s] in
/-- The actual moment equations make every Cauchy column perpendicular to
the source vector. The weights are explicitly tied to that vector. -/
theorem cauchy_orthogonal_of_moments (α b ν : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hweights : ∀ j, star (b j) * b j = ν j)
    (hmom : ∀ i (h : Fin (r i + 1)),
      (∑ j, ν j / (w i - α j) ^ (h.val + 1)) = 0)
    (x : ChainIndex r → ℂ) :
    star b ⬝ᵥ (cauchyMatrix α b w r).mulVec x = 0 := by
  rw [Matrix.dotProduct_mulVec]
  have hv : Matrix.vecMul (star b) (cauchyMatrix α b w r) = 0 := by
    funext a
    change (∑ j, star (b j) * (b j / (w a.1 - α j) ^ (a.2.val + 1))) = 0
    simp_rw [← mul_div_assoc, hweights]
    exact hmom a.1 a.2
  rw [hv, zero_dotProduct]

/-- The complete canonical Cauchy family is linearly independent once its
moments vanish; distinct spectral points supply the observable pair. -/
theorem cauchy_injective_of_moments (α b ν : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hsep : ∀ i j, w i ≠ α j) (hw : Function.Injective w)
    (hweights : ∀ j, star (b j) * b j = ν j) (hn : (∑ j, ν j) ≠ 0)
    (hmom : ∀ i (h : Fin (r i + 1)),
      (∑ j, ν j / (w i - α j) ^ (h.val + 1)) = 0) :
    Function.Injective (cauchyMatrix α b w r).mulVec := by
  let e := dotProductBilin ℂ ℂ (star (outputVector r))
  let ell := dotProductBilin ℂ ℂ (star b)
  apply injective_of_source_identity (Matrix.diagonal α).toLin'
    (cauchyMatrix α b w r).toLin' (jordanMap w r) b e ell
  · intro x
    change (Matrix.diagonal α).mulVec ((cauchyMatrix α b w r).mulVec x) =
      (cauchyMatrix α b w r).mulVec (jordanApply w r x) -
        (star (outputVector r) ⬝ᵥ x) • b
    rw [outputVector_dotProduct]
    simpa only [jordanMatrix_mulVec] using cauchy_source_identity α b w r hsep x
  · intro x
    exact cauchy_orthogonal_of_moments α b ν w r hweights hmom x
  · change (∑ j, star (b j) * b j) ≠ 0
    simpa only [hweights] using hn
  · intro μ x hx he
    apply canonical_eigenvector_observable_dotProduct w r hw μ x _ he
    simpa only [jordanMatrix_mulVec] using hx

omit [DecidableEq σ] in
/-- Polynomial multiplicities now imply source orthogonality without any
additional moment premise. -/
theorem cauchy_orthogonal_of_numerator_dvd (α b ν : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hsep : ∀ i j, w i ≠ α j)
    (hweights : ∀ j, star (b j) * b j = ν j) (hn : (∑ j, ν j) ≠ 0)
    (hroot : ∀ i, (Polynomial.X - Polynomial.C (w i)) ^ (r i + 1) ∣
      Source.numerator Finset.univ α ν) (x : ChainIndex r → ℂ) :
    star b ⬝ᵥ (cauchyMatrix α b w r).mulVec x = 0 := by
  apply cauchy_orthogonal_of_moments α b ν w r hweights _ x
  intro i h
  exact Source.moments_vanish_of_numerator_dvd Finset.univ α ν (w i) (r i + 1)
    hn (fun j _ => hsep i j) (hroot i) h.val h.isLt

/-- Full column rank follows from the polynomial roots themselves. -/
theorem cauchy_injective_of_numerator_dvd (α b ν : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hsep : ∀ i j, w i ≠ α j) (hw : Function.Injective w)
    (hweights : ∀ j, star (b j) * b j = ν j) (hn : (∑ j, ν j) ≠ 0)
    (hroot : ∀ i, (Polynomial.X - Polynomial.C (w i)) ^ (r i + 1) ∣
      Source.numerator Finset.univ α ν) :
    Function.Injective (cauchyMatrix α b w r).mulVec := by
  apply cauchy_injective_of_moments α b ν w r hsep hw hweights hn
  intro i h
  exact Source.moments_vanish_of_numerator_dvd Finset.univ α ν (w i) (r i + 1)
    hn (fun j _ => hsep i j) (hroot i) h.val h.isLt

theorem cauchy_gram_posDef (α b ν : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hsep : ∀ i j, w i ≠ α j) (hw : Function.Injective w)
    (hweights : ∀ j, star (b j) * b j = ν j) (hn : (∑ j, ν j) ≠ 0)
    (hroot : ∀ i, (Polynomial.X - Polynomial.C (w i)) ^ (r i + 1) ∣
      Source.numerator Finset.univ α ν) :
    (gram (cauchyMatrix α b w r)).PosDef :=
  gram_posDef_of_injective _
    (cauchy_injective_of_numerator_dvd α b ν w r hsep hw hweights hn hroot)

/-- The exact Stein identity for the actual source-coordinate matrices. -/
theorem cauchy_stein_identity (α b ν : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hsep : ∀ i j, w i ≠ α j)
    (hweights : ∀ j, star (b j) * b j = ν j) (hn : (∑ j, ν j) ≠ 0)
    (hroot : ∀ i, (Polynomial.X - Polynomial.C (w i)) ^ (r i + 1) ∣
      Source.numerator Finset.univ α ν) :
    gram (cauchyMatrix α b w r) -
        (jordanMatrix w r)ᴴ * gram (cauchyMatrix α b w r) * jordanMatrix w r =
      sourceLoss (Matrix.diagonal α) (cauchyMatrix α b w r) +
        (∑ j, ν j) • (columnMatrix (outputVector r) * (columnMatrix (outputVector r))ᴴ) := by
  apply stein_of_source_chain _ _ _ (columnMatrix b) _ _
    (cauchy_source_matrix_identity α b w r hsep)
  · apply matrix_ext_mulVec
    intro x
    simp only [← Matrix.mulVec_mulVec, columnMatrix_adjoint_mulVec, Matrix.zero_mulVec]
    funext u
    exact cauchy_orthogonal_of_numerator_dvd α b ν w r hsep hweights hn hroot x
  · ext u v
    simp only [columnMatrix, Matrix.mul_apply, Matrix.conjTranspose_apply,
      Matrix.smul_apply, Matrix.one_apply, Subsingleton.elim u v, ite_true, smul_eq_mul, mul_one]
    change (∑ j, star (b j) * b j) = ∑ j, ν j
    simp only [hweights]

end SourceRealization

section CompleteProjection

variable {s k : Type*} [Fintype s] [DecidableEq s] [Fintype k] [DecidableEq k]

noncomputable def sourceSynthesis (b : s → ℂ) (Y : Matrix s k ℂ) :
    (ℂ × (k → ℂ)) →ₗ[ℂ] (s → ℂ) where
  toFun z := z.1 • b + Y.mulVec z.2
  map_add' z t := by simp [add_smul, Matrix.mulVec_add]; abel
  map_smul' c z := by simp [smul_add, Matrix.mulVec_smul, MulAction.mul_smul]

omit [DecidableEq s] [DecidableEq k] in
theorem sourceSynthesis_injective (b : s → ℂ) (Y : Matrix s k ℂ)
    (hY : Function.Injective Y.mulVec) (hn : star b ⬝ᵥ b ≠ 0)
    (horth : ∀ x, star b ⬝ᵥ Y.mulVec x = 0) :
    Function.Injective (sourceSynthesis b Y) := by
  apply LinearMap.ker_eq_bot.mp
  apply LinearMap.ker_eq_bot'.mpr
  rintro ⟨c, x⟩ hx
  change c • b + Y.mulVec x = 0 at hx
  have hc : c = 0 := by
    have heq := congrArg (fun v => star b ⬝ᵥ v) hx
    simp only [dotProduct_add, dotProduct_smul, horth, add_zero, dotProduct_zero,
      smul_eq_mul] at heq
    exact (mul_eq_zero.mp heq).resolve_right hn
  have hx0 : x = 0 := by
    apply hY
    simpa only [hc, zero_smul, zero_add, Matrix.mulVec_zero] using hx
  simp [hc, hx0]

omit [DecidableEq s] [DecidableEq k] in
theorem sourceSynthesis_surjective (b : s → ℂ) (Y : Matrix s k ℂ)
    (hY : Function.Injective Y.mulVec) (hn : star b ⬝ᵥ b ≠ 0)
    (horth : ∀ x, star b ⬝ᵥ Y.mulVec x = 0)
    (hdim : Fintype.card s = Fintype.card k + 1) :
    Function.Surjective (sourceSynthesis b Y) := by
  apply (LinearMap.injective_iff_surjective_of_finrank_eq_finrank
    (show Module.finrank ℂ (ℂ × (k → ℂ)) = Module.finrank ℂ (s → ℂ) from ?_)).mp
    (sourceSynthesis_injective b Y hY hn horth)
  simp [Module.finrank_prod, hdim, Nat.add_comm]

omit [DecidableEq s] in
/-- The independent columns span exactly the source-orthogonal subspace. -/
theorem complete_source_range (b : s → ℂ) (Y : Matrix s k ℂ)
    (hY : Function.Injective Y.mulVec) (hn : star b ⬝ᵥ b ≠ 0)
    (horth : ∀ x, star b ⬝ᵥ Y.mulVec x = 0)
    (hdim : Fintype.card s = Fintype.card k + 1) :
    LinearMap.range Y.toLin' = LinearMap.ker (dotProductBilin ℂ ℂ (star b)) := by
  ext v
  constructor
  · rintro ⟨x, rfl⟩
    exact horth x
  · intro hv
    change star b ⬝ᵥ v = 0 at hv
    obtain ⟨⟨c, x⟩, hx⟩ := sourceSynthesis_surjective b Y hY hn horth hdim v
    change c • b + Y.mulVec x = v at hx
    have hc : c = 0 := by
      have heq := congrArg (fun v => star b ⬝ᵥ v) hx
      simp only [dotProduct_add, dotProduct_smul, horth, add_zero, hv, smul_eq_mul] at heq
      exact (mul_eq_zero.mp heq).resolve_right hn
    refine ⟨x, ?_⟩
    simpa only [hc, zero_smul, zero_add, Matrix.toLin'_apply] using hx

/-- Any full family of source-orthogonal columns has the claimed Gram
projection. The codimension-one hypothesis is explicit. -/
theorem complete_gram_projection (b : s → ℂ) (Y : Matrix s k ℂ)
    (hY : Function.Injective Y.mulVec) (hn : star b ⬝ᵥ b ≠ 0)
    (horth : ∀ x, star b ⬝ᵥ Y.mulVec x = 0)
    (hdim : Fintype.card s = Fintype.card k + 1) :
    Y * (gram Y)⁻¹ * Yᴴ =
      1 - (star b ⬝ᵥ b)⁻¹ • (columnMatrix b * (columnMatrix b)ᴴ) := by
  let B := columnMatrix b
  let n := star b ⬝ᵥ b
  have hBY : Bᴴ * Y = 0 := by
    apply matrix_ext_mulVec
    intro x
    simp only [← Matrix.mulVec_mulVec, B, columnMatrix_adjoint_mulVec, Matrix.zero_mulVec]
    funext u
    exact horth x
  have hYB : Yᴴ * B = 0 := by
    simpa using congrArg Matrix.conjTranspose hBY
  have hBB : Bᴴ * B = n • (1 : Matrix Unit Unit ℂ) := by
    ext u v
    simp only [B, n, columnMatrix, Matrix.mul_apply, Matrix.conjTranspose_apply,
      Matrix.smul_apply, Matrix.one_apply, Subsingleton.elim u v, ite_true, smul_eq_mul, mul_one]
    rfl
  have hH : (gram Y)⁻¹ * gram Y = 1 :=
    Matrix.nonsing_inv_mul _ ((Matrix.isUnit_iff_isUnit_det _).mp
      (gram_posDef_of_injective Y hY).isUnit)
  let P := Y * (gram Y)⁻¹ * Yᴴ
  let R : Matrix s s ℂ := 1 - n⁻¹ • (B * Bᴴ)
  have hPY : P * Y = Y := by
    calc
      _ = Y * ((gram Y)⁻¹ * gram Y) := by simp [P, gram, Matrix.mul_assoc]
      _ = Y := by rw [hH]; simp
  have hPB : P * B = 0 := by simp [P, Matrix.mul_assoc, hYB]
  have hRY : R * Y = Y := by simp [R, Matrix.sub_mul, Matrix.smul_mul, Matrix.mul_assoc, hBY]
  have hRB : R * B = 0 := by
    calc
      _ = B - n⁻¹ • (B * (Bᴴ * B)) := by simp [R, Matrix.sub_mul, Matrix.mul_assoc]
      _ = 0 := by rw [hBB]; simp [smul_smul, n, hn]
  have hb (M : Matrix s s ℂ) (hMB : M * B = 0) : M.mulVec b = 0 := by
    have heq := congrArg (fun T => T.mulVec (fun _ : Unit => (1 : ℂ))) hMB
    simpa only [← Matrix.mulVec_mulVec, B, columnMatrix_mulVec, one_smul,
      Matrix.zero_mulVec] using heq
  have hPb := hb P hPB
  have hRb := hb R hRB
  apply matrix_ext_mulVec
  intro v
  obtain ⟨⟨c, x⟩, hv⟩ := sourceSynthesis_surjective b Y hY hn horth hdim v
  change c • b + Y.mulVec x = v at hv
  rw [← hv]
  change P.mulVec (c • b + Y.mulVec x) = R.mulVec (c • b + Y.mulVec x)
  simp only [Matrix.mulVec_add, Matrix.mulVec_smul, hPb, hRb, smul_zero, zero_add,
    Matrix.mulVec_mulVec, hPY, hRY]

end CompleteProjection

section CompleteCauchyProjection

variable {s : Type*} [Fintype s] [DecidableEq s]

/-- The projection identity for the actual confluent source data. -/
theorem cauchy_projection (α b ν : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hsep : ∀ i j, w i ≠ α j) (hw : Function.Injective w)
    (hweights : ∀ j, star (b j) * b j = ν j) (hn : (∑ j, ν j) ≠ 0)
    (hroot : ∀ i, (Polynomial.X - Polynomial.C (w i)) ^ (r i + 1) ∣
      Source.numerator Finset.univ α ν)
    (hdim : Fintype.card s = Fintype.card (ChainIndex r) + 1) :
    cauchyMatrix α b w r * (gram (cauchyMatrix α b w r))⁻¹ * (cauchyMatrix α b w r)ᴴ =
      1 - (∑ j, ν j)⁻¹ • (columnMatrix b * (columnMatrix b)ᴴ) := by
  have hmass : star b ⬝ᵥ b = ∑ j, ν j := by simp only [dotProduct, Pi.star_apply, hweights]
  rw [← hmass]
  exact complete_gram_projection b (cauchyMatrix α b w r)
    (cauchy_injective_of_numerator_dvd α b ν w r hsep hw hweights hn hroot)
    (hmass ▸ hn)
    (cauchy_orthogonal_of_numerator_dvd α b ν w r hsep hweights hn hroot) hdim

end CompleteCauchyProjection

end PolynomialGeometry.Confluent
