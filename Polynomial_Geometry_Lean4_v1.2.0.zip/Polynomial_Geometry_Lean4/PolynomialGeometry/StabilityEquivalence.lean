import PolynomialGeometry.Stability
import PolynomialGeometry.Mobius
import PolynomialGeometry.ReciprocalSpectrum

/-! # Actual state decay is equivalent to strict spectral stability

The converse uses a genuine characteristic-root eigenvector. Decay of all
states forces decay of its scalar eigenvalue powers, including at the
unit-circle boundary.
-/

noncomputable section
open Matrix Filter
open scoped Topology NNReal ENNReal

namespace PolynomialGeometry.StabilityEquivalence

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

def AsymptoticallyStable (T : Matrix ι ι ℂ) : Prop :=
  ∀ x : ι → ℂ, Tendsto (fun k : ℕ => T^k *ᵥ x) atTop (𝓝 0)

/-- Along an actual eigenvector, every iterate is the corresponding
scalar eigenvalue power times that same vector. -/
theorem powers_on_eigenvector (T : Matrix ι ι ℂ) (z : ℂ) (x : ι → ℂ)
    (he : T *ᵥ x = z • x) (k : ℕ) : T^k *ᵥ x = z^k • x := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [pow_succ', ← Matrix.mulVec_mulVec, ih, Matrix.mulVec_smul, he,
      smul_smul, pow_succ]

/-- Actual all-state decay rules out every eigenvalue of modulus at least one. -/
theorem root_norm_lt_one_of_state_decay (T : Matrix ι ι ℂ)
    (hdecay : AsymptoticallyStable T) (z : ℂ) (hz : T.charpoly.IsRoot z) :
    ‖z‖ < 1 := by
  classical
  obtain ⟨x, hx, he⟩ := Mobius.eigenvector_of_root T z hz
  obtain ⟨j, hj⟩ : ∃ j, x j ≠ 0 := by
    by_contra! h
    apply hx
    funext j
    exact h j
  have ht : Tendsto (fun k : ℕ => (T^k *ᵥ x) j) atTop (𝓝 0) := by
    simpa only [Pi.zero_apply] using
      (continuous_apply j).continuousAt.tendsto.comp (hdecay x)
  have hp : Tendsto (fun k : ℕ => z^k) atTop (𝓝 0) := by
    simpa only [powers_on_eigenvector T z x he, Pi.smul_apply, smul_eq_mul,
      mul_div_cancel_right₀ _ hj, zero_div] using ht.div_const (x j)
  exact tendsto_pow_atTop_nhds_zero_iff_norm_lt_one.mp hp

theorem asymptoticallyStable_iff_roots (T : Matrix ι ι ℂ) :
    AsymptoticallyStable T ↔ ∀ z : ℂ, T.charpoly.IsRoot z → ‖z‖ < 1 := by
  constructor
  · exact root_norm_lt_one_of_state_decay T
  · exact Stability.states_tendsto_zero T

/-- This equivalence includes repeated eigenvalues and non-diagonalizable
matrices. It also handles the zero-dimensional state space. -/
theorem asymptoticallyStable_iff_spectralRadius (T : Matrix ι ι ℂ) :
    AsymptoticallyStable T ↔ spectralRadius ℂ T < 1 := by
  rw [asymptoticallyStable_iff_roots]
  constructor
  · exact CompressionDet.spectralRadius_lt_one_of_charpoly_roots T
  · intro h z hz
    have hm := Matrix.mem_spectrum_iff_isRoot_charpoly.mpr hz
    have hb : (‖z‖₊ : ℝ≥0∞) ≤ spectralRadius ℂ T :=
      le_iSup₂_of_le z hm le_rfl
    exact_mod_cast hb.trans_lt h

/-- Failure of asymptotic stability is exactly the spectral-radius
threshold, with equality and neutral modes included. -/
theorem not_asymptoticallyStable_iff (T : Matrix ι ι ℂ) :
    ¬ AsymptoticallyStable T ↔ 1 ≤ spectralRadius ℂ T := by
  rw [asymptoticallyStable_iff_spectralRadius, not_lt]


section Scaling

variable [Nonempty ι]
attribute [local instance] Matrix.linftyOpNormedRing Matrix.linftyOpNormedAlgebra

/-- Nonnegative real scaling multiplies the actual finite-matrix spectral radius. -/
theorem spectralRadius_smul_nnreal (T : Matrix ι ι ℂ) (r : ℝ≥0) :
    spectralRadius ℂ ((r : ℂ) • T) = (r : ℝ≥0∞) * spectralRadius ℂ T := by
  have hs := spectrum.smul_eq_smul (r : ℂ) T (spectrum.nonempty T)
  have hr : ‖(r : ℂ)‖₊ = r := by
    ext
    simp
  rw [spectralRadius, hs]
  change (⨆ k ∈ (fun z : ℂ => (r : ℂ) * z) '' spectrum ℂ T,
    (‖k‖₊ : ℝ≥0∞)) = _
  simp only [iSup_image, nnnorm_mul, ENNReal.coe_mul, hr]
  simp only [spectralRadius, ENNReal.mul_iSup]

/-- The geometric reciprocal threshold is exactly failure of asymptotic
stability of the rescaled discrete matrix. -/
theorem reciprocal_distance_iff_not_stable (A : Matrix ι ι ℂ) (a : ℂ)
    (ha : IsUnit (a • (1 : Matrix ι ι ℂ) - A)) (r : ℝ≥0) :
    (∃ w : ℂ, A.charpoly.IsRoot w ∧ ‖a - w‖ ≤ (r : ℝ)) ↔
      ¬ AsymptoticallyStable ((r : ℂ) • (a • (1 : Matrix ι ι ℂ) - A)⁻¹) := by
  rw [ReciprocalSpectrum.root_distance_iff_reciprocal_radius A a ha r,
    not_asymptoticallyStable_iff, spectralRadius_smul_nnreal]

end Scaling

/-- The full polynomial derivative, including inherited repeated-root
modes, has exactly the stability interpretation stated in the article. -/
theorem full_reciprocal_distance_iff_not_stable
    (d : ℕ) (hd : 0 < d) (α : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (CompressionDet.normalizedSource d (fun _ => 1) i) * Q i j = 0)
    (a : ℂ) (ha : (Source.support Finset.univ α).derivative.eval a ≠ 0) (r : ℝ≥0) :
    (∃ w : ℂ, (Source.support Finset.univ α).derivative.IsRoot w ∧ ‖a - w‖ ≤ (r : ℝ)) ↔
      ¬ AsymptoticallyStable ((r : ℂ) •
        (a • (1 : Matrix (Fin d) (Fin d) ℂ) - Qᴴ * diagonal α * Q)⁻¹) := by
  letI : Nonempty (Fin d) := ⟨⟨0, hd⟩⟩
  rw [ReciprocalSpectrum.full_reciprocal_distance_threshold d α Q hQ hbQ a ha r,
    not_asymptoticallyStable_iff, spectralRadius_smul_nnreal]

end PolynomialGeometry.StabilityEquivalence

