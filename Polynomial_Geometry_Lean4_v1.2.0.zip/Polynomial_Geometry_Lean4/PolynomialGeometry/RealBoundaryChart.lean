import PolynomialGeometry.FeasibleReduction
import Mathlib.Analysis.SpecialFunctions.ExpDeriv

/-! # Real analytic boundary coordinates for the actual smooth objective -/
noncomputable section
open scoped Topology BigOperators
open Filter Complex
namespace PolynomialGeometry.RealBoundaryChart
open PolynomialGeometry.FeasibleReduction PolynomialGeometry.Variations
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

abbrev Coordinates := (ι → ℝ) × ((κ → ℝ) × ((ι → ℝ) × (κ → ℝ)))

def linearCoordinates : Coordinates (ι := ι) (κ := κ) →L[ℝ] ((ι → ℂ) × (κ → ℂ)) :=
  (ContinuousLinearMap.pi fun i =>
    Complex.ofRealCLM.comp ((ContinuousLinearMap.proj i).comp (ContinuousLinearMap.fst _ _ _)) +
    Complex.I • Complex.ofRealCLM.comp ((ContinuousLinearMap.proj i).comp
      ((ContinuousLinearMap.fst _ _ _).comp ((ContinuousLinearMap.snd _ _ _).comp
        (ContinuousLinearMap.snd _ _ _))))).prod
  (ContinuousLinearMap.pi fun j =>
    Complex.ofRealCLM.comp ((ContinuousLinearMap.proj j).comp
      ((ContinuousLinearMap.fst _ _ _).comp (ContinuousLinearMap.snd _ _ _))) +
    Complex.I • Complex.ofRealCLM.comp ((ContinuousLinearMap.proj j).comp
      ((ContinuousLinearMap.snd _ _ _).comp ((ContinuousLinearMap.snd _ _ _).comp
        (ContinuousLinearMap.snd _ _ _)))))

/-- `(x,rho,y,theta)` maps to `(x+i y, beta exp(rho+i theta))`. -/
def chart (β : κ → ℂ) (p : Coordinates (ι := ι) (κ := κ)) : (ι → ℂ) × (κ → ℂ) :=
  (fun i => p.1 i + Complex.I * p.2.2.1 i,
   fun j => β j * Complex.exp (p.2.1 j + Complex.I * p.2.2.2 j))

omit [Fintype ι] [Fintype κ] in
@[simp] theorem chart_zero (β : κ → ℂ) : chart (ι := ι) β 0 = (0,β) := by
  ext <;> simp [chart]

omit [Fintype ι] [Fintype κ] in
/-- The disk constraint is exactly the nonpositive radial orthant. -/
theorem chart_sources_disk_iff (β : κ → ℂ) (hβ : ∀ j, ‖β j‖ = 1)
    (p : Coordinates (ι := ι) (κ := κ)) :
    (∀ j, ‖(chart β p).2 j‖ ≤ 1) ↔ ∀ j, p.2.1 j ≤ 0 := by
  apply forall_congr'
  intro j
  simpa only [chart,mul_comm Complex.I] using
    boundary_disk_iff (β j) (hβ j) (p.2.1 j) (p.2.2.2 j)

omit [Fintype ι] [Fintype κ] in
/-- Vanishing radial coordinates put every displayed source on the circle. -/
theorem chart_sources_on_circle (β : κ → ℂ) (hβ : ∀ j, ‖β j‖ = 1)
    (p : Coordinates (ι := ι) (κ := κ)) (hp : p.2.1 = 0) :
    ∀ j, ‖(chart β p).2 j‖ = 1 := by
  intro j
  simp [chart,hp,hβ,Complex.norm_exp]

/-- The real boundary chart is analytic at every parameter point. -/
theorem chart_analyticAt (β : κ → ℂ) (p : Coordinates (ι := ι) (κ := κ)) :
    AnalyticAt ℝ (chart β) p := by
  let B : ((ι → ℂ) × (κ → ℂ)) → ((ι → ℂ) × (κ → ℂ)) :=
    fun q => (q.1,fun j => β j * Complex.exp (q.2 j))
  have hB : AnalyticAt ℂ B (linearCoordinates p) := by
    apply analyticAt_fst.prod
    apply AnalyticAt.pi
    intro j
    have hcoord : AnalyticAt ℂ (fun q : (ι → ℂ) × (κ → ℂ) => q.2 j)
        (linearCoordinates p) :=
      ((ContinuousLinearMap.proj j : (κ → ℂ) →L[ℂ] ℂ).comp
        (ContinuousLinearMap.snd ℂ (ι → ℂ) (κ → ℂ))).analyticAt _
    exact analyticAt_const.mul (analyticAt_cexp.comp hcoord)
  have hC := (hB.restrictScalars (𝕜 := ℝ)).comp (linearCoordinates.analyticAt p)
  exact hC

/-- The smooth objective is the real part of the same holomorphic weighted
logarithm, evaluated at the boundary chart. -/
def smoothObjective (H : ((ι → ℂ) × (κ → ℂ)) → ℂ) (β : κ → ℂ)
    (p : Coordinates (ι := ι) (κ := κ)) : ℝ := (H (chart β p)).re

theorem smoothObjective_analyticAt
    (H : ((ι → ℂ) × (κ → ℂ)) → ℂ) (β : κ → ℂ)
    (hH : AnalyticAt ℂ H (0,β)) : AnalyticAt ℝ (smoothObjective H β) 0 := by
  have hcomp := (hH.restrictScalars (𝕜 := ℝ)).comp_of_eq (chart_analyticAt β 0) (chart_zero β)
  exact (Complex.reCLM.analyticAt _).comp hcomp

omit [Fintype ι] [Fintype κ] in
/-- On the balanced boundary slice this is exactly the reduced objective Ψ. -/
@[simp] theorem reduced_objective (H : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (β : κ → ℂ) (u : (ι → ℝ) × (κ → ℝ)) :
    smoothObjective H β (0,(0,u)) =
      (H (fun i => Complex.I * u.1 i, fun j => β j * Complex.exp (Complex.I * u.2 j))).re := by
  simp [smoothObjective,chart]

/-- Zero complex differential in the free ratio variables gives zero real
balancing differential after the actual exponential boundary chart. -/
theorem balancing_derivative_zero
    (H : ((ι → ℂ) × (κ → ℂ)) → ℂ) (β : κ → ℂ)
    (hH : AnalyticAt ℂ H (0,β))
    (hz : fderiv ℂ (fun z : ι → ℂ => H (z,β)) 0 = 0) :
    ∀ x : ι → ℝ, fderiv ℝ (smoothObjective H β) 0 (x,0) = 0 := by
  let R : (ι → ℝ) →L[ℝ] (ι → ℂ) :=
    ContinuousLinearMap.pi fun i => Complex.ofRealCLM.comp (ContinuousLinearMap.proj i)
  have hslice : AnalyticAt ℂ (fun z : ι → ℂ => H (z,β)) 0 :=
    hH.comp_of_eq (analyticAt_id.prod analyticAt_const) rfl
  have hzero : HasFDerivAt (fun z : ι → ℂ => H (z,β)) (0 : (ι → ℂ) →L[ℂ] ℂ) 0 := by
    rw [← hz]
    exact hslice.differentiableAt.hasFDerivAt
  have hreal := (Complex.reCLM.hasFDerivAt.comp 0 ((hzero.restrictScalars ℝ).comp 0 R.hasFDerivAt))
  let J := ContinuousLinearMap.inl ℝ (ι → ℝ) ((κ → ℝ) × ((ι → ℝ) × (κ → ℝ)))
  have hactual : HasFDerivAt (fun x : ι → ℝ => smoothObjective H β (x,0))
      ((fderiv ℝ (smoothObjective H β) 0).comp J) 0 :=
    (smoothObjective_analyticAt H β hH).differentiableAt.hasFDerivAt.comp (f := fun x : ι → ℝ => (x,0)) (0 : ι → ℝ) J.hasFDerivAt
  have heqfun : (fun x : ι → ℝ => smoothObjective H β (x,0)) =
      (fun x : ι → ℝ => (H (R x,β)).re) := by
    ext x
    simp [smoothObjective,chart,R]
  rw [heqfun] at hactual
  have heq := hactual.unique hreal
  intro x
  have hx := congrArg (fun L : (ι → ℝ) →L[ℝ] ℝ => L x) heq
  simpa [ContinuousLinearMap.comp_apply] using hx

/-- Analyticity of the actual logarithmic objective supplies the uniform
strict differentiability needed in the exact two-stage reduction. -/
theorem analytic_boundary_reduction [Nonempty ι] [Nonempty κ] [DecidableEq κ]
    (H : ((ι → ℂ) × (κ → ℂ)) → ℂ) (β : κ → ℂ)
    {τ : ℝ} (hτ : 0 < τ) (hτ1 : τ < 1)
    (hH : AnalyticAt ℂ H (0,β))
    (hx : ∀ x : ι → ℝ, fderiv ℝ (smoothObjective H β) 0 (x,0) = 0)
    (hr : ∀ j, 0 < fderiv ℝ (smoothObjective H β) 0 (0,(Pi.single j 1,0))) :
    arbitrarilyNearPositive (objective (smoothObjective H β) τ)
        (fun p => ∀ j, p.2.1 j ≤ 0) ↔
      arbitrarilyNearPositive (fun u : (ι → ℝ) × (κ → ℝ) =>
        (H (fun i => Complex.I * u.1 i,
          fun j => β j * Complex.exp (Complex.I * u.2 j))).re) (fun _ => True) := by
  have h := arbitrarily_near_improvement_iff hτ hτ1
    (smoothObjective_analyticAt H β hH).hasStrictFDerivAt hx hr
  simpa only [reduced_objective] using h

end PolynomialGeometry.RealBoundaryChart
