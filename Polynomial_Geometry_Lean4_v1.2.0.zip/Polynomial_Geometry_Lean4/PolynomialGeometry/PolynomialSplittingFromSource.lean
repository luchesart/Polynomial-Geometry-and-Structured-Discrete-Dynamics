import PolynomialGeometry.PolynomialSplittingElimination

/-! # The polynomial source of the centered splitting theorem

The chosen reconstruction and inverse ratio chart are the same witnesses for
the feasible reduction and for the centered derivative and elimination results.
The grouping of boundary copies is specified only by their original labels.
-/

noncomputable section
open Filter Polynomial
open scoped Topology

namespace PolynomialGeometry.PolynomialSplittingFromSource
open Factorization CriticalReconstruction SimpleRoot ReconstructionCompletion
open RatioCoordinates PolynomialFeasibleChart FullFeasibleReduction
open OriginalFeasibleReduction PolynomialSplittingElimination
open SymmetricElimination IndependentCenteredBlocks

/-- For any list of negative curvatures of the selected blocks of the actual
objective, removing their zero-sum deviations gives a strict quadratic gain.
The means and all the unselected angles remain free. -/
def NegativeCurvatureGain {nc nb kc kb : ℕ} (m : Index nc nb → ℕ)
    (F : Free nc nb kc kb × Blocks (Copies m) → ℝ) : Prop :=
  ∀ lam : Index nc nb → ℝ,
    (∀ j (v : centeredSubspace (ι := Copies m j)),
      fderiv ℝ (fderiv ℝ F) 0 (0, inclusion (Copies m) j v) (0, inclusion (Copies m) j v) =
        lam j * ‖v‖^2) →
    (∀ j, lam j < 0) →
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ p in 𝓝 0, F p ≤ F (p.1,0) - c * ‖p.2‖^2

/-- The feasible reduction and Proposition D.3 in one chart, starting with
the original factor, labelled boundary roots, and simple marked root.
No reconstruction, chart inverse, permutation invariance, or symmetry of Ψ
is an input. The derivative and radial tests are those of the local theorem. -/
theorem original_polynomial_splitting
    (r s : ℕ) (hr : 0 < r)
    (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ) (D : ℝ)
    (hA : A.Monic) (hAd : A.natDegree = r)
    (hinterior : ∀ z, A.IsRoot z → ‖z‖ < 1)
    (hboundary : ∀ j, ‖β j‖ = 1)
    (hvalue : (A * rootPolynomial (s + 1) β).eval w ≠ 0)
    (hmult : (A * rootPolynomial (s + 1) β).derivative.rootMultiplicity w = r)
    (haRoot : A.eval a₀ = 0) (haSimple : A.derivative.eval a₀ ≠ 0)
    (hwv : v₀ ≠ w)
    (hvRoot : (A * rootPolynomial (s + 1) β).derivative.eval v₀ = 0)
    (hvSimple : (A * rootPolynomial (s + 1) β).derivative.derivative.eval v₀ ≠ 0)
    (hD : 0 < D) (hq : ‖w-a₀‖ = D) (hg : ‖v₀-a₀‖ = D)
    (hgap : ∀ z, (A * rootPolynomial (s + 1) β).derivative.IsRoot z →
      z ≠ w → z ≠ v₀ → D < ‖z-a₀‖) :
    ∃ R : LocalReconstructionResult r s A β w a₀ v₀,
      deriv (fun t => parameterLogRatios R.sourceRoot R.simpleCritical
        (w-a₀) (v₀-a₀) ((fun _ => t),β) ⟨0,hr⟩) w ≠ 0 →
      ∃ G : Parameter r s → Parameter r s,
        AnalyticAt ℂ G (0,β) ∧ G (0,β) = ((fun _ => w),β) ∧
        (∀ᶠ t in 𝓝 (((fun _ => w),β) : Parameter r s),
          G (FullRatioChart.forward r s R.sourceRoot R.simpleCritical
            (w-a₀) (v₀-a₀) t) = t) ∧
        (∀ᶠ p in 𝓝 ((0,β) : Parameter r s),
          FullRatioChart.forward r s R.sourceRoot R.simpleCritical
            (w-a₀) (v₀-a₀) (G p) = p) ∧
        ∀ τ : ℝ, 0 < τ → τ < 1 →
        deriv (fun t : ℂ =>
          (τ : ℂ) * Complex.log ((w-a₀)⁻¹ * (t-R.sourceRoot ((fun _ => t),β))) +
          (1-τ) * Complex.log ((v₀-a₀)⁻¹ *
            (R.simpleCritical ((fun _ => t),β)-R.sourceRoot ((fun _ => t),β)))) w = 0 →
        radialCondition r s R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β τ →
        CompleteConclusion r s A β w a₀ v₀ D τ R G ∧
        ∀ (nc nb kc kb : ℕ) (m : Index nc nb → ℕ)
          (ec : Fin r ≃ CriticalSide m kc) (eb : Fin (s+1) ≃ BoundarySide m kb),
          (∀ j k, β (eb.symm (.inr ⟨j,k⟩)) = β (eb.symm (.inr ⟨j,0⟩))) →
          let F := PolynomialSplittingElimination.objective m ec eb A β w a₀ v₀ R G τ
          IndependentBlockConsequences.CenteredDerivatives (Copies m) F ∧
          NegativeCurvatureGain m F := by
  obtain ⟨R,hR⟩ := original_polynomial_feasible_reduction r s hr A β w a₀ v₀ D
    hA hAd hinterior hboundary hvalue hmult haRoot haSimple hwv hvRoot hvSimple hD hq hg hgap
  refine ⟨R,?_⟩
  intro hdiag
  obtain ⟨G,hG,hG0,hleft,hright,hcomplete⟩ := hR hdiag
  refine ⟨G,hG,hG0,hleft,hright,?_⟩
  intro τ hτ hτ1 hfree hrad
  refine ⟨hcomplete τ hτ hτ1 hfree hrad,?_⟩
  intro nc nb kc kb m ec eb hβ
  have hw : w-a₀ ≠ 0 := norm_ne_zero_iff.mp (hq ▸ hD.ne')
  have hv : v₀-a₀ ≠ 0 := norm_ne_zero_iff.mp (hg ▸ hD.ne')
  refine ⟨polynomial_centered_derivatives m ec eb A β w a₀ v₀ R G τ
    hG hG0 hleft hright hβ hw hv,?_⟩
  intro lam hcurv hneg
  exact negative_block_scalars_exact_elimination (Copies m) _
    (objective_analyticAt m ec eb A β w a₀ v₀ R G τ hG hG0 hw hv)
    (objective_action m ec eb A β w a₀ v₀ R G τ hG hG0 hleft hright hβ)
    lam hneg hcurv

end PolynomialGeometry.PolynomialSplittingFromSource
