import PolynomialGeometry.CriticalReconstruction

/-! # Uniqueness of the prescribed critical factor

A residual factor that is nonzero at all prescribed copies cannot absorb any
part of their multiplicities. This algebraic fact removes any need to assume
that an alternative residual factor is close to the base residual factor.
-/
noncomputable section
open Polynomial
open scoped BigOperators
namespace PolynomialGeometry.CriticalFactorUniqueness
open CriticalReconstruction

/-- Nonvanishing at every labelled copy makes the complete copy product
coprime to the residual factor, including repeated labels. -/
theorem prescribed_factor_coprime (r : ℕ) (z : Fin r → ℂ) (U : ℂ[X])
    (hU : ∀ i, U.eval (z i) ≠ 0) : IsCoprime (rootPolynomial r z) U := by
  apply (Polynomial.isCoprime_iff_aeval_ne_zero_of_isAlgClosed ℂ ℂ _ _).mpr
  intro w
  by_cases hw : (rootPolynomial r z).eval w = 0
  · right
    have hx := hw
    simp only [rootPolynomial, eval_prod, eval_sub, eval_X, eval_C,
      Finset.prod_eq_zero_iff, Finset.mem_univ, true_and, sub_eq_zero] at hx
    obtain ⟨i, rfl⟩ := hx
    exact hU i
  · exact Or.inl hw

/-- A monic degree-r critical factor divisible by all r prescribed copies
is precisely their product. The nonzero normalization and residual factor
cannot absorb any prescribed multiplicity. -/
theorem prescribed_factor_unique (r : ℕ) (z : Fin r → ℂ)
    (N : ℂ) (Cactual U : ℂ[X]) (hN : N ≠ 0)
    (hC : Cactual.Monic) (hCd : Cactual.natDegree = r)
    (hU : ∀ i, U.eval (z i) ≠ 0)
    (hdiv : rootPolynomial r z ∣ C N * Cactual * U) :
    Cactual = rootPolynomial r z := by
  have hcop := prescribed_factor_coprime r z U hU
  have hd : rootPolynomial r z ∣ C N * Cactual := hcop.dvd_of_dvd_mul_right hdiv
  have hd' : rootPolynomial r z ∣ Cactual := by
    have hunit : IsUnit (C N) := (isUnit_iff_ne_zero.mpr hN).map C
    exact hunit.dvd_mul_left.mp hd
  apply eq_of_monic_of_dvd_of_natDegree_le (rootPolynomial_monic r z) hC hd'
  simp only [hCd, rootPolynomial_natDegree, le_refl]

end PolynomialGeometry.CriticalFactorUniqueness
