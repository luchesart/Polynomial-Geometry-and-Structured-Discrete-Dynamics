import PolynomialGeometry.InverseCofactor

/-! # The source identity determines the complete state block

This bridge derives the full numerator from the actual source equations,
instead of assuming a similarity with the prescribed critical block.
-/

noncomputable section
open Matrix
open scoped ComplexOrder

namespace PolynomialGeometry.InverseBasisBridge

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The source equation forces the state block after changing to the
source/state basis. Only the displayed left-inverse identity is needed. -/
theorem sourceBasis_state_block (α b : Option ι → ℂ)
    (Y : Matrix (Option ι) ι ℂ) (J : Matrix ι ι ℂ) (e : ι → ℂ)
    (V : Matrix (Option ι) (Option ι) ℂ)
    (hVU : V * InverseCofactor.sourceBasis b Y = 1)
    (hsource : Matrix.diagonal α * Y = Y * J - Matrix.vecMulVec b (star e)) :
    (V * Matrix.diagonal α * InverseCofactor.sourceBasis b Y).submatrix
      Option.some Option.some = J := by
  let B := InverseCofactor.sourceBasis b Y
  let K : Matrix (Option ι) ι ℂ := fun k j => k.elim (-star (e j)) (fun i => J i j)
  have hBK : B * K = Y * J - Matrix.vecMulVec b (star e) := by
    ext j i
    simp only [B, K, InverseCofactor.sourceBasis, Matrix.mul_apply,
      Fintype.sum_option, Option.elim_none, Option.elim_some,
      Matrix.sub_apply, Matrix.vecMulVec_apply, Pi.star_apply, mul_neg]
    ring
  have hs : Matrix.diagonal α * Y = B * K := hsource.trans hBK.symm
  have hleft : V * Matrix.diagonal α * Y = K := by
    calc
      V * Matrix.diagonal α * Y = V * (Matrix.diagonal α * Y) := by rw [Matrix.mul_assoc]
      _ = V * (B * K) := by rw [hs]
      _ = K := by rw [← Matrix.mul_assoc, hVU, Matrix.one_mul]
  ext i j
  change (V * Matrix.diagonal α * Y) (some i) j = J i j
  rw [hleft]
  rfl

/-- The complete scalar source numerator is the characteristic
polynomial of the prescribed state block. Completeness follows from the
source basis and source equations, not from an assumed numerator identity. -/
theorem source_function_from_source_identity (α b : Option ι → ℂ)
    (Y : Matrix (Option ι) ι ℂ) (J : Matrix ι ι ℂ) (e : ι → ℂ)
    (hY : Function.Injective Y.mulVec) (hn : star b ⬝ᵥ b ≠ 0)
    (horth : star b ᵥ* Y = 0)
    (hsource : Matrix.diagonal α * Y = Y * J - Matrix.vecMulVec b (star e))
    (z : ℂ) (hsep : ∀ j, z ≠ α j) :
    (∑ j, (star (b j) * b j) / (z - α j)) =
      (star b ⬝ᵥ b) * J.charpoly.eval z / (∏ j : Option ι, (z - α j)) := by
  let B := InverseCofactor.sourceBasis b Y
  have horth' : ∀ x, star b ⬝ᵥ Y.mulVec x = 0 := by
    intro x
    rw [Matrix.dotProduct_mulVec, horth, zero_dotProduct]
  have hB : IsUnit B.det := (Matrix.isUnit_iff_isUnit_det B).mp
    (InverseCofactor.sourceBasis_isUnit b Y hY hn horth')
  have hBBinv : B * B⁻¹ = 1 := Matrix.mul_nonsing_inv B hB
  have hBinvB : B⁻¹ * B = 1 := Matrix.nonsing_inv_mul B hB
  apply InverseCofactor.source_function_from_similarity α (fun j => star (b j) * b j)
    (star b ⬝ᵥ b) B B⁻¹ J hBBinv hBinvB
  · exact sourceBasis_state_block α b Y J e B⁻¹ hBinvB hsource
  · exact InverseCofactor.sourceBasis_inverse_weights b Y B⁻¹ hBBinv horth
  · exact hsep

/-- The same complete numerator identity for an arbitrary finite source
index. The dimension condition supplies the reindexing, not an assumed
source-basis similarity. -/
theorem source_function_from_source_identity_finite
    {σ : Type*} [Fintype σ] [DecidableEq σ]
    (α b : σ → ℂ) (Y : Matrix σ ι ℂ) (J : Matrix ι ι ℂ) (e : ι → ℂ)
    (hY : Function.Injective Y.mulVec) (hn : star b ⬝ᵥ b ≠ 0)
    (horth : star b ᵥ* Y = 0)
    (hsource : Matrix.diagonal α * Y = Y * J - Matrix.vecMulVec b (star e))
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (z : ℂ) (hsep : ∀ j, z ≠ α j) :
    (∑ j, (star (b j) * b j) / (z - α j)) =
      (star b ⬝ᵥ b) * J.charpoly.eval z / (∏ j : σ, (z - α j)) := by
  classical
  let q : σ ≃ Option ι := Fintype.equivOfCardEq (by simpa using hdim)
  let α' : Option ι → ℂ := α ∘ q.symm
  let b' : Option ι → ℂ := b ∘ q.symm
  let Y' : Matrix (Option ι) ι ℂ := Y.submatrix q.symm id
  have hY' : Function.Injective Y'.mulVec := by
    intro x y hxy
    apply hY
    funext j
    have hh := congrFun hxy (q j)
    simpa [Y', Matrix.mulVec, dotProduct, Matrix.submatrix_apply] using hh
  have hmass : star b' ⬝ᵥ b' = star b ⬝ᵥ b := by
    exact q.symm.sum_comp (fun j => star (b j) * b j)
  have horth' : star b' ᵥ* Y' = 0 := by
    funext i
    have hh := q.symm.sum_comp (fun j => star (b j) * Y j i)
    change (∑ k : Option ι, star (b (q.symm k)) * Y (q.symm k) i) = 0
    rw [hh]
    exact congrFun horth i
  have hsource' : Matrix.diagonal α' * Y' =
      Y' * J - Matrix.vecMulVec b' (star e) := by
    ext i j
    have hh := congrArg (fun M : Matrix σ ι ℂ => M (q.symm i) j) hsource
    dsimp only at hh
    rw [Matrix.diagonal_mul] at hh ⊢
    simpa only [Matrix.sub_apply, Matrix.vecMulVec_apply, Pi.star_apply,
      Matrix.mul_apply, Y', α', b', Matrix.submatrix_apply, Function.comp_apply,
      id_eq] using hh
  have ht := source_function_from_source_identity α' b' Y' J e hY'
    (hmass ▸ hn) horth' hsource' z (fun j => hsep (q.symm j))
  rw [hmass] at ht
  change (∑ j : Option ι, (star (b (q.symm j)) * b (q.symm j)) /
      (z - α (q.symm j))) =
    (star b ⬝ᵥ b) * J.charpoly.eval z / (∏ j : Option ι, (z - α (q.symm j))) at ht
  rw [q.symm.sum_comp (fun j => (star (b j) * b j) / (z - α j)),
    q.symm.prod_comp (fun j => z - α j)] at ht
  exact ht

/-- The complete constructive sufficient direction of the inverse
realization theorem. In addition to the canonical rows and prescribed
Gram matrix, this theorem proves the full scalar numerator identity.
The source masses are the squares of the returned positive weights ω. -/
theorem normalizedCompletion_complete_realization
    (a : ℂ) (n : ℝ) (H J R : Matrix ι ι ℂ) (e : ι → ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hobs : Inverse.EigenObservable J.mulVecLin (Inverse.rowFunctional e))
    (hnorm : Inverse.normalization H R e = 1 - (n : ℂ)⁻¹)
    (hnormal : Inverse.normalizedCompletion a n H J R e *
        Inverse.weightedAdjoint (BlockMetric.metric n H) (Inverse.normalizedCompletion a n H J R e) =
      Inverse.weightedAdjoint (BlockMetric.metric n H) (Inverse.normalizedCompletion a n H J R e) *
        Inverse.normalizedCompletion a n H J R e)
    (hcontract : (BlockMetric.metric n H - (Inverse.normalizedCompletion a n H J R e)ᴴ *
      BlockMetric.metric n H * Inverse.normalizedCompletion a n H J R e).PosSemidef) :
    ∃ (α : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℂ)
      (ω : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℝ)
      (Y : Matrix (Fin (Module.finrank ℂ (Option ι → ℂ))) ι ℂ),
      Function.Injective α ∧ (∀ j, 0 < ω j ∧ ‖α j‖ ≤ 1) ∧
      (∑ j, ω j ^ 2) = n ∧ (∃ j, α j = a ∧ ω j = 1) ∧ Yᴴ * Y = H ∧
      (∀ j, IsUnit (α j • (1 : Matrix ι ι ℂ) - J) ∧
        (fun i => Y j i) = -(ω j : ℂ) •
          (star e ᵥ* (α j • (1 : Matrix ι ι ℂ) - J)⁻¹)) ∧
      ∀ (z : ℂ), (∀ j, z ≠ α j) →
        (∑ j, ((ω j : ℂ) ^ 2) / (z - α j)) =
          (n : ℂ) * J.charpoly.eval z /
            (∏ j : Fin (Module.finrank ℂ (Option ι → ℂ)), (z - α j)) := by
  obtain ⟨α, ω, Y, hinj, hpos, htotal, hselected, hGram, horth, hsource, hrows⟩ :=
    Inverse.normalizedCompletion_realization a n H J R e hn hH hobs hnorm hnormal hcontract
  refine ⟨α, ω, Y, hinj, hpos, htotal, hselected, hGram, hrows, ?_⟩
  intro z hz
  let b := fun j => (ω j : ℂ)
  have hY : Function.Injective Y.mulVec := by
    intro x y hxy
    apply Matrix.mulVec_injective_of_isUnit hH.isUnit
    rw [← hGram, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec, hxy]
  have hmass : star b ⬝ᵥ b = (n : ℂ) := by
    have hh := congrArg (fun t : ℝ => (t : ℂ)) htotal
    push_cast at hh
    simpa [b, dotProduct, pow_two] using hh
  have hn' : star b ⬝ᵥ b ≠ 0 := by
    rw [hmass]
    exact_mod_cast ne_of_gt hn
  have hdim : Fintype.card (Fin (Module.finrank ℂ (Option ι → ℂ))) = Fintype.card ι + 1 := by
    simp [Module.finrank_fintype_fun_eq_card]
  have hh := source_function_from_source_identity_finite α b Y J e hY hn' horth hsource hdim z hz
  rw [hmass] at hh
  simpa [b, pow_two] using hh

end PolynomialGeometry.InverseBasisBridge
