import PolynomialGeometry.RootLabelCoverage

/-! # Transport between polynomial coefficients and a covering chart

Continuity gives one direction. The reverse direction uses coverage in
every neighborhood of the base labels. This is stronger than existence of
an unspecified root enumeration, and does not assume analytic root labels.
-/
noncomputable section
open Filter
open scoped Topology

namespace PolynomialGeometry.ChartTransport

theorem map_nhds_of_local_coverage {E B : Type*} [TopologicalSpace E]
    [TopologicalSpace B] (Φ : E → B) (x₀ : E) (y₀ : B)
    (hΦ : ContinuousAt Φ x₀) (hbase : Φ x₀ = y₀)
    (hcover : ∀ U : Set E, IsOpen U → x₀ ∈ U →
      ∀ᶠ y in 𝓝 y₀, ∃ x ∈ U, Φ x = y) :
    Filter.map Φ (𝓝 x₀) = 𝓝 y₀ := by
  apply le_antisymm
  · simpa only [hbase] using hΦ.tendsto
  · rw [Filter.le_def]
    intro V hV
    have hpre : Φ ⁻¹' V ∈ 𝓝 x₀ := hV
    obtain ⟨U,hUV,hU,hx₀⟩ := mem_nhds_iff.mp hpre
    filter_upwards [hcover U hU hx₀] with y hy
    obtain ⟨x,hx,rfl⟩ := hy
    exact hUV hx

/-- The root-to-coefficient map is locally onto, even at collisions. -/
theorem rootCoefficients_map_nhds (n : ℕ) (α : Fin n → ℂ) :
    Filter.map (CriticalReconstruction.rootCoefficients n) (𝓝 α) =
      𝓝 (CriticalReconstruction.rootCoefficients n α) :=
  map_nhds_of_local_coverage _ _ _
    (CriticalReconstruction.rootCoefficients_analyticAt n α).continuousAt rfl
    (RootLabelCoverage.nearby_root_labels n α)

/-- Coverage in independent neighborhoods of the two labelled lists is
enough for full neighborhood coverage in their product. -/
theorem map_nhds_of_rectangular_coverage {E T B : Type*}
    [TopologicalSpace E] [TopologicalSpace T] [TopologicalSpace B]
    (Φ : E × T → B) (x₀ : E) (t₀ : T) (y₀ : B)
    (hΦ : ContinuousAt Φ (x₀,t₀)) (hbase : Φ (x₀,t₀) = y₀)
    (hcover : ∀ (U : Set E) (V : Set T), IsOpen U → x₀ ∈ U →
      IsOpen V → t₀ ∈ V → ∀ᶠ y in 𝓝 y₀,
        ∃ p : E × T, p.1 ∈ U ∧ p.2 ∈ V ∧ Φ p = y) :
    Filter.map Φ (𝓝 (x₀,t₀)) = 𝓝 y₀ := by
  apply map_nhds_of_local_coverage Φ (x₀,t₀) y₀ hΦ hbase
  intro W hW hw
  obtain ⟨U,V,hU,hx,hV,ht,hUV⟩ := mem_nhds_prod_iff'.mp (hW.mem_nhds hw)
  filter_upwards [hcover U V hU hx hV ht] with y hy
  obtain ⟨p,hpu,hpv,hp⟩ := hy
  exact ⟨p,hUV ⟨hpu,hpv⟩,hp⟩

/-- A constructed local right inverse supplies exact neighborhood transport
for a change of coordinates, without an additional openness assumption. -/
theorem map_nhds_of_local_inverse {E B : Type*} [TopologicalSpace E]
    [TopologicalSpace B] (Φ : E → B) (G : B → E) (x₀ : E) (y₀ : B)
    (hΦ : ContinuousAt Φ x₀) (hG : ContinuousAt G y₀)
    (hΦbase : Φ x₀ = y₀) (hGbase : G y₀ = x₀)
    (hInv : ∀ᶠ y in 𝓝 y₀, Φ (G y) = y) :
    Filter.map Φ (𝓝 x₀) = 𝓝 y₀ := by
  apply map_nhds_of_local_coverage Φ x₀ y₀ hΦ hΦbase
  intro U hU hx
  have hg := hG.eventually (by simpa only [hGbase] using hU.mem_nhds hx)
  filter_upwards [hg,hInv] with y hy hi
  exact ⟨G y,hy,hi⟩

/-- Exact transport of arbitrarily nearby feasible improvement through a
chart whose local coverage has been proved. -/
theorem nearby_improvement_transport {E B : Type*} [TopologicalSpace E]
    [TopologicalSpace B] (Φ : E → B) (x₀ : E) (y₀ : B)
    (hmap : Filter.map Φ (𝓝 x₀) = 𝓝 y₀)
    (f : B → ℝ) (g : E → ℝ) (feasible : B → Prop) (admissible : E → Prop)
    (hfeas : ∀ᶠ x in 𝓝 x₀, feasible (Φ x) ↔ admissible x)
    (hpos : ∀ᶠ x in 𝓝 x₀, 0 < f (Φ x) ↔ 0 < g x) :
    (∃ᶠ y in 𝓝 y₀, feasible y ∧ 0 < f y) ↔
      (∃ᶠ x in 𝓝 x₀, admissible x ∧ 0 < g x) := by
  rw [← hmap, Filter.frequently_map]
  apply Filter.frequently_congr
  filter_upwards [hfeas,hpos] with x hx hp
  exact and_congr hx hp

end PolynomialGeometry.ChartTransport
