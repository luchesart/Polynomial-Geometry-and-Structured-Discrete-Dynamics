import PolynomialGeometry.WeightedStationarity

/-! # Quantitative strict gains for the same reconstructed objective

Both replacement steps and their combined bound follow from original free
stationarity and actual positive radial derivatives of this objective.
-/
noncomputable section
open scoped Topology BigOperators
open Filter Complex
namespace PolynomialGeometry.WeightedBoundaryStrict
open PolynomialGeometry.WeightedStationarity PolynomialGeometry.FeasibleReduction
variable {ι κ : Type*} [Fintype ι] [Nonempty ι] [Fintype κ]

/-- The two replacement estimates, before and after setting all radial
coordinates to zero, with their uniform positive constants. -/
theorem weighted_boundary_strict [Nonempty κ] [DecidableEq κ]
    (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (G : ((ι → ℂ) × (κ → ℂ)) → ((ι → ℂ) × (κ → ℂ)))
    (q g w : ℂ) (β : κ → ℂ) (τ : ℝ)
    (hτ : 0 < τ) (hτ1 : τ < 1)
    (ha : AnalyticAt ℂ a ((fun _ => w),β))
    (hv : AnalyticAt ℂ v ((fun _ => w),β))
    (hq : q ≠ 0) (hg : g ≠ 0)
    (hqa : w-a ((fun _ => w),β) = q)
    (hgv : v ((fun _ => w),β)-a ((fun _ => w),β) = g)
    (hsa : ∀ (σ : Equiv.Perm ι) z, a (z ∘ σ,β) = a (z,β))
    (hsv : ∀ (σ : Equiv.Perm ι) z, v (z ∘ σ,β) = v (z,β))
    (hG : AnalyticAt ℂ G (0,β)) (hG0 : G (0,β) = ((fun _ => w),β))
    (hparam : ∀ᶠ p in 𝓝 ((0,β) : (ι → ℂ) × (κ → ℂ)), (G p).2 = p.2)
    (hfree : HasDerivAt (fun t : ℂ =>
      (τ : ℂ) * Complex.log (q⁻¹ * (t-a ((fun _ => t),β))) +
      (1-τ) * Complex.log (g⁻¹ * (v ((fun _ => t),β)-a ((fun _ => t),β)))) 0 w)
    (hr : ∀ j, 0 < fderiv ℝ
      (PolynomialGeometry.RealBoundaryChart.smoothObjective
        (fun p => weightedLog a v q g τ (G p)) β) 0 (0,(Pi.single j 1,0))) :
    let F := PolynomialGeometry.RealBoundaryChart.smoothObjective
      (fun p => weightedLog a v q g τ (G p)) β
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ p in 𝓝 (0 : PolynomialGeometry.RealBoundaryChart.Coordinates (ι := ι) (κ := κ)),
      (objective F τ p ≤ F (0,p.2) -
        (PolynomialGeometry.Variations.balancingConstant (ι := ι) τ / 2) * ‖p.1‖) ∧
      ((∀ j, p.2.1 j ≤ 0) → F (0,p.2) ≤ F (0,(0,p.2.2)) - c * ‖p.2.1‖) ∧
      ((∀ j, p.2.1 j ≤ 0) → objective F τ p ≤ F (0,(0,p.2.2)) -
        (PolynomialGeometry.Variations.balancingConstant (ι := ι) τ / 2) * ‖p.1‖ -
        c * ‖p.2.1‖) := by
  let F := PolynomialGeometry.RealBoundaryChart.smoothObjective
    (fun p => weightedLog a v q g τ (G p)) β
  have hK := weightedLog_analyticAt a v q g w β τ ha hv hq hg hqa hgv
  have hz := free_stationarity_full_differential a v q g w β τ ha hv hq hg hqa hgv hsa hsv hfree
  have htrans := parameter_inverse_stationarity (weightedLog a v q g τ) G (fun _ => w) β
    hK hG hG0 hparam hz
  have hH : AnalyticAt ℂ (fun p => weightedLog a v q g τ (G p)) (0,β) :=
    hK.comp_of_eq hG hG0
  have hF : HasStrictFDerivAt F (fderiv ℝ F 0) 0 :=
    (PolynomialGeometry.RealBoundaryChart.smoothObjective_analyticAt _ β hH).hasStrictFDerivAt
  have hx := PolynomialGeometry.RealBoundaryChart.balancing_derivative_zero _ β hH htrans
  let V := (ι → ℝ) × (κ → ℝ)
  let J : ((κ → ℝ) × V) →L[ℝ] ((ι → ℝ) × ((κ → ℝ) × V)) :=
    ContinuousLinearMap.inr ℝ (ι → ℝ) ((κ → ℝ) × V)
  have hslice : HasStrictFDerivAt (fun p : (κ → ℝ) × V => F (0,p))
      ((fderiv ℝ F 0).comp J) 0 := hF.comp 0 J.hasStrictFDerivAt
  obtain ⟨c,hc,hR⟩ := local_uniform_radial_improvement hslice hr
  have hB := PolynomialGeometry.Variations.local_uniform_balancing hτ hτ1 hF hx
  have hproj : Tendsto (fun p : (ι → ℝ) × ((κ → ℝ) × V) => p.2) (𝓝 0) (𝓝 0) :=
    continuous_snd.continuousAt.tendsto
  refine ⟨c,hc,?_⟩
  filter_upwards [hB,hproj.eventually hR] with p hbp hrp
  have hbalance : objective F τ p ≤ F (0,p.2) -
      (PolynomialGeometry.Variations.balancingConstant (ι := ι) τ / 2) * ‖p.1‖ := by
    dsimp [objective, PolynomialGeometry.Variations.penalty]
    linarith
  refine ⟨hbalance,hrp,?_⟩
  intro hp
  have hrad := hrp hp
  linarith

end PolynomialGeometry.WeightedBoundaryStrict
