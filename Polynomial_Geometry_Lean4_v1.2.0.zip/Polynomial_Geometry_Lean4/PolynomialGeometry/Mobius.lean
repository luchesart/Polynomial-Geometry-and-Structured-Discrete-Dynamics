import PolynomialGeometry.Stability
import PolynomialGeometry.Dynamics

noncomputable section
open scoped Topology
open Matrix Filter Complex

namespace PolynomialGeometry.Mobius
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- A characteristic root supplies an actual nonzero eigenvector. -/
theorem eigenvector_of_root (A : Matrix ι ι ℂ) (z : ℂ)
    (hz : A.charpoly.IsRoot z) :
    ∃ x : ι → ℂ, x ≠ 0 ∧ A.mulVec x = z • x := by
  have hnot : ¬ IsUnit (z • (1 : Matrix ι ι ℂ) - A) := by
    simpa only [spectrum.mem_iff, Algebra.algebraMap_eq_smul_one] using
      (Matrix.mem_spectrum_iff_isRoot_charpoly.mpr hz)
  obtain ⟨x, y, hxy, hneq⟩ := Function.not_injective_iff.mp
    (Matrix.mulVec_injective_iff_isUnit.not.mpr hnot)
  refine ⟨x-y, sub_ne_zero.mpr hneq, ?_⟩
  have he : (z • (1 : Matrix ι ι ℂ) - A).mulVec (x-y) = 0 := by
    rw [Matrix.mulVec_sub, hxy, sub_self]
  have hh : z • (x-y) - A.mulVec (x-y) = 0 := by
    simpa only [Matrix.sub_mulVec, Matrix.smul_mulVec, Matrix.one_mulVec] using he
  exact (sub_eq_zero.mp hh).symm

/-- A nonzero eigenvector gives the corresponding characteristic root. -/
theorem root_of_eigenvector (A : Matrix ι ι ℂ) (z : ℂ) (x : ι → ℂ)
    (hx : x ≠ 0) (he : A.mulVec x = z • x) : A.charpoly.IsRoot z := by
  apply Matrix.mem_spectrum_iff_isRoot_charpoly.mp
  rw [spectrum.mem_iff, Algebra.algebraMap_eq_smul_one]
  intro hu
  have hz : (z • (1 : Matrix ι ι ℂ) - A).mulVec x = 0 := by
    simp only [Matrix.sub_mulVec, Matrix.smul_mulVec, Matrix.one_mulVec, he, sub_self]
  exact hx (Matrix.mulVec_injective_iff_isUnit.mpr hu (by simpa using hz))

/-- The exact linear fractional relation transports strict spectral inclusion.
It is an identity of the actual matrices, not a supplied spectral-mapping hypothesis. -/
theorem root_norm_lt_one (a : ℝ) (A T : Matrix ι ι ℂ)
    (ha : a ^ 2 < 1)
    (hA : ∀ z : ℂ, A.charpoly.IsRoot z → ‖z‖ < 1)
    (hrel : (1 - (a : ℂ) • A) * T = (a : ℂ) • 1 - A)
    (τ : ℂ) (hτ : T.charpoly.IsRoot τ) : ‖τ‖ < 1 := by
  obtain ⟨x, hx, he⟩ := eigenvector_of_root T τ hτ
  have hv := congrArg (fun M : Matrix ι ι ℂ => M.mulVec x) hrel
  simp only [← Matrix.mulVec_mulVec, he, Matrix.mulVec_smul, Matrix.sub_mulVec,
    Matrix.one_mulVec, Matrix.smul_mulVec] at hv
  have heq : (1 - (a : ℂ) * τ) • A.mulVec x = ((a : ℂ) - τ) • x := by
    ext i
    have hi := congrFun hv i
    simp only [Pi.smul_apply, Pi.sub_apply, smul_eq_mul] at hi ⊢
    linear_combination hi
  have hd : 1 - (a : ℂ) * τ ≠ 0 := by
    intro hz
    rw [hz, zero_smul] at heq
    have hnum : (a : ℂ) - τ = 0 := (smul_eq_zero.mp heq.symm).resolve_right hx
    have ht : τ = (a : ℂ) := (sub_eq_zero.mp hnum).symm
    rw [ht] at hz
    have hreal : 1 - a * a = 0 := by exact_mod_cast hz
    nlinarith
  let w : ℂ := ((a : ℂ) - τ) / (1 - (a : ℂ) * τ)
  have hw : A.mulVec x = w • x := by
    calc
      A.mulVec x = (1 - (a : ℂ) * τ)⁻¹ • ((1 - (a : ℂ) * τ) • A.mulVec x) := by
        rw [smul_smul, inv_mul_cancel₀ hd, one_smul]
      _ = w • x := by
        rw [heq, smul_smul]
        congr 1
        dsimp [w]
        ring
  have hwnorm := hA w (root_of_eigenvector A w x hx hw)
  have hwsq : Complex.normSq w < 1 := by
    rw [Complex.normSq_eq_norm_sq]
    nlinarith [norm_nonneg w]
  have htw : Dynamics.diskMap a w = τ := by
    unfold Dynamics.diskMap
    apply (div_eq_iff (Dynamics.diskMap_denominator_ne_zero a w ha hwsq)).mpr
    dsimp [w]
    field_simp [hd]
    ring
  have hs := Dynamics.diskMap_normSq_lt_one a w ha hwsq
  rw [htw, Complex.normSq_eq_norm_sq] at hs
  nlinarith [norm_nonneg τ]

end PolynomialGeometry.Mobius
