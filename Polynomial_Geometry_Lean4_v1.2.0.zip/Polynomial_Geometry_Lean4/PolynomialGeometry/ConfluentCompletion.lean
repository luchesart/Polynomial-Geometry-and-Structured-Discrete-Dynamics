import PolynomialGeometry.Confluent
import PolynomialGeometry.SourceStability
import PolynomialGeometry.CompressionDet
import PolynomialGeometry.SteinSeries

/-!
# Complete confluent realization: stability and the infinite Gramian

The roots, Gram matrix, source equations and projection in this module all
refer to the concrete Cauchy coordinates. Neither strict stability nor
convergence of the Stein series is an input hypothesis.
-/

noncomputable section
open scoped BigOperators Matrix ComplexOrder Matrix.Norms.Frobenius
open Matrix

namespace PolynomialGeometry.Confluent

variable {σ s : Type*} [Fintype σ] [DecidableEq σ]
  [Fintype s] [DecidableEq s] [Nonempty s]

/-- The actual confluent source equation transfers each characteristic root
to a nonzero source state. Positivity and source separation then force it
strictly inside the unit disk. -/
theorem cauchy_spectralRadius_lt_one (α b ν : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hα : Function.Injective α) (hb : ∀ j, b j ≠ 0) (hdisk : ∀ j, ‖α j‖ ≤ 1)
    (hsep : ∀ i j, w i ≠ α j) (hw : Function.Injective w)
    (hweights : ∀ j, star (b j) * b j = ν j) (hn : (∑ j, ν j) ≠ 0)
    (hroot : ∀ i, (Polynomial.X - Polynomial.C (w i)) ^ (r i + 1) ∣
      Source.numerator Finset.univ α ν) :
    spectralRadius ℂ (jordanMatrix w r) < 1 := by
  apply CompressionDet.spectralRadius_lt_one_of_charpoly_roots
  intro z hz
  obtain ⟨x, hx0, hx⟩ := Mobius.eigenvector_of_root (jordanMatrix w r) z hz
  have hY := cauchy_injective_of_numerator_dvd α b ν w r hsep hw hweights hn hroot
  have hy : (cauchyMatrix α b w r).mulVec x ≠ 0 := by
    intro hzero
    apply hx0
    apply hY
    simpa using hzero
  apply SourceStability.source_eigenvector_norm_lt_one α b
    ((cauchyMatrix α b w r).mulVec x) z (firstOutput r x) hα hb hdisk hy
  · intro j
    have hc := congrFun (cauchy_source_identity α b w r hsep x) j
    rw [hx, Matrix.mulVec_smul] at hc
    simpa only [Matrix.mulVec_diagonal, Pi.sub_apply, Pi.smul_apply, smul_eq_mul,
      mul_comm (firstOutput r x)] using hc
  · exact cauchy_orthogonal_of_numerator_dvd α b ν w r hsep hweights hn hroot x

omit [Nonempty s] in
/-- Sources in the closed disk have a nonnegative diagonal energy loss. -/
theorem diagonal_source_loss_posSemidef (α : s → ℂ) (hdisk : ∀ j, ‖α j‖ ≤ 1) :
    (1 - (Matrix.diagonal α)ᴴ * Matrix.diagonal α).PosSemidef := by
  have heq : 1 - (Matrix.diagonal α)ᴴ * Matrix.diagonal α =
      Matrix.diagonal (fun j => ((1 - Complex.normSq (α j) : ℝ) : ℂ)) := by
    rw [Matrix.diagonal_conjTranspose, Matrix.diagonal_mul_diagonal,
      ← Matrix.diagonal_one, Matrix.diagonal_sub]
    congr 1
    funext j
    simp only [Pi.star_apply]
    change 1 - (starRingEnd ℂ) (α j) * α j = ((1 - Complex.normSq (α j) : ℝ) : ℂ)
    rw [← Complex.normSq_eq_conj_mul_self]
    push_cast
    rfl
  rw [heq]
  apply Matrix.posSemidef_diagonal_iff.mpr
  intro j
  apply Complex.nonneg_iff.mpr
  constructor
  · change 0 ≤ 1 - Complex.normSq (α j)
    rw [Complex.normSq_eq_norm_sq]
    nlinarith [hdisk j, norm_nonneg (α j)]
  · rfl

omit [Nonempty s] [DecidableEq σ] in
theorem cauchy_loss_posSemidef (α b : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hdisk : ∀ j, ‖α j‖ ≤ 1) :
    (sourceLoss (Matrix.diagonal α) (cauchyMatrix α b w r)).PosSemidef :=
  sourceLoss_posSemidef _ _ (diagonal_source_loss_posSemidef α hdisk)

/-- The actual Cauchy Gramian is the absolutely convergent Stein series and
is its unique matrix solution, with strict stability proved from sources. -/
theorem cauchy_stein_series_and_unique (α b ν : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hα : Function.Injective α) (hb : ∀ j, b j ≠ 0) (hdisk : ∀ j, ‖α j‖ ≤ 1)
    (hsep : ∀ i j, w i ≠ α j) (hw : Function.Injective w)
    (hweights : ∀ j, star (b j) * b j = ν j) (hn : (∑ j, ν j) ≠ 0)
    (hroot : ∀ i, (Polynomial.X - Polynomial.C (w i)) ^ (r i + 1) ∣
      Source.numerator Finset.univ α ν) :
    let Y := cauchyMatrix α b w r
    let J := jordanMatrix w r
    let D := sourceLoss (Matrix.diagonal α) Y +
      (∑ j, ν j) • (columnMatrix (outputVector r) * (columnMatrix (outputVector r))ᴴ)
    Summable (fun m : ℕ => ‖(Jᴴ)^m * D * J^m‖) ∧
      (∑' m : ℕ, (Jᴴ)^m * D * J^m) = gram Y ∧
        ∀ H, H - Jᴴ * H * J = D → H = gram Y := by
  dsimp only
  have hJ := cauchy_spectralRadius_lt_one α b ν w r hα hb hdisk hsep hw hweights hn hroot
  exact ⟨SteinSeries.summable_norm_stein _ _ hJ,
    SteinSeries.series_and_unique _ _ _ hJ
      (cauchy_stein_identity α b ν w r hsep hweights hn hroot)⟩

omit [Nonempty s] [Fintype σ] [DecidableEq σ] in
/-- A critical root cannot equal a distinct source carrying nonzero mass. -/
theorem cauchy_separated_of_numerator_dvd (α ν : s → ℂ) (w : σ → ℂ) (r : σ → ℕ)
    (hα : Function.Injective α) (hν : ∀ j, ν j ≠ 0) (hn : (∑ j, ν j) ≠ 0)
    (hroot : ∀ i, (Polynomial.X - Polynomial.C (w i)) ^ (r i + 1) ∣
      Source.numerator Finset.univ α ν) :
    ∀ i j, w i ≠ α j := by
  intro i j heq
  have hz : (Source.numerator Finset.univ α ν).IsRoot (w i) :=
    Polynomial.dvd_iff_isRoot.mp
      ((dvd_pow_self _ (Nat.succ_ne_zero (r i))).trans (hroot i))
  apply Source.numerator_ne_zero_at_source Finset.univ α ν (fun _ _ _ _ h => hα h)
    hn (Finset.mem_univ j) (hν j)
  simpa only [heq] using hz

noncomputable def positiveSourceVector (ν : s → ℝ) : s → ℂ := fun j => (Real.sqrt (ν j) : ℂ)

omit [Fintype s] [DecidableEq s] [Nonempty s] in
theorem positiveSourceVector_weight (ν : s → ℝ) (hν : ∀ j, 0 < ν j) (j : s) :
    star (positiveSourceVector ν j) * positiveSourceVector ν j = (ν j : ℂ) := by
  simp only [positiveSourceVector, Complex.star_def, Complex.conj_ofReal, ← Complex.ofReal_mul]
  exact congrArg (fun a : ℝ => (a : ℂ)) (Real.mul_self_sqrt (hν j).le)

omit [Fintype s] [DecidableEq s] [Nonempty s] in
theorem positiveSourceVector_ne_zero (ν : s → ℝ) (hν : ∀ j, 0 < ν j) (j : s) :
    positiveSourceVector ν j ≠ 0 := by
  change (Real.sqrt (ν j) : ℂ) ≠ 0
  exact_mod_cast (Real.sqrt_pos.mpr (hν j)).ne'

/-- The complete positive-mass realization of Theorem 3.1, in one checked
statement. Multiplicities and the total number of columns are the input
data; orthogonality, rank, the Gram projection, strict stability, the exact
Stein identity, absolute convergence and uniqueness are all conclusions. -/
theorem complete_positive_source_realization (α : s → ℂ) (ν : s → ℝ)
    (w : σ → ℂ) (r : σ → ℕ)
    (hα : Function.Injective α) (hν : ∀ j, 0 < ν j) (hdisk : ∀ j, ‖α j‖ ≤ 1)
    (hw : Function.Injective w)
    (hroot : ∀ i, (Polynomial.X - Polynomial.C (w i)) ^ (r i + 1) ∣
      Source.numerator Finset.univ α (fun j => (ν j : ℂ)))
    (hdim : Fintype.card s = Fintype.card (ChainIndex r) + 1) :
    let b := positiveSourceVector ν
    let Y := cauchyMatrix α b w r
    let J := jordanMatrix w r
    let H := gram Y
    let L := sourceLoss (Matrix.diagonal α) Y
    let E := columnMatrix (outputVector r)
    let n : ℂ := ∑ j, (ν j : ℂ)
    H.PosDef ∧ L.PosSemidef ∧ Function.Injective Y.mulVec ∧
      (columnMatrix b)ᴴ * Y = 0 ∧
      Matrix.diagonal α * Y = Y * J - columnMatrix b * Eᴴ ∧
      Y * H⁻¹ * Yᴴ = 1 - n⁻¹ • (columnMatrix b * (columnMatrix b)ᴴ) ∧
      spectralRadius ℂ J < 1 ∧
      H - Jᴴ * H * J = L + n • (E * Eᴴ) ∧
      Summable (fun m : ℕ => ‖(Jᴴ)^m * (L + n • (E * Eᴴ)) * J^m‖) ∧
      (∑' m : ℕ, (Jᴴ)^m * (L + n • (E * Eᴴ)) * J^m) = H ∧
      ∀ K, K - Jᴴ * K * J = L + n • (E * Eᴴ) → K = H := by
  let b := positiveSourceVector ν
  let nc : s → ℂ := fun j => (ν j : ℂ)
  have hnc : ∀ j, nc j ≠ 0 := by
    intro j
    change (ν j : ℂ) ≠ 0
    exact_mod_cast (hν j).ne'
  have hn : (∑ j, nc j) ≠ 0 := by
    have hs : 0 < ∑ j, ν j := Finset.sum_pos (fun j _ => hν j) Finset.univ_nonempty
    change (∑ j, (ν j : ℂ)) ≠ 0
    exact_mod_cast hs.ne'
  have hweights : ∀ j, star (b j) * b j = nc j := positiveSourceVector_weight ν hν
  have hb : ∀ j, b j ≠ 0 := positiveSourceVector_ne_zero ν hν
  have hsep := cauchy_separated_of_numerator_dvd α nc w r hα hnc hn hroot
  have horth : (columnMatrix b)ᴴ * cauchyMatrix α b w r = 0 := by
    apply matrix_ext_mulVec
    intro x
    simp only [← Matrix.mulVec_mulVec, columnMatrix_adjoint_mulVec, Matrix.zero_mulVec]
    funext u
    exact cauchy_orthogonal_of_numerator_dvd α b nc w r hsep hweights hn hroot x
  exact ⟨cauchy_gram_posDef α b nc w r hsep hw hweights hn hroot,
    cauchy_loss_posSemidef α b w r hdisk,
    cauchy_injective_of_numerator_dvd α b nc w r hsep hw hweights hn hroot,
    horth, cauchy_source_matrix_identity α b w r hsep,
    cauchy_projection α b nc w r hsep hw hweights hn hroot hdim,
    cauchy_spectralRadius_lt_one α b nc w r hα hb hdisk hsep hw hweights hn hroot,
    cauchy_stein_identity α b nc w r hsep hweights hn hroot,
    cauchy_stein_series_and_unique α b nc w r hα hb hdisk hsep hw hweights hn hroot⟩

end PolynomialGeometry.Confluent
