import PolynomialGeometry.CriticalReconstruction

/-! # Root labels are unique up to permutation, including repeated roots -/

noncomputable section
open Polynomial

namespace PolynomialGeometry.RootPermutation

open CriticalReconstruction

theorem rootPolynomial_roots (n : ℕ) (α : Fin n → ℂ) :
    (rootPolynomial n α).roots = Finset.univ.val.map α := by
  rw [rootPolynomial, Polynomial.roots_prod _ _ (rootPolynomial_monic n α).ne_zero]
  simp only [Polynomial.roots_X_sub_C, Multiset.bind_singleton]

/-- Equality of the root polynomials determines the multiplicity of
every root, hence the size of every label fiber. -/
theorem rootPolynomial_fiber_card (n : ℕ) (α β : Fin n → ℂ)
    (h : rootPolynomial n α = rootPolynomial n β) (z : ℂ) :
    Fintype.card {i // α i = z} = Fintype.card {i // β i = z} := by
  classical
  have hh := congrArg (fun P : ℂ[X] => P.roots.count z) h
  dsimp only at hh
  rw [rootPolynomial_roots, rootPolynomial_roots] at hh
  simpa only [Multiset.count_map, ← Finset.filter_val, ← Finset.card_def,
    eq_comm (a := z), Fintype.card_subtype] using hh

/-- The full finite fiber classification. No injectivity or simple-root
assumption is needed, so colliding root labels are included. -/
theorem rootPolynomial_eq_iff_perm (n : ℕ) (α β : Fin n → ℂ) :
    rootPolynomial n α = rootPolynomial n β ↔
      ∃ σ : Equiv.Perm (Fin n), β ∘ σ = α := by
  classical
  constructor
  · intro h
    let e (z : ℂ) : {i // α i = z} ≃ {i // β i = z} :=
      Fintype.equivOfCardEq (rootPolynomial_fiber_card n α β h z)
    refine ⟨Equiv.ofFiberEquiv e, ?_⟩
    funext i
    exact Equiv.ofFiberEquiv_map e i
  · rintro ⟨σ, rfl⟩
    exact rootPolynomial_comp_perm n β σ

/-- The same exact fiber classification in coefficient coordinates. -/
theorem rootCoefficients_eq_iff_perm (n : ℕ) (α β : Fin n → ℂ) :
    rootCoefficients n α = rootCoefficients n β ↔
      ∃ σ : Equiv.Perm (Fin n), β ∘ σ = α := by
  rw [← rootPolynomial_eq_iff_perm]
  constructor
  · intro h
    have hh := congrArg (Factorization.monicPolynomial n) h
    simpa only [monicPolynomial_rootCoefficients] using hh
  · intro h
    funext i
    exact congrArg (fun P : ℂ[X] => P.coeff i) h

end PolynomialGeometry.RootPermutation
