import Mathlib.Analysis.Complex.CauchyIntegral
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.Analysis.Calculus.Deriv.Polynomial
import Mathlib.Analysis.SpecialFunctions.Complex.LogDeriv
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-! # Counting polynomial zeros on a disk under a certified boundary perturbation

The logarithmic derivative of a linear factor has normalized circle integral one
inside the disk and zero outside. For a strict Rouché perturbation the ratio of
the two polynomials stays in the disk about one of radius one on the contour;
the principal logarithm is then a primitive of the difference of logarithmic
derivatives along that contour. -/

noncomputable section
open Polynomial Complex Metric Set Real
open scoped Polynomial

namespace PolynomialGeometry.NoisyContour

/-- Positively oriented contour integral divided by 2πi. -/
def contour (c : ℂ) (r : ℝ) (f : ℂ → ℂ) : ℂ :=
  (2 * Real.pi * I : ℂ)⁻¹ * circleIntegral f c r

/-- Algebraic roots in the open disk, counted with their multiplicities. -/
def diskCount (P : ℂ[X]) (c : ℂ) (r : ℝ) : ℕ :=
  (P.roots.filter (fun z => dist z c < r)).card

def logarithmic (P : ℂ[X]) (z : ℂ) : ℂ := P.derivative.eval z / P.eval z

theorem contour_congr {f g : ℂ → ℂ} {c : ℂ} {r : ℝ} (hr : 0 ≤ r)
    (h : Set.EqOn f g (sphere c r)) : contour c r f = contour c r g := by
  unfold contour
  rw [circleIntegral.integral_congr hr h]

theorem contour_sub {f g : ℂ → ℂ} {c : ℂ} {r : ℝ}
    (hf : CircleIntegrable f c r) (hg : CircleIntegrable g c r) :
    contour c r (fun z => f z - g z) = contour c r f - contour c r g := by
  simp only [contour, circleIntegral.integral_sub hf hg, mul_sub]

theorem contour_gap {f g : ℂ → ℂ} {c : ℂ} {r C : ℝ} (hr : 0 ≤ r)
    (hf : CircleIntegrable f c r) (hg : CircleIntegrable g c r)
    (h : ∀ z ∈ sphere c r, ‖f z - g z‖ ≤ C) :
    ‖contour c r f - contour c r g‖ ≤ r * C := by
  rw [← contour_sub hf hg]
  exact circleIntegral.norm_two_pi_i_inv_smul_integral_le_of_norm_le_const hr h

private theorem reciprocal_contour {a c : ℂ} {r : ℝ} (hr : 0 ≤ r)
    (ha : a ∉ sphere c r) : contour c r (fun z => (z-a)⁻¹) =
      if dist a c < r then 1 else 0 := by
  split_ifs with hi
  · rw [contour, circleIntegral.integral_sub_inv_of_mem_ball (show a ∈ ball c r from hi)]
    exact inv_mul_cancel₀ (by simp [Real.pi_ne_zero])
  · have hout : a ∉ closedBall c r := fun h => ha (le_antisymm h (le_of_not_gt hi))
    have hn {z : ℂ} (hz : z ∈ closedBall c r) : z - a ≠ 0 :=
      sub_ne_zero.mpr (fun h => hout (h ▸ hz))
    have hh : (∮ z in C(c,r), (z-a)⁻¹) = 0 :=
      Complex.circleIntegral_eq_zero_of_differentiable_on_off_countable hr
        (s := ∅) Set.countable_empty ((continuous_id.sub continuous_const).continuousOn.inv₀
          (fun _ h => hn h)) (fun z hz =>
            (differentiableAt_id.sub_const a).inv (hn (ball_subset_closedBall hz.1)))
    simp [contour, hh]

private theorem integrable_logarithmic (P : ℂ[X]) {c : ℂ} {r : ℝ} (hr : 0 ≤ r)
    (h : ∀ z ∈ sphere c r, P.eval z ≠ 0) : CircleIntegrable (logarithmic P) c r :=
  (P.derivative.continuous.continuousOn.div P.continuous.continuousOn h).circleIntegrable hr

private def rootProduct (s : Multiset ℂ) : ℂ[X] :=
  (s.map (fun a => X - C a)).prod

private theorem rootProduct_count (s : Multiset ℂ) {c : ℂ} {r : ℝ} (hr : 0 ≤ r)
    (h : ∀ z ∈ sphere c r, (rootProduct s).eval z ≠ 0) :
    contour c r (logarithmic (rootProduct s)) =
      ((s.filter (fun z => dist z c < r)).card : ℂ) := by
  classical
  induction s using Multiset.induction_on with
  | empty => simp [rootProduct, logarithmic, contour, circleIntegral]
  | cons a s ih =>
    let P := rootProduct s
    have heq : rootProduct (a ::ₘ s) = (X - C a) * P := by simp [rootProduct, P]
    have hfac (z) (hz : z ∈ sphere c r) : (z-a) * P.eval z ≠ 0 := by
      simpa [heq] using h z hz
    have ha (z) (hz : z ∈ sphere c r) : z-a ≠ 0 := left_ne_zero_of_mul (hfac z hz)
    have hp (z) (hz : z ∈ sphere c r) : P.eval z ≠ 0 := right_ne_zero_of_mul (hfac z hz)
    have hdiff := contour_congr (c := c) hr (f := logarithmic (rootProduct (a ::ₘ s)))
        (g := fun z => (z-a)⁻¹ + logarithmic P z) (by
      intro z hz
      simp only [heq, logarithmic, derivative_mul, derivative_sub, derivative_X, derivative_C,
        sub_zero, eval_add, eval_mul, eval_sub, eval_X, eval_C, one_mul]
      field_simp [ha z hz, hp z hz])
    have hi : CircleIntegrable (fun z : ℂ => (z-a)⁻¹) c r :=
      ((continuous_id.sub continuous_const).continuousOn.inv₀ ha).circleIntegrable hr
    have ho : a ∉ sphere c r := fun hz => ha a hz (sub_self a)
    rw [hdiff]
    change (2 * Real.pi * I : ℂ)⁻¹ * _ = _
    rw [circleIntegral.integral_add hi (integrable_logarithmic P hr hp), mul_add]
    change contour c r (fun z => (z-a)⁻¹) + contour c r (logarithmic P) = _
    rw [reciprocal_contour hr ho, ih hp]
    by_cases hin : dist a c < r <;> simp [hin, add_comm]

/-- Argument principle for arbitrary monic complex polynomials on a circle
avoiding their zeros. No ordering of the multiset of roots is required. -/
theorem contour_logarithmic (P : ℂ[X]) (hP : P.Monic) {c : ℂ} {r : ℝ}
    (hr : 0 ≤ r) (h : ∀ z ∈ sphere c r, P.eval z ≠ 0) :
    contour c r (logarithmic P) = (diskCount P c r : ℂ) := by
  have he : P = rootProduct P.roots :=
    eq_prod_roots_of_monic_of_splits_id hP (IsAlgClosed.splits P)
  exact (congrArg (fun Q => contour c r (logarithmic Q)) he).trans
    (rootProduct_count P.roots hr (by rwa [← he]))

theorem boundary_nonzero {P Q : ℂ[X]} {c : ℂ} {r : ℝ}
    (h : ∀ z ∈ sphere c r, ‖P.eval z - Q.eval z‖ < ‖Q.eval z‖)
    (z : ℂ) (hz : z ∈ sphere c r) : P.eval z ≠ 0 ∧ Q.eval z ≠ 0 := by
  have hpos := h z hz
  constructor
  · intro hh
    simp [hh] at hpos
  · exact norm_pos_iff.mp ((norm_nonneg _).trans_lt hpos)

/-- Strict polynomial Rouché comparison on a circle, counted with multiplicities. -/
theorem rouche (P Q : ℂ[X]) (hP : P.Monic) (hQ : Q.Monic) (c : ℂ) {r : ℝ}
    (hr : 0 ≤ r) (h : ∀ z ∈ sphere c r, ‖P.eval z - Q.eval z‖ < ‖Q.eval z‖) :
    diskCount P c r = diskCount Q c r := by
  have hn := boundary_nonzero h
  have hz : (∮ z in C(c,r), logarithmic P z - logarithmic Q z) = 0 := by
    apply circleIntegral.integral_eq_zero_of_hasDerivWithinAt (f := fun z =>
      Complex.log (P.eval z / Q.eval z)) hr
    intro z hzs
    obtain ⟨hp,hq⟩ := hn z hzs
    have hratio : P.eval z / Q.eval z ∈ Complex.slitPlane := by
      apply Complex.ball_one_subset_slitPlane
      rw [mem_ball, dist_eq_norm, div_sub_one hq, norm_div, div_lt_one (norm_pos_iff.mpr hq)]
      exact h z hzs
    have hd := ((P.hasDerivAt z).div (Q.hasDerivAt z) hq).clog hratio
    simp only [Pi.div_apply] at hd
    convert hd.hasDerivWithinAt using 1
    unfold logarithmic
    field_simp [hp,hq]
  have he : contour c r (logarithmic P) = contour c r (logarithmic Q) := by
    apply sub_eq_zero.mp
    rw [← contour_sub (integrable_logarithmic P hr (fun z hzs => (hn z hzs).1))
        (integrable_logarithmic Q hr (fun z hzs => (hn z hzs).2))]
    simp [contour, hz]
  rw [contour_logarithmic P hP hr (fun z hzs => (hn z hzs).1),
      contour_logarithmic Q hQ hr (fun z hzs => (hn z hzs).2)] at he
  exact_mod_cast he

end PolynomialGeometry.NoisyContour
