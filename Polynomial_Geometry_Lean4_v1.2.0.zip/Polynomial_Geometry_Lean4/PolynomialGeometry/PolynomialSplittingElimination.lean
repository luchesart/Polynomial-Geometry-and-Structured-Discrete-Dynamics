import PolynomialGeometry.IndependentBlockConsequences
import PolynomialGeometry.ReducedObjectiveSymmetry

/-!
# Splitting the copy angles of the reduced polynomial objective

A partition on each side of the balanced chart specifies selected groups of
critical copies and selected groups of boundary copies. The other coordinates
are individually free. Every selected block contributes a freely varying mean
and a zero-sum deviation. The equivalences below only relabel the copies.
-/

noncomputable section
open Filter Polynomial
open scoped Topology
namespace PolynomialGeometry.PolynomialSplittingElimination
open IndependentCenteredBlocks SymmetricElimination

abbrev Copies {J : Type} (m : J → ℕ) (j : J) := Fin (m j + 1)

/-- Coordinates on one side of the chart: unrestricted copies or a labelled
copy in a selected group. -/
abbrev Side {J : Type} (m : J → ℕ) (K L : Type) (tag : L → J) :=
  K ⊕ ((j : L) × Copies m (tag j))

/-- Extend independent permutations to the original labels, fixing every free
copy. This one formula applies to both the critical and boundary angles. -/
def sidePermutation {J K L I : Type} (m : J → ℕ) (tag : L → J)
    (e : I ≃ Side m K L tag) (g : Group (Copies m)) : Equiv.Perm I :=
  (e.trans ((Equiv.refl K).sumCongr (Equiv.sigmaCongrRight (fun j => g (tag j))))).trans e.symm

/-- Add the mean to the centered deviation at a selected copy. -/
def sideValues {J K L I : Type} [Fintype J] (m : J → ℕ) (tag : L → J)
    (e : I ≃ Side m K L tag) (free : K → ℝ) (mean : J → ℝ)
    (d : Blocks (Copies m)) (i : I) : ℝ :=
  match e i with
  | .inl k => free k
  | .inr ⟨j,k⟩ => mean (tag j) + (d (tag j)).1 k

theorem sideValues_action {J K L I : Type} [Fintype J] (m : J → ℕ)
    (tag : L → J) (e : I ≃ Side m K L tag) (free : K → ℝ)
    (mean : J → ℝ) (g : Group (Copies m)) (d : Blocks (Copies m)) :
    sideValues m tag e free mean (action (Copies m) g d) =
      sideValues m tag e free mean d ∘ sidePermutation m tag e g := by
  funext i
  rcases h : e i with x | ⟨j,k⟩
  · simp [sideValues, sidePermutation, Function.comp_def, h]
  · simp [sideValues, sidePermutation, Function.comp_def, h, Equiv.sigmaCongrRight]

theorem sidePermutation_fixes_labels {J K L I : Type} (m : J → ℕ)
    (tag : L → J) (e : I ≃ Side m K L tag) (β : I → ℂ)
    (hβ : ∀ j k, β (e.symm (.inr ⟨j,k⟩)) = β (e.symm (.inr ⟨j,0⟩)))
    (g : Group (Copies m)) : β ∘ sidePermutation m tag e g = β := by
  funext i
  rcases h : e i with x | ⟨j,k⟩
  · have hi := congrArg e.symm h
    simp only [Equiv.symm_apply_apply] at hi
    simp [sidePermutation, Function.comp_def, h]
    exact congrArg β hi.symm
  · have hi := congrArg e.symm h
    simp only [Equiv.symm_apply_apply] at hi
    rw [hi]
    simpa [sidePermutation, Function.comp_def, Equiv.sigmaCongrRight] using
      (hβ j (g (tag j) k)).trans (hβ j k).symm

variable {nc nb kc kb r s : ℕ}
abbrev Index (nc nb : ℕ) := Fin nc ⊕ Fin nb
abbrev Free (nc nb kc kb : ℕ) := (Index nc nb → ℝ) × (Fin kc → ℝ) × (Fin kb → ℝ)
abbrev CriticalSide (m : Index nc nb → ℕ) (kc : ℕ) :=
  Side m (Fin kc) (Fin nc) Sum.inl
abbrev BoundarySide (m : Index nc nb → ℕ) (kb : ℕ) :=
  Side m (Fin kb) (Fin nb) Sum.inr

variable (m : Index nc nb → ℕ)
    (ec : Fin r ≃ CriticalSide m kc) (eb : Fin (s+1) ≃ BoundarySide m kb)

/-- The actual linear change from independent group means, remaining free
angles and selected splitting coordinates to the angles used in Ψ. -/
def angles : (Free nc nb kc kb × Blocks (Copies m)) →L[ℝ]
    ((Fin r → ℝ) × (Fin (s+1) → ℝ)) :=
  LinearMap.toContinuousLinearMap {
    toFun := fun p => (sideValues m Sum.inl ec p.1.2.1 p.1.1 p.2,
                        sideValues m Sum.inr eb p.1.2.2 p.1.1 p.2)
    map_add' := by
      intro p q
      apply Prod.ext <;> funext i
      · rcases h : ec i with x | ⟨j,k⟩
        · simp [sideValues, h]
        · simp [sideValues, h]
          ring
      · rcases h : eb i with x | ⟨j,k⟩
        · simp [sideValues, h]
        · simp [sideValues, h]
          ring
    map_smul' := by
      intro c p
      apply Prod.ext <;> funext i
      · rcases h : ec i with x | ⟨j,k⟩
        · simp [sideValues, h]
        · simp [sideValues, h, mul_add]
      · rcases h : eb i with x | ⟨j,k⟩
        · simp [sideValues, h]
        · simp [sideValues, h, mul_add] }

private def copyMean {n : ℕ} (v : Fin (n+1) → ℝ) : ℝ :=
  (∑ k, v k) / (n+1 : ℕ)

private theorem centerCopies_entry {n : ℕ} (v : Fin (n+1) → ℝ) (k : Fin (n+1)) :
    (IndependentBlockConsequences.centerCopies v).1 k = v k - copyMean v := by
  change v k - (∑ i, v i) / (Fintype.card (Fin (n+1)) : ℝ) = v k - copyMean v
  rw [Fintype.card_fin]
  rfl

/-- Every pair of critical and boundary angle vectors is represented. The
mean on a selected group is its arithmetic mean, and the remaining copies
retain their original angle, so all unselected directions are available. -/
theorem angles_surjective : Function.Surjective (angles m ec eb) := by
  intro x
  let v : (j : Index nc nb) → Copies m j → ℝ := fun j =>
    match j with
    | .inl t => fun k => x.1 (ec.symm (.inr ⟨t,k⟩))
    | .inr t => fun k => x.2 (eb.symm (.inr ⟨t,k⟩))
  let q : Free nc nb kc kb :=
    (fun j => copyMean (v j), fun i => x.1 (ec.symm (.inl i)), fun i => x.2 (eb.symm (.inl i)))
  let d : Blocks (Copies m) := WithLp.toLp 2 (fun j => IndependentBlockConsequences.centerCopies (v j))
  refine ⟨(q,d), Prod.ext ?_ ?_⟩
  · funext i
    change sideValues m Sum.inl ec q.2.1 q.1 d i = x.1 i
    rcases h : ec i with k | ⟨t,k⟩
    · have hi := congrArg ec.symm h
      simp only [Equiv.symm_apply_apply] at hi
      simp only [sideValues, h, q]
      exact congrArg x.1 hi.symm
    · have hi := congrArg ec.symm h
      simp only [sideValues, h]
      change copyMean (v (.inl t)) + (IndependentBlockConsequences.centerCopies (v (.inl t))).1 k = x.1 i
      rw [centerCopies_entry, add_comm, sub_add_cancel]
      simpa only [Equiv.symm_apply_apply] using congrArg x.1 hi.symm
  · funext i
    change sideValues m Sum.inr eb q.2.2 q.1 d i = x.2 i
    rcases h : eb i with k | ⟨t,k⟩
    · have hi := congrArg eb.symm h
      simp only [Equiv.symm_apply_apply] at hi
      simp only [sideValues, h, q]
      exact congrArg x.2 hi.symm
    · have hi := congrArg eb.symm h
      simp only [sideValues, h]
      change copyMean (v (.inr t)) + (IndependentBlockConsequences.centerCopies (v (.inr t))).1 k = x.2 i
      rw [centerCopies_entry, add_comm, sub_add_cancel]
      simpa only [Equiv.symm_apply_apply] using congrArg x.2 hi.symm

theorem angles_action (g : Group (Copies m)) (q : Free nc nb kc kb) (d : Blocks (Copies m)) :
    angles m ec eb (q,action (Copies m) g d) =
      (((angles m ec eb (q,d)).1 ∘ sidePermutation m Sum.inl ec g),
       ((angles m ec eb (q,d)).2 ∘ sidePermutation m Sum.inr eb g)) :=
  Prod.ext (sideValues_action m Sum.inl ec _ _ g d) (sideValues_action m Sum.inr eb _ _ g d)

open Factorization CriticalReconstruction SimpleRoot ReconstructionCompletion FullFeasibleReduction
open PolynomialFeasibleChart FeasibleReduction

variable (A : ℂ[X]) (β : Fin (s+1) → ℂ) (w a₀ v₀ : ℂ)
  (R : LocalReconstructionResult r s A β w a₀ v₀)
  (G : Parameter r s → Parameter r s) (τ : ℝ)

/-- The paper's reduced polynomial objective in centered coordinates. -/
def objective : Free nc nb kc kb × Blocks (Copies m) → ℝ :=
  (reducedLogObjective r s R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β τ) ∘ angles m ec eb

variable (hG : AnalyticAt ℂ G (0,β)) (hG0 : G (0,β) = ((fun _ => w),β))
  (hleft : ∀ᶠ q in 𝓝 (((fun _ => w),β) : Parameter r s),
    G (FullRatioChart.forward r s R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) q) = q)
  (hright : ∀ᶠ p in 𝓝 ((0,β) : Parameter r s),
    FullRatioChart.forward r s R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) (G p) = p)
  (hβ : ∀ j k, β (eb.symm (.inr ⟨j,k⟩)) = β (eb.symm (.inr ⟨j,0⟩)))

include hG hG0 in
theorem objective_analyticAt (hw : w-a₀ ≠ 0) (hv : v₀-a₀ ≠ 0) :
    AnalyticAt ℝ (objective m ec eb A β w a₀ v₀ R G τ) 0 :=
  (OriginalFeasibleReduction.reducedLogObjective_analyticAt r s A β w a₀ v₀ R G τ hG hG0 hw hv).comp_of_eq'
    ((angles m ec eb).analyticAt 0) (map_zero _)

include hG hG0 hleft hright hβ in
/-- Independent permutations leave the actual balanced objective invariant.
Group preservation of β is verified on the chosen boundary-copy partition. -/
theorem objective_action (g : Group (Copies m)) :
    (fun p : Free nc nb kc kb × Blocks (Copies m) =>
      objective m ec eb A β w a₀ v₀ R G τ (p.1,action (Copies m) g p.2)) =ᶠ[𝓝 0]
        objective m ec eb A β w a₀ v₀ R G τ := by
  have h := ReducedObjectiveSymmetry.reducedLogObjective_permutation r s A β w a₀ v₀ R G τ
    hG hG0 hleft hright (sidePermutation m Sum.inl ec g) (sidePermutation m Sum.inr eb g)
    (sidePermutation_fixes_labels m Sum.inr eb β hβ g)
  have ht : Tendsto (angles m ec eb) (𝓝 0) (𝓝 0) := by
    simpa using ((angles m ec eb).continuous.continuousAt (x := 0)).tendsto
  filter_upwards [h.comp_tendsto ht] with p hp
  simpa only [objective, Function.comp_apply, angles_action] using hp

include hG hG0 hleft hright hβ in
/-- All first- and second-derivative conclusions of D.3 for the objective
constructed from the polynomial branches and their genuine local ratio inverse. -/
theorem polynomial_centered_derivatives (hw : w-a₀ ≠ 0) (hv : v₀-a₀ ≠ 0) :
    IndependentBlockConsequences.CenteredDerivatives (Copies m)
      (objective m ec eb A β w a₀ v₀ R G τ) :=
  IndependentBlockConsequences.independent_centered_derivatives (Copies m) _
    (objective_analyticAt m ec eb A β w a₀ v₀ R G τ hG hG0 hw hv)
    (objective_action m ec eb A β w a₀ v₀ R G τ hG hG0 hleft hright hβ)

include hG hG0 hleft hright hβ in
/-- Any computed negative diagonal curvatures of the actual objective give
the advertised strict gain. This form also allows zero-dimensional blocks. -/
theorem elimination_of_negative_curvatures (hw : w-a₀ ≠ 0) (hv : v₀-a₀ ≠ 0)
    (lam : Index nc nb → ℝ) (hneg : ∀ j, lam j < 0)
    (hdiag : ∀ j (v : centeredSubspace (ι := Copies m j)),
      fderiv ℝ (fderiv ℝ (objective m ec eb A β w a₀ v₀ R G τ)) 0
        (0,inclusion (Copies m) j v) (0,inclusion (Copies m) j v) = lam j * ‖v‖^2) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ p in 𝓝 0, objective m ec eb A β w a₀ v₀ R G τ p ≤
      objective m ec eb A β w a₀ v₀ R G τ (p.1,0) - c * ‖p.2‖^2 :=
  negative_block_scalars_exact_elimination (Copies m) _
    (objective_analyticAt m ec eb A β w a₀ v₀ R G τ hG hG0 hw hv)
    (objective_action m ec eb A β w a₀ v₀ R G τ hG hG0 hleft hright hβ)
    lam hneg hdiag

include hG hG0 hleft hright hβ in
/-- D.3 for any selected collection: the scalar curvatures are those of
the actual polynomial objective, and negativity gives uniform quadratic
gain on setting just these deviations to zero, leaving all free angles intact. -/
theorem polynomial_splitting_elimination (hw : w-a₀ ≠ 0) (hv : v₀-a₀ ≠ 0) :
    let F := objective m ec eb A β w a₀ v₀ R G τ
    ∃ lam : Index nc nb → ℝ,
      (∀ j (v : centeredSubspace (ι := Copies m j)),
        fderiv ℝ (fderiv ℝ F) 0 (0,inclusion (Copies m) j v) (0,inclusion (Copies m) j v) =
          lam j * ‖v‖^2) ∧
      ((∀ j, lam j < 0) → ∃ c : ℝ, 0 < c ∧ ∀ᶠ p in 𝓝 0,
        F p ≤ F (p.1,0) - c * ‖p.2‖^2) := by
  dsimp only
  obtain ⟨lam,hq⟩ := (polynomial_centered_derivatives m ec eb A β w a₀ v₀ R G τ
    hG hG0 hleft hright hβ hw hv).scalar_blocks
  refine ⟨lam,hq,fun hneg => ?_⟩
  exact elimination_of_negative_curvatures m ec eb A β w a₀ v₀ R G τ
    hG hG0 hleft hright hβ hw hv lam hneg hq

end PolynomialGeometry.PolynomialSplittingElimination
