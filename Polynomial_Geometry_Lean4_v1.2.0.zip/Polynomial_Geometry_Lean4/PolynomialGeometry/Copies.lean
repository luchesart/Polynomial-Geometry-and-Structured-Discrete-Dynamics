import PolynomialGeometry.CompressionDet
import Mathlib.LinearAlgebra.Dimension.Finrank
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas

/-!
# Repeated source groups and inherited modes

The equal-copy model splits orthogonally into normalized group indicators
and the within-group zero-sum spaces. The latter are invariant and carry
the scalar source values. This gives the intrinsic form of the inherited
mode decomposition in Theorem 2.1.
-/

open scoped BigOperators ComplexConjugate Matrix
open Matrix

noncomputable section
namespace PolynomialGeometry.Copies

variable {ι : Type*}

abbrev CopyIndex (m : ι → ℕ) := (j : ι) × Fin (m j + 1)

def groupScale (m : ι → ℕ) (j : ι) : ℂ :=
  (Real.sqrt ((m j + 1 : ℕ) : ℝ) : ℂ)

theorem groupScale_ne_zero (m : ι → ℕ) (j : ι) : groupScale m j ≠ 0 := by
  unfold groupScale
  exact_mod_cast ne_of_gt (Real.sqrt_pos.mpr (by positivity : 0 < ((m j + 1 : ℕ) : ℝ)))

theorem groupScale_sq (m : ι → ℕ) (j : ι) :
    groupScale m j * groupScale m j = (m j + 1 : ℕ) := by
  unfold groupScale
  norm_cast
  exact Real.mul_self_sqrt (by positivity)

@[simp] theorem star_groupScale (m : ι → ℕ) (j : ι) :
    star (groupScale m j) = groupScale m j := by simp [groupScale]

/-- The normalized group-indicator lift. -/
def groupLift (m : ι → ℕ) (y : ι → ℂ) : CopyIndex m → ℂ :=
  fun c => y c.1 / groupScale m c.1

/-- The adjoint of the normalized group-indicator lift. -/
def groupReduce (m : ι → ℕ) (x : CopyIndex m → ℂ) : ι → ℂ :=
  fun j => (∑ k, x ⟨j, k⟩) / groupScale m j

theorem groupReduce_groupLift (m : ι → ℕ) (y : ι → ℂ) :
    groupReduce m (groupLift m y) = y := by
  funext j
  simp only [groupReduce, groupLift, Finset.sum_const, Finset.card_univ,
    Fintype.card_fin, nsmul_eq_mul]
  have hs := groupScale_sq m j
  have hn := groupScale_ne_zero m j
  field_simp
  linear_combination -(y j) * hs

/-- The group reduction is the Hermitian adjoint of the indicator lift. -/
theorem groupLift_adjoint [Fintype ι] (m : ι → ℕ) (y : ι → ℂ) (x : CopyIndex m → ℂ) :
    star (groupLift m y) ⬝ᵥ x = star y ⬝ᵥ groupReduce m x := by
  simp only [dotProduct, Fintype.sum_sigma, groupLift, Pi.star_apply, star_div₀,
    star_groupScale, groupReduce]
  apply Finset.sum_congr rfl
  intro j hj
  rw [← Finset.mul_sum]
  ring

/-- Normalized group indicators preserve the Hermitian inner product. -/
theorem groupLift_isometry [Fintype ι] (m : ι → ℕ) (x y : ι → ℂ) :
    star (groupLift m x) ⬝ᵥ groupLift m y = star x ⬝ᵥ y := by
  rw [groupLift_adjoint, groupReduce_groupLift]

/-- Remove the group averages; what remains has zero sum in every group. -/
def groupResidual (m : ι → ℕ) (x : CopyIndex m → ℂ) : CopyIndex m → ℂ :=
  x - groupLift m (groupReduce m x)

theorem groupReduce_sub (m : ι → ℕ) (x y : CopyIndex m → ℂ) :
    groupReduce m (x - y) = groupReduce m x - groupReduce m y := by
  ext j
  simp [groupReduce, Finset.sum_sub_distrib, sub_div]

theorem groupResidual_reduce_zero (m : ι → ℕ) (x : CopyIndex m → ℂ) :
    groupReduce m (groupResidual m x) = 0 := by
  rw [groupResidual, groupReduce_sub, groupReduce_groupLift, sub_self]

theorem groupResidual_orthogonal [Fintype ι] (m : ι → ℕ) (x : CopyIndex m → ℂ) (y : ι → ℂ) :
    star (groupLift m y) ⬝ᵥ groupResidual m x = 0 := by
  rw [groupLift_adjoint, groupResidual_reduce_zero, dotProduct_zero]

theorem copy_orthogonal_decomposition (m : ι → ℕ) (x : CopyIndex m → ℂ) :
    x = groupLift m (groupReduce m x) + groupResidual m x := by
  simp [groupResidual]

/-- The copied source diagonal. -/
def copyAction (m : ι → ℕ) (α : ι → ℂ) (x : CopyIndex m → ℂ) : CopyIndex m → ℂ :=
  fun c => α c.1 * x c

theorem copyAction_groupLift (m : ι → ℕ) (α y : ι → ℂ) :
    copyAction m α (groupLift m y) = groupLift m (fun j => α j * y j) := by
  ext c
  simp [copyAction, groupLift, mul_div_assoc]

theorem groupReduce_copyAction (m : ι → ℕ) (α : ι → ℂ) (x : CopyIndex m → ℂ) :
    groupReduce m (copyAction m α x) = fun j => α j * groupReduce m x j := by
  ext j
  simp [groupReduce, copyAction, ← Finset.mul_sum, mul_div_assoc]

/-- All within-group zero-sum vectors are preserved by the source diagonal. -/
theorem inherited_invariant (m : ι → ℕ) (α : ι → ℂ) (x : CopyIndex m → ℂ)
    (hx : groupReduce m x = 0) : groupReduce m (copyAction m α x) = 0 := by
  rw [groupReduce_copyAction, hx]
  ext j
  simp

/-- A vector supported on a single source group is acted on by that scalar. -/
theorem single_group_eigenvector (m : ι → ℕ) (α : ι → ℂ)
    (x : CopyIndex m → ℂ) (j : ι) (hx : ∀ c, c.1 ≠ j → x c = 0) :
    copyAction m α x = α j • x := by
  classical
  ext c
  by_cases h : c.1 = j
  · simp [copyAction, h]
  · simp [copyAction, hx c h]

/-- Zero output passes exactly to grouped coordinates; residual modes are invisible. -/
theorem copy_output_eq_group_output [Fintype ι] (m : ι → ℕ) (b : ι → ℂ) (x : CopyIndex m → ℂ) :
    star (groupLift m b) ⬝ᵥ x = star b ⬝ᵥ groupReduce m x :=
  groupLift_adjoint m b x

/-- The zero-output splitting is exact, with a mutually orthogonal inherited part. -/
theorem zero_output_orthogonal_splitting [Fintype ι] (m : ι → ℕ)
    (b : ι → ℂ) (x : CopyIndex m → ℂ)
    (hx : star (groupLift m b) ⬝ᵥ x = 0) :
    ∃ y : ι → ℂ, ∃ r : CopyIndex m → ℂ,
      x = groupLift m y + r ∧ star b ⬝ᵥ y = 0 ∧
      groupReduce m r = 0 ∧ (∀ z, star (groupLift m z) ⬝ᵥ r = 0) := by
  refine ⟨groupReduce m x, groupResidual m x, copy_orthogonal_decomposition m x, ?_,
    groupResidual_reduce_zero m x, groupResidual_orthogonal m x⟩
  simpa only [groupLift_adjoint] using hx

theorem groupLift_add (m : ι → ℕ) (x y : ι → ℂ) :
    groupLift m (x + y) = groupLift m x + groupLift m y := by
  ext c
  simp [groupLift, add_div]

theorem groupLift_sub (m : ι → ℕ) (x y : ι → ℂ) :
    groupLift m (x - y) = groupLift m x - groupLift m y := by
  ext c
  simp [groupLift, sub_div]

theorem groupLift_smul (m : ι → ℕ) (a : ℂ) (y : ι → ℂ) :
    groupLift m (a • y) = a • groupLift m y := by
  ext c
  simp [groupLift, mul_div_assoc]

theorem groupReduce_add (m : ι → ℕ) (x y : CopyIndex m → ℂ) :
    groupReduce m (x + y) = groupReduce m x + groupReduce m y := by
  ext j
  simp [groupReduce, Finset.sum_add_distrib, add_div]

theorem copyAction_add (m : ι → ℕ) (α : ι → ℂ) (x y : CopyIndex m → ℂ) :
    copyAction m α (x + y) = copyAction m α x + copyAction m α y := by
  ext c
  simp [copyAction, mul_add]

/-- Full equal-copy zero dynamics, with its output-canceling feedback. -/
def copyZeroAction [Fintype ι] (m : ι → ℕ) (α b : ι → ℂ)
    (x : CopyIndex m → ℂ) : CopyIndex m → ℂ :=
  copyAction m α x - (star (groupLift m b) ⬝ᵥ copyAction m α x) • groupLift m b

/-- Grouped zero dynamics before choosing its orthonormal basis. -/
def groupZeroAction [Fintype ι] (α b y : ι → ℂ) : ι → ℂ :=
  (fun j => α j * y j) - (star b ⬝ᵥ (fun j => α j * y j)) • b

/-- The operator itself splits into grouped zero dynamics and the inherited
scalar source action. This is the block-diagonal assertion in intrinsic coordinates. -/
theorem zero_dynamics_block_decomposition [Fintype ι] (m : ι → ℕ)
    (α b y : ι → ℂ) (r : CopyIndex m → ℂ) (hr : groupReduce m r = 0) :
    copyZeroAction m α b (groupLift m y + r) =
      groupLift m (groupZeroAction α b y) + copyAction m α r := by
  have houtput : star (groupLift m b) ⬝ᵥ copyAction m α (groupLift m y + r) =
      star b ⬝ᵥ (fun j => α j * y j) := by
    rw [groupLift_adjoint, groupReduce_copyAction, groupReduce_add,
      groupReduce_groupLift, hr, add_zero]
  rw [copyZeroAction, houtput, copyAction_add, copyAction_groupLift,
    groupZeroAction, groupLift_sub, groupLift_smul]
  abel


/-- Square-root group masses lift to the constant equal-copy source column. -/
theorem groupLift_weighted_source (m : ι → ℕ) (N : ℂ) :
    groupLift m (fun j => groupScale m j / N) = fun _ => 1 / N := by
  ext c
  simp only [groupLift]
  rw [div_right_comm, div_self (groupScale_ne_zero m c.1)]

/-- Resolution of the identity by the source column and compression columns. -/
theorem compression_projection (d : ℕ) (b : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hb : ∑ i, star (b i) * b i = 1) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (b i) * Q i j = 0) :
    Q * Qᴴ = 1 - vecMulVec b (star b) := by
  have hU := Matrix.mul_eq_one_comm.mp
    (CompressionDet.sourceCoordinates_unitary d b Q hb hQ hbQ)
  ext i j
  have hij := congrFun (congrFun hU i) j
  rw [Matrix.mul_apply, Fin.sum_univ_succ] at hij
  simp only [Matrix.conjTranspose_apply, CompressionDet.sourceCoordinates_zero,
    CompressionDet.sourceCoordinates_succ] at hij
  simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, Matrix.sub_apply,
    Matrix.vecMulVec_apply, Pi.star_apply]
  linear_combination hij

/-- Choosing `Q` identifies the grouped zero dynamics with `Qᴴ diag(α) Q`. -/
theorem groupZeroAction_compression (d : ℕ) (α b : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hb : ∑ i, star (b i) * b i = 1) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (b i) * Q i j = 0) (ξ : Fin d → ℂ) :
    groupZeroAction α b (Q *ᵥ ξ) = Q *ᵥ ((Qᴴ * diagonal α * Q) *ᵥ ξ) := by
  have heq : Q *ᵥ ((Qᴴ * diagonal α * Q) *ᵥ ξ) =
      (Q * Qᴴ) *ᵥ (diagonal α *ᵥ (Q *ᵥ ξ)) := by
    simp only [Matrix.mulVec_mulVec, Matrix.mul_assoc]
  have hD : diagonal α *ᵥ (Q *ᵥ ξ) = (fun j => α j * (Q *ᵥ ξ) j) := by
    ext j
    exact Matrix.mulVec_diagonal _ _ _
  rw [heq, compression_projection d b Q hb hQ hbQ,
    Matrix.sub_mulVec, Matrix.one_mulVec, Matrix.vecMulVec_mulVec, hD]
  ext j
  simp [groupZeroAction, mul_comm]


/-- The full copy zero dynamics in grouped compression coordinates. -/
theorem copy_compression_block_action (d : ℕ) (m : Fin (d + 1) → ℕ)
    (α b : Fin (d + 1) → ℂ) (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hb : ∑ i, star (b i) * b i = 1) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (b i) * Q i j = 0)
    (ξ : Fin d → ℂ) (r : CopyIndex m → ℂ) (hr : groupReduce m r = 0) :
    copyZeroAction m α b (groupLift m (Q *ᵥ ξ) + r) =
      groupLift m (Q *ᵥ ((Qᴴ * diagonal α * Q) *ᵥ ξ)) + copyAction m α r := by
  rw [zero_dynamics_block_decomposition m α b _ r hr,
    groupZeroAction_compression d α b Q hb hQ hbQ]

/-- Every group vector orthogonal to the source has compression coordinates. -/
theorem grouped_coordinate_reconstruction (d : ℕ) (b : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hb : ∑ i, star (b i) * b i = 1) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (b i) * Q i j = 0)
    (y : Fin (d + 1) → ℂ) (hy : star b ⬝ᵥ y = 0) :
    Q *ᵥ (Qᴴ *ᵥ y) = y := by
  rw [Matrix.mulVec_mulVec, compression_projection d b Q hb hQ hbQ,
    Matrix.sub_mulVec, Matrix.one_mulVec, Matrix.vecMulVec_mulVec, hy]
  simp

/-- Completeness of the grouped-plus-inherited coordinates on the full zero-output space. -/
theorem copy_zero_output_coordinates (d : ℕ) (m : Fin (d + 1) → ℕ)
    (b : Fin (d + 1) → ℂ) (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hb : ∑ i, star (b i) * b i = 1) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (b i) * Q i j = 0)
    (x : CopyIndex m → ℂ) (hx : star (groupLift m b) ⬝ᵥ x = 0) :
    ∃ ξ : Fin d → ℂ, ∃ r : CopyIndex m → ℂ,
      x = groupLift m (Q *ᵥ ξ) + r ∧ groupReduce m r = 0 := by
  have hy : star b ⬝ᵥ groupReduce m x = 0 := by
    simpa only [groupLift_adjoint] using hx
  refine ⟨Qᴴ *ᵥ groupReduce m x, groupResidual m x, ?_, groupResidual_reduce_zero m x⟩
  rw [grouped_coordinate_reconstruction d b Q hb hQ hbQ _ hy]
  exact copy_orthogonal_decomposition m x


/-- Every grouped-plus-inherited coordinate pair gives a full zero-output vector. -/
theorem copy_coordinates_zero_output (d : ℕ) (m : Fin (d + 1) → ℕ)
    (b : Fin (d + 1) → ℂ) (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hbQ : ∀ j, ∑ i, star (b i) * Q i j = 0)
    (ξ : Fin d → ℂ) (r : CopyIndex m → ℂ) (hr : groupReduce m r = 0) :
    star (groupLift m b) ⬝ᵥ (groupLift m (Q *ᵥ ξ) + r) = 0 := by
  rw [groupLift_adjoint, groupReduce_add, groupReduce_groupLift, hr, add_zero,
    Matrix.dotProduct_mulVec]
  have hrow : star b ᵥ* Q = 0 := by
    ext j
    exact hbQ j
  rw [hrow, zero_dotProduct]

/-- The decomposition coordinates are unique. -/
theorem copy_coordinates_unique (d : ℕ) (m : Fin (d + 1) → ℕ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ) (hQ : Qᴴ * Q = 1)
    (ξ η : Fin d → ℂ) (r s : CopyIndex m → ℂ)
    (hr : groupReduce m r = 0) (hs : groupReduce m s = 0)
    (heq : groupLift m (Q *ᵥ ξ) + r = groupLift m (Q *ᵥ η) + s) :
    ξ = η ∧ r = s := by
  have hy := congrArg (groupReduce m) heq
  rw [groupReduce_add, groupReduce_add, groupReduce_groupLift,
    groupReduce_groupLift, hr, hs, add_zero, add_zero] at hy
  have hξη := congrArg (fun y => Qᴴ *ᵥ y) hy
  change Qᴴ *ᵥ (Q *ᵥ ξ) = Qᴴ *ᵥ (Q *ᵥ η) at hξη
  rw [Matrix.mulVec_mulVec, Matrix.mulVec_mulVec, hQ, Matrix.one_mulVec,
    Matrix.one_mulVec] at hξη
  refine ⟨hξη, ?_⟩
  rw [hξη] at heq
  exact add_left_cancel heq


/-- The combined grouped and inherited coordinates preserve the Hermitian
inner product. Together with completeness, uniqueness and block action this
is the unitary decomposition stated intrinsically. -/
theorem copy_coordinates_isometry (d : ℕ) (m : Fin (d + 1) → ℕ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ) (hQ : Qᴴ * Q = 1)
    (ξ η : Fin d → ℂ) (r s : CopyIndex m → ℂ)
    (hr : groupReduce m r = 0) (hs : groupReduce m s = 0) :
    star (groupLift m (Q *ᵥ ξ) + r) ⬝ᵥ (groupLift m (Q *ᵥ η) + s) =
      star ξ ⬝ᵥ η + star r ⬝ᵥ s := by
  have h1 : star (groupLift m (Q *ᵥ ξ)) ⬝ᵥ s = 0 := by
    rw [groupLift_adjoint, hs, dotProduct_zero]
  have h2 : star r ⬝ᵥ groupLift m (Q *ᵥ η) = 0 := by
    rw [star_dotProduct, groupLift_adjoint, hr, dotProduct_zero, star_zero]
  have h3 : star (Q *ᵥ ξ) ⬝ᵥ (Q *ᵥ η) = star ξ ⬝ᵥ η := by
    rw [Matrix.star_mulVec, Matrix.dotProduct_mulVec, Matrix.vecMul_vecMul,
      hQ, Matrix.vecMul_one]
  rw [star_add, add_dotProduct, dotProduct_add, dotProduct_add,
    h1, h2, add_zero, zero_add, groupLift_isometry, h3]


/-- The inherited subspace is exactly the product of the individual zero-sum spaces. -/
theorem groupReduce_eq_zero_iff (m : ι → ℕ) (x : CopyIndex m → ℂ) :
    groupReduce m x = 0 ↔ ∀ j, ∑ k, x ⟨j, k⟩ = 0 := by
  simp only [funext_iff, groupReduce, Pi.zero_apply, div_eq_zero_iff,
    groupScale_ne_zero, or_false]

/-- For integer masses, the article's normalized grouped source lifts to the
normalized constant source vector in the equal-copy model. -/
theorem normalizedSource_copies (d : ℕ) (m : Fin (d + 1) → ℕ) :
    groupLift m (CompressionDet.normalizedSource d (fun j => ((m j + 1 : ℕ) : ℝ))) =
      fun _ => 1 / (Real.sqrt (∑ j, ((m j + 1 : ℕ) : ℝ)) : ℂ) := by
  unfold CompressionDet.normalizedSource
  simpa only [groupScale, Complex.ofReal_div] using
    groupLift_weighted_source m (Real.sqrt (∑ j, ((m j + 1 : ℕ) : ℝ)) : ℂ)

/-- The sum functional for one repeated source group. -/
def sumLinear (r : ℕ) : (Fin (r + 1) → ℂ) →ₗ[ℂ] ℂ where
  toFun x := ∑ k, x k
  map_add' x y := Finset.sum_add_distrib
  map_smul' c x := by simp [Finset.mul_sum]

/-- A source with `r+1` copies contributes exactly `r` inherited directions. -/
theorem inherited_dimension (r : ℕ) : Module.finrank ℂ (LinearMap.ker (sumLinear r)) = r := by
  have hsurj : Function.Surjective (sumLinear r) := by
    intro z
    refine ⟨Pi.single 0 z, ?_⟩
    simp [sumLinear]
  have h := (sumLinear r).finrank_range_add_finrank_ker
  rw [LinearMap.range_eq_top.mpr hsurj, finrank_top,
    Module.finrank_self, Module.finrank_pi, Fintype.card_fin] at h
  omega

end PolynomialGeometry.Copies
