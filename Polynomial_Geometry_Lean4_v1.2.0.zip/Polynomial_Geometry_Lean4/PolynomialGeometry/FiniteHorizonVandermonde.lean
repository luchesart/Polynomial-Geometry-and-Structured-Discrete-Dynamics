import Mathlib.Data.Complex.Basic
import Mathlib.LinearAlgebra.Vandermonde
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas
import Mathlib.Tactic.Ring
import Lean.Elab.Tactic.Omega

/-! # Coordinate observations and a weighted boundary Vandermonde matrix

The coordinate rows remove all interior directions. Keeping the first
`min t sᶜ.card` moments and an equal number of distinct boundary nodes gives
an explicit invertible minor, even when either block is empty.
-/

open Matrix
open scoped BigOperators

noncomputable section
namespace PolynomialGeometry.FiniteHorizon

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Interior coordinate measurements followed by moments numbered from zero to `t-1`. -/
def finiteSourceRows (s : Finset ι) (u z : ι → ℂ) (t : ℕ) :
    Matrix (s ⊕ Fin t) ι ℂ
  | Sum.inl i, j => if (i : ι) = j then 1 else 0
  | Sum.inr k, j => u j * z j ^ (k : ℕ)

private theorem minor_rank_le {m n m' n' : Type*}
    [Fintype m] [Fintype n] [Fintype m'] [Fintype n']
    (A : Matrix m n ℂ) (r : m' → m) (c : n' → n) :
    (A.submatrix r c).rank ≤ A.rank := by
  have hr := Matrix.rank_submatrix_le r (Equiv.refl n) A
  have hc := Matrix.rank_submatrix_le c (Equiv.refl m') (A.submatrix r id)ᵀ
  change (A.submatrix r c)ᵀ.rank ≤ (A.submatrix r id)ᵀ.rank at hc
  simp only [Matrix.rank_transpose] at hc
  exact hc.trans hr

/-- Exact rank over arbitrary finite coordinate sets, including no interior or boundary nodes. -/
theorem finiteSourceRows_rank (s : Finset ι) (u z : ι → ℂ) (t : ℕ)
    (hu : ∀ j ∉ s, u j ≠ 0) (hz : Set.InjOn z {j | j ∉ s}) :
    (finiteSourceRows s u z t).rank = s.card + min t sᶜ.card := by
  classical
  let q := min t sᶜ.card
  let e : Fin q → ↥(sᶜ : Finset ι) := fun i =>
    sᶜ.equivFin.symm (Fin.castLE (min_le_right t sᶜ.card) i)
  have he : Function.Injective e := by
    intro i j hij
    have hcast : Fin.castLE (min_le_right t sᶜ.card) i = Fin.castLE (min_le_right t sᶜ.card) j :=
      sᶜ.equivFin.symm.injective hij
    exact Fin.ext (congrArg (fun x : Fin sᶜ.card => x.val) hcast)
  let b : Fin q → ι := fun i => (e i).val
  have hb (i : Fin q) : b i ∉ s := Finset.mem_compl.mp (e i).property
  have hzb : Function.Injective (fun i => z (b i)) := by
    intro i j hij
    apply he
    apply Subtype.ext
    exact hz (hb i) (hb j) hij
  let rows : s ⊕ Fin q → s ⊕ Fin t :=
    Sum.map id (Fin.castLE (min_le_left t sᶜ.card))
  let cols : s ⊕ Fin q → ι := Sum.elim Subtype.val b
  let C : Matrix (Fin q) s ℂ := fun k j => u j * z j ^ (k : ℕ)
  let V := (Matrix.vandermonde (fun j => z (b j)))ᵀ * Matrix.diagonal (fun j => u (b j))
  have hblock : (finiteSourceRows s u z t).submatrix rows cols =
      Matrix.fromBlocks 1 0 C V := by
    ext i j
    cases i with
    | inl i =>
      cases j with
      | inl j => simp [finiteSourceRows, rows, cols, Matrix.one_apply, Subtype.ext_iff]
      | inr j =>
        have hn : (i : ι) ≠ b j := fun h => hb j (h ▸ i.property)
        simp [finiteSourceRows, rows, cols, hn]
    | inr i =>
      cases j with
      | inl j => rfl
      | inr j => simp [finiteSourceRows, rows, cols, V, Matrix.mul_diagonal,
          Matrix.vandermonde_apply, mul_comm]
  have hV : V.det ≠ 0 := by
    change ((Matrix.vandermonde (fun j => z (b j)))ᵀ * Matrix.diagonal (fun j => u (b j))).det ≠ 0
    rw [Matrix.det_mul, Matrix.det_transpose, Matrix.det_diagonal]
    exact mul_ne_zero (Matrix.det_vandermonde_ne_zero_iff.mpr hzb)
      (Finset.prod_ne_zero_iff.mpr (fun i _ => hu (b i) (hb i)))
  have hdet : ((finiteSourceRows s u z t).submatrix rows cols).det ≠ 0 := by
    rw [hblock, Matrix.det_fromBlocks_zero₁₂, Matrix.det_one, one_mul]
    exact hV
  have hlo := minor_rank_le (finiteSourceRows s u z t) rows cols
  rw [Matrix.rank_of_isUnit _ ((Matrix.isUnit_iff_isUnit_det _).mpr (isUnit_iff_ne_zero.mpr hdet))] at hlo
  have htop := (finiteSourceRows s u z t).rank_le_card_height
  have hwidth := (finiteSourceRows s u z t).rank_le_card_width
  have htotal := Finset.card_add_card_compl s
  simp only [Fintype.card_sum, Fintype.card_coe, Fintype.card_fin] at hlo htop
  dsimp [q] at hlo
  omega

/-- The unobserved dimension is the excess number of boundary nodes over the moment count. -/
theorem finiteSourceRows_finrank_ker (s : Finset ι) (u z : ι → ℂ) (t : ℕ)
    (hu : ∀ j ∉ s, u j ≠ 0) (hz : Set.InjOn z {j | j ∉ s}) :
    Module.finrank ℂ (LinearMap.ker (finiteSourceRows s u z t).mulVecLin) = sᶜ.card - t := by
  have h := (finiteSourceRows s u z t).mulVecLin.finrank_range_add_finrank_ker
  change (finiteSourceRows s u z t).rank + _ = _ at h
  rw [finiteSourceRows_rank s u z t hu hz, Module.finrank_fintype_fun_eq_card] at h
  have htotal := Finset.card_add_card_compl s
  omega

/-- All state directions are observed exactly when the moment count covers the boundary. -/
theorem finiteSourceRows_full_rank_iff (s : Finset ι) (u z : ι → ℂ) (t : ℕ)
    (hu : ∀ j ∉ s, u j ≠ 0) (hz : Set.InjOn z {j | j ∉ s}) :
    (finiteSourceRows s u z t).rank = Fintype.card ι ↔ sᶜ.card ≤ t := by
  rw [finiteSourceRows_rank s u z t hu hz]
  have htotal := Finset.card_add_card_compl s
  omega

/-- The first strictly positive horizon whose moments observe the whole state space. -/
theorem finiteSourceRows_least_horizon (s : Finset ι) (u z : ι → ℂ)
    (hu : ∀ j ∉ s, u j ≠ 0) (hz : Set.InjOn z {j | j ∉ s}) :
    IsLeast {h : ℕ | 0 < h ∧ (finiteSourceRows s u z (h+1)).rank = Fintype.card ι}
      (max 1 (sᶜ.card - 1)) := by
  constructor
  · change 0 < max 1 (sᶜ.card - 1) ∧
      (finiteSourceRows s u z (max 1 (sᶜ.card - 1) + 1)).rank = Fintype.card ι
    rw [finiteSourceRows_full_rank_iff s u z _ hu hz]
    omega
  · intro h hh
    obtain ⟨hpos, hfull⟩ := hh
    have := (finiteSourceRows_full_rank_iff s u z _ hu hz).mp hfull
    omega

/-- Two ungrouped boundary coordinates with the same node supply one explicit
nonzero direction invisible to *every* length of observation. -/
theorem repeated_boundary_direction (s : Finset ι) (u z : ι → ℂ)
    {p q : ι} (hp : p ∉ s) (hq : q ∉ s) (hpq : p ≠ q)
    (hweight : u q ≠ 0) (hnode : z p = z q) :
    ∃ x : ι → ℂ, x ≠ 0 ∧ ∀ t : ℕ, finiteSourceRows s u z t *ᵥ x = 0 := by
  classical
  refine ⟨Pi.single p (u q) - Pi.single q (u p), ?_, ?_⟩
  · intro h
    have hv := congrFun h p
    apply hweight
    simpa [Pi.single_apply, hpq, hpq.symm] using hv
  · intro t
    rw [Matrix.mulVec_sub, Matrix.mulVec_single, Matrix.mulVec_single]
    funext r
    change (finiteSourceRows s u z t r p) * u q -
      (finiteSourceRows s u z t r q) * u p = 0
    cases r with
    | inl i =>
      have hip : (i : ι) ≠ p := fun h => hp (h ▸ i.property)
      have hiq : (i : ι) ≠ q := fun h => hq (h ▸ i.property)
      simp [finiteSourceRows, hip, hiq]
    | inr k =>
      simp only [finiteSourceRows, hnode]
      ring

end PolynomialGeometry.FiniteHorizon
