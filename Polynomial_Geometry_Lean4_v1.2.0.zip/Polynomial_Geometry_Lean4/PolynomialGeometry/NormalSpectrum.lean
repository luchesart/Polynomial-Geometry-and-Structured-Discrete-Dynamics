import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Analysis.InnerProductSpace.JointEigenspace
import Mathlib.LinearAlgebra.Complex.Module
import Mathlib.Tactic

/-!
# A normal operator has an orthonormal eigenbasis

The finite-dimensional normal spectral theorem is obtained from the
commuting self-adjoint real and imaginary parts. This is classical
infrastructure for the inverse source-realization theorem.
-/

noncomputable section

namespace PolynomialGeometry.NormalSpectrum

open Complex Module Module.End

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]
  [FiniteDimensional ℂ E]

/-- The self-adjoint parts of a normal endomorphism commute. -/
theorem parts_commute (T : E →ₗ[ℂ] E) (hT : IsStarNormal T) :
    Commute (realPart T : E →ₗ[ℂ] E) (imaginaryPart T : E →ₗ[ℂ] E) := by
  have h : Commute (star T) T := hT.star_comm_self
  have hsum : Commute (T + star T) (T - star T) :=
    ((Commute.refl T).sub_right h.symm).add_left
      (h.sub_right (Commute.refl (star T)))
  rw [realPart_apply_coe, imaginaryPart_apply_coe]
  exact ((hsum.smul_left ((2 : ℝ)⁻¹)).smul_right ((2 : ℝ)⁻¹)).smul_right (-I)

set_option maxHeartbeats 2000000 in
/-- A genuine normal spectral theorem: the eigenbasis is derived from
normality, rather than supplied as a realization hypothesis. -/
theorem exists_orthonormal_eigenbasis (T : E →ₗ[ℂ] E) (hT : IsStarNormal T) :
    ∃ (b : OrthonormalBasis (Fin (Module.finrank ℂ E)) ℂ E)
      (μ : Fin (Module.finrank ℂ E) → ℂ), ∀ i, T (b i) = μ i • b i := by
  classical
  let A : E →ₗ[ℂ] E := realPart T
  let B : E →ₗ[ℂ] E := imaginaryPart T
  have hA : A.IsSymmetric :=
    (LinearMap.isSymmetric_iff_isSelfAdjoint A).mpr (realPart T).property
  have hB : B.IsSymmetric :=
    (LinearMap.isSymmetric_iff_isSelfAdjoint B).mpr (imaginaryPart T).property
  have hAB : Commute A B := parts_commute T hT
  let V : ℂ × ℂ → Submodule ℂ E := fun q => eigenspace A q.2 ⊓ eigenspace B q.1
  have hO : OrthogonalFamily ℂ (fun q => V q) (fun q => (V q).subtypeₗᵢ) :=
    hA.orthogonalFamily_eigenspace_inf_eigenspace hB
  let Index := {q : ℂ × ℂ // V q ≠ ⊥}
  let f : Index → Eigenvalues B × Eigenvalues A := fun q =>
    (⟨q.1.1, by intro he; exact q.2 (by simp [V, he])⟩,
     ⟨q.1.2, by intro he; exact q.2 (by simp [V, he])⟩)
  have hf : Function.Injective f := by
    intro q r he
    apply Subtype.ext
    exact Prod.ext (congrArg (fun z => (z.1 : ℂ)) he)
      (congrArg (fun z => (z.2 : ℂ)) he)
  letI : Finite Index := Finite.of_injective f hf
  letI : Fintype Index := Fintype.ofFinite Index
  let V' : Index → Submodule ℂ E := fun q => V q.1
  have hO' : OrthogonalFamily ℂ (fun q => V' q) (fun q => (V' q).subtypeₗᵢ) :=
    hO.comp (f := fun q : Index => (q : ℂ × ℂ)) Subtype.coe_injective
  have htop : (⨆ q : ℂ × ℂ, V q) = ⊤ := by
    change (⨆ q : ℂ × ℂ, eigenspace A q.2 ⊓ eigenspace B q.1) = ⊤
    rw [iSup_prod, iSup_comm]
    exact hA.iSup_iSup_eigenspace_inf_eigenspace_eq_top_of_commute hB hAB
  have hV : DirectSum.IsInternal V' := hO'.isInternal_iff.mpr (by
    change (⨆ q : {q : ℂ × ℂ // V q ≠ ⊥}, V q.1)ᗮ = ⊥
    rw [iSup_ne_bot_subtype, htop, Submodule.top_orthogonal_eq_bot])
  let b := hV.subordinateOrthonormalBasis rfl hO'
  let index := fun i => hV.subordinateOrthonormalBasisIndex rfl i hO'
  refine ⟨b, fun i => (index i).1.2 + I * (index i).1.1, ?_⟩
  intro i
  have hv : b i ∈ V (index i).1 :=
    hV.subordinateOrthonormalBasis_subordinate rfl i hO'
  have hAi : A (b i) = (index i).1.2 • b i := mem_eigenspace_iff.mp hv.1
  have hBi : B (b i) = (index i).1.1 • b i := mem_eigenspace_iff.mp hv.2
  have hdecomp : A + I • B = T := realPart_add_I_smul_imaginaryPart T
  rw [← hdecomp, LinearMap.add_apply, LinearMap.smul_apply, hAi, hBi,
    smul_smul, ← add_smul]

end PolynomialGeometry.NormalSpectrum
