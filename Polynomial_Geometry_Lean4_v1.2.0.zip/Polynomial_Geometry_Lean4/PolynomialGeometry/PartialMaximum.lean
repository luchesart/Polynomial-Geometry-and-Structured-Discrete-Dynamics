import Mathlib.Analysis.Calculus.FDeriv.Analytic
import Mathlib.Analysis.Calculus.InverseFunctionTheorem.FDeriv
import Mathlib.Analysis.Calculus.Gradient.Basic
import Mathlib.Topology.Algebra.Module.FiniteDimension
import Mathlib.Tactic

/-!
# Analytic stationary response in partial maximization

The analytic inverse theorem is applied to the augmented stationarity map.
No stationary response or local inverse is assumed as input.
-/

noncomputable section
open scoped Topology
open Filter

namespace PolynomialGeometry.PartialMaximum

variable {E S : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup S] [NormedSpace ℝ S]
  [FiniteDimensional ℝ E] [FiniteDimensional ℝ S]

/-- The derivative of `(x,s) ↦ (x, ∇ₛF(x,s))` when the partial Hessian is `-P`. -/
def stationarityEquiv (C : E →L[ℝ] S) (P : S ≃L[ℝ] S) : (E × S) ≃L[ℝ] (E × S) :=
  ({ toFun := fun p => (p.1, C p.1 - P p.2)
     invFun := fun p => (p.1, P.symm (C p.1 - p.2))
     left_inv := by intro p; ext <;> simp
     right_inv := by intro p; ext <;> simp
     map_add' := by
       intro p q
       apply Prod.ext
       · rfl
       · simp only [Prod.fst_add, Prod.snd_add, map_add]
         abel
     map_smul' := by intro c p; ext <;> simp [smul_sub] } :
    (E × S) ≃ₗ[ℝ] (E × S)).toContinuousLinearEquiv

@[simp] theorem stationarityEquiv_apply (C : E →L[ℝ] S) (P : S ≃L[ℝ] S) (p : E × S) :
    stationarityEquiv C P p = (p.1, C p.1 - P p.2) := rfl

@[simp] theorem stationarityEquiv_symm_apply (C : E →L[ℝ] S) (P : S ≃L[ℝ] S) (p : E × S) :
    (stationarityEquiv C P).symm p = (p.1, P.symm (C p.1 - p.2)) := rfl

/-- Analytic stationarity has an analytic, locally unique response, with
its exact first derivative. The supplied derivative is the Hessian block,
not an assumed implicit function. -/
theorem analytic_stationary_response (g : E × S → S)
    (C : E →L[ℝ] S) (P : S ≃L[ℝ] S)
    (hg : AnalyticAt ℝ g 0) (hg0 : g 0 = 0)
    (hD : fderiv ℝ g 0 = C.comp (ContinuousLinearMap.fst ℝ E S) -
      P.toContinuousLinearMap.comp (ContinuousLinearMap.snd ℝ E S)) :
    ∃ θ : E → S, AnalyticAt ℝ θ 0 ∧ θ 0 = 0 ∧
      HasFDerivAt θ (P.symm.toContinuousLinearMap.comp C) 0 ∧
      (∀ᶠ x in 𝓝 (0 : E), g (x, θ x) = 0) ∧
      (∀ᶠ p : E × S in 𝓝 0, g p = 0 → p.2 = θ p.1) := by
  let H : E × S → E × S := fun p => (p.1, g p)
  let L := stationarityEquiv C P
  have hH0 : H 0 = 0 := by simp [H, hg0]
  have hH : AnalyticAt ℝ H 0 := analyticAt_fst.prod hg
  have hDH : fderiv ℝ H 0 = L.toContinuousLinearMap := by
    change fderiv ℝ (fun p : E × S => (p.1, g p)) 0 = L.toContinuousLinearMap
    rw [differentiableAt_fst.fderiv_prodMk hg.differentiableAt, hD]
    simp only [fderiv_fst]
    ext p <;> rfl
  have hstrict : HasStrictFDerivAt H L.toContinuousLinearMap 0 := by
    rw [← hDH]
    exact hH.hasStrictFDerivAt
  let J := hstrict.localInverse H L 0
  have hJ : AnalyticAt ℝ J 0 := by
    rw [← hH0]
    exact (hstrict.toOpenPartialHomeomorph H).analyticAt_symm'
      hstrict.mem_toOpenPartialHomeomorph_source hH hDH
  have hJ0 : J 0 = 0 := by
    simpa only [hH0] using hstrict.localInverse_apply_image
  let θ : E → S := fun x => (J (x, 0)).2
  have hin : AnalyticAt ℝ (fun x : E => (x, (0 : S))) 0 := analyticAt_id.prod analyticAt_const
  have hθ : AnalyticAt ℝ θ 0 := by
    exact ((ContinuousLinearMap.snd ℝ E S).analyticAt _).comp'
      (hJ.comp_of_eq' hin rfl)
  refine ⟨θ, hθ, ?_, ?_, ?_, ?_⟩
  · change (J (0 : E × S)).2 = 0
    rw [hJ0]
    rfl
  · have hJI : HasFDerivAt J L.symm.toContinuousLinearMap ((0 : E), (0 : S)) := by
      simpa only [hH0] using hstrict.to_localInverse.hasFDerivAt
    have hinD : HasFDerivAt (fun x : E => (x, (0 : S))) (ContinuousLinearMap.inl ℝ E S) 0 :=
      (ContinuousLinearMap.inl ℝ E S).hasFDerivAt
    have hcomp := hJI.comp (0 : E) hinD
    have hcomp2 := (ContinuousLinearMap.snd ℝ E S).hasFDerivAt.comp (0 : E) hcomp
    convert hcomp2 using 1
    ext x
    simp [L, ContinuousLinearMap.comp_apply]
  · have hright := hstrict.eventually_right_inverse
    rw [hH0] at hright
    have hright' := hin.continuousAt.eventually hright
    filter_upwards [hright'] with x hx
    have hfst : (J (x, 0)).1 = x := congrArg Prod.fst hx
    have hsnd : g (J (x, 0)) = 0 := congrArg Prod.snd hx
    have heqJ : J (x, 0) = (x, θ x) := Prod.ext hfst rfl
    rw [heqJ] at hsnd
    exact hsnd
  · have hleft := hstrict.eventually_left_inverse
    filter_upwards [hleft] with p hp hgp
    have heq : J (p.1, 0) = p := by simpa only [H, hgp] using hp
    exact (congrArg Prod.snd heq).symm

section Objective

variable {T : Type*} [NormedAddCommGroup T] [InnerProductSpace ℝ T]
  [FiniteDimensional ℝ T]

/-- Restrict a total derivative to the eliminated space and apply the Riesz inverse. -/
def partialGradientMap : ((E × T) →L[ℝ] ℝ) →L[ℝ] T :=
  (InnerProductSpace.toDual ℝ T).symm.toContinuousLinearEquiv.toContinuousLinearMap.comp
    ((ContinuousLinearMap.compL ℝ T (E × T) ℝ).flip (ContinuousLinearMap.inr ℝ E T))

/-- The actual partial gradient of the objective, not an independent auxiliary map. -/
def partialGradient (F : E × T → ℝ) : E × T → T :=
  fun p => partialGradientMap (fderiv ℝ F p)

omit [FiniteDimensional ℝ E] in
theorem partialGradient_analytic (F : E × T → ℝ) (hF : AnalyticAt ℝ F 0) :
    AnalyticAt ℝ (partialGradient F) 0 := by
  exact ((partialGradientMap (E := E) (T := T)).analyticAt _).comp' hF.fderiv

theorem positive_hessian_bijective (P : T →L[ℝ] T)
    (hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s)) : Function.Bijective P := by
  have hi : Function.Injective P := by
    intro x y hxy
    by_contra hne
    have hp := hP (x - y) (sub_ne_zero.mpr hne)
    have hz : P (x - y) = 0 := by rw [map_sub, hxy, sub_self]
    simp only [hz, inner_zero_right] at hp
    exact lt_irrefl _ hp
  exact ⟨hi, LinearMap.injective_iff_surjective.mp hi⟩

/-- A positive Hessian block has an actual continuous linear inverse. -/
def positiveHessianEquiv (P : T →L[ℝ] T)
    (hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s)) : T ≃L[ℝ] T :=
  (LinearEquiv.ofBijective P.toLinearMap (positive_hessian_bijective P hP)).toContinuousLinearEquiv

@[simp] theorem positiveHessianEquiv_apply (P : T →L[ℝ] T)
    (hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s)) (s : T) :
    positiveHessianEquiv P hP s = P s := rfl

/-- The analytic-response part of Lemma 5.5 for an actual real objective.
The derivative hypothesis states the mixed and eliminated Hessian blocks;
positive definiteness supplies invertibility. The response, its derivative,
stationarity and local uniqueness are conclusions. -/
theorem analytic_partial_stationary_response (F : E × T → ℝ)
    (hF : AnalyticAt ℝ F 0) (hF0 : fderiv ℝ F 0 = 0)
    (C : E →L[ℝ] T) (P : T →L[ℝ] T)
    (hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s))
    (hD : fderiv ℝ (partialGradient F) 0 =
      C.comp (ContinuousLinearMap.fst ℝ E T) -
      P.comp (ContinuousLinearMap.snd ℝ E T)) :
    ∃ θ : E → T, AnalyticAt ℝ θ 0 ∧ θ 0 = 0 ∧
      HasFDerivAt θ ((positiveHessianEquiv P hP).symm.toContinuousLinearMap.comp C) 0 ∧
      (∀ᶠ x in 𝓝 (0 : E), partialGradient F (x, θ x) = 0) ∧
      (∀ᶠ p : E × T in 𝓝 0, partialGradient F p = 0 → p.2 = θ p.1) := by
  apply analytic_stationary_response (partialGradient F) C (positiveHessianEquiv P hP)
    (partialGradient_analytic F hF)
  · simp [partialGradient, hF0]
  · convert hD using 1

/-- The mixed block is extracted from the same objective. Only the negative
eliminated Hessian and stationarity are assumptions. This is the analytic
existence and first-response conclusion of Lemma 5.5. -/
theorem analytic_response_of_negative_partial_hessian (F : E × T → ℝ)
    (hF : AnalyticAt ℝ F 0) (hF0 : fderiv ℝ F 0 = 0)
    (P : T →L[ℝ] T) (hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s))
    (hss : (fderiv ℝ (partialGradient F) 0).comp (ContinuousLinearMap.inr ℝ E T) = -P) :
    ∃ θ : E → T, AnalyticAt ℝ θ 0 ∧ θ 0 = 0 ∧
      HasFDerivAt θ ((positiveHessianEquiv P hP).symm.toContinuousLinearMap.comp
        ((fderiv ℝ (partialGradient F) 0).comp (ContinuousLinearMap.inl ℝ E T))) 0 ∧
      (∀ᶠ x in 𝓝 (0 : E), partialGradient F (x, θ x) = 0) ∧
      (∀ᶠ p : E × T in 𝓝 0, partialGradient F p = 0 → p.2 = θ p.1) := by
  refine analytic_partial_stationary_response F hF hF0
    ((fderiv ℝ (partialGradient F) 0).comp (ContinuousLinearMap.inl ℝ E T)) P hP ?_
  apply ContinuousLinearMap.ext
  intro p
  have hs := congrArg (fun L : T →L[ℝ] T => L p.2) hss
  change fderiv ℝ (partialGradient F) 0 (0, p.2) = -(P p.2) at hs
  change fderiv ℝ (partialGradient F) 0 p =
    fderiv ℝ (partialGradient F) 0 (p.1, 0) - P p.2
  calc
    _ = fderiv ℝ (partialGradient F) 0 (p.1, 0) +
        fderiv ℝ (partialGradient F) 0 (0, p.2) := by rw [← map_add]; simp
    _ = _ := by rw [hs, sub_eq_add_neg]

end Objective

end PolynomialGeometry.PartialMaximum
