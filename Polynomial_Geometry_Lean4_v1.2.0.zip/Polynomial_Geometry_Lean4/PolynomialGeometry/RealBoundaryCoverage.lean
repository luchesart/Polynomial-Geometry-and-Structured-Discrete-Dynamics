import PolynomialGeometry.RealBoundaryChart
import PolynomialGeometry.PolarCoordinates
import PolynomialGeometry.ChartTransport

/-! # The real logarithmic boundary chart is locally onto -/
noncomputable section
open Filter
open scoped Topology
namespace PolynomialGeometry.RealBoundaryCoverage
open PolynomialGeometry.RealBoundaryChart PolynomialGeometry.PolarCoordinates
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

def inverseChart (β : κ → ℂ) (q : (ι → ℂ) × (κ → ℂ)) : Coordinates (ι := ι) (κ := κ) :=
  (fun i => (q.1 i).re, ((realCoordinates β q.2).1,
    (fun i => (q.1 i).im, (realCoordinates β q.2).2)))

omit [Fintype ι] [Fintype κ] in
@[simp] theorem inverseChart_base (β : κ → ℂ) (hβ : ∀ j, β j ≠ 0) :
    inverseChart (ι := ι) β (0,β) = 0 := by
  simp only [inverseChart,realCoordinates_base β hβ]
  rfl

omit [Fintype ι] in
theorem inverseChart_continuousAt (β : κ → ℂ) (hβ : ∀ j, β j ≠ 0) :
    ContinuousAt (inverseChart (ι := ι) β) (0,β) := by
  have hp : ContinuousAt (fun q : (ι → ℂ) × (κ → ℂ) => realCoordinates β q.2) (0,β) :=
    (realCoordinates_continuous β hβ).comp_of_eq continuousAt_snd rfl
  have hr : ContinuousAt (fun q : (ι → ℂ) × (κ → ℂ) => fun i => (q.1 i).re) (0,β) :=
    continuousAt_pi.mpr fun i => Complex.continuous_re.continuousAt.comp
      ((continuous_apply i).continuousAt.comp continuousAt_fst)
  have hi : ContinuousAt (fun q : (ι → ℂ) × (κ → ℂ) => fun i => (q.1 i).im) (0,β) :=
    continuousAt_pi.mpr fun i => Complex.continuous_im.continuousAt.comp
      ((continuous_apply i).continuousAt.comp continuousAt_fst)
  exact hr.prodMk (hp.fst.prodMk (hi.prodMk hp.snd))

omit [Fintype ι] [Fintype κ] in
theorem chart_inverseChart (β : κ → ℂ) (hβ : ∀ j, β j ≠ 0)
    (q : (ι → ℂ) × (κ → ℂ)) (hq : ∀ j, q.2 j ≠ 0) :
    chart β (inverseChart β q) = q := by
  apply Prod.ext
  · ext i
    simpa only [chart,inverseChart,mul_comm Complex.I] using Complex.re_add_im (q.1 i)
  · have he := polarSources_realCoordinates β q.2 hβ hq
    simpa only [chart,inverseChart,polarSources,mul_comm Complex.I] using he

/-- The actual chart pushes the complete neighborhood filter onto the
complex ratio/source neighborhood, not only a selected parameter family. -/
theorem chart_map_nhds (β : κ → ℂ) (hβ : ∀ j, β j ≠ 0) :
    Filter.map (chart (ι := ι) β) (𝓝 0) = 𝓝 (0,β) := by
  apply PolynomialGeometry.ChartTransport.map_nhds_of_local_coverage _ _ _
    (chart_analyticAt β 0).continuousAt (chart_zero β)
  intro U hU h0
  have hc := inverseChart_continuousAt (ι := ι) β hβ
  have hmem : ∀ᶠ q in 𝓝 ((0,β) : (ι → ℂ) × (κ → ℂ)), inverseChart β q ∈ U := by
    apply hc.eventually
    rw [inverseChart_base β hβ]
    exact hU.mem_nhds h0
  have hn : ∀ᶠ q in 𝓝 ((0,β) : (ι → ℂ) × (κ → ℂ)), ∀ j, q.2 j ≠ 0 := by
    apply Filter.eventually_all.mpr
    intro j
    exact ((continuous_apply j).continuousAt.comp continuousAt_snd).eventually_ne (hβ j)
  filter_upwards [hmem,hn] with q hq hnq
  exact ⟨inverseChart β q,hq,chart_inverseChart β hβ q hnq⟩
end PolynomialGeometry.RealBoundaryCoverage
