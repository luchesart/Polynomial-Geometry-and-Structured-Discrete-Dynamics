import PolynomialGeometry.PartialMaximum
import PolynomialGeometry.SchurHessian
import PolynomialGeometry.Variations
import Mathlib.Analysis.Analytic.IteratedFDeriv
import Mathlib.Analysis.Asymptotics.Lemmas

/-!
# Analytic Taylor remainders and compensated fourth-order variation

The remainders below are obtained from analyticity of the same objective.
They are uniform in the norm topology, not assertions only along selected rays.
-/

noncomputable section
open Filter Asymptotics
open scoped Topology ContDiff

namespace PolynomialGeometry.AnalyticCompensation

variable {E S V : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup V] [NormedSpace ℝ V] [CompleteSpace V]

/-- The homogeneous Taylor term, with the usual factorial normalization. -/
def taylorTerm (f : E → V) (n : ℕ) (x : E) : V :=
  (n.factorial : ℝ)⁻¹ • iteratedFDeriv ℝ n f 0 (fun _ => x)

/-- Analyticity gives the Taylor remainder to every finite order, with the
actual iterated derivatives and a uniform norm bound. -/
theorem analytic_taylor_remainder (f : E → V) (hf : AnalyticAt ℝ f 0) (n : ℕ) :
    (fun x => f x - ∑ k ∈ Finset.range n, taylorTerm f k x)
      =O[𝓝 0] (fun x => ‖x‖ ^ n) := by
  rcases hf with ⟨p, r, hr⟩
  have hcoeff (k : ℕ) (x : E) : p k (fun _ => x) = taylorTerm f k x := by
    have h := hr.factorial_smul x k
    rw [taylorTerm, ← h]
    rw [← Nat.cast_smul_eq_nsmul ℝ, smul_smul]
    rw [inv_mul_cancel₀ (Nat.cast_ne_zero.mpr (Nat.factorial_ne_zero k)), one_smul]
  simpa only [zero_add, FormalMultilinearSeries.partialSum, hcoeff]
    using hr.hasFPowerSeriesAt.isBigO_sub_partialSum_pow n

omit [CompleteSpace V] in
@[simp] theorem taylorTerm_zero (f : E → V) (x : E) : taylorTerm f 0 x = f 0 := by
  simp [taylorTerm, iteratedFDeriv_zero_apply]

omit [CompleteSpace V] in
@[simp] theorem taylorTerm_one (f : E → V) (x : E) :
    taylorTerm f 1 x = fderiv ℝ f 0 x := by
  simp [taylorTerm, iteratedFDeriv_one_apply]

/-- A stationary analytic map with zero value starts at quadratic order. -/
theorem analytic_zero_first_order (f : E → V) (hf : AnalyticAt ℝ f 0)
    (hf0 : f 0 = 0) (hD : fderiv ℝ f 0 = 0) :
    f =O[𝓝 0] (fun x => ‖x‖ ^ 2) := by
  simpa [Finset.sum_range_succ, hf0, hD] using analytic_taylor_remainder f hf 2

/-- The quadratic jet of an analytic map with zero constant and linear terms. -/
theorem analytic_quadratic_remainder (f : E → V) (hf : AnalyticAt ℝ f 0)
    (hf0 : f 0 = 0) (hD : fderiv ℝ f 0 = 0) :
    (fun x => f x - taylorTerm f 2 x) =O[𝓝 0] (fun x => ‖x‖ ^ 3) := by
  simpa [Finset.sum_range_succ, hf0, hD] using analytic_taylor_remainder f hf 3

omit [CompleteSpace V] in
/-- Restricting a homogeneous Taylor term to a ray gives the ordinary power. -/
theorem taylorTerm_smul (f : E → V) (n : ℕ) (c : ℝ) (x : E) :
    taylorTerm f n (c • x) = c ^ n • taylorTerm f n x := by
  unfold taylorTerm
  rw [(iteratedFDeriv ℝ n f 0).map_smul_univ (fun _ => c) (fun _ => x)]
  simp [smul_smul, mul_comm]

/-- A leading coefficient of a nonpositive function is nonpositive when
approached from the positive side. -/
theorem leading_coefficient_nonpos (f : ℝ → ℝ) (c : ℝ) (n : ℕ)
    (hrem : (fun t => f t - c * t ^ n) =o[𝓝 0] (fun t => t ^ n))
    (hmax : ∀ᶠ t in 𝓝 (0 : ℝ), f t ≤ 0) : c ≤ 0 := by
  have hp : ∀ᶠ t : ℝ in 𝓝[Set.Ioi 0] 0, 0 < t := self_mem_nhdsWithin
  have hrem' := hrem.mono (nhdsWithin_le_nhds (s := Set.Ioi (0 : ℝ)))
  have hlim := (isLittleO_iff_tendsto' (by
    filter_upwards [hp] with t ht hzero
    exact (ne_of_gt (pow_pos ht n) hzero).elim)).mp hrem'
  have hlim' : Tendsto (fun t => f t / t ^ n) (𝓝[Set.Ioi 0] 0) (𝓝 c) := by
    have h := hlim.add_const c
    rw [zero_add] at h
    apply h.congr'
    filter_upwards [hp] with t ht
    field_simp
    ring
  apply le_of_tendsto hlim'
  filter_upwards [hp, hmax.filter_mono nhdsWithin_le_nhds] with t ht hf
  exact div_nonpos_of_nonpos_of_nonneg hf (pow_nonneg ht.le n)

/-- At a local maximum with no lower-order terms, a cubic coefficient
vanishes and the fourth coefficient is nonpositive. The remainder estimate
is uniform at zero and is used on both signs. -/
theorem cubic_quartic_necessary (f : ℝ → ℝ) (c d : ℝ)
    (hrem : (fun t => f t - (c * t ^ 3 + d * t ^ 4))
      =O[𝓝 0] (fun t => ‖t‖ ^ 5))
    (hmax : ∀ᶠ t in 𝓝 (0 : ℝ), f t ≤ 0) : c = 0 ∧ d ≤ 0 := by
  have hr3 : (fun t => f t - (c * t ^ 3 + d * t ^ 4))
      =o[𝓝 0] (fun t => t ^ 3) := by
    have h := hrem.trans_isLittleO (isLittleO_norm_pow_norm_pow (by decide : 3 < 5))
    apply Asymptotics.IsLittleO.of_norm_right
    simpa only [norm_pow] using h
  have hd3 : (fun t : ℝ => d * t ^ 4) =o[𝓝 0] (fun t => t ^ 3) :=
    (isLittleO_pow_pow (by decide : 3 < 4)).const_mul_left d
  have hc3 : (fun t => f t - c * t ^ 3) =o[𝓝 0] (fun t => t ^ 3) := by
    convert hr3.add hd3 using 1
    funext t
    ring
  have hc : c ≤ 0 := leading_coefficient_nonpos f c 3 hc3 hmax
  have hcneg : -c ≤ 0 := by
    apply leading_coefficient_nonpos (fun t => f (-t)) (-c) 3
    · have h := hc3.comp_tendsto ((by simpa using (tendsto_id.neg : Tendsto (fun t : ℝ => -t) (𝓝 0) (𝓝 (-0)))) : Tendsto (fun t : ℝ => -t) (𝓝 0) (𝓝 0))
      apply Asymptotics.IsLittleO.of_neg_right
      convert h using 1 <;> ext t <;> simp only [Function.comp_apply] <;> ring
    · exact Filter.Tendsto.eventually (by simpa using (tendsto_id.neg : Tendsto (fun t : ℝ => -t) (𝓝 0) (𝓝 (-0)))) hmax
  have hc0 : c = 0 := by linarith
  refine ⟨hc0, ?_⟩
  apply leading_coefficient_nonpos f d 4
  · have hr4 := hrem.trans_isLittleO (isLittleO_norm_pow_norm_pow (by decide : 4 < 5))
    apply Asymptotics.IsLittleO.of_norm_right
    simpa only [hc0, zero_mul, zero_add, norm_pow] using hr4
  · exact hmax

/-- The first two nonzero possible Taylor orders at a flat local maximum.
The coefficients are the actual third and fourth derivatives of the analytic
function, and the fifth-order remainder is derived rather than assumed. -/
theorem analytic_local_max_cubic_quartic (f : E → ℝ) (hf : AnalyticAt ℝ f 0)
    (hf0 : f 0 = 0) (hD : fderiv ℝ f 0 = 0) (hmax : IsLocalMax f 0)
    (x : E) (hH : iteratedFDeriv ℝ 2 f 0 (fun _ => x) = 0) :
    iteratedFDeriv ℝ 3 f 0 (fun _ => x) = 0 ∧
    iteratedFDeriv ℝ 4 f 0 (fun _ => x) ≤ 0 := by
  let L := ContinuousLinearMap.toSpanSingleton ℝ x
  have hL : Tendsto (fun t : ℝ => t • x) (𝓝 0) (𝓝 (0 : E)) := by
    simpa using L.continuous.tendsto 0
  have hcomp := (analytic_taylor_remainder f hf 5).comp_tendsto hL
  have hbound : (fun t : ℝ => ‖t • x‖ ^ 5) =O[𝓝 0] (fun t : ℝ => ‖t‖ ^ 5) :=
    (L.isBigO_id (𝓝 0)).norm_norm.pow 5
  have hrem : (fun t : ℝ => f (t • x) -
      (taylorTerm f 3 x * t ^ 3 + taylorTerm f 4 x * t ^ 4))
        =O[𝓝 0] (fun t : ℝ => ‖t‖ ^ 5) := by
    convert hcomp.trans hbound using 1
    ext t
    simp only [Function.comp_apply, Finset.sum_range_succ, Finset.sum_range_zero,
      taylorTerm_zero, taylorTerm_one, taylorTerm_smul, hf0, hD,
      ContinuousLinearMap.zero_apply, smul_eq_mul, zero_add]
    simp [taylorTerm, hH, mul_comm]
  have hm : ∀ᶠ t : ℝ in 𝓝 0, f (t • x) ≤ 0 := by
    have h := hL.eventually hmax
    simpa only [hf0] using h
  have hc := cubic_quartic_necessary (fun t : ℝ => f (t • x))
    (taylorTerm f 3 x) (taylorTerm f 4 x) hrem hm
  dsimp [taylorTerm] at hc
  norm_num at hc
  constructor <;> linarith [hc.1, hc.2]

section MultilinearBounds
variable {W : Type*} [NormedAddCommGroup W] [NormedSpace ℝ W]

omit [NormedSpace ℝ E] [CompleteSpace V] in
/-- Multilinearity adds the orders of independently bounded inputs. -/
theorem multilinear_isBigO {n : ℕ} (A : ContinuousMultilinearMap ℝ (fun _ : Fin n => W) V)
    (g : Fin n → E → W) (m : Fin n → ℕ)
    (hg : ∀ i, (g i) =O[𝓝 0] (fun x => ‖x‖ ^ m i)) :
    (fun x => A (fun i => g i x)) =O[𝓝 0] (fun x => ‖x‖ ^ ∑ i, m i) := by
  have hb : (fun x => A (fun i => g i x)) =O[𝓝 0]
      (fun x => ∏ i, ‖g i x‖) := by
    apply IsBigO.of_bound ‖A‖
    filter_upwards [] with x
    simpa only [Real.norm_eq_abs, abs_of_nonneg (Finset.prod_nonneg (fun i _ => norm_nonneg _))]
      using A.le_opNorm (fun i => g i x)
  have hp := IsBigO.finsetProd (s := Finset.univ) (fun i _ => (hg i).norm_left)
  have hp' : (fun x => ∏ i, ‖g i x‖) =O[𝓝 0] (fun x => ‖x‖ ^ ∑ i, m i) := by
    simpa only [← Finset.prod_pow_eq_pow_sum] using hp
  exact hb.trans hp'

omit [CompleteSpace V] in
/-- A homogeneous continuous multilinear term has its indicated degree. -/
theorem multilinear_diagonal_isBigO {n : ℕ}
    (A : ContinuousMultilinearMap ℝ (fun _ : Fin n => E) V) :
    (fun x => A (fun _ => x)) =O[𝓝 0] (fun x => ‖x‖ ^ n) := by
  simpa using multilinear_isBigO A (fun _ x => x) (fun _ => 1)
    (fun _ => by simpa using (isBigO_refl (fun x : E => x) (𝓝 0)).norm_right)

omit [NormedSpace ℝ E] [CompleteSpace V] in
/-- Replacing a linear-size argument by a perturbation of order `m`
changes a degree-`n` homogeneous term only at order `n-1+m`. -/
theorem multilinear_diagonal_difference {n m : ℕ} [NeZero n]
    (A : ContinuousMultilinearMap ℝ (fun _ : Fin n => W) V)
    (g h : E → W) (hg : g =O[𝓝 0] (fun x => ‖x‖))
    (hh : h =O[𝓝 0] (fun x => ‖x‖))
    (hd : (fun x => g x - h x) =O[𝓝 0] (fun x => ‖x‖ ^ m)) :
    (fun x => A (fun _ => g x) - A (fun _ => h x))
      =O[𝓝 0] (fun x => ‖x‖ ^ (n - 1 + m)) := by
  have hb : (fun x => A (fun _ => g x) - A (fun _ => h x))
      =O[𝓝 0] (fun x => max ‖g x‖ ‖h x‖ ^ (n - 1) * ‖g x - h x‖) := by
    apply IsBigO.of_bound (‖A‖ * n)
    filter_upwards [] with x
    have := A.norm_image_sub_le (fun _ => g x) (fun _ => h x)
    simpa only [Fintype.card_fin, pi_norm_const, Pi.sub_def,
      Real.norm_eq_abs, abs_mul, abs_pow, abs_of_nonneg (norm_nonneg _),
      abs_of_nonneg (le_trans (norm_nonneg _) (le_max_left _ _)), mul_assoc] using this
  have hm : (fun x => max ‖g x‖ ‖h x‖) =O[𝓝 0] (fun x => ‖x‖) := by
    simpa only [Prod.norm_def] using (hg.prod_left hh).norm_left
  have hp := (hm.pow (n - 1)).mul hd.norm_left
  have hp' : (fun x => max ‖g x‖ ‖h x‖ ^ (n - 1) * ‖g x - h x‖)
      =O[𝓝 0] (fun x => ‖x‖ ^ (n - 1 + m)) := by
    simpa only [pow_add] using hp
  exact hb.trans hp'

omit [CompleteSpace V] in
/-- The eight terms of a cubic multilinear expansion. -/
theorem cubic_add (A : ContinuousMultilinearMap ℝ (fun _ : Fin 3 => W) V)
    (a b : W) :
    A (fun _ => a + b) =
      A ![a,a,a] + A ![a,a,b] + A ![a,b,a] + A ![a,b,b] +
      A ![b,a,a] + A ![b,a,b] + A ![b,b,a] + A ![b,b,b] := by
  have hc : (fun _ : Fin 3 => a + b) = ![a+b,a+b,a+b] := by ext i; fin_cases i <;> rfl
  rw [hc]
  simp only [Matrix.vecCons, ← ContinuousMultilinearMap.curryLeft_apply,
    map_add, ContinuousMultilinearMap.add_apply]
  abel

omit [NormedSpace ℝ E] in
/-- A symmetric cubic evaluated on a quadratic perturbation has only one
mixed term below fifth order. -/
theorem cubic_quadratic_perturbation
    (A : ContinuousMultilinearMap ℝ (fun _ : Fin 3 => W) ℝ)
    (hsym₁ : ∀ a b, A ![b,a,a] = A ![a,a,b])
    (hsym₂ : ∀ a b, A ![a,b,a] = A ![a,a,b])
    (a b : E → W) (ha : a =O[𝓝 0] (fun x => ‖x‖))
    (hb : b =O[𝓝 0] (fun x => ‖x‖ ^ 2)) :
    (fun x => A (fun _ => a x + b x) -
      (A (fun _ => a x) + 3 * A ![a x,a x,b x]))
      =O[𝓝 0] (fun x => ‖x‖ ^ 5) := by
  have h1 : (fun x => A ![a x,b x,b x]) =O[𝓝 0] (fun x => ‖x‖ ^ 5) := by
    convert multilinear_isBigO A ![a,b,b] ![1,2,2] (by
      intro i; fin_cases i
      · simpa using ha
      · exact hb
      · exact hb) using 1
    · funext x; congr 1; funext i; fin_cases i <;> rfl
  have h2 : (fun x => A ![b x,a x,b x]) =O[𝓝 0] (fun x => ‖x‖ ^ 5) := by
    convert multilinear_isBigO A ![b,a,b] ![2,1,2] (by
      intro i; fin_cases i
      · exact hb
      · simpa using ha
      · exact hb) using 1
    · funext x; congr 1; funext i; fin_cases i <;> rfl
  have h3 : (fun x => A ![b x,b x,a x]) =O[𝓝 0] (fun x => ‖x‖ ^ 5) := by
    convert multilinear_isBigO A ![b,b,a] ![2,2,1] (by
      intro i; fin_cases i
      · exact hb
      · exact hb
      · simpa using ha) using 1
    · funext x; congr 1; funext i; fin_cases i <;> rfl
  have h4 : (fun x => A ![b x,b x,b x]) =O[𝓝 0] (fun x => ‖x‖ ^ 5) := by
    have h6 := multilinear_isBigO A (fun _ => b) (fun _ => 2) (fun _ => hb)
    have h6' : (fun x => A ![b x,b x,b x]) =O[𝓝 0] (fun x => ‖x‖ ^ 6) := by
      convert h6 using 1
      · funext x; congr 1; funext i; fin_cases i <;> rfl
    exact h6'.trans (isLittleO_norm_pow_norm_pow (by decide : 5 < 6)).isBigO
  apply (h1.add h2 |>.add h3 |>.add h4).congr_left
  intro x
  rw [cubic_add, hsym₁ (a x) (b x), hsym₂ (a x) (b x)]
  have heq : (fun _ : Fin 3 => a x) = ![a x,a x,a x] := by funext i; fin_cases i <;> rfl
  rw [heq]
  ring

end MultilinearBounds

section StationaryJet
variable [NormedAddCommGroup S] [NormedSpace ℝ S] [CompleteSpace S]

/-- A flat analytic response has quadratic size and its graph has linear size. -/
theorem flat_response_bounds (θ : E → S) (hθ : AnalyticAt ℝ θ 0)
    (hθ0 : θ 0 = 0) (hDθ : fderiv ℝ θ 0 = 0) :
    θ =O[𝓝 0] (fun x => ‖x‖ ^ 2) ∧
    (fun x => (x, θ x)) =O[𝓝 0] (fun x => ‖x‖) ∧
    (fun x => ((x, θ x) : E × S) - (x, 0)) =O[𝓝 0] (fun x => ‖x‖ ^ 2) := by
  have h2 := analytic_zero_first_order θ hθ hθ0 hDθ
  have h1 : θ =O[𝓝 0] (fun x => ‖x‖) :=
    h2.trans (by simpa using (isLittleO_norm_pow_norm_pow (by decide : 1 < 2)).isBigO)
  refine ⟨h2, (isBigO_refl (fun x : E => x) (𝓝 0)).norm_right.prod_left h1, ?_⟩
  have hb := (ContinuousLinearMap.inr ℝ E S).isBigO_comp θ (𝓝 0) |>.trans h2
  convert hb using 1
  funext x
  exact Prod.ext (sub_self x) (sub_zero (θ x))

/-- The stationarity equation determines the quadratic response with a
uniform cubic remainder. The quadratic coefficient is computed from the
actual second derivative of the stationarity map. -/
theorem stationary_quadratic_jet (g : E × S → S) (hg : AnalyticAt ℝ g 0)
    (hg0 : g 0 = 0) (P : S ≃L[ℝ] S)
    (hDg : fderiv ℝ g 0 = -P.toContinuousLinearMap.comp (ContinuousLinearMap.snd ℝ E S))
    (θ : E → S) (hθ : AnalyticAt ℝ θ 0) (hθ0 : θ 0 = 0)
    (hDθ : fderiv ℝ θ 0 = 0)
    (hstat : ∀ᶠ x in 𝓝 0, g (x, θ x) = 0) :
    (fun x => θ x - (1 / 2 : ℝ) • P.symm
      (iteratedFDeriv ℝ 2 g 0 (fun _ => (x, 0))))
        =O[𝓝 0] (fun x => ‖x‖ ^ 3) := by
  rcases flat_response_bounds θ hθ hθ0 hDθ with ⟨h2, hq, hd⟩
  have hq0 : Tendsto (fun x => (x, θ x)) (𝓝 0) (𝓝 (0 : E × S)) := by
    simpa only [hθ0] using (continuousAt_id.prodMk hθ.continuousAt).tendsto
  have hrem := (analytic_taylor_remainder g hg 3).comp_tendsto hq0
  have hrem' : (fun x => g (x, θ x) -
      (-(P (θ x)) + (1 / 2 : ℝ) • iteratedFDeriv ℝ 2 g 0 (fun _ => (x, θ x))))
      =O[𝓝 0] (fun x => ‖x‖ ^ 3) := by
    have hh := hrem.trans (hq.norm_left.pow 3)
    simpa [Function.comp_def, Finset.sum_range_succ, taylorTerm,
      iteratedFDeriv_zero_apply, iteratedFDeriv_one_apply, hg0, hDg] using hh
  have hdiff := multilinear_diagonal_difference (iteratedFDeriv ℝ 2 g 0)
    (fun x => (x, θ x)) (fun x => (x, (0 : S))) hq
    ((ContinuousLinearMap.inl ℝ E S).isBigO_id (𝓝 0)).norm_right hd
  have hs : (fun x => P (θ x) -
      (1 / 2 : ℝ) • iteratedFDeriv ℝ 2 g 0 (fun _ => (x, 0)))
      =O[𝓝 0] (fun x => ‖x‖ ^ 3) := by
    have ha := hrem'.add (hdiff.const_smul_left (1 / 2 : ℝ))
    apply ha.congr' _ Filter.EventuallyEq.rfl
    filter_upwards [hstat] with x hx
    simp only [hx, zero_sub, Pi.smul_apply, smul_sub]
    abel
  have hp := (P.symm.toContinuousLinearMap.isBigO_comp _ (𝓝 0)).trans hs
  simpa only [map_sub, map_smul, ContinuousLinearEquiv.coe_coe,
    ContinuousLinearEquiv.symm_apply_apply] using hp

end StationaryJet

section ObjectiveJet
variable [NormedAddCommGroup S] [InnerProductSpace ℝ S] [FiniteDimensional ℝ S]

/-- The cubic mixed tensor represented as a vector in the eliminated space.
It is computed by differentiating the actual partial gradient twice. -/
def mixedCubic (F : E × S → ℝ) (x : E) : S :=
  iteratedFDeriv ℝ 2 (PartialMaximum.partialGradient F) 0 (fun _ => (x, 0))

/-- The partial-gradient definition gives exactly the article's cubic tensor
pairing, rather than introducing an independent tensor as input. -/
theorem mixedCubic_pairing (F : E × S → ℝ) (hF : AnalyticAt ℝ F 0)
    (x : E) (s : S) :
    inner ℝ (mixedCubic F x) s =
      iteratedFDeriv ℝ 3 F 0 ![(x,0), (x,0), (0,s)] := by
  have hd := (PartialMaximum.partialGradientMap (E := E) (T := S)).iteratedFDeriv_comp_left
    (n := ⊤) hF.fderiv.contDiffAt (i := 2) (by simp)
  have hd' := congrArg (fun A => A (fun _ => ((x, 0) : E × S))) hd
  change mixedCubic F x = PartialMaximum.partialGradientMap
    (iteratedFDeriv ℝ 2 (fderiv ℝ F) 0 (fun _ => (x, 0))) at hd'
  rw [hd']
  change inner ℝ ((InnerProductSpace.toDual ℝ S).symm
    ((iteratedFDeriv ℝ 2 (fderiv ℝ F) 0 (fun _ => (x, 0))).comp
      (ContinuousLinearMap.inr ℝ E S))) s = _
  rw [InnerProductSpace.toDual_symm_apply]
  conv_rhs => rw [iteratedFDeriv_succ_apply_right]
  change (iteratedFDeriv ℝ 2 (fderiv ℝ F) 0 (fun _ => (x, 0))) (0, s) = _
  have hv : Fin.init (![(x, (0 : S)), (x, 0), ((0 : E), s)]) = (fun _ : Fin 2 => (x, 0)) := by
    funext i
    fin_cases i <;> rfl
  rw [hv]
  rfl

omit [FiniteDimensional ℝ S] in
/-- Actual third derivatives have the two symmetries needed in the
fourth-order substitution. -/
theorem cubic_derivative_symmetries (F : E × S → ℝ) (hF : AnalyticAt ℝ F 0) :
    (∀ a b, iteratedFDeriv ℝ 3 F 0 ![b,a,a] = iteratedFDeriv ℝ 3 F 0 ![a,a,b]) ∧
    (∀ a b, iteratedFDeriv ℝ 3 F 0 ![a,b,a] = iteratedFDeriv ℝ 3 F 0 ![a,a,b]) := by
  constructor
  · intro a b
    have h := hF.contDiffAt.iteratedFDeriv_comp_perm ![a,a,b] (Equiv.swap 0 2)
    convert h using 1
    congr 1
    funext i
    fin_cases i <;> simp [Equiv.swap_apply_def]
  · intro a b
    have h := hF.contDiffAt.iteratedFDeriv_comp_perm ![a,a,b] (Equiv.swap 1 2)
    convert h using 1
    congr 1
    funext i
    fin_cases i <;> simp [Equiv.swap_apply_def]

/-- Substituting a flat analytic response in the actual objective leaves
only the pure cubic, pure quartic and the quadratic/cubic eliminated terms
through order four. All discarded terms have a uniform fifth-order bound. -/
theorem objective_flat_graph_expansion (F : E × S → ℝ) (hF : AnalyticAt ℝ F 0)
    (hF0 : F 0 = 0) (hDF : fderiv ℝ F 0 = 0) (P : S →L[ℝ] S)
    (hH : ∀ u v : E × S, fderiv ℝ (fderiv ℝ F) 0 u v = -inner ℝ u.2 (P v.2))
    (θ : E → S) (hθ : AnalyticAt ℝ θ 0) (hθ0 : θ 0 = 0)
    (hDθ : fderiv ℝ θ 0 = 0) :
    (fun x => F (x, θ x) -
      ((1 / 6 : ℝ) * iteratedFDeriv ℝ 3 F 0 (fun _ => (x, 0)) +
       (1 / 24 : ℝ) * iteratedFDeriv ℝ 4 F 0 (fun _ => (x, 0)) -
       (1 / 2 : ℝ) * inner ℝ (θ x) (P (θ x)) +
       (1 / 2 : ℝ) * inner ℝ (mixedCubic F x) (θ x)))
        =O[𝓝 0] (fun x => ‖x‖ ^ 5) := by
  rcases flat_response_bounds θ hθ hθ0 hDθ with ⟨h2,hq,hd⟩
  have hq0 : Tendsto (fun x => (x, θ x)) (𝓝 0) (𝓝 (0 : E × S)) := by
    simpa only [hθ0] using (continuousAt_id.prodMk hθ.continuousAt).tendsto
  have ha : (fun x : E => (x, (0 : S))) =O[𝓝 0] (fun x => ‖x‖) :=
    ((ContinuousLinearMap.inl ℝ E S).isBigO_id (𝓝 0)).norm_right
  have hb : (fun x => ((0 : E), θ x)) =O[𝓝 0] (fun x => ‖x‖ ^ 2) :=
    ((ContinuousLinearMap.inr ℝ E S).isBigO_comp θ (𝓝 0)).trans h2
  have hrem := ((analytic_taylor_remainder F hF 5).comp_tendsto hq0).trans (hq.norm_left.pow 5)
  have hsym := cubic_derivative_symmetries F hF
  have h3 := cubic_quadratic_perturbation (iteratedFDeriv ℝ 3 F 0)
    hsym.1 hsym.2 (fun x => (x, (0 : S))) (fun x => ((0 : E), θ x)) ha hb
  have h4 := multilinear_diagonal_difference (iteratedFDeriv ℝ 4 F 0)
    (fun x => (x, θ x)) (fun x => (x, (0 : S))) hq ha hd
  have hh := (hrem.add (h3.const_mul_left (1 / 6 : ℝ))).add
    (h4.const_mul_left (1 / 24 : ℝ))
  apply hh.congr_left
  intro x
  have hHq : iteratedFDeriv ℝ 2 F 0 (fun _ => (x, θ x)) =
      -inner ℝ (θ x) (P (θ x)) := by
    rw [iteratedFDeriv_two_apply]
    exact hH (x, θ x) (x, θ x)
  have hqeq : ((x, (0 : S)) + ((0 : E), θ x)) = (x, θ x) := by simp
  simp only [Function.comp_apply, Finset.sum_range_succ, Finset.sum_range_zero,
    taylorTerm, iteratedFDeriv_zero_apply, iteratedFDeriv_one_apply, hF0, hDF,
    ContinuousLinearMap.zero_apply, hqeq, hHq, mixedCubic_pairing F hF x (θ x)]
  norm_num
  ring

omit [NormedSpace ℝ E] [FiniteDimensional ℝ S] in
/-- Inner products add the orders of their two factors. -/
theorem inner_isBigO (f g : E → S) (m n : ℕ)
    (hf : f =O[𝓝 0] (fun x => ‖x‖ ^ m))
    (hg : g =O[𝓝 0] (fun x => ‖x‖ ^ n)) :
    (fun x => inner ℝ (f x) (g x)) =O[𝓝 0] (fun x => ‖x‖ ^ (m+n)) := by
  have hb : (fun x => inner ℝ (f x) (g x)) =O[𝓝 0] (fun x => ‖f x‖ * ‖g x‖) := by
    apply IsBigO.of_bound 1
    filter_upwards [] with x
    simpa only [one_mul, Real.norm_eq_abs, abs_mul, abs_of_nonneg (norm_nonneg _)]
      using norm_inner_le_norm (𝕜 := ℝ) (f x) (g x)
  have hp := hf.norm_left.mul hg.norm_left
  exact hb.trans (by simpa only [pow_add] using hp)

/-- The stationary-response substitution produces the compensated quartic
with the exact coefficient one eighth and a genuine fifth-order remainder. -/
theorem compensated_graph_expansion (F : E × S → ℝ) (hF : AnalyticAt ℝ F 0)
    (hF0 : F 0 = 0) (hDF : fderiv ℝ F 0 = 0) (P : S ≃L[ℝ] S)
    (hP : ∀ s t : S, inner ℝ s (P t) = inner ℝ (P s) t)
    (hH : ∀ u v : E × S, fderiv ℝ (fderiv ℝ F) 0 u v = -inner ℝ u.2 (P v.2))
    (hgD : fderiv ℝ (PartialMaximum.partialGradient F) 0 =
      -P.toContinuousLinearMap.comp (ContinuousLinearMap.snd ℝ E S))
    (θ : E → S) (hθ : AnalyticAt ℝ θ 0) (hθ0 : θ 0 = 0)
    (hDθ : fderiv ℝ θ 0 = 0)
    (hstat : ∀ᶠ x in 𝓝 0, PartialMaximum.partialGradient F (x, θ x) = 0) :
    ((fun x => θ x - (1 / 2 : ℝ) • P.symm (mixedCubic F x))
        =O[𝓝 0] (fun x => ‖x‖ ^ 3)) ∧
    ((fun x => F (x, θ x) -
      ((1 / 6 : ℝ) * iteratedFDeriv ℝ 3 F 0 (fun _ => (x, 0)) +
       (1 / 24 : ℝ) * iteratedFDeriv ℝ 4 F 0 (fun _ => (x, 0)) +
       (1 / 8 : ℝ) * inner ℝ (mixedCubic F x) (P.symm (mixedCubic F x))))
        =O[𝓝 0] (fun x => ‖x‖ ^ 5)) := by
  have hg0 : PartialMaximum.partialGradient F 0 = 0 := by
    simp [PartialMaximum.partialGradient, hDF]
  have hjet := stationary_quadratic_jet (PartialMaximum.partialGradient F)
    (PartialMaximum.partialGradient_analytic F hF) hg0 P hgD θ hθ hθ0 hDθ hstat
  change (fun x => θ x - (1 / 2 : ℝ) • P.symm (mixedCubic F x))
    =O[𝓝 0] (fun x => ‖x‖ ^ 3) at hjet
  refine ⟨hjet, ?_⟩
  let e : E → S := fun x => θ x - (1 / 2 : ℝ) • P.symm (mixedCubic F x)
  have hPe : (fun x => P (e x)) =O[𝓝 0] (fun x => ‖x‖ ^ 3) :=
    (P.toContinuousLinearMap.isBigO_comp e (𝓝 0)).trans hjet
  have herror := inner_isBigO e (fun x => P (e x)) 3 3 hjet hPe
  have herror5 : (fun x => inner ℝ (e x) (P (e x))) =O[𝓝 0] (fun x => ‖x‖ ^ 5) :=
    herror.trans (isLittleO_norm_pow_norm_pow (by decide : 5 < 3+3)).isBigO
  have hexp := objective_flat_graph_expansion F hF hF0 hDF P.toContinuousLinearMap
    hH θ hθ hθ0 hDθ
  have hval (t s : S) :
      -(1 / 2 : ℝ) * inner ℝ s (P s) + (1 / 2 : ℝ) * inner ℝ t s -
        (1 / 8 : ℝ) * inner ℝ t (P.symm t) =
      -(1 / 2 : ℝ) * inner ℝ (s - (1 / 2 : ℝ) • P.symm t)
        (P (s - (1 / 2 : ℝ) • P.symm t)) := by
    have hc := Variations.quadratic_complete_square P.toLinearEquiv.toLinearMap 0
      ((1 / 2 : ℝ) • t) ((1 / 2 : ℝ) • P.symm t) s hP (by simp)
    have hv := Variations.compensated_quartic_identity P.toLinearEquiv.toLinearMap
      t (P.symm t) (P.apply_symm_apply t)
    simp only [Variations.quadraticSlice, zero_add, real_inner_smul_left] at hc
    change -(1 / 2 : ℝ) * inner ℝ ((1 / 2 : ℝ) • P.symm t)
      (P ((1 / 2 : ℝ) • P.symm t)) +
      (1 / 2 : ℝ) * inner ℝ t ((1 / 2 : ℝ) • P.symm t) =
      (1 / 8 : ℝ) * inner ℝ t (P.symm t) at hv
    simp only [real_inner_smul_left] at hv
    change (1 / 2 : ℝ) * inner ℝ t s - (1 / 2 : ℝ) * inner ℝ s (P s) =
      (1 / 2 : ℝ) * inner ℝ t ((1 / 2 : ℝ) • P.symm t) -
        (1 / 2 : ℝ) * ((1 / 2 : ℝ) * inner ℝ (P.symm t)
          (P ((1 / 2 : ℝ) • P.symm t))) -
        (1 / 2 : ℝ) * inner ℝ (s - (1 / 2 : ℝ) • P.symm t)
          (P (s - (1 / 2 : ℝ) • P.symm t)) at hc
    linarith only [hc, hv]
  apply (hexp.sub (herror5.const_mul_left (1 / 2 : ℝ))).congr_left
  intro x
  have hx := hval (mixedCubic F x) (θ x)
  dsimp [e]
  change _ = _
  linarith

/-- Scaling law for the mixed cubic response vector. -/
theorem mixedCubic_smul (F : E × S → ℝ) (c : ℝ) (x : E) :
    mixedCubic F (c • x) = c ^ 2 • mixedCubic F x := by
  unfold mixedCubic
  have h := (iteratedFDeriv ℝ 2 (PartialMaximum.partialGradient F) 0).map_smul_univ
    (fun _ => c) (fun _ => ((x, 0) : E × S))
  simpa only [Prod.smul_mk, smul_zero, Finset.prod_const, Finset.card_univ, Fintype.card_fin] using h

omit [FiniteDimensional ℝ S] in
/-- Scaling law for a pure retained derivative. -/
theorem pureDerivative_smul (F : E × S → ℝ) (n : ℕ) (c : ℝ) (x : E) :
    iteratedFDeriv ℝ n F 0 (fun _ => (c • x, 0)) =
      c ^ n * iteratedFDeriv ℝ n F 0 (fun _ => (x, 0)) := by
  have h := (iteratedFDeriv ℝ n F 0).map_smul_univ
    (fun _ => c) (fun _ => ((x, 0) : E × S))
  simpa only [Prod.smul_mk, smul_zero, Finset.prod_const, Finset.card_univ,
    Fintype.card_fin, smul_eq_mul] using h

variable [FiniteDimensional ℝ E]

/-- The full nonlinear higher-order specialization: the actual negative
Hessian constructs one analytic partial maximum, determines its quadratic
response and yields the compensated quartic with uniform remainders. -/
theorem analytic_compensated_partial_maximum (F : E × S → ℝ)
    (hF : AnalyticAt ℝ F 0) (hF0 : F 0 = 0) (hDF : fderiv ℝ F 0 = 0)
    (P : S →L[ℝ] S) (hP : ∀ s : S, s ≠ 0 → 0 < inner ℝ s (P s))
    (hH : ∀ u v : E × S, fderiv ℝ (fderiv ℝ F) 0 u v = -inner ℝ u.2 (P v.2)) :
    ∃ θ : E → S, AnalyticAt ℝ θ 0 ∧ θ 0 = 0 ∧ fderiv ℝ θ 0 = 0 ∧
      AnalyticAt ℝ (fun x => F (x, θ x)) 0 ∧
      (∀ᶠ x in 𝓝 0, PartialMaximum.partialGradient F (x, θ x) = 0) ∧
      (∀ᶠ p : E × S in 𝓝 0, PartialMaximum.partialGradient F p = 0 → p.2 = θ p.1) ∧
      (∃ c : ℝ, 0 < c ∧ ∀ᶠ p : E × S in 𝓝 0,
        F p ≤ F (p.1, θ p.1) - c * ‖p.2 - θ p.1‖ ^ 2) ∧
      ((∃ᶠ p : E × S in 𝓝 0, 0 < F p) ↔
        (∃ᶠ x : E in 𝓝 0, 0 < F (x, θ x))) ∧
      ((fun x => θ x - (1 / 2 : ℝ) •
          (PartialMaximum.positiveHessianEquiv P hP).symm (mixedCubic F x))
        =O[𝓝 0] (fun x => ‖x‖ ^ 3)) ∧
      ((fun x => F (x, θ x) -
        ((1 / 6 : ℝ) * iteratedFDeriv ℝ 3 F 0 (fun _ => (x, 0)) +
         (1 / 24 : ℝ) * iteratedFDeriv ℝ 4 F 0 (fun _ => (x, 0)) +
         (1 / 8 : ℝ) * inner ℝ (mixedCubic F x)
           ((PartialMaximum.positiveHessianEquiv P hP).symm (mixedCubic F x))))
        =O[𝓝 0] (fun x => ‖x‖ ^ 5)) := by
  obtain ⟨θ, hθ, hθ0, hDθ, hG, hs, hu, hd, hp, _⟩ :=
    SchurHessian.flat_analytic_partial_maximum F hF hDF P hP hH
  have hsym : ∀ s t, inner ℝ s (P t) = inner ℝ (P s) t :=
    fun s t => (SchurHessian.eliminated_operator_symmetric F hF P hH s t).symm
  have hgd := SchurHessian.flat_partialGradient_derivative F hF P hH
  have hexp := compensated_graph_expansion F hF hF0 hDF
    (PartialMaximum.positiveHessianEquiv P hP) hsym hH hgd θ hθ hθ0 hDθ hs
  exact ⟨θ, hθ, hθ0, hDθ, hG, hs, hu, hd, hp, hexp.1, hexp.2⟩

/-- A local maximum forces the cubic tensor to vanish on every kernel ray
and the compensated quartic tensor to be nonpositive. This is obtained from
the constructed nonlinear response and its proved remainder bounds. -/
theorem analytic_kernel_necessary (F : E × S → ℝ)
    (hF : AnalyticAt ℝ F 0) (hF0 : F 0 = 0) (hDF : fderiv ℝ F 0 = 0)
    (P : S →L[ℝ] S) (hP : ∀ s : S, s ≠ 0 → 0 < inner ℝ s (P s))
    (hH : ∀ u v : E × S, fderiv ℝ (fderiv ℝ F) 0 u v = -inner ℝ u.2 (P v.2))
    (hmax : IsLocalMax F 0) (x : E) :
    iteratedFDeriv ℝ 3 F 0 (fun _ => (x, 0)) = 0 ∧
    iteratedFDeriv ℝ 4 F 0 (fun _ => (x, 0)) +
      3 * inner ℝ (mixedCubic F x)
        ((PartialMaximum.positiveHessianEquiv P hP).symm (mixedCubic F x)) ≤ 0 := by
  obtain ⟨θ, hθ, hθ0, _, _, _, _, _, _, _, he⟩ :=
    analytic_compensated_partial_maximum F hF hF0 hDF P hP hH
  let L := ContinuousLinearMap.toSpanSingleton ℝ x
  have hL : Tendsto (fun t : ℝ => t • x) (𝓝 0) (𝓝 (0 : E)) := by
    simpa using L.continuous.tendsto 0
  have hq0 : Tendsto (fun t : ℝ => (t • x, θ (t • x))) (𝓝 0) (𝓝 (0 : E × S)) := by
    have hq : Tendsto (fun y : E => (y, θ y)) (𝓝 0) (𝓝 (0 : E × S)) := by
      simpa only [hθ0] using (continuousAt_id.prodMk hθ.continuousAt).tendsto
    exact hq.comp hL
  let c := (1 / 6 : ℝ) * iteratedFDeriv ℝ 3 F 0 (fun _ => (x, 0))
  let d := (1 / 24 : ℝ) * iteratedFDeriv ℝ 4 F 0 (fun _ => (x, 0)) +
    (1 / 8 : ℝ) * inner ℝ (mixedCubic F x)
      ((PartialMaximum.positiveHessianEquiv P hP).symm (mixedCubic F x))
  have hr : (fun t : ℝ => F (t • x, θ (t • x)) - (c * t ^ 3 + d * t ^ 4))
      =O[𝓝 0] (fun t => ‖t‖ ^ 5) := by
    have hh := (he.comp_tendsto hL).trans ((L.isBigO_id (𝓝 0)).norm_norm.pow 5)
    apply hh.congr_left
    intro t
    dsimp only [Function.comp_def, c, d]
    rw [pureDerivative_smul, pureDerivative_smul, mixedCubic_smul,
      map_smul, real_inner_smul_left, real_inner_smul_right]
    ring
  have hm : ∀ᶠ t : ℝ in 𝓝 0, F (t • x, θ (t • x)) ≤ 0 := by
    simpa only [hF0] using hq0.eventually hmax
  have hc := cubic_quartic_necessary (fun t => F (t • x, θ (t • x))) c d hr hm
  dsimp [c,d] at hc
  constructor <;> linarith [hc.1, hc.2]

end ObjectiveJet

end PolynomialGeometry.AnalyticCompensation
