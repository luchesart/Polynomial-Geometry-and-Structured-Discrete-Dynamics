import PolynomialGeometry.NoisyContour

/-! # Actual contour residues in an isolated simple-root disk -/

noncomputable section
open Polynomial Complex Metric Set Real
open scoped Polynomial

namespace PolynomialGeometry.NoisyContour

/-- Counting one root with multiplicity gives a simple linear factor and a
cofactor which does not vanish anywhere in the closed disk. -/
theorem isolated_factor (P : ℂ[X]) (hP : P.Monic) (c : ℂ) (r : ℝ)
    (hbdy : ∀ z ∈ sphere c r, P.eval z ≠ 0) (hcount : diskCount P c r = 1) :
    ∃ b H, b ∈ ball c r ∧ P = (X-C b) * H ∧
      ∀ z ∈ closedBall c r, H.eval z ≠ 0 := by
  classical
  obtain ⟨b, hb⟩ := Multiset.card_eq_one.mp hcount
  have hmem : b ∈ P.roots.filter (fun z => dist z c < r) := by simp [hb]
  obtain ⟨hroot, hball⟩ := Multiset.mem_filter.mp hmem
  obtain ⟨H, hp⟩ := dvd_iff_isRoot.mpr (isRoot_of_mem_roots hroot)
  have hp0 : (X - C b) * H ≠ 0 := hp ▸ hP.ne_zero
  have hH0 := right_ne_zero_of_mul hp0
  have hf : H.roots.filter (fun z => dist z c < r) = 0 := by
    have hdec := hb
    rw [hp, roots_mul hp0, roots_X_sub_C, Multiset.filter_add,
      Multiset.filter_singleton, if_pos hball] at hdec
    apply add_left_cancel (a := ({b} : Multiset ℂ))
    simpa only [add_zero] using hdec
  refine ⟨b, H, hball, hp, ?_⟩
  intro z hz hzero
  rcases lt_or_eq_of_le (show dist z c ≤ r from hz) with hi | he
  · have hh : z ∈ H.roots.filter (fun z => dist z c < r) :=
      Multiset.mem_filter.mpr ⟨(mem_roots hH0).mpr hzero, hi⟩
    simp [hf] at hh
  · exact hbdy z he (by simp [hp, hzero])

/-- A pole at b in the disk, with zero returned when the numerator vanishes
there. This is computed from the full denominator derivative. -/
def rootResidue (A P : ℂ[X]) (a b : ℂ) : ℂ :=
  A.eval b / (((X-C a)*P).derivative.eval b)

/-- An isolated zero makes the normalized contour integral of the observed
rational function equal to its explicit residue, including cancellation. -/
theorem contour_eq_rootResidue (A P H : ℂ[X]) {a b c : ℂ} {r : ℝ}
    (hb : b ∈ ball c r) (ha : a ∉ closedBall c r) (hP : P = (X-C b)*H)
    (hH : ∀ z ∈ closedBall c r, H.eval z ≠ 0) :
    contour c r (fun z => A.eval z / ((z-a)*P.eval z)) = rootResidue A P a b := by
  have hr : 0 < r := lt_of_le_of_lt dist_nonneg hb
  let F : ℂ → ℂ := fun z => A.eval z / ((z-a)*H.eval z)
  have hna {z : ℂ} (hz : z ∈ closedBall c r) : z-a ≠ 0 :=
    sub_ne_zero.mpr (fun he => ha (he ▸ hz))
  have hdf : DifferentiableOn ℂ F (closedBall c r) :=
    A.differentiable.differentiableOn.div
      ((differentiable_id.sub_const a).differentiableOn.mul H.differentiable.differentiableOn)
      (fun z hz => mul_ne_zero (hna hz) (hH z hz))
  have hdiff := (hdf.mono closure_ball_subset_closedBall).diffContOnCl
  have hC := hdiff.two_pi_i_inv_smul_circleIntegral_sub_inv_smul hb
  have hcong := contour_congr (c := c) hr.le (f := fun z => A.eval z / ((z-a)*P.eval z))
      (g := fun z => (z-b)⁻¹ • F z) (by
    intro z _
    simp only [hP, eval_mul, eval_sub, eval_X, eval_C, F, smul_eq_mul, div_eq_mul_inv, mul_inv_rev]
    ring)
  rw [hcong]
  change (2 * Real.pi * I : ℂ)⁻¹ • circleIntegral (fun z => (z-b)⁻¹ • F z) c r = _
  rw [hC]
  simp [F, rootResidue, hP, derivative_mul]

/-- Isolating one root of the denominator polynomial yields both its unique
location in the disk and a residue computed by the normalized circle integral. -/
theorem isolated_residue (A P : ℂ[X]) (hP : P.Monic) {a c : ℂ} {r : ℝ}
    (ha : a ∉ closedBall c r) (hbd : ∀ z ∈ sphere c r, P.eval z ≠ 0)
    (hc : diskCount P c r = 1) :
    ∃ b, b ∈ ball c r ∧ P.eval b = 0 ∧
      (∀ z ∈ closedBall c r, P.eval z = 0 → z = b) ∧
      contour c r (fun z => A.eval z / ((z-a)*P.eval z)) = rootResidue A P a b := by
  obtain ⟨b, H, hb, hfac, hH⟩ := isolated_factor P hP c r hbd hc
  refine ⟨b, hb, by simp [hfac], ?_, contour_eq_rootResidue A P H hb ha hfac hH⟩
  intro z hz hzero
  rw [hfac, eval_mul, eval_sub, eval_X, eval_C, mul_eq_zero] at hzero
  exact sub_eq_zero.mp (hzero.resolve_right (hH z hz))

end PolynomialGeometry.NoisyContour
