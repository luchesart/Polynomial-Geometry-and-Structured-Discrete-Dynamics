import PolynomialGeometry.RealBoundaryChart
import PolynomialGeometry.ReconstructionRatios

/-! # Stationarity of the actual weighted logarithmic objective -/
noncomputable section
open scoped Topology BigOperators
open Filter Complex
namespace PolynomialGeometry.WeightedStationarity
open PolynomialGeometry.FeasibleReduction PolynomialGeometry.RatioCoordinates
variable {ι κ : Type*} [Fintype ι] [Nonempty ι] [Fintype κ]

def weightedLog (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (q g : ℂ) (τ : ℝ) (p : (ι → ℂ) × (κ → ℂ)) : ℂ :=
  ((τ : ℂ) / Fintype.card ι) * ∑ i, Complex.log (q⁻¹ * (p.1 i-a p)) +
    (1-τ) * Complex.log (g⁻¹ * (v p-a p))

omit [Fintype κ] in
/-- This weighted logarithm is exactly `L_v + (tau/r) sum Z_i`. -/
theorem weightedLog_eq_ratios (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (q g : ℂ) (τ : ℝ) (p : (ι → ℂ) × (κ → ℂ)) :
    weightedLog a v q g τ p = Complex.log (g⁻¹ * (v p-a p)) +
      ((τ : ℂ) / Fintype.card ι) * ∑ i, parameterLogRatios a v q g p i := by
  have hn : (Fintype.card ι : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  simp only [weightedLog, parameterLogRatios, Finset.sum_sub_distrib,
    Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  field_simp
  ring

omit [Fintype κ] in
/-- Exact logarithmic distance as weighted smooth part minus the balancing
penalty, before any local approximations. -/
theorem weightedLog_distance_identity
    (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (q g : ℂ) (D τ : ℝ) (p : (ι → ℂ) × (κ → ℂ))
    (hD : 0 < D) (hq : ‖q‖ = D) (hg : ‖g‖ = D)
    (hv : v p-a p ≠ 0) (hz : ∀ i, p.1 i-a p ≠ 0) :
    Real.log (activeDistance (a p) (v p) p.1 / D) =
      (weightedLog a v q g τ p).re -
        PolynomialGeometry.Variations.penalty τ (fun i => (parameterLogRatios a v q g p i).re) := by
  have heq := logarithmic_distance_identity (a p) (v p) p.1 q g D τ hD hq hg hv hz
  dsimp only at heq
  rw [weightedLog_eq_ratios]
  have hscalar : ((τ : ℂ) / Fintype.card ι) = ((τ / Fintype.card ι : ℝ) : ℂ) := by
    simp
  rw [hscalar, ← Complex.real_smul]
  change Real.log (activeDistance (a p) (v p) p.1 / D) =
    (Complex.log (g⁻¹ * (v p-a p)) +
      (τ / Fintype.card ι : ℝ) • ∑ i, parameterLogRatios a v q g p i).re -
      PolynomialGeometry.Variations.penalty τ (fun i => (parameterLogRatios a v q g p i).re)
  rw [heq]
  unfold PolynomialGeometry.Variations.penalty parameterLogRatios
  ring

omit [Fintype κ] in
/-- On the diagonal, the complete weighting is the two-gap expression
appearing in the free stationarity hypothesis of the article. -/
theorem weightedLog_diagonal (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (q g w : ℂ) (β : κ → ℂ) (τ : ℝ) :
    weightedLog a v q g τ ((fun _ => w),β) =
      (τ : ℂ) * Complex.log (q⁻¹ * (w-a ((fun _ => w),β))) +
      (1-τ) * Complex.log (g⁻¹ * (v ((fun _ => w),β)-a ((fun _ => w),β))) := by
  have hn : (Fintype.card ι : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  simp only [weightedLog, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  field_simp

omit [Nonempty ι] in
/-- Analyticity of the full parameter-dependent ratio map, exported for
transport between the actual forward and inverse coordinate neighborhoods. -/
theorem parameterLogRatios_analyticAt
    (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (q g w : ℂ) (β : κ → ℂ)
    (ha : AnalyticAt ℂ a ((fun _ => w),β))
    (hv : AnalyticAt ℂ v ((fun _ => w),β))
    (hq : q ≠ 0) (hg : g ≠ 0)
    (hqa : w-a ((fun _ => w),β) = q)
    (hgv : v ((fun _ => w),β)-a ((fun _ => w),β) = g) :
    AnalyticAt ℂ (parameterLogRatios a v q g) ((fun _ => w),β) := by
  apply AnalyticAt.pi
  intro i
  have hi : AnalyticAt ℂ (fun p : (ι → ℂ) × (κ → ℂ) => p.1 i) ((fun _ => w),β) :=
    ((ContinuousLinearMap.proj i : (ι → ℂ) →L[ℂ] ℂ).comp
      (ContinuousLinearMap.fst ℂ (ι → ℂ) (κ → ℂ))).analyticAt _
  exact (analyticAt_log_comp (analyticAt_const.mul (hi.sub ha)) (by simp [hqa,hq])).sub
    (analyticAt_log_comp (analyticAt_const.mul (hv.sub ha)) (by simp [hgv,hg]))

omit [Nonempty ι] in
/-- Analyticity follows from the same normalized logarithms used in the
ratio coordinates, which have argument one at the base point. -/
theorem weightedLog_analyticAt (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (q g w : ℂ) (β : κ → ℂ) (τ : ℝ)
    (ha : AnalyticAt ℂ a ((fun _ => w),β))
    (hv : AnalyticAt ℂ v ((fun _ => w),β))
    (hq : q ≠ 0) (hg : g ≠ 0)
    (hqa : w-a ((fun _ => w),β) = q)
    (hgv : v ((fun _ => w),β)-a ((fun _ => w),β) = g) :
    AnalyticAt ℂ (weightedLog a v q g τ) ((fun _ => w),β) := by
  apply AnalyticAt.add
  · apply analyticAt_const.mul
    apply Finset.analyticAt_fun_sum
    intro i _
    have hi : AnalyticAt ℂ (fun p : (ι → ℂ) × (κ → ℂ) => p.1 i) ((fun _ => w),β) :=
      ((ContinuousLinearMap.proj i : (ι → ℂ) →L[ℂ] ℂ).comp
        (ContinuousLinearMap.fst ℂ (ι → ℂ) (κ → ℂ))).analyticAt _
    exact analyticAt_log_comp (analyticAt_const.mul (hi.sub ha)) (by simp [hqa,hq])
  · exact analyticAt_const.mul (analyticAt_log_comp
      (analyticAt_const.mul (hv.sub ha)) (by simp [hgv,hg]))

omit [Nonempty ι] [Fintype κ] in
/-- Permutation symmetry of the actual marked branches passes to the
weighted objective. -/
theorem weightedLog_permutation (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (q g : ℂ) (τ : ℝ) (β : κ → ℂ)
    (ha : ∀ (σ : Equiv.Perm ι) z, a (z ∘ σ,β) = a (z,β))
    (hv : ∀ (σ : Equiv.Perm ι) z, v (z ∘ σ,β) = v (z,β)) :
    ∀ (σ : Equiv.Perm ι) z,
      weightedLog a v q g τ (z ∘ σ,β) = weightedLog a v q g τ (z,β) := by
  intro σ z
  have ha' : a ((fun i => z (σ i)),β) = a (z,β) := ha σ z
  have hv' : v ((fun i => z (σ i)),β) = v (z,β) := hv σ z
  simp only [weightedLog,Function.comp_def,ha',hv']
  rw [Equiv.sum_comp σ (fun i => Complex.log (q⁻¹ * (z i-a (z,β))))]

/-- The article's derivative-equals-zero condition supplies the full
`HasDerivAt` statement because the actual logarithmic diagonal is analytic. -/
theorem free_stationarity_hasDerivAt
    (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (q g w : ℂ) (β : κ → ℂ) (τ : ℝ)
    (ha : AnalyticAt ℂ a ((fun _ => w),β))
    (hv : AnalyticAt ℂ v ((fun _ => w),β))
    (hq : q ≠ 0) (hg : g ≠ 0)
    (hqa : w-a ((fun _ => w),β) = q)
    (hgv : v ((fun _ => w),β)-a ((fun _ => w),β) = g)
    (hfree : deriv (fun t : ℂ =>
      (τ : ℂ) * Complex.log (q⁻¹ * (t-a ((fun _ => t),β))) +
      (1-τ) * Complex.log (g⁻¹ * (v ((fun _ => t),β)-a ((fun _ => t),β)))) w = 0) :
    HasDerivAt (fun t : ℂ =>
      (τ : ℂ) * Complex.log (q⁻¹ * (t-a ((fun _ => t),β))) +
      (1-τ) * Complex.log (g⁻¹ * (v ((fun _ => t),β)-a ((fun _ => t),β)))) 0 w := by
  have han := weightedLog_analyticAt a v q g w β τ ha hv hq hg hqa hgv
  let d : ℂ →L[ℂ] (ι → ℂ) := ContinuousLinearMap.pi fun _ => ContinuousLinearMap.id ℂ ℂ
  have hdiag : AnalyticAt ℂ (fun t : ℂ => weightedLog a v q g τ ((fun _ => t),β)) w :=
    han.comp_of_eq (d.analyticAt w |>.prod analyticAt_const) rfl
  have hdiff := hdiag.differentiableAt
  simp only [weightedLog_diagonal] at hdiff
  rw [← hfree]
  exact hdiff.hasDerivAt

/-- The actual free stationarity hypothesis annihilates every free copy
direction, with no extra coordinatewise stationarity assumption. -/
theorem free_stationarity_full_differential
    (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (q g w : ℂ) (β : κ → ℂ) (τ : ℝ)
    (ha : AnalyticAt ℂ a ((fun _ => w),β))
    (hv : AnalyticAt ℂ v ((fun _ => w),β))
    (hq : q ≠ 0) (hg : g ≠ 0)
    (hqa : w-a ((fun _ => w),β) = q)
    (hgv : v ((fun _ => w),β)-a ((fun _ => w),β) = g)
    (hsa : ∀ (σ : Equiv.Perm ι) z, a (z ∘ σ,β) = a (z,β))
    (hsv : ∀ (σ : Equiv.Perm ι) z, v (z ∘ σ,β) = v (z,β))
    (hfree : HasDerivAt (fun t : ℂ =>
      (τ : ℂ) * Complex.log (q⁻¹ * (t-a ((fun _ => t),β))) +
      (1-τ) * Complex.log (g⁻¹ * (v ((fun _ => t),β)-a ((fun _ => t),β)))) 0 w) :
    fderiv ℂ (fun z : ι → ℂ => weightedLog a v q g τ (z,β)) (fun _ => w) = 0 := by
  have han := weightedLog_analyticAt a v q g w β τ ha hv hq hg hqa hgv
  apply diagonal_stationarity_gives_zero_differential _ w
    (han.comp_of_eq (analyticAt_id.prod analyticAt_const) rfl).differentiableAt
  · intro σ
    exact Filter.Eventually.of_forall (weightedLog_permutation a v q g τ β hsa hsv σ)
  · change HasDerivAt (fun t => weightedLog a v q g τ ((fun _ => t),β)) 0 w
    simpa only [weightedLog_diagonal] using hfree

omit [Nonempty ι] in
/-- A parameter-preserving inverse transfers this stationarity to the
ratio-coordinate objective. Preservation is only needed locally. -/
theorem parameter_inverse_stationarity
    (K : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (G : ((ι → ℂ) × (κ → ℂ)) → ((ι → ℂ) × (κ → ℂ)))
    (z₀ : ι → ℂ) (β : κ → ℂ)
    (hK : AnalyticAt ℂ K (z₀,β)) (hG : AnalyticAt ℂ G (0,β))
    (hG0 : G (0,β) = (z₀,β))
    (hparam : ∀ᶠ p in 𝓝 ((0,β) : (ι → ℂ) × (κ → ℂ)), (G p).2 = p.2)
    (hzero : fderiv ℂ (fun z : ι → ℂ => K (z,β)) z₀ = 0) :
    fderiv ℂ (fun Z : ι → ℂ => K (G (Z,β))) 0 = 0 := by
  let g : (ι → ℂ) → (ι → ℂ) := fun Z => (G (Z,β)).1
  have hg : AnalyticAt ℂ g 0 := analyticAt_fst.comp
    (hG.comp_of_eq (analyticAt_id.prod analyticAt_const) rfl)
  have hg0 : g 0 = z₀ := by simp [g,hG0]
  have hslice : AnalyticAt ℂ (fun z : ι → ℂ => K (z,β)) z₀ :=
    hK.comp_of_eq (analyticAt_id.prod analyticAt_const) rfl
  have hder : HasFDerivAt (fun z : ι → ℂ => K (z,β)) (0 : (ι → ℂ) →L[ℂ] ℂ) z₀ := by
    rw [← hzero]
    exact hslice.differentiableAt.hasFDerivAt
  have hcomp := stationarity_under_coordinates hder hg.differentiableAt hg0
  have hinc : ContinuousAt (fun Z : ι → ℂ => (Z,β)) 0 :=
    continuousAt_id.prodMk continuousAt_const
  have hpeq := hinc.eventually hparam
  have heq : (fun Z : ι → ℂ => K (g Z,β)) =ᶠ[𝓝 0]
      (fun Z : ι → ℂ => K (G (Z,β))) := by
    filter_upwards [hpeq] with Z hZ
    have he : (g Z,β) = G (Z,β) := by ext <;> simp [g,hZ]
    rw [he]
  exact (hcomp.congr_of_eventuallyEq heq.symm).fderiv


omit [Fintype κ] in
/-- The real chart objective equals the exact logarithmic active distance
whenever the constructed inverse satisfies its right-inverse identity. -/
theorem inverse_chart_distance_objective
    (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (G : ((ι → ℂ) × (κ → ℂ)) → ((ι → ℂ) × (κ → ℂ)))
    (q g : ℂ) (β : κ → ℂ) (D τ : ℝ)
    (p : PolynomialGeometry.RealBoundaryChart.Coordinates (ι := ι) (κ := κ))
    (hD : 0 < D) (hq : ‖q‖ = D) (hg : ‖g‖ = D)
    (hv : v (G (PolynomialGeometry.RealBoundaryChart.chart β p))-
      a (G (PolynomialGeometry.RealBoundaryChart.chart β p)) ≠ 0)
    (hz : ∀ i, (G (PolynomialGeometry.RealBoundaryChart.chart β p)).1 i-
      a (G (PolynomialGeometry.RealBoundaryChart.chart β p)) ≠ 0)
    (hrat : parameterLogRatios a v q g (G (PolynomialGeometry.RealBoundaryChart.chart β p)) =
      (PolynomialGeometry.RealBoundaryChart.chart β p).1) :
    Real.log (activeDistance
      (a (G (PolynomialGeometry.RealBoundaryChart.chart β p)))
      (v (G (PolynomialGeometry.RealBoundaryChart.chart β p)))
      (G (PolynomialGeometry.RealBoundaryChart.chart β p)).1 / D) =
      objective (PolynomialGeometry.RealBoundaryChart.smoothObjective
        (fun t => weightedLog a v q g τ (G t)) β) τ p := by
  rw [weightedLog_distance_identity a v q g D τ
    (G (PolynomialGeometry.RealBoundaryChart.chart β p)) hD hq hg hv hz]
  rw [hrat]
  have hre : (fun i => ((PolynomialGeometry.RealBoundaryChart.chart β p).1 i).re) = p.1 := by
    ext i
    simp [PolynomialGeometry.RealBoundaryChart.chart]
  rw [hre]
  rfl

omit [Fintype ι] [Nonempty ι] [Fintype κ] in
/-- Balanced inverse coordinates make all actual active distances equal. -/
theorem inverse_chart_balanced_distances_equal
    (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (G : ((ι → ℂ) × (κ → ℂ)) → ((ι → ℂ) × (κ → ℂ)))
    (q g : ℂ) (β : κ → ℂ) (D : ℝ)
    (p : PolynomialGeometry.RealBoundaryChart.Coordinates (ι := ι) (κ := κ))
    (hD : 0 < D) (hq : ‖q‖ = D) (hg : ‖g‖ = D) (hp : p.1 = 0)
    (hv : v (G (PolynomialGeometry.RealBoundaryChart.chart β p))-
      a (G (PolynomialGeometry.RealBoundaryChart.chart β p)) ≠ 0)
    (hz : ∀ i, (G (PolynomialGeometry.RealBoundaryChart.chart β p)).1 i-
      a (G (PolynomialGeometry.RealBoundaryChart.chart β p)) ≠ 0)
    (hrat : parameterLogRatios a v q g (G (PolynomialGeometry.RealBoundaryChart.chart β p)) =
      (PolynomialGeometry.RealBoundaryChart.chart β p).1) :
    ∀ i, ‖(G (PolynomialGeometry.RealBoundaryChart.chart β p)).1 i-
      a (G (PolynomialGeometry.RealBoundaryChart.chart β p))‖ =
      ‖v (G (PolynomialGeometry.RealBoundaryChart.chart β p))-
        a (G (PolynomialGeometry.RealBoundaryChart.chart β p))‖ := by
  apply active_distances_equal_of_real_ratios_zero _ _ _ q g D hD hq hg hv hz
  intro i
  change (parameterLogRatios a v q g (G (PolynomialGeometry.RealBoundaryChart.chart β p)) i).re = 0
  rw [hrat]
  simp [PolynomialGeometry.RealBoundaryChart.chart,hp]

/-- Exact local reduction for the actual logarithmic objective, using only
the scalar free stationarity hypothesis and the actual outward responses.
The source branches and parameter inverse are the constructions supplied
by the reconstruction and ratio-coordinate modules. -/
theorem weighted_boundary_reduction [Nonempty κ] [DecidableEq κ]
    (a v : ((ι → ℂ) × (κ → ℂ)) → ℂ)
    (G : ((ι → ℂ) × (κ → ℂ)) → ((ι → ℂ) × (κ → ℂ)))
    (q g w : ℂ) (β : κ → ℂ) (τ : ℝ)
    (hτ : 0 < τ) (hτ1 : τ < 1)
    (ha : AnalyticAt ℂ a ((fun _ => w),β))
    (hv : AnalyticAt ℂ v ((fun _ => w),β))
    (hq : q ≠ 0) (hg : g ≠ 0)
    (hqa : w-a ((fun _ => w),β) = q)
    (hgv : v ((fun _ => w),β)-a ((fun _ => w),β) = g)
    (hsa : ∀ (σ : Equiv.Perm ι) z, a (z ∘ σ,β) = a (z,β))
    (hsv : ∀ (σ : Equiv.Perm ι) z, v (z ∘ σ,β) = v (z,β))
    (hG : AnalyticAt ℂ G (0,β)) (hG0 : G (0,β) = ((fun _ => w),β))
    (hparam : ∀ᶠ p in 𝓝 ((0,β) : (ι → ℂ) × (κ → ℂ)), (G p).2 = p.2)
    (hfree : HasDerivAt (fun t : ℂ =>
      (τ : ℂ) * Complex.log (q⁻¹ * (t-a ((fun _ => t),β))) +
      (1-τ) * Complex.log (g⁻¹ * (v ((fun _ => t),β)-a ((fun _ => t),β)))) 0 w)
    (hr : ∀ j, 0 < fderiv ℝ
      (PolynomialGeometry.RealBoundaryChart.smoothObjective
        (fun p => weightedLog a v q g τ (G p)) β) 0 (0,(Pi.single j 1,0))) :
    arbitrarilyNearPositive
      (objective (PolynomialGeometry.RealBoundaryChart.smoothObjective
        (fun p => weightedLog a v q g τ (G p)) β) τ)
      (fun p => ∀ j, p.2.1 j ≤ 0) ↔
    arbitrarilyNearPositive (fun u : (ι → ℝ) × (κ → ℝ) =>
      (weightedLog a v q g τ (G
        (fun i => Complex.I * u.1 i,
         fun j => β j * Complex.exp (Complex.I * u.2 j)))).re) (fun _ => True) := by
  have hK := weightedLog_analyticAt a v q g w β τ ha hv hq hg hqa hgv
  have hz := free_stationarity_full_differential a v q g w β τ ha hv hq hg hqa hgv hsa hsv hfree
  have htrans := parameter_inverse_stationarity (weightedLog a v q g τ) G (fun _ => w) β
    hK hG hG0 hparam hz
  have hH : AnalyticAt ℂ (fun p => weightedLog a v q g τ (G p)) (0,β) :=
    hK.comp_of_eq hG hG0
  exact PolynomialGeometry.RealBoundaryChart.analytic_boundary_reduction _ β hτ hτ1 hH
    (PolynomialGeometry.RealBoundaryChart.balancing_derivative_zero _ β hH htrans) hr

end PolynomialGeometry.WeightedStationarity
