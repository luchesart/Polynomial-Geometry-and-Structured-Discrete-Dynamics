import Mathlib.LinearAlgebra.Matrix.Charpoly.Coeff
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.Topology.Instances.Matrix
import Mathlib.Topology.Instances.ENNReal.Lemmas
import Mathlib.Analysis.Complex.Norm
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Analysis.Normed.Module.RCLike.Real
import Mathlib.Topology.Order.Compact
import Mathlib.Tactic

/-!
# Discrete energy recovery and finite observability

This module proves the matrix and scalar dynamical lemmas used by
Corollary 4.2 of *Polynomial Geometry and Structured Discrete Dynamics*.
The matrix energy identities are over arbitrary finite complex matrices.
The source-specific construction and its spectral stability are separate
dependencies: `hasSum_outputEnergy` and `observationMatrix_injective`
explicitly take state decay as a hypothesis.

The output energy is the sum of complex squared moduli. In particular it
is the Euclidean squared norm, not the default sup norm on a function type.
-/

open scoped BigOperators ComplexConjugate ComplexOrder Topology
open Matrix Filter Polynomial

noncomputable section

namespace PolynomialGeometry.Dynamics

section DiskMap

/-- The real-centred disk automorphism used to transform reciprocal modes. -/
def diskMap (a : ℝ) (z : ℂ) : ℂ := ((a : ℂ) - z) / (1 - (a : ℂ) * z)

/-- The exact denominator-minus-numerator identity behind strict stability. -/
theorem diskMap_gap (a : ℝ) (z : ℂ) :
    Complex.normSq (1 - (a : ℂ) * z) - Complex.normSq ((a : ℂ) - z) =
      (1 - a ^ 2) * (1 - Complex.normSq z) := by
  simp only [Complex.normSq_apply, Complex.sub_re, Complex.sub_im,
    Complex.one_re, Complex.one_im, Complex.ofReal_re, Complex.ofReal_im,
    Complex.mul_re, Complex.mul_im]
  ring

theorem diskMap_denominator_ne_zero (a : ℝ) (z : ℂ)
    (ha : a ^ 2 < 1) (hz : Complex.normSq z < 1) :
    1 - (a : ℂ) * z ≠ 0 := by
  have hgap : 0 < Complex.normSq (1 - (a : ℂ) * z) -
      Complex.normSq ((a : ℂ) - z) := by
    rw [diskMap_gap]
    exact mul_pos (sub_pos.mpr ha) (sub_pos.mpr hz)
  apply Complex.normSq_pos.mp
  have := Complex.normSq_nonneg ((a : ℂ) - z)
  linarith

/-- Strict interior critical modes become strict interior transformed modes. -/
theorem diskMap_normSq_lt_one (a : ℝ) (z : ℂ)
    (ha : a ^ 2 < 1) (hz : Complex.normSq z < 1) :
    Complex.normSq (diskMap a z) < 1 := by
  have hd : 0 < Complex.normSq (1 - (a : ℂ) * z) :=
    Complex.normSq_pos.mpr (diskMap_denominator_ne_zero a z ha hz)
  rw [diskMap, Complex.normSq_div, div_lt_one hd]
  have hgap := diskMap_gap a z
  have hpos := mul_pos (sub_pos.mpr ha) (sub_pos.mpr hz)
  linarith

end DiskMap

section Matrices

variable {ι κ : Type*} [Fintype ι] [DecidableEq ι] [Fintype κ]

/-- Quadratic storage in a specified complex matrix metric. -/
def energy (E : Matrix ι ι ℂ) (x : ι → ℂ) : ℝ :=
  (star x ⬝ᵥ (E *ᵥ x)).re

/-- Squared Euclidean output norm, expressed without a norm convention ambiguity. -/
def outputEnergy (y : κ → ℂ) : ℝ := ∑ j, Complex.normSq (y j)

/-- The one-step Stein defect. -/
def defect (E T : Matrix ι ι ℂ) : Matrix ι ι ℂ := E - Tᴴ * E * T

omit [DecidableEq ι] in
@[simp] theorem energy_zero (E : Matrix ι ι ℂ) : energy E 0 = 0 := by
  simp [energy]

@[simp] theorem outputEnergy_zero : outputEnergy (0 : κ → ℂ) = 0 := by
  simp [outputEnergy]

theorem outputEnergy_nonneg (y : κ → ℂ) : 0 ≤ outputEnergy y := by
  exact Finset.sum_nonneg fun j _ => Complex.normSq_nonneg (y j)

theorem outputEnergy_eq_zero_iff (y : κ → ℂ) : outputEnergy y = 0 ↔ y = 0 := by
  constructor
  · intro h
    ext j
    have hj : Complex.normSq (y j) = 0 := by
      exact (Finset.sum_eq_zero_iff_of_nonneg
        (fun k (_ : k ∈ (Finset.univ : Finset κ)) => Complex.normSq_nonneg (y k))).mp h j
          (Finset.mem_univ j)
    exact Complex.normSq_eq_zero.mp hj
  · intro h
    simp [h]

omit [DecidableEq ι] in
theorem energy_sub (E F : Matrix ι ι ℂ) (x : ι → ℂ) :
    energy (E - F) x = energy E x - energy F x := by
  simp [energy, Matrix.sub_mulVec]

omit [DecidableEq ι] in
theorem energy_congruence (E T : Matrix ι ι ℂ) (x : ι → ℂ) :
    energy (Tᴴ * E * T) x = energy E (T *ᵥ x) := by
  unfold energy
  simp only [← Matrix.mulVec_mulVec, Matrix.dotProduct_mulVec, Matrix.star_mulVec,
    Matrix.vecMul_vecMul]

omit [DecidableEq ι] in
theorem energy_gram (C : Matrix κ ι ℂ) (x : ι → ℂ) :
    energy (Cᴴ * C) x = outputEnergy (C *ᵥ x) := by
  unfold energy outputEnergy
  rw [← Matrix.mulVec_mulVec, Matrix.dotProduct_mulVec, ← Matrix.star_mulVec]
  simp only [dotProduct, Complex.re_sum, Pi.star_apply]
  apply Finset.sum_congr rfl
  intro j _
  simp [Complex.normSq_apply, Complex.mul_re]

omit [DecidableEq ι] in
/-- The exact one-step storage/output balance follows from the matrix factorization. -/
theorem energy_step (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (hfactor : defect E T = Cᴴ * C) (x : ι → ℂ) :
    energy E x - energy E (T *ᵥ x) = outputEnergy (C *ᵥ x) := by
  calc
    energy E x - energy E (T *ᵥ x) = energy (defect E T) x := by
      rw [defect, energy_sub, energy_congruence]
    _ = outputEnergy (C *ᵥ x) := by rw [hfactor, energy_gram]

omit [DecidableEq ι] in
theorem energy_step_le (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (hfactor : defect E T = Cᴴ * C) (x : ι → ℂ) :
    energy E (T *ᵥ x) ≤ energy E x := by
  have h := energy_step E T C hfactor x
  have hn := outputEnergy_nonneg (C *ᵥ x)
  linarith

/-- Finite matrix telescoping, before imposing any stability condition. -/
theorem stein_sum (E T : Matrix ι ι ℂ) (N : ℕ) :
    (∑ k ∈ Finset.range N, (Tᴴ) ^ k * defect E T * T ^ k) =
      E - (Tᴴ) ^ N * E * T ^ N := by
  induction N with
  | zero => simp
  | succ N ih =>
      rw [Finset.sum_range_succ, ih, defect, mul_sub, sub_mul]
      rw [pow_succ (Tᴴ), pow_succ' T]
      noncomm_ring

/-- Finite cumulative output loss equals the decrease in storage. -/
theorem finite_energy_recovery (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (hfactor : defect E T = Cᴴ * C) (x : ι → ℂ) (N : ℕ) :
    (∑ k ∈ Finset.range N, outputEnergy (C *ᵥ (T ^ k *ᵥ x))) =
      energy E x - energy E (T ^ N *ᵥ x) := by
  induction N with
  | zero => simp
  | succ N ih =>
      rw [Finset.sum_range_succ, ih, pow_succ' T, ← Matrix.mulVec_mulVec]
      have h := energy_step E T C hfactor (T ^ N *ᵥ x)
      linarith

omit [DecidableEq ι] in
theorem continuous_energy (E : Matrix ι ι ℂ) : Continuous (energy E) := by
  unfold energy
  fun_prop

/-- State decay implies that the sum of all future output energies is the initial storage. -/
theorem hasSum_outputEnergy (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (hfactor : defect E T = Cᴴ * C) (x : ι → ℂ)
    (hdecay : Tendsto (fun k : ℕ => T ^ k *ᵥ x) atTop (𝓝 0)) :
    HasSum (fun k : ℕ => outputEnergy (C *ᵥ (T ^ k *ᵥ x))) (energy E x) := by
  apply (hasSum_iff_tendsto_nat_of_nonneg
    (fun k => outputEnergy_nonneg (C *ᵥ (T ^ k *ᵥ x))) (energy E x)).mpr
  simp_rw [finite_energy_recovery E T C hfactor x]
  have he : Tendsto (fun k : ℕ => energy E (T ^ k *ᵥ x)) atTop (𝓝 0) := by
    simpa using (continuous_energy E).continuousAt.tendsto.comp hdecay
  simpa using tendsto_const_nhds.sub he

theorem tsum_outputEnergy (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (hfactor : defect E T = Cᴴ * C) (x : ι → ℂ)
    (hdecay : Tendsto (fun k : ℕ => T ^ k *ᵥ x) atTop (𝓝 0)) :
    (∑' k : ℕ, outputEnergy (C *ᵥ (T ^ k *ᵥ x))) = energy E x :=
  (hasSum_outputEnergy E T C hfactor x hdecay).tsum_eq

omit [Fintype κ] in
/-- Cayley--Hamilton propagates zero output from the first `card ι` times to all times. -/
theorem zero_outputs_of_first_card [Nonempty ι]
    (T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) (x : ι → ℂ)
    (hfirst : ∀ k < Fintype.card ι, C *ᵥ (T ^ k *ᵥ x) = 0) (k : ℕ) :
    C *ᵥ (T ^ k *ᵥ x) = 0 := by
  have hc : T.charpoly ≠ 1 := by
    intro h
    have hd := congrArg Polynomial.natDegree h
    simp only [Matrix.charpoly_natDegree_eq_dim, Polynomial.natDegree_one] at hd
    exact (Nat.ne_of_gt Fintype.card_pos) hd
  have hdeg : (Polynomial.X ^ k %ₘ T.charpoly).natDegree < Fintype.card ι := by
    simpa using Polynomial.natDegree_modByMonic_lt (Polynomial.X ^ k) T.charpoly_monic hc
  rw [T.pow_eq_aeval_mod_charpoly k, Polynomial.aeval_eq_sum_range' hdeg]
  rw [Matrix.sum_mulVec, Matrix.mulVec_sum]
  apply Finset.sum_eq_zero
  intro j hj
  simp only [Matrix.smul_mulVec, Matrix.mulVec_smul]
  rw [hfirst j (Finset.mem_range.mp hj)]
  simp

/-- Positive storage and decay rule out a nonzero state with zero first `card ι` outputs. -/
theorem state_zero_of_first_card [Nonempty ι]
    (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) (hE : E.PosDef)
    (hfactor : defect E T = Cᴴ * C)
    (hdecay : ∀ x : ι → ℂ, Tendsto (fun k : ℕ => T ^ k *ᵥ x) atTop (𝓝 0))
    (x : ι → ℂ)
    (hfirst : ∀ k < Fintype.card ι, C *ᵥ (T ^ k *ᵥ x) = 0) : x = 0 := by
  have hall := zero_outputs_of_first_card T C x hfirst
  have hs := tsum_outputEnergy E T C hfactor x (hdecay x)
  simp only [hall, outputEnergy_zero, tsum_zero] at hs
  by_contra hx
  have hp : 0 < energy E x := hE.re_dotProduct_pos hx
  linarith

/-- The usual finite observability matrix, with block rows indexed by time and output. -/
def observationMatrix (T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) :
    Matrix (Fin (Fintype.card ι) × κ) ι ℂ :=
  fun p j => (C * T ^ (p.1 : ℕ)) p.2 j

omit [Fintype κ] in
theorem observationMatrix_mulVec (T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (x : ι → ℂ) (p : Fin (Fintype.card ι) × κ) :
    (observationMatrix T C *ᵥ x) p = (C *ᵥ (T ^ (p.1 : ℕ) *ᵥ x)) p.2 := by
  rw [Matrix.mulVec_mulVec]
  rfl

/-- Full column rank in its injectivity form, with decay and positive storage explicit. -/
theorem observationMatrix_injective [Nonempty ι]
    (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) (hE : E.PosDef)
    (hfactor : defect E T = Cᴴ * C)
    (hdecay : ∀ x : ι → ℂ, Tendsto (fun k : ℕ => T ^ k *ᵥ x) atTop (𝓝 0)) :
    Function.Injective (observationMatrix T C).mulVec := by
  intro x y hxy
  apply sub_eq_zero.mp
  apply state_zero_of_first_card E T C hE hfactor hdecay (x - y)
  intro k hk
  ext j
  have h := congrFun hxy (⟨k, hk⟩, j)
  simp only [observationMatrix_mulVec] at h
  simpa only [Matrix.mulVec_sub, Pi.sub_apply, Pi.zero_apply] using sub_eq_zero.mpr h

/-- The numerical rank of the finite observation matrix equals the state dimension. -/
theorem observationMatrix_rank [Nonempty ι]
    (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) (hE : E.PosDef)
    (hfactor : defect E T = Cᴴ * C)
    (hdecay : ∀ x : ι → ℂ, Tendsto (fun k : ℕ => T ^ k *ᵥ x) atTop (𝓝 0)) :
    (observationMatrix T C).rank = Fintype.card ι := by
  rw [Matrix.rank, LinearMap.finrank_range_of_inj
    (observationMatrix_injective E T C hE hfactor hdecay)]
  exact Module.finrank_fintype_fun_eq_card ℂ

theorem observation_gram_eq_sum (T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) :
    (observationMatrix T C)ᴴ * observationMatrix T C =
      ∑ k : Fin (Fintype.card ι), (C * T ^ (k : ℕ))ᴴ * (C * T ^ (k : ℕ)) := by
  ext i j
  simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, observationMatrix,
    Fintype.sum_prod_type, Matrix.sum_apply]

/-- The finite observability Gramian is the exact finite-step energy defect. -/
theorem observation_gram_eq_defect (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (hfactor : defect E T = Cᴴ * C) :
    (observationMatrix T C)ᴴ * observationMatrix T C =
      E - (Tᴴ) ^ Fintype.card ι * E * T ^ Fintype.card ι := by
  rw [observation_gram_eq_sum]
  simp only [Matrix.conjTranspose_mul, Matrix.conjTranspose_pow]
  have hs : (∑ k : Fin (Fintype.card ι),
      (Tᴴ) ^ (k : ℕ) * Cᴴ * (C * T ^ (k : ℕ))) =
      ∑ k ∈ Finset.range (Fintype.card ι),
        (Tᴴ) ^ k * defect E T * T ^ k := by
    rw [← Fin.sum_univ_eq_sum_range]
    apply Finset.sum_congr rfl
    intro k _
    rw [hfactor]
    simp only [Matrix.mul_assoc]
  rw [hs, stein_sum]

/-- The finite-step energy defect is positive definite even if one-step loss is singular. -/
theorem finite_defect_posDef [Nonempty ι]
    (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) (hE : E.PosDef)
    (hfactor : defect E T = Cᴴ * C)
    (hdecay : ∀ x : ι → ℂ, Tendsto (fun k : ℕ => T ^ k *ᵥ x) atTop (𝓝 0)) :
    (E - (Tᴴ) ^ Fintype.card ι * E * T ^ Fintype.card ι).PosDef := by
  rw [← observation_gram_eq_defect E T C hfactor]
  exact Matrix.PosDef.conjTranspose_mul_self _
    (observationMatrix_injective E T C hE hfactor hdecay)

/-- Every finite iterate is nonexpansive for a factored nonnegative loss. -/
theorem energy_pow_le (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (hfactor : defect E T = Cᴴ * C) (x : ι → ℂ) (k : ℕ) :
    energy E (T ^ k *ᵥ x) ≤ energy E x := by
  have hsum := finite_energy_recovery E T C hfactor x k
  have hn : 0 ≤ ∑ j ∈ Finset.range k, outputEnergy (C *ᵥ (T ^ j *ᵥ x)) :=
    Finset.sum_nonneg fun j _ => outputEnergy_nonneg _
  linarith

/-- Positive finite defect gives strict finite-step energy loss for every nonzero state. -/
theorem energy_card_lt [Nonempty ι]
    (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) (hE : E.PosDef)
    (hfactor : defect E T = Cᴴ * C)
    (hdecay : ∀ x : ι → ℂ, Tendsto (fun k : ℕ => T ^ k *ᵥ x) atTop (𝓝 0))
    (x : ι → ℂ) (hx : x ≠ 0) :
    energy E (T ^ Fintype.card ι *ᵥ x) < energy E x := by
  have h := (finite_defect_posDef E T C hE hfactor hdecay).re_dotProduct_pos hx
  change 0 < energy (E - (Tᴴ) ^ Fintype.card ι * E * T ^ Fintype.card ι) x at h
  rw [energy_sub, ← Matrix.conjTranspose_pow, energy_congruence] at h
  linarith

omit [DecidableEq ι] in
theorem energy_real_smul (E : Matrix ι ι ℂ) (r : ℝ) (x : ι → ℂ) :
    energy E (r • x) = r ^ 2 * energy E x := by
  simp [energy, Matrix.mulVec_smul, star_smul, smul_dotProduct, dotProduct_smul,
    Complex.real_smul, pow_two, mul_assoc]

omit [DecidableEq ι] in
/-- Compactness upgrades strict loss for every state to a uniform factor below one.
This is an existence statement; it does not identify the eigenvalue formula for the
best contraction factor displayed in the article. -/
theorem exists_uniform_energy_contraction [Nonempty ι]
    (E B : Matrix ι ι ℂ) (hE : E.PosDef)
    (hstrict : ∀ x : ι → ℂ, x ≠ 0 → energy E (B *ᵥ x) < energy E x) :
    ∃ θ : ℝ, 0 < θ ∧ θ < 1 ∧
      ∀ x : ι → ℂ, energy E (B *ᵥ x) ≤ θ * energy E x := by
  let ratio : (ι → ℂ) → ℝ := fun x => energy E (B *ᵥ x) / energy E x
  have hne : ∀ x ∈ Metric.sphere (0 : ι → ℂ) 1, x ≠ 0 := by
    intro x hx hzero
    simp [hzero] at hx
  have hnum : Continuous (fun x : ι → ℂ => energy E (B *ᵥ x)) := by
    apply (continuous_energy E).comp
    fun_prop
  have hratio : ContinuousOn ratio (Metric.sphere (0 : ι → ℂ) 1) := by
    apply hnum.continuousOn.div (continuous_energy E).continuousOn
    intro x hx
    exact ne_of_gt (hE.re_dotProduct_pos (hne x hx))
  obtain ⟨y, hy, hmax⟩ := (isCompact_sphere (0 : ι → ℂ) 1).exists_isMaxOn
    (NormedSpace.sphere_nonempty.mpr (by norm_num : (0 : ℝ) ≤ 1)) hratio
  have hypos : 0 < energy E y := hE.re_dotProduct_pos (hne y hy)
  have hrnonneg : 0 ≤ ratio y := div_nonneg
    (hE.posSemidef.re_dotProduct_nonneg (B *ᵥ y)) hypos.le
  have hrlt : ratio y < 1 := (div_lt_one hypos).mpr (hstrict y (hne y hy))
  refine ⟨(ratio y + 1) / 2, by linarith, by linarith, ?_⟩
  intro x
  by_cases hx : x = 0
  · simp [hx]
  let z : ι → ℂ := (‖x‖⁻¹ : ℝ) • x
  have hz : z ∈ Metric.sphere (0 : ι → ℂ) 1 := by
    simpa only [Metric.mem_sphere, dist_zero_right] using norm_smul_inv_norm (𝕜 := ℝ) hx
  have hzpos : 0 < energy E z := hE.re_dotProduct_pos (hne z hz)
  have hratio_bound : ratio z ≤ (ratio y + 1) / 2 := (hmax hz).trans (by linarith)
  have hbound : energy E (B *ᵥ z) ≤ ((ratio y + 1) / 2) * energy E z :=
    (div_le_iff₀ hzpos).mp hratio_bound
  dsimp [z] at hbound
  rw [Matrix.mulVec_smul, energy_real_smul, energy_real_smul] at hbound
  have hscale : 0 < (‖x‖⁻¹) ^ 2 := sq_pos_of_pos (inv_pos.mpr (norm_pos_iff.mpr hx))
  apply (mul_le_mul_iff_right₀ hscale).mp
  nlinarith [hbound]

/-- The finite observability block admits a uniform contraction factor. -/
theorem exists_energy_block_factor [Nonempty ι]
    (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) (hE : E.PosDef)
    (hfactor : defect E T = Cᴴ * C)
    (hdecay : ∀ x : ι → ℂ, Tendsto (fun k : ℕ => T ^ k *ᵥ x) atTop (𝓝 0)) :
    ∃ θ : ℝ, 0 < θ ∧ θ < 1 ∧
      ∀ x : ι → ℂ, energy E (T ^ Fintype.card ι *ᵥ x) ≤ θ * energy E x := by
  exact exists_uniform_energy_contraction E (T ^ Fintype.card ι) hE
    (energy_card_lt E T C hE hfactor hdecay)

omit [DecidableEq ι] in
/-- Every exact dissipation factor has the same rank as the energy defect. -/
theorem defect_rank_eq_output_rank (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (hfactor : defect E T = Cᴴ * C) : (defect E T).rank = C.rank := by
  rw [hfactor, Matrix.rank_conjTranspose_mul_self]

omit [DecidableEq ι] in
/-- The defect rank is a necessary lower bound for the number of output channels. -/
theorem output_dimension_lower_bound (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (hfactor : defect E T = Cᴴ * C) : (defect E T).rank ≤ Fintype.card κ := by
  rw [defect_rank_eq_output_rank E T C hfactor]
  exact Matrix.rank_le_card_height C

/-- Repeated use of any verified one-block bound yields a geometric bound on block times. -/
theorem energy_block_multiples (E T : Matrix ι ι ℂ) (d : ℕ) (θ : ℝ)
    (hθ : 0 ≤ θ)
    (hblock : ∀ x : ι → ℂ, energy E (T ^ d *ᵥ x) ≤ θ * energy E x)
    (x : ι → ℂ) (k : ℕ) :
    energy E (T ^ (d * k) *ᵥ x) ≤ θ ^ k * energy E x := by
  induction k with
  | zero => simp
  | succ k ih =>
      rw [Nat.mul_succ, Nat.add_comm (d * k) d, pow_add, ← Matrix.mulVec_mulVec]
      calc
        energy E (T ^ d *ᵥ (T ^ (d * k) *ᵥ x)) ≤
            θ * energy E (T ^ (d * k) *ᵥ x) := hblock _
        _ ≤ θ * (θ ^ k * energy E x) := mul_le_mul_of_nonneg_left ih hθ
        _ = θ ^ (k + 1) * energy E x := by rw [pow_succ']; ring

/-- The block bound extends to every time, using nonincrease between block endpoints. -/
theorem energy_block_floor (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (hfactor : defect E T = Cᴴ * C) (d : ℕ) (θ : ℝ) (hθ : 0 ≤ θ)
    (hblock : ∀ x : ι → ℂ, energy E (T ^ d *ᵥ x) ≤ θ * energy E x)
    (x : ι → ℂ) (k : ℕ) :
    energy E (T ^ k *ᵥ x) ≤ θ ^ (k / d) * energy E x := by
  calc
    energy E (T ^ k *ᵥ x) =
        energy E (T ^ (k % d) *ᵥ (T ^ (d * (k / d)) *ᵥ x)) := by
      rw [Matrix.mulVec_mulVec, ← pow_add, Nat.mod_add_div]
    _ ≤ energy E (T ^ (d * (k / d)) *ᵥ x) :=
      energy_pow_le E T C hfactor _ _
    _ ≤ θ ^ (k / d) * energy E x :=
      energy_block_multiples E T d θ hθ hblock x (k / d)

/-- The exact dissipation identity and asymptotic state decay imply geometric energy
contraction on blocks of the state dimension. -/
theorem exists_geometric_energy_bound [Nonempty ι]
    (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ) (hE : E.PosDef)
    (hfactor : defect E T = Cᴴ * C)
    (hdecay : ∀ x : ι → ℂ, Tendsto (fun k : ℕ => T ^ k *ᵥ x) atTop (𝓝 0)) :
    ∃ θ : ℝ, 0 < θ ∧ θ < 1 ∧ ∀ (x : ι → ℂ) (k : ℕ),
      energy E (T ^ k *ᵥ x) ≤ θ ^ (k / Fintype.card ι) * energy E x := by
  obtain ⟨θ, hθ, hθ1, hb⟩ := exists_energy_block_factor E T C hE hfactor hdecay
  exact ⟨θ, hθ, hθ1, energy_block_floor E T C hfactor (Fintype.card ι) θ hθ.le hb⟩

end Matrices

end PolynomialGeometry.Dynamics
