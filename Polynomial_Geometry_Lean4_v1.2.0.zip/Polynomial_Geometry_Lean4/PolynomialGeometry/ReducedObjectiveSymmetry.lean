import PolynomialGeometry.OriginalFeasibleReduction

/-! # Copy symmetry of the reduced polynomial objective

The inverse ratio chart is unique near its base point. Consequently it
commutes locally with the copy permutations that fix the boundary base.
The weighted logarithm is symmetric in the reconstructed labels, so this
equivariance survives the restriction to the balanced boundary slice.
-/

noncomputable section
open Polynomial Filter
open scoped Topology BigOperators

namespace PolynomialGeometry.ReducedObjectiveSymmetry
open CriticalReconstruction ReconstructionCompletion FullFeasibleReduction

/-- Relabel the critical and boundary coordinates independently. -/
def relabel {r s : ℕ} (σ : Equiv.Perm (Fin r))
    (π : Equiv.Perm (Fin (s + 1))) (p : Parameter r s) : Parameter r s :=
  (p.1 ∘ σ, p.2 ∘ π)

theorem relabel_continuous {r s : ℕ}
    (σ : Equiv.Perm (Fin r)) (π : Equiv.Perm (Fin (s + 1))) :
    Continuous (relabel σ π) :=
  (continuous_pi fun i => (continuous_apply (σ i)).comp continuous_fst).prodMk
    (continuous_pi fun j => (continuous_apply (π j)).comp continuous_snd)

/-- The forward logarithmic ratio chart commutes with simultaneous relabelling. -/
theorem forward_relabel {r s : ℕ} {A : ℂ[X]}
    {β : Fin (s + 1) → ℂ} {w a₀ v₀ : ℂ}
    (R : LocalReconstructionResult r s A β w a₀ v₀) (q g : ℂ)
    (σ : Equiv.Perm (Fin r)) (π : Equiv.Perm (Fin (s + 1))) (p : Parameter r s) :
    FullRatioChart.forward r s R.sourceRoot R.simpleCritical q g (relabel σ π p) =
      relabel σ π (FullRatioChart.forward r s R.sourceRoot R.simpleCritical q g p) := by
  obtain ⟨_,ha,hv⟩ := R.permutation_invariance σ π p
  apply Prod.ext
  · funext i
    simp only [relabel, FullRatioChart.forward, RatioCoordinates.parameterLogRatios,
      ha, hv, Function.comp_apply]
  · rfl

/-- The labelled weighted logarithm is unchanged by independent permutations. -/
theorem weightedLog_relabel {r s : ℕ} {A : ℂ[X]}
    {β : Fin (s + 1) → ℂ} {w a₀ v₀ : ℂ}
    (R : LocalReconstructionResult r s A β w a₀ v₀) (q g : ℂ) (τ : ℝ)
    (σ : Equiv.Perm (Fin r)) (π : Equiv.Perm (Fin (s + 1))) (p : Parameter r s) :
    WeightedStationarity.weightedLog R.sourceRoot R.simpleCritical q g τ (relabel σ π p) =
      WeightedStationarity.weightedLog R.sourceRoot R.simpleCritical q g τ p := by
  obtain ⟨_,ha,hv⟩ := R.permutation_invariance σ π p
  simp only [relabel, WeightedStationarity.weightedLog, ha, hv, Function.comp_apply]
  rw [Equiv.sum_comp σ (fun i => Complex.log (q⁻¹ * (p.1 i - R.sourceRoot p)))]

/-- The local inverse of the full ratio chart respects every permutation that
fixes the boundary base. The claim uses the same inverse as the feasible reduction. -/
theorem inverse_relabel
    (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ)
    (R : LocalReconstructionResult r s A β w a₀ v₀)
    (G : Parameter r s → Parameter r s)
    (hG : AnalyticAt ℂ G (0,β)) (hG0 : G (0,β) = ((fun _ => w),β))
    (hleft : ∀ᶠ q in 𝓝 (((fun _ => w),β) : Parameter r s),
      G (FullRatioChart.forward r s R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) q) = q)
    (hright : ∀ᶠ p in 𝓝 ((0,β) : Parameter r s),
      FullRatioChart.forward r s R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) (G p) = p)
    (σ : Equiv.Perm (Fin r)) (π : Equiv.Perm (Fin (s + 1)))
    (hβ : β ∘ π = β) :
    ∀ᶠ p in 𝓝 ((0,β) : Parameter r s), G (relabel σ π p) = relabel σ π (G p) := by
  let P := relabel σ π
  have hP0 : P ((fun _ => w),β) = ((fun _ => w),β) := Prod.ext rfl hβ
  have hPt : Tendsto P (𝓝 ((fun _ => w),β)) (𝓝 ((fun _ => w),β)) := by
    simpa only [hP0] using
      (show ContinuousAt P ((fun _ => w),β) from (relabel_continuous σ π).continuousAt).tendsto
  have hGt : Tendsto G (𝓝 (0,β)) (𝓝 ((fun _ => w),β)) := by
    simpa only [hG0] using hG.continuousAt.tendsto
  -- Apply the local left inverse at the permuted labels, then the right inverse at p.
  filter_upwards [(hPt.comp hGt).eventually hleft, hright] with p hl hr
  change G (FullRatioChart.forward r s R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀)
    (relabel σ π (G p))) = P (G p) at hl
  rw [forward_relabel,hr] at hl
  exact hl

/-- Independent permutations of the critical copies and of equal boundary
copies leave the actual reduced logarithmic objective unchanged near zero.
The chart inverse need satisfy its two inverse identities only locally. -/
theorem reducedLogObjective_permutation
    (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ)
    (R : LocalReconstructionResult r s A β w a₀ v₀)
    (G : Parameter r s → Parameter r s) (τ : ℝ)
    (hG : AnalyticAt ℂ G (0,β)) (hG0 : G (0,β) = ((fun _ => w),β))
    (hleft : ∀ᶠ q in 𝓝 (((fun _ => w),β) : Parameter r s),
      G (FullRatioChart.forward r s R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) q) = q)
    (hright : ∀ᶠ p in 𝓝 ((0,β) : Parameter r s),
      FullRatioChart.forward r s R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) (G p) = p)
    (σ : Equiv.Perm (Fin r)) (π : Equiv.Perm (Fin (s + 1)))
    (hβ : β ∘ π = β) :
    (fun u : (Fin r → ℝ) × (Fin (s + 1) → ℝ) =>
      reducedLogObjective r s R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β τ
        (u.1 ∘ σ, u.2 ∘ π)) =ᶠ[𝓝 0]
      reducedLogObjective r s R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β τ := by
  let P := relabel σ π
  let S (u : (Fin r → ℝ) × (Fin (s + 1) → ℝ)) : Parameter r s :=
    (fun i => Complex.I * u.1 i, fun j => β j * Complex.exp (Complex.I * u.2 j))
  have hcomm := inverse_relabel r s A β w a₀ v₀ R G hG hG0 hleft hright σ π hβ
  have hS : Continuous S := by
    apply Continuous.prodMk
    · apply continuous_pi
      intro i
      exact continuous_const.mul (Complex.continuous_ofReal.comp
        ((continuous_apply i).comp continuous_fst))
    · apply continuous_pi
      intro j
      exact continuous_const.mul (Complex.continuous_exp.comp
        (continuous_const.mul (Complex.continuous_ofReal.comp
          ((continuous_apply j).comp continuous_snd))))
  have hS0 : S 0 = (0,β) := by ext <;> simp [S]
  have hSt : Tendsto S (𝓝 0) (𝓝 (0,β)) := by
    simpa only [hS0] using (hS.continuousAt (x := 0)).tendsto
  filter_upwards [hSt.eventually hcomm] with u hu
  have hs : S (u.1 ∘ σ, u.2 ∘ π) = P (S u) := by
    apply Prod.ext
    · rfl
    · funext j
      change β j * Complex.exp (Complex.I * u.2 (π j)) =
        β (π j) * Complex.exp (Complex.I * u.2 (π j))
      rw [show β (π j) = β j from congrFun hβ j]
  change (WeightedStationarity.weightedLog _ _ _ _ _ (G (S (u.1 ∘ σ, u.2 ∘ π)))).re =
    (WeightedStationarity.weightedLog _ _ _ _ _ (G (S u))).re
  rw [hs,hu]
  exact congrArg Complex.re (weightedLog_relabel R (w-a₀) (v₀-a₀) τ σ π (G (S u)))

end PolynomialGeometry.ReducedObjectiveSymmetry
