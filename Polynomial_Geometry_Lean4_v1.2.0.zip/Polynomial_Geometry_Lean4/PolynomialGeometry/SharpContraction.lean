import PolynomialGeometry.SourceDynamics
import Mathlib.Analysis.Matrix.Order

/-! # The sharp finite-block contraction factor

The minimum eigenvalue is computed from the actual normalized loss matrix
`E⁻¹ᐟ² W E⁻¹ᐟ²`. Its Rayleigh bound and an attaining state are proved,
rather than included as hypotheses.
-/

noncomputable section
open Matrix PolynomialGeometry.Dynamics
open scoped ComplexOrder MatrixOrder

namespace PolynomialGeometry.SharpContraction

variable {ι : Type*} [Fintype ι] [DecidableEq ι] [Nonempty ι]

def minEigenvalue (A : Matrix ι ι ℂ) (hA : A.IsHermitian) : ℝ :=
  Finset.univ.inf' Finset.univ_nonempty hA.eigenvalues

theorem minEigenvalue_le (A : Matrix ι ι ℂ) (hA : A.IsHermitian) (j : ι) :
    minEigenvalue A hA ≤ hA.eigenvalues j :=
  Finset.inf'_le _ (Finset.mem_univ j)

theorem minEigenvalue_attained (A : Matrix ι ι ℂ) (hA : A.IsHermitian) :
    ∃ j, hA.eigenvalues j = minEigenvalue A hA := by
  obtain ⟨j, _, hj⟩ := Finset.exists_mem_eq_inf' Finset.univ_nonempty hA.eigenvalues
  exact ⟨j, hj.symm⟩

theorem minEigenvalue_pos (A : Matrix ι ι ℂ) (hA : A.PosDef) :
    0 < minEigenvalue A hA.isHermitian := by
  obtain ⟨j, hj⟩ := minEigenvalue_attained A hA.isHermitian
  rw [← hj]
  exact hA.eigenvalues_pos j

omit [Nonempty ι] in
theorem energy_scalar_identity (c : ℝ) (x : ι → ℂ) :
    energy ((c : ℂ) • (1 : Matrix ι ι ℂ)) x = c * energy 1 x := by
  simp [energy, Matrix.smul_mulVec, dotProduct_smul]

/-- The least eigenvalue gives an actual positive semidefinite difference. -/
theorem minEigenvalue_defect (A : Matrix ι ι ℂ) (hA : A.IsHermitian) :
    (A - (minEigenvalue A hA : ℂ) • (1 : Matrix ι ι ℂ)).PosSemidef := by
  let U : Matrix ι ι ℂ := hA.eigenvectorUnitary
  let D := diagonal (fun j => (hA.eigenvalues j : ℂ))
  let c := minEigenvalue A hA
  have hD : (D - (c : ℂ) • (1 : Matrix ι ι ℂ)).PosSemidef := by
    rw [show D - (c : ℂ) • (1 : Matrix ι ι ℂ) =
      diagonal (fun j => ((hA.eigenvalues j - c : ℝ) : ℂ)) by
      simp only [D, ← Matrix.diagonal_one, ← Matrix.diagonal_smul, Matrix.diagonal_sub]
      congr 1
      funext j
      simp]
    apply Matrix.posSemidef_diagonal_iff.mpr
    intro j
    exact_mod_cast sub_nonneg.mpr (minEigenvalue_le A hA j)
  have hh := hD.mul_mul_conjTranspose_same U
  have hU : U * Uᴴ = 1 := unitary.coe_mul_star_self hA.eigenvectorUnitary
  have hAD : U * D * Uᴴ = A := by
    simpa only [U, D, Function.comp_apply, RCLike.ofReal_eq_complex_ofReal,
      Matrix.star_eq_conjTranspose] using hA.spectral_theorem.symm
  simpa only [Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_smul, Matrix.mul_one,
    Matrix.smul_mul, hU, hAD] using hh

/-- The Rayleigh lower bound and an exact unit-energy minimizer. -/
theorem minEigenvalue_rayleigh (A : Matrix ι ι ℂ) (hA : A.IsHermitian) :
    (∀ x : ι → ℂ, minEigenvalue A hA * energy 1 x ≤ energy A x) ∧
    ∃ x : ι → ℂ, x ≠ 0 ∧ energy 1 x = 1 ∧ energy A x = minEigenvalue A hA := by
  constructor
  · intro x
    have hh := (minEigenvalue_defect A hA).re_dotProduct_nonneg x
    change 0 ≤ energy (A - (minEigenvalue A hA : ℂ) • 1) x at hh
    rw [energy_sub, energy_scalar_identity] at hh
    linarith
  · obtain ⟨j, hj⟩ := minEigenvalue_attained A hA
    refine ⟨hA.eigenvectorBasis j, ?_, ?_, hA.eigenvalues_eq j |>.symm.trans hj⟩
    · intro hx
      apply hA.eigenvectorBasis.orthonormal.ne_zero j
      apply PiLp.ext
      exact congrFun hx
    · change (star ⇑(hA.eigenvectorBasis j) ⬝ᵥ (1 *ᵥ ⇑(hA.eigenvectorBasis j))).re = 1
      rw [Matrix.one_mulVec, dotProduct_comm, ← EuclideanSpace.inner_eq_star_dotProduct,
        inner_self_eq_norm_sq_to_K, hA.eigenvectorBasis.orthonormal.1 j]
      norm_num

/-- The standard Hermitian inverse square root is defined by continuous
functional calculus, not by an arbitrary energy factor. -/
def inverseSquareRoot (E : Matrix ι ι ℂ) : Matrix ι ι ℂ := (CFC.sqrt E)⁻¹

def normalizedLoss (E W : Matrix ι ι ℂ) : Matrix ι ι ℂ :=
  inverseSquareRoot E * W * inverseSquareRoot E

omit [Nonempty ι] in
theorem inverseSquareRoot_posDef (E : Matrix ι ι ℂ) (hE : E.PosDef) :
    (inverseSquareRoot E).PosDef := Matrix.posDef_inv_iff.mpr hE.posDef_sqrt

omit [Nonempty ι] in
theorem inverseSquareRoot_energy_identity (E : Matrix ι ι ℂ) (hE : E.PosDef) :
    (inverseSquareRoot E)ᴴ * E * inverseSquareRoot E = 1 := by
  let Q := CFC.sqrt E
  have hQ := hE.posDef_sqrt
  have hsq : Q * Q = E := CFC.sqrt_mul_sqrt_self E hE.posSemidef.nonneg
  have hinv : (inverseSquareRoot E)ᴴ = inverseSquareRoot E :=
    (inverseSquareRoot_posDef E hE).isHermitian.eq
  rw [hinv]
  calc
    _ = inverseSquareRoot E * (Q * Q) * inverseSquareRoot E := by rw [hsq]
    _ = 1 := by
      change Q⁻¹ * (Q * Q) * Q⁻¹ = 1
      letI := hQ.isUnit.invertible
      rw [← Matrix.mul_assoc, Matrix.inv_mul_of_invertible, Matrix.one_mul,
        Matrix.mul_inv_of_invertible]

omit [Nonempty ι] in
theorem normalizedLoss_posDef (E W : Matrix ι ι ℂ) (hE : E.PosDef) (hW : W.PosDef) :
    (normalizedLoss E W).PosDef := by
  have hB := inverseSquareRoot_posDef E hE
  simpa only [normalizedLoss, hB.isHermitian.eq] using
    hW.conjTranspose_mul_mul_same (Matrix.mulVec_injective_of_isUnit hB.isUnit)

/-- The normalized least eigenvalue is exactly the generalized Rayleigh
minimum for the original energy and loss matrices. -/
theorem normalizedLoss_rayleigh (E W : Matrix ι ι ℂ) (hE : E.PosDef) (hW : W.PosDef) :
    let hK := (normalizedLoss_posDef E W hE hW).isHermitian
    let μ := minEigenvalue (normalizedLoss E W) hK
    (∀ x : ι → ℂ, μ * energy E x ≤ energy W x) ∧
    ∃ x : ι → ℂ, x ≠ 0 ∧ energy E x = 1 ∧ energy W x = μ := by
  dsimp only
  let B := inverseSquareRoot E
  have hB := inverseSquareRoot_posDef E hE
  have hBE : Bᴴ * E * B = 1 := inverseSquareRoot_energy_identity E hE
  have hBW : Bᴴ * W * B = normalizedLoss E W := by
    rw [hB.isHermitian.eq]
    rfl
  have hEenergy (y : ι → ℂ) : energy 1 y = energy E (B *ᵥ y) := by
    rw [← hBE, energy_congruence]
  have hWenergy (y : ι → ℂ) : energy (normalizedLoss E W) y = energy W (B *ᵥ y) := by
    rw [← hBW, energy_congruence]
  obtain ⟨hbound, y, hy, hyE, hyW⟩ :=
    minEigenvalue_rayleigh _ (normalizedLoss_posDef E W hE hW).isHermitian
  constructor
  · intro x
    let y := B⁻¹ *ᵥ x
    have hBy : B *ᵥ y = x := by
      dsimp only [y]
      rw [Matrix.mulVec_mulVec, Matrix.mul_nonsing_inv _
        ((Matrix.isUnit_iff_isUnit_det _).mp hB.isUnit), Matrix.one_mulVec]
    have hh := hbound y
    rw [hEenergy y, hWenergy y, hBy] at hh
    exact hh
  · refine ⟨B *ᵥ y, ?_, ?_, ?_⟩
    · intro hz
      apply hy
      exact (Matrix.mulVec_injective_of_isUnit hB.isUnit) (by simpa using hz)
    · exact (hEenergy y).symm.trans hyE
    · exact (hWenergy y).symm.trans hyW


/-- The exact factor written in the article: one minus the least
normalized-loss eigenvalue. -/
def sharpFactor (E B : Matrix ι ι ℂ) (hE : E.PosDef) (hW : (defect E B).PosDef) : ℝ :=
  1 - minEigenvalue (normalizedLoss E (defect E B))
    (normalizedLoss_posDef E (defect E B) hE hW).isHermitian

/-- The formula gives the optimal uniform contraction factor, with an
attaining state. Strict positivity requires injectivity of the transition;
without it the sharp factor can correctly be zero. -/
theorem sharpFactor_spec (E B : Matrix ι ι ℂ) (hE : E.PosDef)
    (hW : (defect E B).PosDef) :
    0 ≤ sharpFactor E B hE hW ∧ sharpFactor E B hE hW < 1 ∧
    IsLeast {c : ℝ | ∀ x : ι → ℂ, energy E (B *ᵥ x) ≤ c * energy E x}
      (sharpFactor E B hE hW) ∧
    ∃ x : ι → ℂ, x ≠ 0 ∧ energy E x = 1 ∧
      energy E (B *ᵥ x) = sharpFactor E B hE hW := by
  let μ := minEigenvalue (normalizedLoss E (defect E B))
    (normalizedLoss_posDef E (defect E B) hE hW).isHermitian
  have hμ : 0 < μ := minEigenvalue_pos _ (normalizedLoss_posDef E (defect E B) hE hW)
  obtain ⟨hb, x, hx, hEx, hWx⟩ := normalizedLoss_rayleigh E (defect E B) hE hW
  have hloss (y : ι → ℂ) : energy (defect E B) y = energy E y - energy E (B *ᵥ y) := by
    rw [defect, energy_sub, energy_congruence]
  have hθx : energy E (B *ᵥ x) = sharpFactor E B hE hW := by
    rw [hloss, hEx] at hWx
    change 1 - energy E (B *ᵥ x) = μ at hWx
    change energy E (B *ᵥ x) = 1 - μ
    linarith
  have hbound : ∀ y : ι → ℂ, energy E (B *ᵥ y) ≤ sharpFactor E B hE hW * energy E y := by
    intro y
    have hh := hb y
    rw [hloss] at hh
    change μ * energy E y ≤ energy E y - energy E (B *ᵥ y) at hh
    change energy E (B *ᵥ y) ≤ (1 - μ) * energy E y
    nlinarith
  refine ⟨?_, ?_, ⟨hbound, ?_⟩, x, hx, hEx, hθx⟩
  · rw [← hθx]
    exact hE.posSemidef.re_dotProduct_nonneg _
  · change 1 - μ < 1
    linarith
  · intro c hc
    have hh := hc x
    rwa [hθx, hEx, mul_one] at hh

/-- For an invertible transition the sharp factor lies strictly between
zero and one, as asserted for the source system in the article. -/
theorem sharpFactor_pos (E B : Matrix ι ι ℂ) (hE : E.PosDef)
    (hW : (defect E B).PosDef) (hB : IsUnit B) : 0 < sharpFactor E B hE hW := by
  obtain ⟨_, _, _, x, hx, _, hθx⟩ := sharpFactor_spec E B hE hW
  rw [← hθx]
  apply hE.re_dotProduct_pos
  intro hz
  apply hx
  exact (Matrix.mulVec_injective_of_isUnit hB) (by simpa using hz)

/-- The same sharp block factor controls every time, with the literal
floor exponent. The one-step balance supplies nonincrease between blocks. -/
theorem sharp_block_floor {κ : Type*} [Fintype κ]
    (E T : Matrix ι ι ℂ) (C : Matrix κ ι ℂ)
    (hE : E.PosDef) (hfactor : defect E T = Cᴴ * C)
    (d : ℕ) (hW : (defect E (T^d)).PosDef) (x : ι → ℂ) (k : ℕ) :
    energy E (T^k *ᵥ x) ≤
      (sharpFactor E (T^d) hE hW)^(k / d) * energy E x := by
  have hs := sharpFactor_spec E (T^d) hE hW
  exact Dynamics.energy_block_floor E T C hfactor d _ hs.1 hs.2.2.1.1 x k

/-- The article's exact sharp contraction factor, its optimality, its
strict interval and all-time estimate, derived from original source data. -/
theorem source_sharp_block_contraction (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, Complex.normSq (α j) ≤ 1)
    (hinj : Function.Injective α) :
    let E := Geometry.metric u
    let T := SourceDynamics.transition a u α
    let d := Fintype.card ι
    ∃ hW : (defect E (T^d)).PosDef,
      let θ := sharpFactor E (T^d) (Geometry.metric_posDef u) hW
      0 < θ ∧ θ < 1 ∧
      IsLeast {c : ℝ | ∀ x : ι → ℂ, energy E (T^d *ᵥ x) ≤ c * energy E x} θ ∧
      (∀ (x : ι → ℂ) (k : ℕ), energy E (T^k *ᵥ x) ≤ θ^(k / d) * energy E x) ∧
      (∃ x : ι → ℂ, x ≠ 0 ∧ energy E x = 1 ∧ energy E (T^d *ᵥ x) = θ) := by
  dsimp only
  let E := Geometry.metric u
  let T := SourceDynamics.transition a u α
  let C := SourceRank.sourceContractiveLossFactor a u α
  let d := Fintype.card ι
  have hfactor : defect E T = Cᴴ * C :=
    (SourceRank.sourceContractiveLossFactor_gram a u α ha₀ ha₁ hsep hdisk).symm
  have hdecay := SourceDynamics.states_tendsto_zero a u α ha₀ ha₁ hu hsep hdisk hinj
  have hW : (defect E (T^d)).PosDef := by
    simpa only [defect, Matrix.conjTranspose_pow] using
      Dynamics.finite_defect_posDef E T C (Geometry.metric_posDef u) hfactor hdecay
  have hT : IsUnit T := Matrix.isUnit_nonsing_inv_iff.mpr
    (Geometry.source_expansive_isUnit a u α ha₀ ha₁ hsep hdisk)
  have hs := sharpFactor_spec E (T^d) (Geometry.metric_posDef u) hW
  refine ⟨hW, sharpFactor_pos E (T^d) (Geometry.metric_posDef u) hW (hT.pow d),
    hs.2.1, hs.2.2.1, ?_, hs.2.2.2⟩
  exact sharp_block_floor E T C (Geometry.metric_posDef u) hfactor d hW

end PolynomialGeometry.SharpContraction

