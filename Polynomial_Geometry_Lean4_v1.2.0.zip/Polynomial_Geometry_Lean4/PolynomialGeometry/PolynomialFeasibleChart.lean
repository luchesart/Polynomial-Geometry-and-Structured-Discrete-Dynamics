import PolynomialGeometry.RootMargins
import PolynomialGeometry.WeightedStationarity

/-! # Actual reconstructed polynomials in the feasible distance chart

The conclusions below are derived from the algebraic identities and continuous
coefficient/root branches constructed by the reconstruction modules.
-/
noncomputable section
open scoped Topology BigOperators
open Polynomial Filter
namespace PolynomialGeometry.PolynomialFeasibleChart
open PolynomialGeometry.Factorization PolynomialGeometry.CriticalReconstruction
open PolynomialGeometry.RootMargins PolynomialGeometry.FeasibleReduction
open PolynomialGeometry.Variations

/-- Every zero of the polynomial lies in the closed unit disk. -/
def rootsInDisk (p : ℂ[X]) : Prop := ∀ z, p.IsRoot z → ‖z‖ ≤ 1

/-- Once the interior factor has a strict margin, only the displayed source
copies determine disk feasibility. -/
theorem source_disk_iff (r b : ℕ) (A : Fin r → ℂ) (α : Fin b → ℂ)
    (hA : ∀ z, (monicPolynomial r A).IsRoot z → ‖z‖ < 1) :
    rootsInDisk (monicPolynomial r A * rootPolynomial b α) ↔ ∀ j, ‖α j‖ ≤ 1 := by
  constructor
  · intro h j
    apply h (α j)
    rw [Polynomial.IsRoot, eval_mul, rootPolynomial_eval_copy, mul_zero]
  · intro h z hz
    rw [Polynomial.IsRoot, eval_mul, mul_eq_zero] at hz
    rcases hz with hAz | hαz
    · exact (hA z hAz).le
    · simp only [rootPolynomial, eval_prod, eval_sub, eval_X, eval_C,
        Finset.prod_eq_zero_iff, Finset.mem_univ, true_and, sub_eq_zero] at hαz
      obtain ⟨j,hj⟩ := hαz
      exact hj ▸ h j

/-- A continued critical point separated from the prescribed cluster is
a root of the actual residual factor. No residual-root branch is assumed. -/
theorem marked_critical_is_residual_root {E : Type*} [TopologicalSpace E]
    (r s : ℕ) (P : E → ℂ[X]) (U : E → Fin s → ℂ)
    (z : E → Fin r → ℂ) (v : E → ℂ) (x : E) (c : ℂ)
    (hz : ContinuousAt z x) (hv : ContinuousAt v x) (hc : c ≠ 0)
    (hsep : ∀ i, v x ≠ z x i)
    (hfactor : ∀ᶠ t in 𝓝 x, (P t).derivative = C c * rootPolynomial r (z t) * monicPolynomial s (U t))
    (hcritical : ∀ᶠ t in 𝓝 x, (P t).derivative.IsRoot (v t)) :
    ∀ᶠ t in 𝓝 x, (monicPolynomial s (U t)).IsRoot (v t) := by
  have hsepLocal : ∀ᶠ t in 𝓝 x, ∀ i, v t-z t i ≠ 0 := by
    apply Filter.eventually_all.mpr
    intro i
    exact (hv.sub ((continuous_apply i).continuousAt.comp hz)).eventually_ne
      (sub_ne_zero.mpr (hsep i))
  filter_upwards [hfactor,hcritical,hsepLocal] with t hFt hct hst
  have hprod : (rootPolynomial r (z t)).eval (v t) ≠ 0 := by
    simp only [rootPolynomial, eval_prod, eval_sub, eval_X, eval_C]
    exact Finset.prod_ne_zero_iff.mpr (fun i _ => hst i)
  have he := congrArg (fun Q : ℂ[X] => Q.eval (v t)) hFt
  dsimp only at he
  change (P t).derivative.eval (v t) = 0 at hct
  rw [hct, eval_mul, eval_mul, eval_C] at he
  exact (mul_eq_zero.mp he.symm).resolve_left (mul_ne_zero hc hprod)

/-- The inactive gap, source disk feasibility, and exact logarithmic
critical-distance identity all hold uniformly for the same reconstructed
polynomial family. No nearby root labels are imposed on the interior or
inactive factors. -/
theorem reconstructed_family_geometry {E : Type*} [TopologicalSpace E]
    (r s b : ℕ) [NeZero r]
    (A : E → Fin r → ℂ) (U : E → Fin (s+1) → ℂ)
    (z : E → Fin r → ℂ) (α : E → Fin b → ℂ) (a v : E → ℂ)
    (x : E) (c q g : ℂ) (D τ : ℝ)
    (hA : ContinuousAt A x) (hU : ContinuousAt U x)
    (hz : ContinuousAt z x) (ha : ContinuousAt a x) (hv : ContinuousAt v x)
    (hc : c ≠ 0) (hD : 0 < D) (hq : ‖q‖ = D) (hg : ‖g‖ = D)
    (hqa : ∀ i, z x i-a x = q) (hgv : v x-a x = g)
    (hinterior : ∀ w, (monicPolynomial r (A x)).IsRoot w → ‖w‖ < 1)
    (hvsimple : (monicPolynomial (s+1) (U x)).derivative.eval (v x) ≠ 0)
    (hvroot : (monicPolynomial (s+1) (U x)).IsRoot (v x))
    (hgap : ∀ w, (monicPolynomial (s+1) (U x)).IsRoot w → w ≠ v x → D < ‖w-a x‖)
    (hfactor : ∀ᶠ t in 𝓝 x,
      (monicPolynomial r (A t) * rootPolynomial b (α t)).derivative =
        C c * rootPolynomial r (z t) * monicPolynomial (s+1) (U t))
    (hvlocal : ∀ᶠ t in 𝓝 x, (monicPolynomial (s+1) (U t)).IsRoot (v t)) :
    ∀ᶠ t in 𝓝 x,
      (rootsInDisk (monicPolynomial r (A t) * rootPolynomial b (α t)) ↔
        ∀ j, ‖α t j‖ ≤ 1) ∧
      criticalDistance (monicPolynomial r (A t) * rootPolynomial b (α t)) (a t) =
        activeDistance (a t) (v t) (z t) ∧
      (let L := Complex.log (g⁻¹ * (v t-a t))
       let Z := fun i => Complex.log (q⁻¹ * (z t i-a t))-L
       let H := L + (τ / r : ℝ) • ∑ i, Z i
       Real.log (criticalDistance (monicPolynomial r (A t) * rootPolynomial b (α t)) (a t) / D) =
         H.re + minZero (fun i => (Z i).re) - (τ / r) * ∑ i, (Z i).re) := by
  have hq0 : q ≠ 0 := norm_ne_zero_iff.mp (hq ▸ hD.ne')
  have hg0 : g ≠ 0 := norm_ne_zero_iff.mp (hg ▸ hD.ne')
  have hactive : ContinuousAt (fun t => ‖v t-a t‖) x := (hv.sub ha).norm
  have hgap' : ∀ w, (monicPolynomial (s+1) (U x)).IsRoot w → w ≠ v x →
      ‖v x-a x‖ < ‖w-a x‖ := by
    simpa only [hgv,hg] using hgap
  have hgaplocal := inactive_gap_after_marked_root s U v a (fun t => ‖v t-a t‖) x
    hU hv ha hactive hvroot hvsimple hgap'
  have hI := interior_roots_persist r A x hA hinterior
  have hvnz : ∀ᶠ t in 𝓝 x, v t-a t ≠ 0 := (hv.sub ha).eventually_ne (hgv ▸ hg0)
  have hznz : ∀ᶠ t in 𝓝 x, ∀ i, z t i-a t ≠ 0 := by
    apply Filter.eventually_all.mpr
    intro i
    have hzi := (continuous_apply i).continuousAt.comp hz
    exact (hzi.sub ha).eventually_ne (hqa i ▸ hq0)
  filter_upwards [hfactor,hvlocal,hgaplocal,hI,hvnz,hznz] with t hFt hvt hgt hIt hvnt hznt
  have hQ := marked_root_factorization s (U t) (v t) hvt
  have hid : (monicPolynomial r (A t) * rootPolynomial b (α t)).derivative =
      C c * (X-C (v t)) * (∏ i, (X-C (z t i))) *
        monicPolynomial s (quotientCoefficients s (U t) (v t)) := by
    rw [hFt, ← hQ]
    unfold rootPolynomial
    ring
  have heq := criticalDistance_eq_active _ _ (a t) (v t) c (z t) hc hid hgt
  refine ⟨source_disk_iff r b (A t) (α t) hIt,heq,?_⟩
  rw [heq]
  simpa only [Fintype.card_fin] using
    logarithmic_distance_identity (a t) (v t) (z t) q g D τ hD hq hg hvnt hznt

end PolynomialGeometry.PolynomialFeasibleChart
