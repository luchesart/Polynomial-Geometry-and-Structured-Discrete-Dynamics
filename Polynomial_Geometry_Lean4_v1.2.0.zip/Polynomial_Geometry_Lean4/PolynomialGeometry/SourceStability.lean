import PolynomialGeometry.Compression
import PolynomialGeometry.Mobius
import Mathlib.Tactic

/-! # Strict stability from the actual source equations -/
noncomputable section
open Complex Matrix
open scoped BigOperators
namespace PolynomialGeometry.SourceStability
variable {ι : Type*} [Fintype ι] [Nonempty ι]

omit [Nonempty ι] in
/-- A diagonal source eigenvector orthogonal to a nonvanishing source vector
must be zero when all source positions are distinct. -/
theorem diagonal_unobservable_zero (α b y : ι → ℂ) (w : ℂ)
    (hα : Function.Injective α) (hb : ∀ j, b j ≠ 0)
    (he : ∀ j, α j * y j = w * y j)
    (hout : ∑ j, star (b j) * y j = 0) : y = 0 := by
  by_contra hy
  obtain ⟨j, hj⟩ : ∃ j, y j ≠ 0 := by
    by_contra h
    push_neg at h
    exact hy (funext h)
  have hjw : α j = w := mul_right_cancel₀ hj (he j)
  have hz (k : ι) (hkj : k ≠ j) : y k = 0 := by
    have hk : α k ≠ w := fun h => hkj (hα (h.trans hjw.symm))
    have hprod : (α k - w) * y k = 0 := by linear_combination he k
    exact (mul_eq_zero.mp hprod).resolve_left (sub_ne_zero.mpr hk)
  have hone : (∑ k, star (b k) * y k) = star (b j) * y j := by
    apply Finset.sum_eq_single j
    · intro k _ hkj
      rw [hz k hkj, mul_zero]
    · simp
  rw [hone] at hout
  exact hj ((mul_eq_zero.mp hout).resolve_left (star_ne_zero.mpr (hb j)))

/-- Source equations and zero output force a positive-residue source zero.
This proves strict disk inclusion without assuming a compressed spectrum. -/
theorem source_eigenvector_norm_lt_one (α b y : ι → ℂ) (w c : ℂ)
    (hα : Function.Injective α) (hb : ∀ j, b j ≠ 0)
    (hdisk : ∀ j, ‖α j‖ ≤ 1) (hy : y ≠ 0)
    (he : ∀ j, α j * y j = w * y j - b j * c)
    (hout : ∑ j, star (b j) * y j = 0) : ‖w‖ < 1 := by
  have hc : c ≠ 0 := by
    intro hc
    apply hy
    apply diagonal_unobservable_zero α b y w hα hb _ hout
    intro j
    simpa [hc] using he j
  have hsep : ∀ j, w ≠ α j := by
    intro j hj
    have hp : b j * c = 0 := by rw [hj] at he; linear_combination he j
    exact (mul_ne_zero (hb j) hc) hp
  have hyj (j : ι) : y j = b j * c / (w - α j) := by
    apply (eq_div_iff (sub_ne_zero.mpr (hsep j))).mpr
    linear_combination -(he j)
  have hsum : c * (∑ j, (normSq (b j) : ℂ) / (w - α j)) = 0 := by
    rw [Finset.mul_sum]
    convert hout using 1
    apply Finset.sum_congr rfl
    intro j _
    rw [hyj, Complex.normSq_eq_conj_mul_self]
    change c * (star (b j) * b j / (w - α j)) =
      star (b j) * (b j * c / (w - α j))
    ring
  exact Compression.source_zero_norm_lt_one α (fun j => normSq (b j)) w
    (fun j => normSq_pos.mpr (hb j)) hdisk hsep
    ((mul_eq_zero.mp hsum).resolve_left hc)

end PolynomialGeometry.SourceStability
