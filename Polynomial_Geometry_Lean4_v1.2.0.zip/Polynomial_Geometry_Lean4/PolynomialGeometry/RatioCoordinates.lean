import PolynomialGeometry.Variations
import Mathlib.Analysis.SpecialFunctions.Complex.Analytic
import Mathlib.Analysis.SpecialFunctions.Complex.LogDeriv

/-! # Actual logarithmic-ratio coordinates at a collision

The derivatives are computed from the logarithm formula and function-level
permutation invariance. No Jacobian formula is imposed as a hypothesis.
-/
noncomputable section
open Complex Filter
open scoped Topology
namespace PolynomialGeometry.RatioCoordinates
open PolynomialGeometry.Variations
variable {ι : Type*} [Fintype ι] [Nonempty ι]

/-- Universe-polymorphic composition with the analytic complex logarithm. -/
theorem analyticAt_log_comp {E : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]
    {f : E → ℂ} {x : E} (hf : AnalyticAt ℂ f x) (h : f x ∈ Complex.slitPlane) :
    AnalyticAt ℂ (fun y => Complex.log (f y)) x := (analyticAt_clog h).comp hf


/-- Permuting labelled critical copies is a continuous linear map. -/
def permute (σ : Equiv.Perm ι) : (ι → ℂ) →L[ℂ] (ι → ℂ) :=
  ContinuousLinearMap.pi fun i => ContinuousLinearMap.proj (σ i)

omit [Fintype ι] [Nonempty ι] in
@[simp] theorem permute_apply (σ : Equiv.Perm ι) (x : ι → ℂ) :
    permute σ x = x ∘ σ := rfl

omit [Nonempty ι] in
/-- Local permutation invariance passes to the actual differential at a collision. -/
theorem differential_permutation_invariant (f : (ι → ℂ) → ℂ) (w : ℂ)
    (hf : DifferentiableAt ℂ f (fun _ => w))
    (hsym : ∀ σ : Equiv.Perm ι,
      (fun z => f (z ∘ σ)) =ᶠ[𝓝 (fun _ => w)] f) :
    ∀ (σ : Equiv.Perm ι) x,
      fderiv ℂ f (fun _ => w) (x ∘ σ) = fderiv ℂ f (fun _ => w) x := by
  intro σ x
  have hc := hf.hasFDerivAt.comp (fun _ => w) (permute σ).hasFDerivAt
  have hcf : HasFDerivAt f ((fderiv ℂ f (fun _ => w)).comp (permute σ))
      (fun _ => w) := hc.congr_of_eventuallyEq (hsym σ).symm
  exact congrArg (fun L : (ι → ℂ) →L[ℂ] ℂ => L x) (hcf.unique hf.hasFDerivAt)

/-- A complex invariant functional annihilates all centered variations. -/
theorem invariant_linear_vanishes_centered (L : (ι → ℂ) →ₗ[ℂ] ℂ)
    (hperm : ∀ (σ : Equiv.Perm ι) x, L (x ∘ σ) = L x)
    (x : ι → ℂ) (hx : ∑ i, x i = 0) : L x = 0 := by
  classical
  let e : ι → ι → ℂ := fun i j => if i = j then 1 else 0
  let i₀ : ι := Classical.arbitrary ι
  have hc (i : ι) : L (e i) = L (e i₀) := by
    have he : e i ∘ Equiv.swap i i₀ = e i₀ := by
      ext k
      by_cases hk : k = i
      · subst k; simp [e, eq_comm]
      · by_cases hk' : k = i₀
        · subst k; simp [e]
        · simp [e, Equiv.swap_apply_def, hk, hk', Ne.symm hk, Ne.symm hk']
    have hh := hperm (Equiv.swap i i₀) (e i)
    rw [he] at hh
    exact hh.symm
  calc
    L x = L (∑ i, x i • e i) := congrArg L (pi_eq_sum_univ x)
    _ = ∑ i, x i * L (e i₀) := by simp [hc]
    _ = (∑ i, x i) * L (e i₀) := (Finset.sum_mul ..).symm
    _ = 0 := by rw [hx, zero_mul]

/-- The complete differential of an invariant scalar function factors through the mean. -/
theorem invariant_linear_formula (L : (ι → ℂ) →ₗ[ℂ] ℂ)
    (hperm : ∀ (σ : Equiv.Perm ι) x, L (x ∘ σ) = L x) (x : ι → ℂ) :
    L x = copyMean x * L (fun _ => 1) := by
  have hn : (Fintype.card ι : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have hz : ∑ i, (x - copyMean x • (fun _ : ι => (1 : ℂ))) i = 0 := by
    simp only [Pi.sub_apply, Pi.smul_apply, smul_eq_mul, mul_one, Finset.sum_sub_distrib,
      Finset.sum_const, Finset.card_univ, nsmul_eq_mul, copyMean]
    field_simp
    ring
  have h := invariant_linear_vanishes_centered L hperm
    (x - copyMean x • (fun _ : ι => (1 : ℂ))) hz
  simpa only [map_sub, map_smul, smul_eq_mul, sub_eq_zero] using h

/-- The actual ratio map, with logarithms normalized to vanish at the base. -/
def logRatios (a v : (ι → ℂ) → ℂ) (q g : ℂ) (z : ι → ℂ) : ι → ℂ := fun i =>
  Complex.log (q⁻¹ * (z i - a z)) - Complex.log (g⁻¹ * (v z - a z))

/-- The differential obtained by differentiating the two actual logarithms. -/
def ratioDerivative (q g : ℂ) (A V : (ι → ℂ) →L[ℂ] ℂ) :
    (ι → ℂ) →L[ℂ] (ι → ℂ) :=
  ContinuousLinearMap.pi fun i =>
    q⁻¹ • (ContinuousLinearMap.proj i - A) - g⁻¹ • (V - A)

/-- The response of the ratios to a common shift of all critical copies. -/
def commonResponse (q g : ℂ) (A V : (ι → ℂ) →L[ℂ] ℂ) : ℂ :=
  q⁻¹ * (1 - A (fun _ => 1)) - g⁻¹ * (V (fun _ => 1) - A (fun _ => 1))

omit [Nonempty ι] in
theorem hasFDerivAt_logRatios (a v : (ι → ℂ) → ℂ) (q g w : ℂ)
    (ha : DifferentiableAt ℂ a (fun _ => w))
    (hv : DifferentiableAt ℂ v (fun _ => w))
    (hq : q ≠ 0) (hg : g ≠ 0)
    (hqa : w - a (fun _ => w) = q) (hgv : v (fun _ => w) - a (fun _ => w) = g) :
    HasFDerivAt (logRatios a v q g)
      (ratioDerivative q g (fderiv ℂ a (fun _ => w)) (fderiv ℂ v (fun _ => w)))
      (fun _ => w) := by
  apply hasFDerivAt_pi.mpr
  intro i
  have h1 := (((ContinuousLinearMap.proj i : (ι → ℂ) →L[ℂ] ℂ).hasFDerivAt.sub
    ha.hasFDerivAt).const_smul q⁻¹).clog (by simp [hqa, hq])
  have h2 := ((hv.hasFDerivAt.sub ha.hasFDerivAt).const_smul g⁻¹).clog
    (by simp [hgv, hg])
  simpa only [logRatios, ratioDerivative, Pi.smul_apply, Pi.sub_apply,
    ContinuousLinearMap.proj_apply, smul_eq_mul, hqa, hgv,
    inv_mul_cancel₀ hq, inv_mul_cancel₀ hg, inv_one, one_smul] using h1.sub h2

omit [Nonempty ι] in
theorem analyticAt_logRatios (a v : (ι → ℂ) → ℂ) (q g w : ℂ)
    (ha : AnalyticAt ℂ a (fun _ => w)) (hv : AnalyticAt ℂ v (fun _ => w))
    (hq : q ≠ 0) (hg : g ≠ 0)
    (hqa : w - a (fun _ => w) = q) (hgv : v (fun _ => w) - a (fun _ => w) = g) :
    AnalyticAt ℂ (logRatios a v q g) (fun _ => w) := by
  apply AnalyticAt.pi
  intro i
  have h1 : AnalyticAt ℂ (fun z : ι → ℂ => q⁻¹ * (z i - a z)) (fun _ => w) :=
    (((ContinuousLinearMap.proj i : (ι → ℂ) →L[ℂ] ℂ).analyticAt _).sub ha).const_smul
  have h2 : AnalyticAt ℂ (fun z : ι → ℂ => g⁻¹ * (v z - a z)) (fun _ => w) :=
    (hv.sub ha).const_smul
  exact (analyticAt_log_comp h1 (by simp [hqa, hq])).sub
    (analyticAt_log_comp h2 (by simp [hgv, hg]))

/-- Permutation invariance gives exactly the claimed two mode multipliers. -/
theorem ratioDerivative_centeredCollective (q g : ℂ)
    (A V : (ι → ℂ) →L[ℂ] ℂ)
    (hA : ∀ (σ : Equiv.Perm ι) x, A (x ∘ σ) = A x)
    (hV : ∀ (σ : Equiv.Perm ι) x, V (x ∘ σ) = V x) :
    (ratioDerivative q g A V : (ι → ℂ) →ₗ[ℂ] (ι → ℂ)) =
      centeredCollectiveMap q⁻¹ (commonResponse q g A V) := by
  ext x i
  change q⁻¹ * (x i - A x) - g⁻¹ * (V x - A x) =
    q⁻¹ * (x i - copyMean x) + commonResponse q g A V * copyMean x
  have hAx : A x = copyMean x * A (fun _ => 1) :=
    invariant_linear_formula A.toLinearMap hA x
  have hVx : V x = copyMean x * V (fun _ => 1) :=
    invariant_linear_formula V.toLinearMap hV x
  rw [hAx, hVx]
  unfold commonResponse
  ring

/-- The actual analytic ratio map has a holomorphic local inverse whenever
the common response is nonzero. Its Jacobian is derived, not assumed. -/
theorem logRatios_local_inverse (a v : (ι → ℂ) → ℂ) (q g w : ℂ)
    (ha : AnalyticAt ℂ a (fun _ => w)) (hv : AnalyticAt ℂ v (fun _ => w))
    (hq : q ≠ 0) (hg : g ≠ 0)
    (hqa : w - a (fun _ => w) = q) (hgv : v (fun _ => w) - a (fun _ => w) = g)
    (hsa : ∀ σ : Equiv.Perm ι,
      (fun z => a (z ∘ σ)) =ᶠ[𝓝 (fun _ => w)] a)
    (hsv : ∀ σ : Equiv.Perm ι,
      (fun z => v (z ∘ σ)) =ᶠ[𝓝 (fun _ => w)] v)
    (hμ : commonResponse q g (fderiv ℂ a (fun _ => w))
      (fderiv ℂ v (fun _ => w)) ≠ 0) :
    ∃ G : (ι → ℂ) → (ι → ℂ),
      AnalyticAt ℂ G 0 ∧ G 0 = (fun _ => w) ∧
      (∀ᶠ z in 𝓝 (fun _ => w), G (logRatios a v q g z) = z) ∧
      (∀ᶠ Z in 𝓝 0, logRatios a v q g (G Z) = Z) := by
  let D := ratioDerivative q g (fderiv ℂ a (fun _ => w)) (fderiv ℂ v (fun _ => w))
  have hD := hasFDerivAt_logRatios a v q g w ha.differentiableAt hv.differentiableAt
    hq hg hqa hgv
  have hDc : (D : (ι → ℂ) →ₗ[ℂ] (ι → ℂ)) =
      centeredCollectiveMap q⁻¹ (commonResponse q g (fderiv ℂ a (fun _ => w))
        (fderiv ℂ v (fun _ => w))) :=
    ratioDerivative_centeredCollective q g _ _
      (differential_permutation_invariant a w ha.differentiableAt hsa)
      (differential_permutation_invariant v w hv.differentiableAt hsv)
  have hbij : Function.Bijective D := by
    change Function.Bijective (D : (ι → ℂ) →ₗ[ℂ] (ι → ℂ))
    rw [hDc]
    exact centeredCollectiveMap_bijective _ _ (inv_ne_zero hq) hμ
  let e := (LinearEquiv.ofBijective D.toLinearMap hbij).toContinuousLinearEquiv
  have he : (e : (ι → ℂ) →L[ℂ] (ι → ℂ)) = D := by ext x i; rfl
  have hAn := analyticAt_logRatios a v q g w ha hv hq hg hqa hgv
  have hf : HasStrictFDerivAt (logRatios a v q g) (e : (ι → ℂ) →L[ℂ] (ι → ℂ))
      (fun _ => w) := by
    rw [he]
    change HasStrictFDerivAt _ (ratioDerivative q g _ _) _
    rw [← hD.fderiv]
    exact hAn.hasStrictFDerivAt
  have hzero : logRatios a v q g (fun _ => w) = 0 := by
    ext i
    simp [logRatios, hqa, hgv, hq, hg]
  have hInv : AnalyticAt ℂ (hf.localInverse (logRatios a v q g) e (fun _ => w))
      (logRatios a v q g (fun _ => w)) :=
    (hf.toOpenPartialHomeomorph (logRatios a v q g)).analyticAt_symm'
    hf.mem_toOpenPartialHomeomorph_source hAn (hD.fderiv.trans he.symm)
  refine ⟨hf.localInverse (logRatios a v q g) e (fun _ => w), ?_, ?_,
    hf.eventually_left_inverse, ?_⟩
  · simpa only [hzero] using hInv
  · simpa only [hzero] using hf.localInverse_apply_image
  · simpa only [hzero] using hf.eventually_right_inverse

omit [Nonempty ι] in
/-- The common response is the derivative of each actual diagonal ratio. -/
theorem diagonal_ratio_deriv (a v : (ι → ℂ) → ℂ) (q g w : ℂ)
    (ha : DifferentiableAt ℂ a (fun _ => w))
    (hv : DifferentiableAt ℂ v (fun _ => w))
    (hq : q ≠ 0) (hg : g ≠ 0)
    (hqa : w - a (fun _ => w) = q) (hgv : v (fun _ => w) - a (fun _ => w) = g)
    (i : ι) :
    deriv (fun t => logRatios a v q g (fun _ => t) i) w =
      commonResponse q g (fderiv ℂ a (fun _ => w)) (fderiv ℂ v (fun _ => w)) := by
  let d : ℂ →L[ℂ] (ι → ℂ) := ContinuousLinearMap.pi fun _ => ContinuousLinearMap.id ℂ ℂ
  have hD := hasFDerivAt_logRatios a v q g w ha hv hq hg hqa hgv
  have h := ((hasFDerivAt_pi'.mp hD i).comp w d.hasFDerivAt).hasDerivAt.deriv
  simpa [d, ratioDerivative, commonResponse] using h

/-- The actual Jacobian has the article's centered and collective multipliers,
with the latter expressed as the actual diagonal-ratio derivative. -/
theorem logRatios_fderiv (a v : (ι → ℂ) → ℂ) (q g w : ℂ) (i₀ : ι)
    (ha : DifferentiableAt ℂ a (fun _ => w))
    (hv : DifferentiableAt ℂ v (fun _ => w))
    (hq : q ≠ 0) (hg : g ≠ 0)
    (hqa : w - a (fun _ => w) = q) (hgv : v (fun _ => w) - a (fun _ => w) = g)
    (hsa : ∀ σ : Equiv.Perm ι,
      (fun z => a (z ∘ σ)) =ᶠ[𝓝 (fun _ => w)] a)
    (hsv : ∀ σ : Equiv.Perm ι,
      (fun z => v (z ∘ σ)) =ᶠ[𝓝 (fun _ => w)] v) :
    (fderiv ℂ (logRatios a v q g) (fun _ => w) : (ι → ℂ) →ₗ[ℂ] (ι → ℂ)) =
      centeredCollectiveMap q⁻¹ (deriv (fun t => logRatios a v q g (fun _ => t) i₀) w) := by
  rw [(hasFDerivAt_logRatios a v q g w ha hv hq hg hqa hgv).fderiv,
    diagonal_ratio_deriv a v q g w ha hv hq hg hqa hgv i₀]
  exact ratioDerivative_centeredCollective q g _ _
    (differential_permutation_invariant a w ha hsa)
    (differential_permutation_invariant v w hv hsv)

omit [Nonempty ι] in
/-- On centered critical-copy variations the derivative is multiplication by `1/q`. -/
theorem centeredCollective_centered (κ μ : ℂ) (x : ι → ℂ) (hx : ∑ i, x i = 0) :
    centeredCollectiveMap κ μ x = κ • x := by
  ext i
  simp [centeredCollectiveMap, copyMean, hx]

/-- On common shifts the derivative is multiplication by the diagonal response. -/
theorem centeredCollective_common (κ μ t : ℂ) :
    centeredCollectiveMap κ μ (fun _ : ι => t) = fun _ => μ * t := by
  ext i
  simp [centeredCollectiveMap]

section Parameters
variable {P : Type*} [NormedAddCommGroup P] [NormedSpace ℂ P]
  [FiniteDimensional ℂ P] [CompleteSpace P]

omit [Nonempty ι] in
/-- An analytic parameter-preserving map is locally invertible when its
actual derivative in the first variables is invertible. -/
theorem parameter_preserving_local_inverse
    (F : (ι → ℂ) × P → (ι → ℂ)) (z₀ : ι → ℂ) (p₀ : P)
    (hF : AnalyticAt ℂ F (z₀, p₀))
    (hpartial : Function.Bijective (fderiv ℂ (fun z => F (z, p₀)) z₀)) :
    ∃ G : (ι → ℂ) × P → (ι → ℂ) × P,
      AnalyticAt ℂ G (F (z₀, p₀), p₀) ∧ G (F (z₀, p₀), p₀) = (z₀, p₀) ∧
      (∀ᶠ t in 𝓝 (z₀, p₀), G (F t, t.2) = t) ∧
      (∀ᶠ s in 𝓝 (F (z₀, p₀), p₀), (F (G s), (G s).2) = s) := by
  let H : (ι → ℂ) × P → (ι → ℂ) × P := fun t => (F t, t.2)
  let D := (fderiv ℂ F (z₀, p₀)).prod (ContinuousLinearMap.snd ℂ (ι → ℂ) P)
  have hD : HasFDerivAt H D (z₀, p₀) := hF.differentiableAt.hasFDerivAt.prodMk hasFDerivAt_snd
  have hs : fderiv ℂ (fun z => F (z, p₀)) z₀ =
      (fderiv ℂ F (z₀, p₀)).comp (ContinuousLinearMap.inl ℂ (ι → ℂ) P) :=
    (hF.differentiableAt.hasFDerivAt.comp z₀ (hasFDerivAt_prodMk_left z₀ p₀)).fderiv
  have hinj : Function.Injective D := by
    intro t s hts
    have hp₁ := congrArg Prod.snd hts
    have hp : t.2 = s.2 := hp₁
    have hfirst₁ := congrArg Prod.fst hts
    have hfirst : fderiv ℂ F (z₀, p₀) t = fderiv ℂ F (z₀, p₀) s := hfirst₁
    have hd : t - s = (t.1 - s.1, 0) := by ext <;> simp [hp]
    have hz : fderiv ℂ (fun z => F (z, p₀)) z₀ (t.1 - s.1) = 0 := by
      rw [hs]
      change fderiv ℂ F (z₀, p₀) (t.1 - s.1, 0) = 0
      rw [← hd, map_sub, hfirst, sub_self]
    have heq : t.1 = s.1 := sub_eq_zero.mp (hpartial.1 (by simpa using hz))
    exact Prod.ext heq hp
  let e := (LinearEquiv.ofBijective D.toLinearMap
    ⟨hinj, LinearMap.surjective_of_injective hinj⟩).toContinuousLinearEquiv
  have he : (e : ((ι → ℂ) × P) →L[ℂ] ((ι → ℂ) × P)) = D := by ext x <;> rfl
  have hAn : AnalyticAt ℂ H (z₀, p₀) := hF.prod analyticAt_snd
  have hf : HasStrictFDerivAt H (e : ((ι → ℂ) × P) →L[ℂ] ((ι → ℂ) × P)) (z₀, p₀) := by
    rw [he, ← hD.fderiv]
    exact hAn.hasStrictFDerivAt
  have hInv : AnalyticAt ℂ (hf.localInverse H e (z₀, p₀)) (H (z₀, p₀)) :=
    (hf.toOpenPartialHomeomorph H).analyticAt_symm'
      hf.mem_toOpenPartialHomeomorph_source hAn (hD.fderiv.trans he.symm)
  exact ⟨hf.localInverse H e (z₀, p₀), hInv, hf.localInverse_apply_image,
    hf.eventually_left_inverse, hf.eventually_right_inverse⟩

/-- The actual logarithmic ratios with independently varying boundary parameters. -/
def parameterLogRatios (a v : (ι → ℂ) × P → ℂ) (q g : ℂ)
    (t : (ι → ℂ) × P) : ι → ℂ := fun i =>
  Complex.log (q⁻¹ * (t.1 i - a t)) - Complex.log (g⁻¹ * (v t - a t))

/-- Full parameter-preserving form of Lemma 5.2. The diagonal nondegeneracy
condition is stated using the derivative of the actual logarithmic ratio. -/
theorem parameter_logRatios_local_inverse
    (a v : (ι → ℂ) × P → ℂ) (q g w : ℂ) (p₀ : P) (i₀ : ι)
    (ha : AnalyticAt ℂ a ((fun _ => w), p₀))
    (hv : AnalyticAt ℂ v ((fun _ => w), p₀))
    (hq : q ≠ 0) (hg : g ≠ 0)
    (hqa : w - a ((fun _ => w), p₀) = q)
    (hgv : v ((fun _ => w), p₀) - a ((fun _ => w), p₀) = g)
    (hsa : ∀ σ : Equiv.Perm ι,
      (fun z => a (z ∘ σ, p₀)) =ᶠ[𝓝 (fun _ => w)] (fun z => a (z, p₀)))
    (hsv : ∀ σ : Equiv.Perm ι,
      (fun z => v (z ∘ σ, p₀)) =ᶠ[𝓝 (fun _ => w)] (fun z => v (z, p₀)))
    (hdiag : deriv (fun t => parameterLogRatios a v q g ((fun _ => t), p₀) i₀) w ≠ 0) :
    ∃ G : (ι → ℂ) × P → (ι → ℂ) × P,
      AnalyticAt ℂ G (0, p₀) ∧ G (0, p₀) = ((fun _ => w), p₀) ∧
      (∀ᶠ t in 𝓝 ((fun _ => w), p₀), G (parameterLogRatios a v q g t, t.2) = t) ∧
      (∀ᶠ s in 𝓝 (0, p₀), (parameterLogRatios a v q g (G s), (G s).2) = s) := by
  let aₛ : (ι → ℂ) → ℂ := fun z => a (z, p₀)
  let vₛ : (ι → ℂ) → ℂ := fun z => v (z, p₀)
  have hslice : AnalyticAt ℂ (fun z : ι → ℂ => (z, p₀)) (fun _ => w) :=
    analyticAt_id.prod analyticAt_const
  have has : AnalyticAt ℂ aₛ (fun _ => w) := by
    exact AnalyticAt.comp (f := fun z : ι → ℂ => (z, p₀)) ha hslice
  have hvs : AnalyticAt ℂ vₛ (fun _ => w) := by
    exact AnalyticAt.comp (f := fun z : ι → ℂ => (z, p₀)) hv hslice
  have hμ : commonResponse q g (fderiv ℂ aₛ (fun _ => w))
      (fderiv ℂ vₛ (fun _ => w)) ≠ 0 := by
    rw [← diagonal_ratio_deriv aₛ vₛ q g w has.differentiableAt hvs.differentiableAt
      hq hg hqa hgv i₀]
    exact hdiag
  have hD := hasFDerivAt_logRatios aₛ vₛ q g w has.differentiableAt hvs.differentiableAt
    hq hg hqa hgv
  have hpartial : Function.Bijective
      (fderiv ℂ (fun z => parameterLogRatios a v q g (z, p₀)) (fun _ => w)) := by
    change Function.Bijective (fderiv ℂ (logRatios aₛ vₛ q g) (fun _ => w))
    rw [hD.fderiv]
    change Function.Bijective ((ratioDerivative q g _ _).toLinearMap)
    rw [ratioDerivative_centeredCollective q g _ _
      (differential_permutation_invariant aₛ w has.differentiableAt hsa)
      (differential_permutation_invariant vₛ w hvs.differentiableAt hsv)]
    exact centeredCollectiveMap_bijective _ _ (inv_ne_zero hq) hμ
  have hAn : AnalyticAt ℂ (parameterLogRatios a v q g) ((fun _ => w), p₀) := by
    apply AnalyticAt.pi
    intro i
    have hcoord : AnalyticAt ℂ (fun t : (ι → ℂ) × P => t.1 i) ((fun _ => w), p₀) :=
      ((ContinuousLinearMap.proj i : (ι → ℂ) →L[ℂ] ℂ).analyticAt _).comp
        (analyticAt_fst (𝕜 := ℂ))
    have h1 : AnalyticAt ℂ (fun t : (ι → ℂ) × P => q⁻¹ * (t.1 i - a t))
        ((fun _ => w), p₀) := (hcoord.sub ha).const_smul
    have h2 : AnalyticAt ℂ (fun t : (ι → ℂ) × P => g⁻¹ * (v t - a t))
        ((fun _ => w), p₀) := (hv.sub ha).const_smul
    exact (analyticAt_log_comp h1 (by simp [hqa, hq])).sub
      (analyticAt_log_comp h2 (by simp [hgv, hg]))

  have hzero : parameterLogRatios a v q g ((fun _ => w), p₀) = 0 := by
    ext i
    simp [parameterLogRatios, hqa, hgv, hq, hg]
  simpa only [hzero] using parameter_preserving_local_inverse
    (parameterLogRatios a v q g) (fun _ => w) p₀ hAn hpartial
end Parameters

end PolynomialGeometry.RatioCoordinates
