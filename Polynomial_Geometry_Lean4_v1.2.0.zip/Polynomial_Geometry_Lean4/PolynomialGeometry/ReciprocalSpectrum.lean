import PolynomialGeometry.ReciprocalDistance
import PolynomialGeometry.Geometry
import PolynomialGeometry.CompressionDet
import PolynomialGeometry.Mobius

/-!
# The actual reciprocal matrix and the distance threshold

Unlike a statement about a supplied spectral list, these results derive the
reciprocal spectrum from the resolvent of the actual finite matrix.
-/

noncomputable section
open Matrix
open scoped Pointwise ENNReal NNReal

namespace PolynomialGeometry.ReciprocalSpectrum

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The determinant formula is valid for every perturbation parameter,
including values at which a displayed rational source formula has a pole. -/
theorem resolvent_determinant (A : Matrix ι ι ℂ) (a t : ℂ)
    (ha : IsUnit (a • (1 : Matrix ι ι ℂ) - A)) :
    (1 + t • (a • (1 : Matrix ι ι ℂ) - A)⁻¹).det =
      A.charpoly.eval (a + t) / A.charpoly.eval a := by
  let B := a • (1 : Matrix ι ι ℂ) - A
  letI := ha.invertible
  have hm : B * (1 + t • B⁻¹) = (a + t) • (1 : Matrix ι ι ℂ) - A := by
    rw [mul_add, mul_one, Matrix.mul_smul, Matrix.mul_inv_of_invertible, add_smul]
    dsimp [B]
    abel
  have hd := congrArg Matrix.det hm
  rw [Matrix.det_mul] at hd
  rw [Matrix.eval_charpoly, Matrix.eval_charpoly]
  have hs (z : ℂ) : Matrix.scalar ι z = z • (1 : Matrix ι ι ℂ) := by
    ext i j
    simp [Matrix.scalar_apply, Matrix.one_apply, Matrix.diagonal_apply]
  simp only [hs]
  apply (eq_div_iff ((Matrix.isUnit_iff_isUnit_det _).mp ha).ne_zero).mpr
  simpa only [mul_comm] using hd

theorem resolvent_spectrum (A : Matrix ι ι ℂ) (a : ℂ)
    (ha : IsUnit (a • (1 : Matrix ι ι ℂ) - A)) :
    spectrum ℂ ((a • (1 : Matrix ι ι ℂ) - A)⁻¹) =
      (fun w : ℂ => (a - w)⁻¹) '' spectrum ℂ A := by
  have hi := spectrum.map_inv (𝕜 := ℂ) ha.unit
  rw [Matrix.coe_units_inv, ha.unit_spec] at hi
  rw [← hi, ← Algebra.algebraMap_eq_smul_one,
    ← spectrum.singleton_sub_eq]
  ext z
  simp only [Set.mem_inv, Set.mem_sub, Set.mem_singleton_iff, Set.mem_image]
  constructor
  · rintro ⟨x, rfl, w, hw, he⟩
    refine ⟨w, hw, ?_⟩
    rw [he, inv_inv]
  · rintro ⟨w, hw, rfl⟩
    exact ⟨a, rfl, w, hw, by simp⟩

theorem resolvent_root_iff (A : Matrix ι ι ℂ) (a : ℂ)
    (ha : IsUnit (a • (1 : Matrix ι ι ℂ) - A)) (z : ℂ) :
    ((a • (1 : Matrix ι ι ℂ) - A)⁻¹).charpoly.IsRoot z ↔
      ∃ w : ℂ, A.charpoly.IsRoot w ∧ (a - w)⁻¹ = z := by
  rw [← Matrix.mem_spectrum_iff_isRoot_charpoly, resolvent_spectrum A a ha]
  simp only [Set.mem_image, Matrix.mem_spectrum_iff_isRoot_charpoly]

/-- Exact spectral-radius threshold of the actual reciprocal matrix. The
finite-dimensional maximum is attained, so equality is included. -/
theorem root_distance_iff_reciprocal_radius (A : Matrix ι ι ℂ) (a : ℂ)
    (ha : IsUnit (a • (1 : Matrix ι ι ℂ) - A)) (r : ℝ≥0) :
    (∃ w : ℂ, A.charpoly.IsRoot w ∧ ‖a - w‖ ≤ (r : ℝ)) ↔
      1 ≤ (r : ℝ≥0∞) * spectralRadius ℂ ((a • (1 : Matrix ι ι ℂ) - A)⁻¹) := by
  let R := (a • (1 : Matrix ι ι ℂ) - A)⁻¹
  have hsep : ∀ w, A.charpoly.IsRoot w → a - w ≠ 0 := by
    intro w hw he
    have hwa : a = w := sub_eq_zero.mp he
    apply (spectrum.notMem_iff.mpr (by
      simpa only [Algebra.algebraMap_eq_smul_one] using ha))
    simpa only [hwa] using Matrix.mem_spectrum_iff_isRoot_charpoly.mpr hw
  have hscalar : ∀ w, A.charpoly.IsRoot w →
      (‖a - w‖ ≤ (r : ℝ) ↔ 1 ≤ (r : ℝ≥0∞) * (‖(a - w)⁻¹‖₊ : ℝ≥0∞)) := by
    intro w hw
    have hd : 0 < ‖a - w‖ := norm_pos_iff.mpr (hsep w hw)
    have he : (‖a - w‖ ≤ (r : ℝ)) ↔ 1 ≤ (r : ℝ) * ‖(a - w)⁻¹‖ := by
      rw [norm_inv, ← div_eq_mul_inv, le_div_iff₀ hd, one_mul]
    rw [he]
    exact_mod_cast (Iff.rfl : (1 : ℝ≥0) ≤ r * ‖(a - w)⁻¹‖₊ ↔
      (1 : ℝ≥0) ≤ r * ‖(a - w)⁻¹‖₊)
  constructor
  · rintro ⟨w, hw, hd⟩
    have hs : (a - w)⁻¹ ∈ spectrum ℂ R := by
      rw [resolvent_spectrum A a ha]
      exact ⟨w, Matrix.mem_spectrum_iff_isRoot_charpoly.mpr hw, rfl⟩
    have hb : (‖(a - w)⁻¹‖₊ : ℝ≥0∞) ≤ spectralRadius ℂ R :=
      le_iSup₂_of_le ((a - w)⁻¹) hs le_rfl
    exact ((hscalar w hw).mp hd).trans (mul_le_mul_left' hb _)
  · intro h
    have hfin : (spectrum ℂ R).Finite := by
      simpa only [← Matrix.mem_spectrum_iff_isRoot_charpoly] using
        Polynomial.finite_setOf_isRoot R.charpoly_monic.ne_zero
    rcases Set.eq_empty_or_nonempty (spectrum ℂ R) with hempty | hne
    · have hz : spectralRadius ℂ R = 0 := by simp [spectralRadius, hempty]
      change 1 ≤ (r : ℝ≥0∞) * spectralRadius ℂ R at h
      simp only [hz, mul_zero] at h
      exact False.elim (by simp at h)
    · obtain ⟨z, hz, heq⟩ := hfin.ciSup_mem_image
        (f := fun z : ℂ => (‖z‖₊ : ℝ≥0∞))
        (by obtain ⟨z, hz⟩ := hne; exact ⟨z, hz, by simp⟩)
      change (‖z‖₊ : ℝ≥0∞) = spectralRadius ℂ R at heq
      obtain ⟨w, hw, rfl⟩ := (resolvent_root_iff A a ha z).mp
        (Matrix.mem_spectrum_iff_isRoot_charpoly.mp hz)
      refine ⟨w, hw, (hscalar w hw).mpr ?_⟩
      simpa only [heq] using h

theorem source_reciprocal_spectrum (a : ℝ) (u α : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j) :
    spectrum ℂ (Geometry.reciprocal u (Geometry.sourceResolvent a α)) =
      (fun w : ℂ => ((a : ℂ) - w)⁻¹) ''
        spectrum ℂ (Geometry.compressed a u (diagonal α)) := by
  have hi := Geometry.source_reciprocal_isUnit a u α hsep
  have he := Geometry.source_compression_reciprocal a u α hsep
  have hu : IsUnit ((a : ℂ) • (1 : Matrix ι ι ℂ) -
      Geometry.compressed a u (diagonal α)) := by
    rw [he]
    exact Matrix.isUnit_nonsing_inv_iff.mpr hi
  have h := resolvent_spectrum (Geometry.compressed a u (diagonal α)) (a : ℂ) hu
  rw [he] at h
  letI := hi.invertible
  simpa only [Matrix.inv_inv_of_invertible] using h

/-- Listing all roots, including repetitions, gives the full derivative
compression. No distinct-source assumption removes inherited critical modes. -/
theorem equal_copy_derivative (d : ℕ) (α : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (CompressionDet.normalizedSource d (fun _ => 1) i) * Q i j = 0) :
    (Source.support Finset.univ α).derivative =
      Polynomial.C (d + 1 : ℂ) * (Qᴴ * diagonal α * Q).charpoly := by
  have hc := CompressionDet.positive_weight_compression_charpoly d α
    (fun _ => 1) Q (fun _ => by norm_num) hQ hbQ
  have hn : (d + 1 : ℂ) ≠ 0 := by exact_mod_cast Nat.succ_ne_zero d
  have hd := Source.inherited_derivative_identity Finset.univ α (fun _ => 1)
    (fun _ _ => by norm_num) (by simpa [Source.mass] using hn)
  rw [hc]
  simpa [Source.sourcePolynomial, Source.support, Source.inheritedFactor, Source.mass] using hd

/-- The full reciprocal matrix includes inherited modes automatically.
The selected root is simple exactly where the reciprocal resolvent exists. -/
theorem full_reciprocal_distance_threshold (d : ℕ) (α : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (CompressionDet.normalizedSource d (fun _ => 1) i) * Q i j = 0)
    (a : ℂ) (ha : (Source.support Finset.univ α).derivative.eval a ≠ 0) (r : ℝ≥0) :
    (∃ w : ℂ, (Source.support Finset.univ α).derivative.IsRoot w ∧ ‖a - w‖ ≤ (r : ℝ)) ↔
      1 ≤ (r : ℝ≥0∞) * spectralRadius ℂ
        ((a • (1 : Matrix (Fin d) (Fin d) ℂ) - Qᴴ * diagonal α * Q)⁻¹) := by
  let A := Qᴴ * diagonal α * Q
  have hp := equal_copy_derivative d α Q hQ hbQ
  have hn : (d + 1 : ℂ) ≠ 0 := by exact_mod_cast Nat.succ_ne_zero d
  have hroots : ∀ w, (Source.support Finset.univ α).derivative.IsRoot w ↔ A.charpoly.IsRoot w := by
    intro w
    simp only [A, Polynomial.IsRoot, hp, Polynomial.eval_mul, Polynomial.eval_C,
      mul_eq_zero, hn, false_or]
  have hu : IsUnit (a • (1 : Matrix (Fin d) (Fin d) ℂ) - A) := by
    have hnot : a ∉ spectrum ℂ A := by
      intro h
      exact ha ((hroots a).mpr (Matrix.mem_spectrum_iff_isRoot_charpoly.mp h))
    simpa only [Algebra.algebraMap_eq_smul_one] using spectrum.notMem_iff.mp hnot
  simpa only [hroots] using root_distance_iff_reciprocal_radius A a hu r

/-- With the nearest critical distance written as its literal finite
minimum, the preceding theorem is the article's `D ≤ r ↔ r ρ ≥ 1`. -/
theorem nearest_critical_distance_threshold (d : ℕ) (α : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (CompressionDet.normalizedSource d (fun _ => 1) i) * Q i j = 0)
    (a : ℂ) (ha : (Source.support Finset.univ α).derivative.eval a ≠ 0)
    (hne : (Source.support Finset.univ α).derivative.roots.toFinset.Nonempty) (r : ℝ≥0) :
    (Source.support Finset.univ α).derivative.roots.toFinset.inf' hne (fun w => ‖a - w‖) ≤
      (r : ℝ) ↔
      1 ≤ (r : ℝ≥0∞) * spectralRadius ℂ
        ((a • (1 : Matrix (Fin d) (Fin d) ℂ) - Qᴴ * diagonal α * Q)⁻¹) := by
  have hp : (Source.support Finset.univ α).derivative ≠ 0 := by
    intro he
    simp only [he, Polynomial.eval_zero] at ha
    exact ha rfl
  rw [Finset.inf'_le_iff]
  simpa only [Multiset.mem_toFinset, Polynomial.mem_roots hp] using
    full_reciprocal_distance_threshold d α Q hQ hbQ a ha r

end PolynomialGeometry.ReciprocalSpectrum
