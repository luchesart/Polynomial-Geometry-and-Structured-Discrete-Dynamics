import PolynomialGeometry.NoisyMetric
import PolynomialGeometry.NoisyContourResidue

/-! # Certified mass recovery for a promised finite-dimensional realization -/

noncomputable section
open Polynomial Complex Metric Set WithLp
open scoped Polynomial ComplexOrder

namespace PolynomialGeometry.NoisyContour

/-- This version accepts any certified lower bounds on the marked separation and
the fitted denominator, and upper bounds for the cofactor row and numerator. -/
theorem noisy_mass_recovery {ι σ : Type*} [Fintype ι] [DecidableEq ι]
    [Fintype σ] [DecidableEq σ] (a : ℂ) (n : ℝ) (H J Fhat : Matrix ι ι ℂ)
    (e : ι → ℂ) (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef) (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y) (j₀ : σ)
    (hmark : α j₀ = a) (c : ℂ) (r ε L d m η M : ℝ) (hr : 0 ≤ r)
    (ha : a ∉ closedBall c r) (hd : 0 < d) (hηm : η < m)
    (hF : NoisyMetric.opNorm₂ (H⁻¹ - Fhat) ≤ ε)
    (hL : ∀ z ∈ sphere c r, NoisyMetric.adjRowNorm J e z ≤ L)
    (hη : n * ε * ‖toLp 2 (NoisyMetric.metricVector a J e)‖ * L ≤ η)
    (hdist : ∀ z ∈ sphere c r, d ≤ ‖z-a‖)
    (hG : ∀ z ∈ sphere c r, ‖J.charpoly.eval z‖ ≤ M) :
    let Qhat := NoisyMetric.supportPoly J e Fhat (NoisyMetric.metricVector a J e) n
    (∀ z ∈ sphere c r, m ≤ ‖Qhat.eval z‖) → diskCount Qhat c r = 1 →
    ∃ (j : σ) (bhat : ℂ), j ≠ j₀ ∧ α j ∈ ball c r ∧
      (∀ k, α k ∈ closedBall c r → k = j) ∧
      bhat ∈ ball c r ∧ Qhat.eval bhat = 0 ∧
      (∀ b ∈ closedBall c r, Qhat.eval b = 0 → b = bhat) ∧
      ‖(ω j : ℂ)^2 - rootResidue (C (n:ℂ) * J.charpoly) Qhat a bhat‖ ≤
        r * (n*M*η/(d*m*(m-η))) ∧
      (∀ (k : ℕ), (∃ T : ℂ[X], T.Monic ∧ ∀ z, T.eval z ≠ 0 → (∀ l, z ≠ α l) →
          T.derivative.eval z / T.eval z = ∑ l, (ω l : ℂ)^2 / (z - α l)) →
        (∀ t : ℕ, 0 < t → ‖(t:ℂ) - rootResidue (C (n:ℂ)*J.charpoly) Qhat a bhat‖ ≤
          r * (n*M*η/(d*m*(m-η))) → t = k) → ω j^2 = (k:ℝ)) := by
  classical
  let v := NoisyMetric.metricVector a J e
  let Q := NoisyMetric.supportPoly J e H⁻¹ v n
  let A := C (n:ℂ) * J.charpoly
  intro Qhat hm hcount
  have hQ : Q.Monic := Matrix.charpoly_monic _
  have hhat : Qhat.Monic := Matrix.charpoly_monic _
  have hgap (z) (hz : z ∈ sphere c r) : ‖Q.eval z - Qhat.eval z‖ ≤ η :=
    (NoisyMetric.supportPoly_uniform_gap J H⁻¹ Fhat e v n ε L hn.le hF _ hL z hz).trans hη
  have hsmall (z) (hz : z ∈ sphere c r) : ‖Q.eval z - Qhat.eval z‖ < ‖Qhat.eval z‖ :=
    (hgap z hz).trans_lt (hηm.trans_le (hm z hz))
  have hnz := boundary_nonzero hsmall
  have hcount' : diskCount Q c r = 1 := (rouche Q Qhat hQ hhat c hr hsmall).trans hcount
  obtain ⟨b, hb, hroot, huniq, hres⟩ :=
    isolated_residue A Q hQ ha (fun z hz => (hnz z hz).1) hcount'
  obtain ⟨bhat, hh, hhzero, hhuniq, hhres⟩ :=
    isolated_residue A Qhat hhat ha (fun z hz => (hnz z hz).2) hcount
  have hprod : Q = ∏ j : {j : σ // j ≠ j₀}, (X - C (α j)) :=
    NoisyMetric.supportPoly_eq_product a n H J e α ω Y hn hH hdim hreal j₀ hmark
  have hroot_iff (z : ℂ) : Q.eval z = 0 ↔ ∃ j : {j : σ // j ≠ j₀}, z = α j := by
    rw [hprod, eval_prod]
    simp [Finset.prod_eq_zero_iff, sub_eq_zero]
  obtain ⟨j,hj⟩ := (hroot_iff b).mp hroot
  have hfull := RecoveryCompletion.completeRealization_selected_factorization
    a n H J e α ω Y hn hH hdim hreal j₀ hmark
  change _ = (X-C a)*Q at hfull
  have hmres : (ω j : ℂ)^2 = rootResidue A Q a b := by
    have hresj := RecoveryCompletion.completeRealization_completion_residue
      a n H J e α ω Y hn hH hdim hreal j
    rw [hfull] at hresj
    simpa only [rootResidue, A, hj, eval_mul, eval_C] using hresj
  have herr : ‖(ω j : ℂ)^2 - rootResidue A Qhat a bhat‖ ≤
        r * (n*M*η/(d*m*(m-η))) := by
    have hi (P : ℂ[X]) (hp : ∀ z ∈ sphere c r, P.eval z ≠ 0) :
        CircleIntegrable (fun z => A.eval z / ((z-a)*P.eval z)) c r :=
      (A.continuous.continuousOn.div
        ((continuous_id.sub continuous_const).continuousOn.mul P.continuous.continuousOn)
        (fun z hz => mul_ne_zero (norm_pos_iff.mp (hd.trans_le (hdist z hz))) (hp z hz))).circleIntegrable hr
    rw [hmres, ← hres, ← hhres]
    apply contour_gap hr (hi Q (fun z hz => (hnz z hz).1)) (hi Qhat (fun z hz => (hnz z hz).2))
    intro z hz
    simpa only [A, eval_mul, eval_C] using NoisyMetric.rational_gap
      (Q.eval z) (Qhat.eval z) (J.charpoly.eval z) (z-a) n d m η M
      (hdist z hz) (hm z hz) (hG z hz) (hgap z hz) hηm hd hn.le
  refine ⟨j,bhat,j.prop,hj ▸ hb,?_,hh,hhzero,hhuniq,herr,?_⟩
  · intro k hk
    by_cases hke : k = j₀
    · subst k
      exact False.elim (ha (hmark ▸ hk))
    · have hzr := (hroot_iff (α k)).mpr ⟨⟨k,hke⟩,rfl⟩
      exact hreal.1 ((huniq (α k) hk hzr).trans hj)
  · intro k hpol hisolate
    exact NoisyMetric.certified_integer_mass a n H J e α ω Y hreal hpol j _ _ k herr hisolate

end PolynomialGeometry.NoisyContour
