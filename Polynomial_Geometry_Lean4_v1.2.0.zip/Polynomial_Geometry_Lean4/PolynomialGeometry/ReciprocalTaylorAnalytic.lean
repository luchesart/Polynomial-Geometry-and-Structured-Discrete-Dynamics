import PolynomialGeometry.ReconstructionCompletion
import Mathlib.Analysis.Calculus.IteratedDeriv.Lemmas
import Mathlib.Analysis.Analytic.Polynomial

/-! # Analytic derivative meaning of the reciprocal Taylor reconstruction -/

noncomputable section
namespace PolynomialGeometry.ReconstructionCompletion
open Polynomial Filter
open scoped BigOperators Topology

/-- A factor of order `k+1` annihilates the actual analytic derivative of
order `k`. No formal-series interpretation is used in this lemma. -/
theorem iteratedDeriv_pow_mul_zero (k : ℕ) (g : ℂ → ℂ) (w : ℂ)
    (hg : AnalyticAt ℂ g w) :
    iteratedDeriv k (fun z => (z - w) ^ (k + 1) * g z) w = 0 := by
  induction k generalizing g with
  | zero => simp
  | succ k ih =>
    let h : ℂ → ℂ := fun z => (k + 2 : ℂ) * g z + (z - w) * deriv g z
    have hh : AnalyticAt ℂ h w :=
      (analyticAt_const.mul hg).add ((analyticAt_id.sub analyticAt_const).mul hg.deriv)
    have heq : deriv (fun z => (z - w) ^ (k + 1 + 1) * g z) =ᶠ[𝓝 w]
        (fun z => (z - w) ^ (k + 1) * h z) := by
      filter_upwards [hg.eventually_analyticAt] with z hz
      have hp := (((hasDerivAt_id z).sub_const w).pow (k + 1 + 1)).mul
        hz.differentiableAt.hasDerivAt
      have hp' : deriv (fun z => (z - w) ^ (k + 1 + 1) * g z) z =
          (k + 1 + 1 : ℂ) * (z - w) ^ (k + 1) * g z +
          (z - w) ^ (k + 1 + 1) * deriv g z := by
        simpa only [Pi.mul_apply, Pi.pow_apply, id_eq, Nat.add_sub_cancel,
          Nat.cast_add, Nat.cast_one, mul_one] using hp.deriv
      rw [hp']
      dsimp [h]
      ring
    rw [iteratedDeriv_succ']
    exact (heq.iteratedDeriv_eq k).trans (ih h hh)

/-- The same vanishing statement for any higher order factor. -/
theorem iteratedDeriv_higher_pow_mul_zero (k n : ℕ) (hkn : k < n)
    (g : ℂ → ℂ) (w : ℂ) (hg : AnalyticAt ℂ g w) :
    iteratedDeriv k (fun z => (z - w) ^ n * g z) w = 0 := by
  have hn : n = k + 1 + (n - (k + 1)) := by omega
  have he : (fun z => (z - w) ^ n * g z) =
      (fun z => (z - w) ^ (k + 1) * ((z - w) ^ (n - (k + 1)) * g z)) := by
    ext z
    conv_lhs => rw [hn]
    rw [pow_add, mul_assoc]
  rw [he]
  exact iteratedDeriv_pow_mul_zero k _ w
    (((analyticAt_id.sub analyticAt_const).pow _).mul hg)

/-- Analytic and algebraic iterated differentiation agree for every polynomial. -/
theorem polynomial_iteratedDeriv (P : ℂ[X]) (k : ℕ) (w : ℂ) :
    iteratedDeriv k (fun z => P.eval z) w = (derivative^[k] P).eval w := by
  induction k generalizing P with
  | zero => rfl
  | succ k ih =>
    rw [iteratedDeriv_succ']
    have hd : deriv (fun z => P.eval z) = fun z => P.derivative.eval z :=
      funext (fun z => P.deriv)
    rw [hd, ih, Function.iterate_succ_apply]

/-- Polynomial Taylor coefficients are normalized actual derivatives. -/
theorem polynomial_taylor_coeff_derivative (P : ℂ[X]) (w : ℂ) (k : ℕ) :
    (taylor w P).coeff k =
      (k.factorial : ℂ)⁻¹ * iteratedDeriv k (fun z => P.eval z) w := by
  rw [polynomial_iteratedDeriv]
  have hp := congrFun (Polynomial.factorial_smul_hasseDeriv (R := ℂ) (k := k)) P
  change k.factorial • hasseDeriv k P = derivative^[k] P at hp
  rw [← hp]
  simp only [nsmul_eq_mul, eval_natCast_mul, taylor_coeff]
  rw [← mul_assoc, inv_mul_cancel₀ (by exact_mod_cast k.factorial_ne_zero), one_mul]

/-- In a genuine monic critical configuration, the algebraically defined
reciprocal Taylor coefficients are exactly the analytic derivatives of `1/M`
divided by the factorial. -/
theorem reciprocalTaylorCoeff_eq_iteratedDeriv (A M : ℂ[X]) (w : ℂ) (r k : ℕ)
    (hA : A.Monic) (hd : A.natDegree = r) (hM : M.eval w ≠ 0)
    (hcrit : (X - C w) ^ r ∣ (A * M).derivative) (hk : k ≤ r) :
    reciprocalTaylorCoeff M w k =
      (k.factorial : ℂ)⁻¹ * iteratedDeriv k (fun z => (M.eval z)⁻¹) w := by
  have hMa : AnalyticAt ℂ (fun z => M.eval z) w :=
    AnalyticOnNhd.eval_polynomial M w (Set.mem_univ w)
  have hAi : AnalyticAt ℂ (fun z => (M.eval z)⁻¹) w := hMa.inv hM
  obtain ⟨Q, hQ⟩ := Variations.derivative_divisibility_constant_jet (A * M) w r hcrit
  let c := (A * M).eval w
  have hc : c ≠ 0 := by
    obtain ⟨hc, _⟩ := diagonal_top_coefficient A M w r hA hd hM hcrit
    intro hz
    change c * _ = 1 at hc
    rw [hz, zero_mul] at hc
    exact zero_ne_one hc
  let g : ℂ → ℂ := fun z => Q.eval z * (M.eval z)⁻¹
  have hg : AnalyticAt ℂ g w :=
    (AnalyticOnNhd.eval_polynomial Q w (Set.mem_univ w)).mul hAi
  have heq : (fun z => A.eval z) =ᶠ[𝓝 w]
      (fun z => c * (M.eval z)⁻¹ + (z - w) ^ (r + 1) * g z) := by
    filter_upwards [hMa.continuousAt.eventually_ne hM] with z hz
    have hev := congrArg (fun p : ℂ[X] => p.eval z) hQ
    simp only [eval_sub, eval_mul, eval_C, eval_pow, eval_X] at hev
    dsimp [g, c]
    apply (mul_right_cancel₀ hz)
    calc
      A.eval z * M.eval z = (A * M).eval w + (z - w) ^ (r + 1) * Q.eval z := by
        simpa only [eval_mul] using (sub_eq_iff_eq_add.mp hev).trans (add_comm _ _)
      _ = ((A * M).eval w * (M.eval z)⁻¹ +
            (z - w) ^ (r + 1) * (Q.eval z * (M.eval z)⁻¹)) * M.eval z := by
        field_simp
  have ha : AnalyticAt ℂ (fun z => c * (M.eval z)⁻¹) w := analyticAt_const.mul hAi
  have hb : AnalyticAt ℂ (fun z => (z - w) ^ (r + 1) * g z) w :=
    ((analyticAt_id.sub analyticAt_const).pow _).mul hg
  have hj := heq.iteratedDeriv_eq k
  change iteratedDeriv k (fun z => A.eval z) w =
    iteratedDeriv k ((fun z => c * (M.eval z)⁻¹) + (fun z => (z - w) ^ (r + 1) * g z)) w at hj
  rw [iteratedDeriv_add ha.contDiffAt hb.contDiffAt,
    iteratedDeriv_const_mul hAi.contDiffAt,
    iteratedDeriv_higher_pow_mul_zero k (r + 1) (by omega) g w hg,
    add_zero] at hj
  apply (mul_left_cancel₀ hc)
  rw [← diagonal_reciprocal_coefficients A M w r hM hcrit k hk,
    polynomial_taylor_coeff_derivative, hj]
  ring

/-- The diagonal formula in Lemma 5.1, now written with the actual analytic
higher derivatives appearing in the article. -/
theorem diagonal_analytic_taylor_formula (A M : ℂ[X]) (w : ℂ) (r : ℕ)
    (hA : A.Monic) (hd : A.natDegree = r) (hM : M.eval w ≠ 0)
    (hcrit : (X - C w) ^ r ∣ (A * M).derivative) (z : ℂ) :
    let f := fun k => (k.factorial : ℂ)⁻¹ *
      iteratedDeriv k (fun y => (M.eval y)⁻¹) w
    f r ≠ 0 ∧ A.eval z = (f r)⁻¹ *
      ∑ k ∈ Finset.range (r + 1), f k * (z - w) ^ k := by
  dsimp only
  have hf := reciprocalTaylorCoeff_eq_iteratedDeriv A M w r r hA hd hM hcrit le_rfl
  refine ⟨?_, ?_⟩
  · rw [← hf]
    exact (diagonal_top_coefficient A M w r hA hd hM hcrit).2
  · rw [← hf, diagonal_reciprocal_taylor_formula A M w r hA hd hM hcrit z]
    congr 1
    apply Finset.sum_congr rfl
    intro k hk
    rw [reciprocalTaylorCoeff_eq_iteratedDeriv A M w r k hA hd hM hcrit
      (by simpa only [Finset.mem_range, Nat.lt_succ_iff] using hk)]

end PolynomialGeometry.ReconstructionCompletion
