import PolynomialGeometry.Factorization

/-!
# Moving critical-factor reconstruction

A direct square coefficient system enforces `(AM)' = N C U` while both
prescribed critical factor `C` and source factor `M` vary. All coefficients
are retained, so the system allows critical and source root splitting.
-/

noncomputable section
namespace PolynomialGeometry.CriticalReconstruction

open Polynomial Filter
open PolynomialGeometry.Factorization PolynomialGeometry.Variations
open scoped BigOperators Topology

abbrev Unknown (r s : ℕ) := (Fin r → ℂ) × (Fin s → ℂ)
abbrev Parameter (r s : ℕ) := (Fin r → ℂ) × (Fin (s + 1) → ℂ)
abbrev Domain (r s : ℕ) := Unknown r s × Parameter r s
abbrev Target (r s : ℕ) := (Fin (r + s) → ℂ) × Parameter r s

def amProjection (r s : ℕ) : Domain r s →L[ℂ] Parameter r s :=
  LinearMap.toContinuousLinearMap {
    toFun := fun x => (x.1.1, x.2.2)
    map_add' := by intros; rfl
    map_smul' := by intros; rfl }

def cuProjection (r s : ℕ) : Domain r s →L[ℂ] Unknown r s :=
  LinearMap.toContinuousLinearMap {
    toFun := fun x => (x.2.1, x.1.2)
    map_add' := by intros; rfl
    map_smul' := by intros; rfl }

/-- Differentiate a monic polynomial in coefficient coordinates and
retain all coefficients below its derivative's fixed leading coefficient. -/
def derivativeProjection (r s : ℕ) :
    (Fin (r + (s + 1)) → ℂ) →L[ℂ] (Fin (r + s) → ℂ) :=
  LinearMap.toContinuousLinearMap {
    toFun := fun a k => a ⟨k + 1, by omega⟩ * (k + 1 : ℕ)
    map_add' := by intros; ext k; simp [add_mul]
    map_smul' := by intros; ext k; simp [mul_assoc] }

def derivativeLowMap (r s : ℕ) (a : Parameter r s) : Fin (r + s) → ℂ :=
  derivativeProjection r s (factorCoefficientMap r (s + 1) a)

def criticalSystemMap (r s : ℕ) (x : Domain r s) : Target r s :=
  (derivativeLowMap r s (amProjection r s x) -
    (r + s + 1 : ℂ) • factorCoefficientMap r s (cuProjection r s x), x.2)

def criticalDifferential (r s : ℕ) (x : Domain r s) :
    Domain r s →L[ℂ] Target r s :=
  ((derivativeProjection r s).comp
      ((LinearMap.toContinuousLinearMap (factorTangentMap r (s + 1)
        (monicPolynomial r x.1.1) (monicPolynomial (s + 1) x.2.2))).comp
          (amProjection r s)) -
    (r + s + 1 : ℂ) •
      ((LinearMap.toContinuousLinearMap (factorTangentMap r s
        (monicPolynomial r x.2.1) (monicPolynomial s x.1.2))).comp
          (cuProjection r s))).prod (ContinuousLinearMap.snd ℂ _ _)

@[simp] theorem derivativeLowMap_apply (r s : ℕ) (a : Parameter r s) (k : Fin (r + s)) :
    derivativeLowMap r s a k =
      (monicPolynomial r a.1 * monicPolynomial (s + 1) a.2).derivative.coeff k := by
  rw [coeff_derivative]
  simp [derivativeLowMap, derivativeProjection, factorCoefficientMap]

/-- Analyticity is proved for the concrete polynomial coefficient system. -/
theorem criticalSystemMap_analyticAt (r s : ℕ) (x : Domain r s) :
    AnalyticAt ℂ (criticalSystemMap r s) x := by
  have ham := (factorCoefficientMap_analyticAt r (s + 1) (amProjection r s x)).comp
    ((amProjection r s).analyticAt x)
  have hcu := (factorCoefficientMap_analyticAt r s (cuProjection r s x)).comp
    ((cuProjection r s).analyticAt x)
  exact (((derivativeProjection r s).analyticAt _).comp ham |>.sub
    (hcu.const_smul (c := (r + s + 1 : ℂ)))).prod analyticAt_snd

/-- The derivative is obtained by differentiating the actual two products. -/
theorem criticalSystemMap_hasFDerivAt (r s : ℕ) (x : Domain r s) :
    HasFDerivAt (criticalSystemMap r s) (criticalDifferential r s x) x := by
  have ham := (factorCoefficientMap_hasFDerivAt r (s + 1) (amProjection r s x)).comp x
    (amProjection r s).hasFDerivAt
  have hcu := (factorCoefficientMap_hasFDerivAt r s (cuProjection r s x)).comp x
    (cuProjection r s).hasFDerivAt
  exact (((derivativeProjection r s).hasFDerivAt.comp x ham).sub
    (hcu.const_smul (r + s + 1 : ℂ))).prodMk hasFDerivAt_snd

/-- At a diagonal critical factor, polynomial compatibility rules out
all nonzero kernel directions, while retaining both prescribed factors
as independent parameters. -/
theorem criticalDifferential_injective (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (x : Domain r s) (w : ℂ)
    (hcrit : monicPolynomial r x.2.1 = (X - C w) ^ r)
    (hM : (monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hvalue : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hbase : (X - C w) ^ r ∣
      (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative) :
    Function.Injective (criticalDifferential r s x) := by
  apply LinearMap.ker_eq_bot.mp
  apply LinearMap.ker_eq_bot'.mpr
  intro h hh
  have hp : h.2 = 0 := congrArg Prod.snd hh
  let Q := coefficientPolynomial r h.1.1
  let V := coefficientPolynomial s h.1.2
  let A := monicPolynomial r x.1.1
  let M := monicPolynomial (s + 1) x.2.2
  let Cp := monicPolynomial r x.2.1
  let N : ℂ := r + s + 1
  have hN : N ≠ 0 := by dsimp [N]; exact_mod_cast (by omega : r + s + 1 ≠ 0)
  have hQdeg : Q.natDegree < r := coefficientPolynomial_natDegree_lt r hr h.1.1
  have hVdeg : V.natDegree < s := coefficientPolynomial_natDegree_lt s hs h.1.2
  have hMdeg : M.natDegree = s + 1 := monicPolynomial_natDegree _ _
  have hCdeg : Cp.natDegree = r := monicPolynomial_natDegree _ _
  have hdeg : ((Q * M).derivative - C N * Cp * V).natDegree < r + s := by
    apply (natDegree_sub_le _ _).trans_lt
    apply max_lt
    · apply (natDegree_derivative_le _).trans_lt
      have hm : (Q * M).natDegree ≤ Q.natDegree + M.natDegree := natDegree_mul_le
      omega
    · have hm : (Cp * V).natDegree ≤ Cp.natDegree + V.natDegree := natDegree_mul_le
      have hc := natDegree_C_mul_le N (Cp * V)
      rw [← mul_assoc] at hc
      omega
  have hz : (Q * M).derivative - C N * Cp * V = 0 := by
    apply Polynomial.ext
    intro k
    rw [coeff_zero]
    by_cases hk : k < r + s
    · have hh' := congrArg (fun y : Target r s => y.1 ⟨k, hk⟩) hh
      have hp1 : h.2.1 = 0 := congrArg Prod.fst hp
      have hp2 : h.2.2 = 0 := congrArg Prod.snd hp
      rw [show C N * Cp * V = C N * (Cp * V) by ring,
        coeff_sub, coeff_derivative, coeff_C_mul]
      simpa [criticalDifferential, derivativeProjection, amProjection, cuProjection,
        factorTangentMap, hp1, hp2, Q, M, Cp, V, N] using hh'
    · exact coeff_eq_zero_of_natDegree_lt (by omega)
  have hdiv : (X - C w) ^ r ∣ (Q * M).derivative := by
    have heq := sub_eq_zero.mp hz
    rw [heq, ← hcrit]
    exact dvd_mul_of_dvd_left (dvd_mul_left Cp (C N)) V
  have hQzero : Q = 0 := polynomial_derivative_jet_kernel A M Q w r
    (monicPolynomial_monic r x.1.1) (monicPolynomial_natDegree r x.1.1)
    hQdeg hM hvalue hbase hdiv
  have hVzero : V = 0 := by
    have hv : C N * Cp * V = 0 := by simpa [hQzero] using hz
    exact (mul_eq_zero.mp hv).resolve_left
      (mul_ne_zero (Polynomial.C_ne_zero.mpr hN) (monicPolynomial_monic r x.2.1).ne_zero)
  apply Prod.ext
  · apply Prod.ext
    · apply coefficientPolynomial_injective r
      simpa [Q] using hQzero
    · apply coefficientPolynomial_injective s
      simpa [V] using hVzero
  · exact hp


/-- The complete polynomial identity is equivalent to the zero residual:
monicity already fixes the omitted leading coefficient. -/
theorem criticalSystemMap_zero_iff (r s : ℕ) (x : Domain r s) :
    (criticalSystemMap r s x).1 = 0 ↔
      (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative =
        C (r + s + 1 : ℂ) * monicPolynomial r x.2.1 * monicPolynomial s x.1.2 := by
  let P := monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2
  let R := monicPolynomial r x.2.1 * monicPolynomial s x.1.2
  have hP : P.Monic := (monicPolynomial_monic r x.1.1).mul (monicPolynomial_monic _ x.2.2)
  have hR : R.Monic := (monicPolynomial_monic r x.2.1).mul (monicPolynomial_monic s x.1.2)
  have hPd : P.natDegree = r + s + 1 := by
    dsimp [P]
    rw [natDegree_mul (monicPolynomial_monic r x.1.1).ne_zero
      (monicPolynomial_monic _ x.2.2).ne_zero]
    simp [Nat.add_assoc]
  have hRd : R.natDegree = r + s := by
    dsimp [R]
    rw [natDegree_mul (monicPolynomial_monic r x.2.1).ne_zero
      (monicPolynomial_monic s x.1.2).ne_zero]
    simp
  constructor
  · intro hz
    rw [mul_assoc]
    change P.derivative = C (r + s + 1 : ℂ) * R
    apply Polynomial.ext
    intro k
    rw [coeff_C_mul]
    rcases lt_trichotomy k (r + s) with hlt | heq | hgt
    · have hh := congrFun hz ⟨k, hlt⟩
      change derivativeLowMap r s (x.1.1, x.2.2) ⟨k, hlt⟩ -
        (r + s + 1 : ℂ) * R.coeff k = 0 at hh
      rw [derivativeLowMap_apply] at hh
      exact sub_eq_zero.mp hh
    · subst k
      rw [coeff_derivative]
      have hp : P.coeff (r + s + 1) = 1 := by simpa [hPd] using hP.coeff_natDegree
      have hr : R.coeff (r + s) = 1 := by simpa [hRd] using hR.coeff_natDegree
      rw [hp, hr]
      simp
    · rw [coeff_derivative, coeff_eq_zero_of_natDegree_lt (by omega),
        coeff_eq_zero_of_natDegree_lt (by omega)]
      simp
  · intro hz
    ext k
    have hh := congrArg (fun p : ℂ[X] => p.coeff k) hz
    change derivativeLowMap r s (x.1.1, x.2.2) k -
      (r + s + 1 : ℂ) * R.coeff k = 0
    rw [derivativeLowMap_apply]
    apply sub_eq_zero.mpr
    simpa only [mul_assoc, coeff_C_mul] using hh

/-- The direct reconstruction Jacobian has full rank on the diagonal. -/
theorem criticalDifferential_bijective (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (x : Domain r s) (w : ℂ)
    (hcrit : monicPolynomial r x.2.1 = (X - C w) ^ r)
    (hM : (monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hvalue : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hbase : (X - C w) ^ r ∣
      (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative) :
    Function.Bijective (criticalDifferential r s x) := by
  have hi := criticalDifferential_injective r s hr hs x w hcrit hM hvalue hbase
  refine ⟨hi, ?_⟩
  exact (LinearMap.injective_iff_surjective_of_finrank_eq_finrank
    (by simp [Domain, Target, Unknown, Parameter])).mp hi

/-- A genuine local analytic inverse of the full moving-factor coefficient
system. Its derivative and its invertibility were proved above from polynomial
identities, rather than supplied as chart assumptions. -/
theorem criticalSystemMap_local_inverse (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (x : Domain r s) (w : ℂ)
    (hcrit : monicPolynomial r x.2.1 = (X - C w) ^ r)
    (hM : (monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hvalue : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hbase : (X - C w) ^ r ∣
      (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative) :
    ∃ G : Target r s → Domain r s,
      AnalyticAt ℂ G (criticalSystemMap r s x) ∧
      G (criticalSystemMap r s x) = x ∧
      (∀ᶠ z in 𝓝 x, G (criticalSystemMap r s z) = z) ∧
      (∀ᶠ y in 𝓝 (criticalSystemMap r s x), criticalSystemMap r s (G y) = y) := by
  let D := criticalDifferential r s x
  have hbij : Function.Bijective D :=
    criticalDifferential_bijective r s hr hs x w hcrit hM hvalue hbase
  let e := (LinearEquiv.ofBijective D.toLinearMap hbij).toContinuousLinearEquiv
  have hfe : HasFDerivAt (criticalSystemMap r s) (e : Domain r s →L[ℂ] Target r s) x :=
    criticalSystemMap_hasFDerivAt r s x
  have hf : HasStrictFDerivAt (criticalSystemMap r s) (e : Domain r s →L[ℂ] Target r s) x := by
    rw [← hfe.fderiv]
    exact (criticalSystemMap_analyticAt r s x).hasStrictFDerivAt
  refine ⟨hf.localInverse (criticalSystemMap r s) e x, ?_, hf.localInverse_apply_image,
    hf.eventually_left_inverse, hf.eventually_right_inverse⟩
  exact (hf.toOpenPartialHomeomorph (criticalSystemMap r s)).analyticAt_symm'
    hf.mem_toOpenPartialHomeomorph_source (criticalSystemMap_analyticAt r s x) hfe.fderiv


/-- Holomorphic reconstruction of the interior factor for every nearby
prescribed critical factor and source factor. The reconstructed factors
satisfy the exact polynomial identity `(AM)' = N C U`, are monic of their
stated degrees, and are locally unique. This allows arbitrary splittings
through the full coefficient vectors of `C` and `M`. -/
theorem moving_critical_factor_reconstruction
    (r s : ℕ) (hr : 0 < r) (hs : 0 < s) (x : Domain r s) (w : ℂ)
    (hcrit : monicPolynomial r x.2.1 = (X - C w) ^ r)
    (hM : (monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hvalue : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hidentity :
      (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative =
        C (r + s + 1 : ℂ) * monicPolynomial r x.2.1 * monicPolynomial s x.1.2) :
    ∃ G : Parameter r s → Unknown r s,
      AnalyticAt ℂ G x.2 ∧ G x.2 = x.1 ∧
      (∀ᶠ p in 𝓝 x.2,
        (monicPolynomial r (G p).1 * monicPolynomial (s + 1) p.2).derivative =
          C (r + s + 1 : ℂ) * monicPolynomial r p.1 * monicPolynomial s (G p).2) ∧
      (∀ᶠ z in 𝓝 x,
        (monicPolynomial r z.1.1 * monicPolynomial (s + 1) z.2.2).derivative =
          C (r + s + 1 : ℂ) * monicPolynomial r z.2.1 * monicPolynomial s z.1.2 →
        G z.2 = z.1) := by
  have hb : (X - C w) ^ r ∣
      (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative := by
    rw [hidentity, ← hcrit]
    exact dvd_mul_of_dvd_left (dvd_mul_left _ _) _
  obtain ⟨H, hH, hHbase, hHleft, hHright⟩ :=
    criticalSystemMap_local_inverse r s hr hs x w hcrit hM hvalue hb
  have hzero : (criticalSystemMap r s x).1 = 0 :=
    (criticalSystemMap_zero_iff r s x).mpr hidentity
  have hFx : criticalSystemMap r s x = (0, x.2) := Prod.ext hzero rfl
  let G : Parameter r s → Unknown r s := fun p => (H (0, p)).1
  have han : AnalyticAt ℂ G x.2 := by
    rw [hFx] at hH
    exact analyticAt_fst.comp (hH.comp (analyticAt_const.prod analyticAt_id))
  have hg : G x.2 = x.1 := by
    rw [hFx] at hHbase
    exact congrArg Prod.fst hHbase
  have ht : Tendsto (fun p : Parameter r s => ((0 : Fin (r + s) → ℂ), p))
      (𝓝 x.2) (𝓝 (criticalSystemMap r s x)) := by
    rw [hFx]
    exact continuousAt_const.prodMk continuousAt_id
  refine ⟨G, han, hg, ?_, ?_⟩
  · filter_upwards [ht.eventually hHright] with p hp
    have hp' : (H (0, p)).2 = p := congrArg Prod.snd hp
    have hz : (criticalSystemMap r s (H (0, p))).1 = 0 := congrArg Prod.fst hp
    have heq := (criticalSystemMap_zero_iff r s (H (0, p))).mp hz
    simpa only [hp'] using heq
  · filter_upwards [hHleft] with z hz
    intro hpoly
    have hz0 : (criticalSystemMap r s z).1 = 0 :=
      (criticalSystemMap_zero_iff r s z).mpr hpoly
    have hfz : criticalSystemMap r s z = (0, z.2) := Prod.ext hz0 rfl
    rw [hfz] at hz
    exact congrArg Prod.fst hz


/-- Analyticity of each coefficient is preserved under any finite product
of polynomial-valued expressions. This avoids choosing analytic root labels
for a varying polynomial. -/
theorem analytic_polynomial_prod_coeff {E ι : Type*}
    [NormedAddCommGroup E] [NormedSpace ℂ E]
    (S : Finset ι) (f : E → ι → ℂ[X]) (x : E)
    (hf : ∀ i ∈ S, ∀ k, AnalyticAt ℂ (fun y => (f y i).coeff k) x) :
    ∀ k, AnalyticAt ℂ (fun y => (∏ i ∈ S, f y i).coeff k) x := by
  classical
  induction S using Finset.induction_on with
  | empty => intro k; simpa using (analyticAt_const (𝕜 := ℂ) (x := x) (v := (1 : ℂ[X]).coeff k))
  | @insert i S hi ih =>
    intro k
    have hfi := hf i (Finset.mem_insert_self i S)
    have hS := ih (fun j hj => hf j (Finset.mem_insert_of_mem hj))
    simp only [Finset.prod_insert hi, coeff_mul]
    apply Finset.analyticAt_fun_sum
    intro ij _
    exact (hfi ij.1).mul (hS ij.2)

/-- The monic polynomial with a full labelled list of roots, including
all repeated copies. -/
def rootPolynomial (n : ℕ) (z : Fin n → ℂ) : ℂ[X] := ∏ i, (X - C (z i))

def rootCoefficients (n : ℕ) (z : Fin n → ℂ) : Fin n → ℂ :=
  fun k => (rootPolynomial n z).coeff k

theorem rootPolynomial_monic (n : ℕ) (z : Fin n → ℂ) : (rootPolynomial n z).Monic :=
  monic_prod_of_monic _ _ (fun i _ => monic_X_sub_C (z i))

@[simp] theorem rootPolynomial_natDegree (n : ℕ) (z : Fin n → ℂ) :
    (rootPolynomial n z).natDegree = n := by
  unfold rootPolynomial
  rw [natDegree_prod_of_monic _ _ (fun i _ => monic_X_sub_C (z i))]
  simp

@[simp] theorem monicPolynomial_rootCoefficients (n : ℕ) (z : Fin n → ℂ) :
    monicPolynomial n (rootCoefficients n z) = rootPolynomial n z := by
  apply monic_eq_of_low_coeff _ _ n (monicPolynomial_monic _ _) (rootPolynomial_monic _ _)
  · simp
  · simp
  · intro k
    exact monicPolynomial_coeff _ _ k

@[simp] theorem rootPolynomial_const (n : ℕ) (w : ℂ) :
    rootPolynomial n (fun _ => w) = (X - C w) ^ n := by
  simp [rootPolynomial]

/-- The labelled-copy to coefficient map is holomorphic even at collisions. -/
theorem rootCoefficients_analyticAt (n : ℕ) (z : Fin n → ℂ) :
    AnalyticAt ℂ (rootCoefficients n) z := by
  apply AnalyticAt.pi
  intro k
  apply analytic_polynomial_prod_coeff
  intro i _ j
  simp only [coeff_sub, coeff_C]
  by_cases hj : j = 0
  · simp only [hj, ite_true]
    exact analyticAt_const.sub ((ContinuousLinearMap.proj i : (Fin n → ℂ) →L[ℂ] ℂ).analyticAt z)
  · simp only [hj, ite_false, sub_zero]
    exact analyticAt_const


@[simp] theorem rootPolynomial_comp_perm (n : ℕ) (z : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) : rootPolynomial n (z ∘ σ) = rootPolynomial n z := by
  exact Equiv.prod_comp σ (fun i => X - C (z i))

@[simp] theorem rootCoefficients_comp_perm (n : ℕ) (z : Fin n → ℂ)
    (σ : Equiv.Perm (Fin n)) : rootCoefficients n (z ∘ σ) = rootCoefficients n z := by
  ext k
  change (rootPolynomial n (z ∘ σ)).coeff k = (rootPolynomial n z).coeff k
  rw [rootPolynomial_comp_perm]

/-- The reconstruction in full labelled-copy coordinates. Neither critical
nor source multiplicities are required to persist; every nearby list of roots
is inserted into the exact polynomial identity. -/
theorem splitting_critical_factor_reconstruction
    (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (a : Unknown r s) (α : Fin (s + 1) → ℂ) (w : ℂ)
    (hM : (rootPolynomial (s + 1) α).eval w ≠ 0)
    (hvalue : (monicPolynomial r a.1 * rootPolynomial (s + 1) α).eval w ≠ 0)
    (hidentity :
      (monicPolynomial r a.1 * rootPolynomial (s + 1) α).derivative =
        C (r + s + 1 : ℂ) * (X - C w) ^ r * monicPolynomial s a.2) :
    ∃ G : Parameter r s → Unknown r s,
      AnalyticAt ℂ G ((fun _ => w), α) ∧ G ((fun _ => w), α) = a ∧
      (∀ᶠ q in 𝓝 (((fun _ => w), α) : Parameter r s),
        (monicPolynomial r (G q).1 * rootPolynomial (s + 1) q.2).derivative =
          C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s (G q).2) ∧
      (∀ (σ : Equiv.Perm (Fin r)) (π : Equiv.Perm (Fin (s + 1))) q,
        G (q.1 ∘ σ, q.2 ∘ π) = G q) := by
  let T : Parameter r s → Parameter r s :=
    fun q => (rootCoefficients r q.1, rootCoefficients (s + 1) q.2)
  let q₀ : Parameter r s := ((fun _ => w), α)
  let x : Domain r s := (a, T q₀)
  have hc : monicPolynomial r x.2.1 = (X - C w) ^ r := by simp [x, T, q₀]
  have hm : (monicPolynomial (s + 1) x.2.2).eval w ≠ 0 := by simpa [x, T, q₀] using hM
  have hv : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).eval w ≠ 0 := by
    simpa [x, T, q₀] using hvalue
  have he : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative =
      C (r + s + 1 : ℂ) * monicPolynomial r x.2.1 * monicPolynomial s x.1.2 := by
    simpa [x, T, q₀] using hidentity
  obtain ⟨G, hG, hG0, hpoly, _⟩ :=
    moving_critical_factor_reconstruction r s hr hs x w hc hm hv he
  have hT : AnalyticAt ℂ T q₀ :=
    ((rootCoefficients_analyticAt r q₀.1).comp analyticAt_fst).prod
      ((rootCoefficients_analyticAt (s + 1) q₀.2).comp analyticAt_snd)
  have hGa : AnalyticAt ℂ G (T q₀) := hG
  refine ⟨G ∘ T, hGa.comp hT, hG0, ?_, ?_⟩
  · filter_upwards [hT.continuousAt.eventually hpoly] with q hq
    simpa [T] using hq
  · intro σ π q
    simp [T]


/-- Evaluation of a monic coefficient vector is its leading monomial
plus the finite lower-coefficient sum. -/
theorem monicPolynomial_eval (n : ℕ) (a : Fin n → ℂ) (z : ℂ) :
    (monicPolynomial n a).eval z = z ^ n + ∑ i, a i * z ^ (i : ℕ) := by
  have he : (coefficientPolynomial n a).eval z = ∑ i, a i * z ^ (i : ℕ) := by
    simpa [coefficientPolynomial] using
      (eval_eq_sum_degreeLTEquiv ((degreeLTEquiv ℂ n).symm a).property z)
  simpa [monicPolynomial] using congrArg (fun t : ℂ => z ^ n + t) he

/-- Joint analyticity in all polynomial coefficients and the evaluation point. -/
theorem monicPolynomial_eval_analyticAt (n : ℕ) (x : (Fin n → ℂ) × ℂ) :
    AnalyticAt ℂ (fun y : (Fin n → ℂ) × ℂ => (monicPolynomial n y.1).eval y.2) x := by
  simp_rw [monicPolynomial_eval]
  apply (analyticAt_snd.pow n).add
  apply Finset.analyticAt_fun_sum
  intro i _
  exact (((ContinuousLinearMap.proj i : (Fin n → ℂ) →L[ℂ] ℂ).analyticAt x.1).comp
    analyticAt_fst).mul (analyticAt_snd.pow (i : ℕ))

@[simp] theorem rootPolynomial_eval_copy (n : ℕ) (z : Fin n → ℂ) (i : Fin n) :
    (rootPolynomial n z).eval (z i) = 0 := by
  simp only [rootPolynomial, eval_prod, eval_sub, eval_X, eval_C]
  exact Finset.prod_eq_zero (Finset.mem_univ i) (sub_self _)

/-- A nonvanishing residual factor at the collision stays nonvanishing
at every nearby labelled critical copy. This prevents unintended extra
multiplicity at the prescribed copies. -/
theorem residual_factor_nonzero_near_copies (r s : ℕ)
    (G : Parameter r s → Unknown r s) (α : Fin (s + 1) → ℂ) (w : ℂ)
    (hG : AnalyticAt ℂ G (((fun _ => w), α) : Parameter r s))
    (hU : (monicPolynomial s (G ((fun _ => w), α)).2).eval w ≠ 0) :
    ∀ᶠ q in 𝓝 (((fun _ => w), α) : Parameter r s),
      ∀ i : Fin r, (monicPolynomial s (G q).2).eval (q.1 i) ≠ 0 := by
  apply Filter.eventually_all.mpr
  intro i
  have hcoeff : AnalyticAt ℂ (fun q => (G q).2)
      (((fun _ => w), α) : Parameter r s) := analyticAt_snd.comp hG
  have hroot : AnalyticAt ℂ (fun q : Parameter r s => q.1 i)
      (((fun _ => w), α) : Parameter r s) :=
    (((ContinuousLinearMap.proj i : (Fin r → ℂ) →L[ℂ] ℂ).comp
      (ContinuousLinearMap.fst ℂ (Fin r → ℂ) (Fin (s + 1) → ℂ))).analyticAt _)
  have heval := (monicPolynomial_eval_analyticAt s ((G ((fun _ => w), α)).2, w)).comp_of_eq
    (hcoeff.prod hroot) rfl
  exact heval.continuousAt.eventually_ne hU

/-- In the reconstructed polynomial, a prescribed critical copy has
exactly the multiplicity supplied by its labelled critical factor whenever
the residual factor is nonzero there. -/
theorem reconstructed_critical_multiplicity
    (r s : ℕ) (a : Unknown r s) (q : Parameter r s)
    (hid : (monicPolynomial r a.1 * rootPolynomial (s + 1) q.2).derivative =
      C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s a.2)
    (i : Fin r) (hU : (monicPolynomial s a.2).eval (q.1 i) ≠ 0) :
    (monicPolynomial r a.1 * rootPolynomial (s + 1) q.2).derivative.rootMultiplicity (q.1 i) =
      (rootPolynomial r q.1).rootMultiplicity (q.1 i) := by
  have hN : (r + s + 1 : ℂ) ≠ 0 := by exact_mod_cast (by omega : r + s + 1 ≠ 0)
  have hC : (C (r + s + 1 : ℂ) * rootPolynomial r q.1) ≠ 0 :=
    mul_ne_zero (Polynomial.C_ne_zero.mpr hN) (rootPolynomial_monic r q.1).ne_zero
  have hprod : (C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s a.2) ≠ 0 :=
    mul_ne_zero hC (monicPolynomial_monic s a.2).ne_zero
  rw [hid, rootMultiplicity_mul hprod, rootMultiplicity_mul hC, rootMultiplicity_C,
    rootMultiplicity_eq_zero hU]
  simp


/-- Nonvanishing of a residual polynomial persists uniformly on a disk
around the base point, not only at the prescribed copies. -/
theorem residual_factor_nonzero_on_disk {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℂ E]
    (n : ℕ) (H : E → Fin n → ℂ) (x : E) (w : ℂ)
    (hH : ContinuousAt H x) (hU : (monicPolynomial n (H x)).eval w ≠ 0) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ᶠ y in 𝓝 x,
      ∀ z ∈ Metric.ball w ε, (monicPolynomial n (H y)).eval z ≠ 0 := by
  have hp : ContinuousAt (fun y : E × ℂ => (H y.1, y.2)) (x, w) :=
    (hH.comp continuousAt_fst).prodMk continuousAt_snd
  have he : ContinuousAt (fun y : E × ℂ => (monicPolynomial n (H y.1)).eval y.2)
      (x, w) := (monicPolynomial_eval_analyticAt n (H x, w)).continuousAt.comp_of_eq hp rfl
  have hn := he.eventually_ne hU
  obtain ⟨U, hUx, V, hVw, hsub⟩ := mem_nhds_prod_iff.mp hn
  obtain ⟨ε, hε, hball⟩ := Metric.mem_nhds_iff.mp hVw
  refine ⟨ε, hε, ?_⟩
  filter_upwards [hUx] with y hy
  intro z hz
  exact @hsub (y, z) ⟨hy, hball hz⟩

/-- In a disk where the residual factor is nonzero, the actual critical
roots are exactly the prescribed cluster. -/
theorem reconstructed_cluster_exact_on_disk
    (r s : ℕ) (a : Unknown r s) (q : Parameter r s) (w : ℂ) (ε : ℝ)
    (hid : (monicPolynomial r a.1 * rootPolynomial (s + 1) q.2).derivative =
      C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s a.2)
    (hU : ∀ z ∈ Metric.ball w ε, (monicPolynomial s a.2).eval z ≠ 0) :
    ∀ z ∈ Metric.ball w ε,
      (monicPolynomial r a.1 * rootPolynomial (s + 1) q.2).derivative.IsRoot z ↔
        (rootPolynomial r q.1).IsRoot z := by
  intro z hz
  have hN : (r + s + 1 : ℂ) ≠ 0 := by exact_mod_cast (by omega : r + s + 1 ≠ 0)
  rw [hid]
  simp only [Polynomial.IsRoot, eval_mul, eval_C, mul_eq_zero, hN, hU z hz,
    false_or, or_false]

end PolynomialGeometry.CriticalReconstruction
