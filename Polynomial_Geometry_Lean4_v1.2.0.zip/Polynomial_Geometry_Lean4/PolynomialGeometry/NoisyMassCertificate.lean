import PolynomialGeometry.NoisyContourRecovery
import Mathlib.Topology.MetricSpace.HausdorffDistance

/-! # Certified recovery on a circle with the exact extrema of Theorem 3.4 -/

noncomputable section

open Polynomial Complex Metric Set WithLp
open scoped Polynomial ComplexOrder

namespace PolynomialGeometry.NoisyContour

/-- The radius and all constants in this statement are computed from the fitted
data and the given inverse-metric error bound. The complete realization supplies
a true source inside the circle. For polynomial data its mass is identified
whenever the resulting closed mass disk isolates a positive integer. -/
theorem noisy_mass_recovery_extrema {ι σ : Type*} [Fintype ι] [DecidableEq ι]
    [Fintype σ] [DecidableEq σ] (a : ℂ) (n : ℝ) (H J Fhat : Matrix ι ι ℂ)
    (e : ι → ℂ) (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef) (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y) (j₀ : σ)
    (hmark : α j₀ = a) (c : ℂ) (r ε : ℝ) (hr : 0 < r)
    (hout : a ∉ closedBall c r) (hF : NoisyMetric.opNorm₂ (H⁻¹ - Fhat) ≤ ε) :
    let Γ := sphere c r
    let v := NoisyMetric.metricVector a J e
    let Qhat := NoisyMetric.supportPoly J e Fhat v n
    let m := sInf ((fun z => ‖Qhat.eval z‖) '' Γ)
    let η := n * ε * ‖toLp 2 v‖ * sSup (NoisyMetric.adjRowNorm J e '' Γ)
    let M := sSup ((fun z => ‖J.charpoly.eval z‖) '' Γ)
    let E := r * (n * M * η / (infDist a Γ * m * (m - η)))
    η < m → diskCount Qhat c r = 1 →
    ∃ (j : σ) (bhat : ℂ), j ≠ j₀ ∧ α j ∈ ball c r ∧
      (∀ k, α k ∈ closedBall c r → k = j) ∧
      bhat ∈ ball c r ∧ Qhat.eval bhat = 0 ∧
      (∀ b ∈ closedBall c r, Qhat.eval b = 0 → b = bhat) ∧
      ‖(ω j : ℂ)^2 - rootResidue (C (n:ℂ) * J.charpoly) Qhat a bhat‖ ≤ E ∧
      (∀ (k : ℕ), (∃ T : ℂ[X], T.Monic ∧ ∀ z, T.eval z ≠ 0 → (∀ l, z ≠ α l) →
          T.derivative.eval z / T.eval z = ∑ l, (ω l : ℂ)^2 / (z - α l)) →
        (∀ t : ℕ, 0 < t → ‖(t:ℂ) - rootResidue (C (n:ℂ) * J.charpoly) Qhat a bhat‖ ≤ E →
          t = k) → ω j^2 = (k:ℝ)) := by
  classical
  let Γ := sphere c r
  let v := NoisyMetric.metricVector a J e
  let Qhat := NoisyMetric.supportPoly J e Fhat v n
  let L := sSup (NoisyMetric.adjRowNorm J e '' Γ)
  let m := sInf ((fun z => ‖Qhat.eval z‖) '' Γ)
  let η := n * ε * ‖toLp 2 v‖ * L
  let M := sSup ((fun z => ‖J.charpoly.eval z‖) '' Γ)
  change η < m → diskCount Qhat c r = 1 → _
  intro hgap hcount
  have hne : Γ.Nonempty := NormedSpace.sphere_nonempty.mpr hr.le
  have hd : 0 < infDist a Γ := (isClosed_sphere.notMem_iff_infDist_pos hne).mp
    (fun hz => hout (sphere_subset_closedBall hz))
  have hrow (z) (hz : z ∈ Γ) : NoisyMetric.adjRowNorm J e z ≤ L :=
    le_csSup ((isCompact_sphere c r).bddAbove_image
      (NoisyMetric.continuous_adjRowNorm J e).continuousOn) ⟨z, hz, rfl⟩
  have hdist (z) (hz : z ∈ Γ) : infDist a Γ ≤ ‖z-a‖ := by
    simpa only [dist_comm a z, dist_eq_norm] using infDist_le_dist_of_mem (x := a) hz
  have heval (z) (hz : z ∈ Γ) := NoisyMetric.circle_eval_bounds Qhat J.charpoly c r z hz
  exact noisy_mass_recovery a n H J Fhat e α ω Y hn hH hdim hreal j₀ hmark
    c r ε L (infDist a Γ) m η M hr.le hout hd hgap hF hrow le_rfl hdist
    (fun z hz => (heval z hz).2) (fun z hz => (heval z hz).1) hcount

end PolynomialGeometry.NoisyContour
