import Mathlib.Analysis.Complex.Norm
import Mathlib.Data.Finset.Lattice.Fold
import Mathlib.Tactic

/-!
# Nearest distance and reciprocal spectral thresholds

The finite spectral list includes inherited modes when present. The
matrix realization of that list is a separate construction, so no
matrix-spectrum equality is silently assumed here.
-/
noncomputable section
namespace PolynomialGeometry.ReciprocalDistance
variable {ι : Type*} [Fintype ι] [Nonempty ι]

/-- Distance to the nearest point in a nonempty finite spectral list. -/
def nearestDistance (a : ℂ) (w : ι → ℂ) : ℝ :=
  Finset.univ.inf' Finset.univ_nonempty (fun j => ‖a - w j‖)

/-- Radius of the reciprocal spectral list. -/
def reciprocalRadius (a : ℂ) (w : ι → ℂ) : ℝ :=
  Finset.univ.sup' Finset.univ_nonempty (fun j => ‖(a - w j)⁻¹‖)

/-- The exact geometric-to-discrete-instability threshold, including equality. -/
theorem distance_iff_reciprocal_threshold (a : ℂ) (w : ι → ℂ)
    (hsep : ∀ j, a ≠ w j) (r : ℝ) (hr : 0 < r) :
    nearestDistance a w ≤ r ↔ 1 ≤ r * reciprocalRadius a w := by
  rw [mul_comm r, ← div_le_iff₀ hr]
  unfold nearestDistance reciprocalRadius
  rw [Finset.inf'_le_iff, Finset.le_sup'_iff]
  apply exists_congr
  intro j
  rw [norm_inv, one_div]
  have hd : 0 < ‖a - w j‖ := norm_pos_iff.mpr (sub_ne_zero.mpr (hsep j))
  rw [inv_le_inv₀ hr hd]

end PolynomialGeometry.ReciprocalDistance
