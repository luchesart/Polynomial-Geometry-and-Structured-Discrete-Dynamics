import PolynomialGeometry.AnalyticCompensation
import PolynomialGeometry.KernelMaximum

/-!
# Compensated maximum in the actual Hessian-kernel coordinates

The kernel and its orthogonal complement are constructed from the objective.
The negative block and its inverse are derived from negative semidefiniteness.
-/

noncomputable section
open Filter Asymptotics
open scoped Topology

namespace PolynomialGeometry.KernelCompensation
open KernelMaximum AnalyticCompensation

variable {W : Type*} [NormedAddCommGroup W] [InnerProductSpace ℝ W]
  [FiniteDimensional ℝ W]

/-- All iterated derivatives in the canonical coordinates are the actual
original derivatives applied to the corresponding vectors. -/
theorem kernel_coordinate_iterated_derivative (F : W → ℝ) (n : ℕ)
    (v : Fin n → hessianKernel F × (hessianKernel F)ᗮ) :
    iteratedFDeriv ℝ n (fun p => F (kernelCoordinates F p)) 0 v =
      iteratedFDeriv ℝ n F 0 (fun i => kernelCoordinates F (v i)) := by
  have h := (kernelCoordinates F).iteratedFDerivWithin_comp_right F
    uniqueDiffOn_univ (Set.mem_univ ((kernelCoordinates F) 0)) n
  have hv := congrArg (fun A => A v) h
  simpa only [Set.preimage_univ, iteratedFDerivWithin_univ,
    ContinuousMultilinearMap.compContinuousLinearMap_apply,
    ContinuousLinearEquiv.coe_coe, map_zero] using hv

/-- In canonical coordinates the mixed response pairs with the original
third derivative, with vectors included from the actual kernel and its
orthogonal complement. -/
theorem canonical_mixedCubic_pairing (F : W → ℝ) (hF : AnalyticAt ℝ F 0)
    (x : hessianKernel F) (s : (hessianKernel F)ᗮ) :
    inner ℝ (mixedCubic (fun p => F (kernelCoordinates F p)) x) s =
      iteratedFDeriv ℝ 3 F 0 ![(x : W),(x : W),(s : W)] := by
  have hG : AnalyticAt ℝ (fun p => F (kernelCoordinates F p)) 0 :=
    hF.comp_of_eq' ((kernelCoordinates F).toContinuousLinearMap.analyticAt 0)
      (map_zero (kernelCoordinates F))
  rw [mixedCubic_pairing _ hG, kernel_coordinate_iterated_derivative]
  congr 1
  funext i
  fin_cases i <;> simp

/-- The response vector in the actual orthogonal complement of the Hessian
kernel, computed from the objective in its canonical coordinates. -/
def canonicalMixedCubic (F : W → ℝ) (x : hessianKernel F) : (hessianKernel F)ᗮ :=
  mixedCubic (fun p => F (kernelCoordinates F p)) x

/-- The full compensated nonlinear construction from the original hypotheses:
analyticity, stationarity and a negative semidefinite actual Hessian.
Neither the kernel decomposition, the positive operator nor its response is
supplied as an additional hypothesis. -/
theorem canonical_compensated_partial_maximum (F : W → ℝ)
    (hF : AnalyticAt ℝ F 0) (hF0 : F 0 = 0) (hDF : fderiv ℝ F 0 = 0)
    (hneg : ∀ u : W, fderiv ℝ (fderiv ℝ F) 0 u u ≤ 0) :
    ∃ (P : (hessianKernel F)ᗮ →L[ℝ] (hessianKernel F)ᗮ)
      (hP : ∀ s : (hessianKernel F)ᗮ, s ≠ 0 → 0 < inner ℝ s (P s))
      (θ : hessianKernel F → (hessianKernel F)ᗮ),
      (∀ s t : (hessianKernel F)ᗮ, inner ℝ s (P t) =
        -fderiv ℝ (fderiv ℝ F) 0 (s : W) (t : W)) ∧
      AnalyticAt ℝ θ 0 ∧ θ 0 = 0 ∧ fderiv ℝ θ 0 = 0 ∧
      AnalyticAt ℝ (fun x : hessianKernel F => F ((x : W) + (θ x : W))) 0 ∧
      (∀ᶠ x in 𝓝 0, PartialMaximum.partialGradient
        (fun p => F (kernelCoordinates F p)) (x, θ x) = 0) ∧
      (∀ᶠ p : hessianKernel F × (hessianKernel F)ᗮ in 𝓝 0,
        PartialMaximum.partialGradient (fun p => F (kernelCoordinates F p)) p = 0 →
          p.2 = θ p.1) ∧
      (∃ c : ℝ, 0 < c ∧ ∀ᶠ p : hessianKernel F × (hessianKernel F)ᗮ in 𝓝 0,
        F ((p.1 : W) + (p.2 : W)) ≤
          F ((p.1 : W) + (θ p.1 : W)) - c * ‖p.2 - θ p.1‖ ^ 2) ∧
      ((∃ᶠ w : W in 𝓝 0, 0 < F w) ↔
        (∃ᶠ x : hessianKernel F in 𝓝 0, 0 < F ((x : W) + (θ x : W)))) ∧
      ((fun x => θ x - (1 / 2 : ℝ) •
          (PartialMaximum.positiveHessianEquiv P hP).symm (canonicalMixedCubic F x))
        =O[𝓝 0] (fun x => ‖x‖ ^ 3)) ∧
      ((fun x : hessianKernel F => F ((x : W) + (θ x : W)) -
        ((1 / 6 : ℝ) * iteratedFDeriv ℝ 3 F 0 (fun _ => (x : W)) +
         (1 / 24 : ℝ) * iteratedFDeriv ℝ 4 F 0 (fun _ => (x : W)) +
         (1 / 8 : ℝ) * inner ℝ (canonicalMixedCubic F x)
           ((PartialMaximum.positiveHessianEquiv P hP).symm (canonicalMixedCubic F x))))
        =O[𝓝 0] (fun x => ‖x‖ ^ 5)) := by
  obtain ⟨P,hP,hH⟩ := canonical_kernel_block_data F hF hneg
  let G := fun p => F (kernelCoordinates F p)
  have hG := kernel_coordinate_analytic F hF
  have hG0 : G 0 = 0 := by simp [G, hF0]
  have hDG := kernel_coordinate_zero_derivative F hF hDF
  obtain ⟨θ,hθ,hθ0,hDθ,ha,hs,hu,hd,hp,hj,he⟩ :=
    analytic_compensated_partial_maximum G hG hG0 hDG P hP hH
  refine ⟨P,hP,θ,?_,hθ,hθ0,hDθ,ha,hs,hu,hd,?_,hj,?_⟩
  · intro s t
    have hh := hH (0,s) (0,t)
    rw [kernel_coordinate_hessian F hF] at hh
    simp only [kernelCoordinates_apply, Submodule.coe_zero, zero_add] at hh
    linarith
  · exact (kernel_coordinate_frequently_positive_iff F).symm.trans hp
  · dsimp only [G] at he
    simp only [kernel_coordinate_iterated_derivative] at he
    simpa only [canonicalMixedCubic, kernelCoordinates_apply, Submodule.coe_zero, add_zero] using he

/-- The necessary cubic and compensated quartic tests on the actual Hessian
kernel of the original objective. The positive operator is recovered from
the same actual Hessian. -/
theorem canonical_kernel_necessary (F : W → ℝ)
    (hF : AnalyticAt ℝ F 0) (hF0 : F 0 = 0) (hDF : fderiv ℝ F 0 = 0)
    (hneg : ∀ u : W, fderiv ℝ (fderiv ℝ F) 0 u u ≤ 0)
    (hmax : IsLocalMax F 0) :
    ∃ (P : (hessianKernel F)ᗮ →L[ℝ] (hessianKernel F)ᗮ)
      (hP : ∀ s : (hessianKernel F)ᗮ, s ≠ 0 → 0 < inner ℝ s (P s)),
      (∀ s t : (hessianKernel F)ᗮ, inner ℝ s (P t) =
        -fderiv ℝ (fderiv ℝ F) 0 (s : W) (t : W)) ∧
      ∀ x : hessianKernel F,
        iteratedFDeriv ℝ 3 F 0 (fun _ => (x : W)) = 0 ∧
        iteratedFDeriv ℝ 4 F 0 (fun _ => (x : W)) +
          3 * inner ℝ (canonicalMixedCubic F x)
            ((PartialMaximum.positiveHessianEquiv P hP).symm (canonicalMixedCubic F x)) ≤ 0 := by
  obtain ⟨P,hP,hH⟩ := canonical_kernel_block_data F hF hneg
  refine ⟨P,hP,?_,?_⟩
  · intro s t
    have hh := hH (0,s) (0,t)
    rw [kernel_coordinate_hessian F hF] at hh
    simp only [kernelCoordinates_apply, Submodule.coe_zero, zero_add] at hh
    linarith
  · intro x
    have hG := kernel_coordinate_analytic F hF
    have hG0 : (fun p => F (kernelCoordinates F p)) 0 = 0 := by simp [hF0]
    have hDG := kernel_coordinate_zero_derivative F hF hDF
    have hm := (kernel_coordinate_local_max_iff F).mpr hmax
    have h := analytic_kernel_necessary _ hG hG0 hDG P hP hH hm x
    simp only [kernel_coordinate_iterated_derivative] at h
    simpa only [canonicalMixedCubic, kernelCoordinates_apply, Submodule.coe_zero, add_zero] using h

end PolynomialGeometry.KernelCompensation
