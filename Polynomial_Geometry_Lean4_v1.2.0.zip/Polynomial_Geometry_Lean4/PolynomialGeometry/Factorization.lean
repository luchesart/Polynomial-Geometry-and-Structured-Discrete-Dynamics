import PolynomialGeometry.Variations
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas
import Mathlib.Analysis.Calculus.FDeriv.Mul

/-!
# Analytic factorization in finite coefficient coordinates

The coefficient map and its differential are concrete polynomial expressions.
The coprime kernel argument below is the first factorization step in Lemma 5.1.
-/

noncomputable section

namespace PolynomialGeometry.Factorization

open Polynomial Filter
open scoped BigOperators Topology

/-- The polynomial with the prescribed coefficients below degree `n`. -/
def coefficientPolynomial (n : ℕ) : (Fin n → ℂ) →ₗ[ℂ] ℂ[X] :=
  (degreeLT ℂ n).subtype.comp (degreeLTEquiv ℂ n).symm.toLinearMap

/-- A monic polynomial parameterized by all of its lower coefficients. -/
def monicPolynomial (n : ℕ) (a : Fin n → ℂ) : ℂ[X] :=
  X ^ n + coefficientPolynomial n a

theorem coefficientPolynomial_degree_lt (n : ℕ) (a : Fin n → ℂ) :
    (coefficientPolynomial n a).degree < n :=
  mem_degreeLT.mp ((degreeLTEquiv ℂ n).symm a).property

theorem coefficientPolynomial_natDegree_lt (n : ℕ) (hn : 0 < n) (a : Fin n → ℂ) :
    (coefficientPolynomial n a).natDegree < n := by
  by_cases h : coefficientPolynomial n a = 0
  · simpa [h] using hn
  · exact (natDegree_lt_iff_degree_lt h).mpr (coefficientPolynomial_degree_lt n a)

theorem monicPolynomial_monic (n : ℕ) (a : Fin n → ℂ) :
    (monicPolynomial n a).Monic :=
  monic_X_pow_add (coefficientPolynomial_degree_lt n a)

@[simp] theorem monicPolynomial_natDegree (n : ℕ) (a : Fin n → ℂ) :
    (monicPolynomial n a).natDegree = n := by
  unfold monicPolynomial
  rw [natDegree_add_eq_left_of_degree_lt]
  · simp
  · simpa using coefficientPolynomial_degree_lt n a

theorem coefficientPolynomial_injective (n : ℕ) :
    Function.Injective (coefficientPolynomial n) := by
  intro a b hab
  apply (degreeLTEquiv ℂ n).symm.injective
  exact Subtype.ext hab

/-- All lower coefficients of the product of the two monic factors. -/
def factorCoefficientMap (r s : ℕ)
    (a : (Fin r → ℂ) × (Fin s → ℂ)) : Fin (r + s) → ℂ :=
  fun k => (monicPolynomial r a.1 * monicPolynomial s a.2).coeff k

/-- The true differential of multiplication: `U δC + C δU`. -/
def factorTangentMap (r s : ℕ) (C U : ℂ[X]) :
    ((Fin r → ℂ) × (Fin s → ℂ)) →ₗ[ℂ] (Fin (r + s) → ℂ) where
  toFun h k := (coefficientPolynomial r h.1 * U + C * coefficientPolynomial s h.2).coeff k
  map_add' a b := by
    ext k
    simp [add_mul, mul_add]
    ring
  map_smul' c a := by
    ext k
    simp [mul_add]

/-- Coprimality of the factors makes the coefficient multiplication
Jacobian injective, including all coefficient directions of each factor. -/
theorem factorTangentMap_injective (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (C U : ℂ[X]) (hC : C.Monic) (_hU : U.Monic)
    (hdegC : C.natDegree = r) (hdegU : U.natDegree = s)
    (hcop : IsCoprime C U) : Function.Injective (factorTangentMap r s C U) := by
  apply LinearMap.ker_eq_bot.mp
  apply LinearMap.ker_eq_bot'.mpr
  intro a ha
  let Q := coefficientPolynomial r a.1
  let V := coefficientPolynomial s a.2
  have hQdeg : Q.natDegree < r := coefficientPolynomial_natDegree_lt r hr a.1
  have hVdeg : V.natDegree < s := coefficientPolynomial_natDegree_lt s hs a.2
  have hdeg : (Q * U + C * V).natDegree < r + s := by
    apply (natDegree_add_le _ _).trans_lt
    apply max_lt
    · exact natDegree_mul_le.trans_lt (by omega)
    · exact natDegree_mul_le.trans_lt (by omega)
  have hzero : Q * U + C * V = 0 := by
    apply Polynomial.ext
    intro k
    rw [coeff_zero]
    by_cases hk : k < r + s
    · exact congrFun ha ⟨k, hk⟩
    · exact coeff_eq_zero_of_natDegree_lt (by omega)
  have hdvd : C ∣ Q * U := by
    have heq : Q * U = -(C * V) := eq_neg_of_add_eq_zero_left hzero
    rw [heq]
    exact dvd_neg.mpr (dvd_mul_right C V)
  have hQzero : Q = 0 :=
    eq_zero_of_dvd_of_natDegree_lt (hcop.dvd_of_dvd_mul_right hdvd) (by omega)
  have hVzero : V = 0 := by
    have hh : C * V = 0 := by simpa [hQzero] using hzero
    exact (mul_eq_zero.mp hh).resolve_left hC.ne_zero
  apply Prod.ext
  · apply coefficientPolynomial_injective r
    simpa [Q] using hQzero
  · apply coefficientPolynomial_injective s
    simpa [V] using hVzero

/-- The factorization differential is square, hence its injectivity
is equivalent to the full-rank condition required by analytic inversion. -/
theorem factorTangentMap_bijective (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (C U : ℂ[X]) (hC : C.Monic) (hU : U.Monic)
    (hdegC : C.natDegree = r) (hdegU : U.natDegree = s)
    (hcop : IsCoprime C U) : Function.Bijective (factorTangentMap r s C U) := by
  have hi := factorTangentMap_injective r s hr hs C U hC hU hdegC hdegU hcop
  refine ⟨hi, ?_⟩
  exact (LinearMap.injective_iff_surjective_of_finrank_eq_finrank (by simp)).mp hi


/-- A single lower coefficient, as a continuous linear functional. -/
def coefficientCLM (n k : ℕ) : (Fin n → ℂ) →L[ℂ] ℂ :=
  LinearMap.toContinuousLinearMap {
    toFun := fun a => (coefficientPolynomial n a).coeff k
    map_add' := by intros; simp
    map_smul' := by intros; simp }

theorem analytic_monic_coefficient (n k : ℕ) (a : Fin n → ℂ) :
    AnalyticAt ℂ (fun x => (monicPolynomial n x).coeff k) a := by
  change AnalyticAt ℂ (fun x => (X ^ n + coefficientPolynomial n x).coeff k) a
  simp only [coeff_add]
  exact analyticAt_const.add ((coefficientCLM n k).analyticAt a)

theorem hasFDerivAt_monic_coefficient (n k : ℕ) (a : Fin n → ℂ) :
    HasFDerivAt (fun x => (monicPolynomial n x).coeff k) (coefficientCLM n k) a := by
  change HasFDerivAt (fun x => (X ^ n + coefficientPolynomial n x).coeff k) _ a
  simp only [coeff_add]
  exact (coefficientCLM n k).hasFDerivAt.const_add ((X ^ n : ℂ[X]).coeff k)

/-- Multiplication of monic factors is analytic in all finite coefficient
coordinates. There is no root-labelling assumption in this assertion. -/
theorem factorCoefficientMap_analyticAt (r s : ℕ)
    (a : (Fin r → ℂ) × (Fin s → ℂ)) :
    AnalyticAt ℂ (factorCoefficientMap r s) a := by
  apply AnalyticAt.pi
  intro k
  simp only [factorCoefficientMap, coeff_mul]
  apply Finset.analyticAt_fun_sum
  intro ij _
  exact ((analytic_monic_coefficient r ij.1 a.1).comp analyticAt_fst).mul
    ((analytic_monic_coefficient s ij.2 a.2).comp analyticAt_snd)

/-- Direct differentiation of coefficient convolution gives the
multiplication tangent map used in the coprimality argument. -/
theorem factorCoefficientMap_hasFDerivAt (r s : ℕ)
    (a : (Fin r → ℂ) × (Fin s → ℂ)) :
    HasFDerivAt (factorCoefficientMap r s)
      (LinearMap.toContinuousLinearMap
        (factorTangentMap r s (monicPolynomial r a.1) (monicPolynomial s a.2))) a := by
  apply hasFDerivAt_pi'.mpr
  intro k
  have hh := HasFDerivAt.fun_sum (u := Finset.antidiagonal (k : ℕ))
    (fun ij _ =>
      ((hasFDerivAt_monic_coefficient r ij.1 a.1).comp a hasFDerivAt_fst).mul
        ((hasFDerivAt_monic_coefficient s ij.2 a.2).comp a hasFDerivAt_snd))
  convert hh using 1
  · funext x
    simp [factorCoefficientMap, coeff_mul]
  · apply ContinuousLinearMap.ext
    intro x
    simp [factorTangentMap, coeff_add, coeff_mul, Finset.sum_add_distrib, coefficientCLM]
    rw [add_comm]
    congr 1
    apply Finset.sum_congr rfl
    intro ij _
    ring


@[simp] theorem coefficientPolynomial_coeff (n : ℕ) (a : Fin n → ℂ) (k : Fin n) :
    (coefficientPolynomial n a).coeff k = a k :=
  congrFun ((degreeLTEquiv ℂ n).apply_symm_apply a) k

@[simp] theorem monicPolynomial_coeff (n : ℕ) (a : Fin n → ℂ) (k : Fin n) :
    (monicPolynomial n a).coeff k = a k := by
  simp [monicPolynomial, coeff_X_pow, ne_of_lt k.isLt]

/-- Monicity and the degree fix the missing leading coefficient, so the
lower coefficient vector determines the whole polynomial. -/
theorem monic_eq_of_low_coeff (P Q : ℂ[X]) (n : ℕ)
    (hP : P.Monic) (hQ : Q.Monic) (hPd : P.natDegree = n) (hQd : Q.natDegree = n)
    (hc : ∀ k : Fin n, P.coeff k = Q.coeff k) : P = Q := by
  apply Polynomial.ext
  intro k
  rcases lt_trichotomy k n with hlt | heq | hgt
  · exact hc ⟨k, hlt⟩
  · subst k
    simpa [hPd, hQd] using hP.coeff_natDegree.trans hQ.coeff_natDegree.symm
  · rw [coeff_eq_zero_of_natDegree_lt (by omega),
      coeff_eq_zero_of_natDegree_lt (by omega)]

theorem monicPolynomial_factorCoefficientMap (r s : ℕ)
    (a : (Fin r → ℂ) × (Fin s → ℂ)) :
    monicPolynomial (r + s) (factorCoefficientMap r s a) =
      monicPolynomial r a.1 * monicPolynomial s a.2 := by
  apply monic_eq_of_low_coeff _ _ (r + s)
  · exact monicPolynomial_monic _ _
  · exact (monicPolynomial_monic r a.1).mul (monicPolynomial_monic s a.2)
  · simp
  · rw [natDegree_mul (monicPolynomial_monic r a.1).ne_zero
      (monicPolynomial_monic s a.2).ne_zero]
    simp
  · intro k
    exact monicPolynomial_coeff _ _ k

/-- Actual local holomorphic factorization near two coprime monic
factors. The factors vary analytically with all coefficients of the product.
This establishes the monic-factorization step in Lemma 5.1; it does not yet
construct the subsequent critical-root/marked-source coordinate chart. -/
theorem local_holomorphic_monic_factorization (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (a : (Fin r → ℂ) × (Fin s → ℂ))
    (hcop : IsCoprime (monicPolynomial r a.1) (monicPolynomial s a.2)) :
    ∃ G : (Fin (r + s) → ℂ) → ((Fin r → ℂ) × (Fin s → ℂ)),
      AnalyticAt ℂ G (factorCoefficientMap r s a) ∧
      G (factorCoefficientMap r s a) = a ∧
      (∀ᶠ b in 𝓝 a, G (factorCoefficientMap r s b) = b) ∧
      (∀ᶠ p in 𝓝 (factorCoefficientMap r s a),
        monicPolynomial r (G p).1 * monicPolynomial s (G p).2 =
          monicPolynomial (r + s) p) := by
  let D := factorTangentMap r s (monicPolynomial r a.1) (monicPolynomial s a.2)
  have hbij : Function.Bijective D := factorTangentMap_bijective r s hr hs _ _
    (monicPolynomial_monic r a.1) (monicPolynomial_monic s a.2)
    (monicPolynomial_natDegree r a.1) (monicPolynomial_natDegree s a.2) hcop
  let e := (LinearEquiv.ofBijective D hbij).toContinuousLinearEquiv
  have hfe : HasFDerivAt (factorCoefficientMap r s)
      (e : ((Fin r → ℂ) × (Fin s → ℂ)) →L[ℂ] (Fin (r + s) → ℂ)) a :=
    factorCoefficientMap_hasFDerivAt r s a
  have hf : HasStrictFDerivAt (factorCoefficientMap r s)
      (e : ((Fin r → ℂ) × (Fin s → ℂ)) →L[ℂ] (Fin (r + s) → ℂ)) a := by
    rw [← hfe.fderiv]
    exact (factorCoefficientMap_analyticAt r s a).hasStrictFDerivAt
  let G := hf.localInverse (factorCoefficientMap r s) e a
  have han : AnalyticAt ℂ G (factorCoefficientMap r s a) :=
    (hf.toOpenPartialHomeomorph (factorCoefficientMap r s)).analyticAt_symm'
      hf.mem_toOpenPartialHomeomorph_source (factorCoefficientMap_analyticAt r s a) hfe.fderiv
  refine ⟨G, han, hf.localInverse_apply_image, hf.eventually_left_inverse, ?_⟩
  filter_upwards [hf.eventually_right_inverse] with p hp
  rw [← monicPolynomial_factorCoefficientMap]
  exact congrArg (monicPolynomial (r + s)) hp

end PolynomialGeometry.Factorization
