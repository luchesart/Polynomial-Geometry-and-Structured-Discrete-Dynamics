import PolynomialGeometry.FullFeasibleReduction
import PolynomialGeometry.FullRatioChart
import PolynomialGeometry.WeightedBoundaryStrict

/-! # The feasible reduction from original polynomial hypotheses

The complete reconstruction and the ratio inverse are constructed here. The
only further conditions are the actual diagonal nondegeneracy, scalar free
stationarity, and strictly positive outward responses appearing in the article.
-/
noncomputable section
open Polynomial Filter
open scoped Topology
namespace PolynomialGeometry.OriginalFeasibleReduction
open Factorization CriticalReconstruction SimpleRoot ReconstructionCompletion FullFeasibleReduction
open PolynomialFeasibleChart FeasibleReduction RatioCoordinates

/-- The reduced objective of the same reconstructed family and ratio inverse
is a real analytic function of all remaining angle coordinates. -/
theorem reducedLogObjective_analyticAt
    (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ)
    (R : LocalReconstructionResult r s A β w a₀ v₀)
    (G : Parameter r s → Parameter r s) (τ : ℝ)
    (hG : AnalyticAt ℂ G (0,β)) (hG0 : G (0,β) = ((fun _ => w),β))
    (hq : w-a₀ ≠ 0) (hg : v₀-a₀ ≠ 0) :
    AnalyticAt ℝ (reducedLogObjective r s R.sourceRoot R.simpleCritical G
      (w-a₀) (v₀-a₀) β τ) 0 := by
  have hK := WeightedStationarity.weightedLog_analyticAt R.sourceRoot R.simpleCritical
    (w-a₀) (v₀-a₀) w β τ R.source_analytic R.critical_analytic hq hg
    (by rw [R.source_base]) (by rw [R.source_base,R.critical_base])
  have hH := hK.comp_of_eq hG hG0
  have hF := RealBoundaryChart.smoothObjective_analyticAt
    (fun p => WeightedStationarity.weightedLog R.sourceRoot R.simpleCritical
      (w-a₀) (v₀-a₀) τ (G p)) β hH
  have hslice : AnalyticAt ℝ
      (fun u : (Fin r → ℝ) × (Fin (s + 1) → ℝ) =>
        ((0 : Fin r → ℝ), ((0 : Fin (s + 1) → ℝ), u))) 0 :=
    analyticAt_const.prod (analyticAt_const.prod analyticAt_id)
  have hresult := hF.comp_of_eq hslice rfl
  simpa only [Function.comp_def, RealBoundaryChart.reduced_objective, reducedLogObjective] using hresult

/-- The precise coefficient-space conclusion, with an actual analytic
continuation of the selected root and the actual reduced logarithm. -/
def CoefficientConclusion
    (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ) (D τ : ℝ)
    (R : LocalReconstructionResult r s A β w a₀ v₀)
    (G : Parameter r s → Parameter r s) : Prop :=
  ∃ a : Coefficients r s → ℂ,
    AnalyticAt ℂ a (baseCoefficients r s A β) ∧
    a (baseCoefficients r s A β) = a₀ ∧
    (∀ᶠ p in 𝓝 (baseCoefficients r s A β),
      (monicPolynomial (r + (s + 1)) p).eval (a p) = 0) ∧
    ((∃ᶠ p in 𝓝 (baseCoefficients r s A β),
        rootsInDisk (monicPolynomial (r + (s + 1)) p) ∧
        D < criticalDistance (monicPolynomial (r + (s + 1)) p) (a p)) ↔
      arbitrarilyNearPositive
        (reducedLogObjective r s R.sourceRoot R.simpleCritical G
          (w-a₀) (v₀-a₀) β τ) (fun _ => True))

/-- Every sufficiently small reduced parameter describes an actual feasible
polynomial with balanced active distances and the exact reduced log gain. -/
def BalancedSliceConclusion
    (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ) (D τ : ℝ)
    (R : LocalReconstructionResult r s A β w a₀ v₀)
    (G : Parameter r s → Parameter r s) : Prop :=
  ∀ᶠ u : (Fin r → ℝ) × (Fin (s + 1) → ℝ) in 𝓝 0,
    let t := balancedLabels r s G β u
    rootsInDisk (reconstructedPolynomial r s R.family t) ∧
    (∀ j, ‖t.2 j‖ = 1) ∧
    (∀ z, (monicPolynomial r (R.family t).1).IsRoot z → ‖z‖ < 1) ∧
    (∀ i, ‖t.1 i-R.sourceRoot t‖ = ‖R.simpleCritical t-R.sourceRoot t‖) ∧
    criticalDistance (reconstructedPolynomial r s R.family t) (R.sourceRoot t) =
      ‖R.simpleCritical t-R.sourceRoot t‖ ∧
    Real.log (criticalDistance (reconstructedPolynomial r s R.family t) (R.sourceRoot t) / D) =
      reducedLogObjective r s R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β τ u

/-- The real chart covers every coefficient neighborhood and identifies
the exact distance objective and source constraints on one full neighborhood. -/
def RealChartConclusion
    (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ) (D τ : ℝ)
    (R : LocalReconstructionResult r s A β w a₀ v₀)
    (G : Parameter r s → Parameter r s) : Prop :=
  Filter.map (fun p : RealBoundaryChart.Coordinates (ι := Fin r) (κ := Fin (s + 1)) =>
    coefficientChart r s R.family (G (RealBoundaryChart.chart β p))) (𝓝 0) =
      𝓝 (baseCoefficients r s A β) ∧
  ∀ᶠ p : RealBoundaryChart.Coordinates (ι := Fin r) (κ := Fin (s + 1)) in 𝓝 0,
    let t := G (RealBoundaryChart.chart β p)
    (rootsInDisk (reconstructedPolynomial r s R.family t) ↔ ∀ j, p.2.1 j ≤ 0) ∧
    (∀ z, (monicPolynomial r (R.family t).1).IsRoot z → ‖z‖ < 1) ∧
    (reconstructedPolynomial r s R.family t).eval (R.sourceRoot t) = 0 ∧
    reconstructedLogGain r s R.family R.sourceRoot G β D p =
      objective (RealBoundaryChart.smoothObjective
        (fun q => WeightedStationarity.weightedLog R.sourceRoot R.simpleCritical
          (w-a₀) (v₀-a₀) τ (G q)) β) τ p

/-- Exact uniform replacement gains for the full critical distance of the
actual reconstructed polynomial, on the same chart as the other conclusions. -/
def StrictReductionConclusion
    (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ) (D τ : ℝ)
    (R : LocalReconstructionResult r s A β w a₀ v₀)
    (G : Parameter r s → Parameter r s) : Prop :=
  let L := reconstructedLogGain r s R.family R.sourceRoot G β D
  ∃ c : ℝ, 0 < c ∧ ∀ᶠ p in
      𝓝 (0 : RealBoundaryChart.Coordinates (ι := Fin r) (κ := Fin (s + 1))),
    (L p ≤ L (0,p.2) - (Variations.balancingConstant (ι := Fin r) τ / 2) * ‖p.1‖) ∧
    ((∀ j, p.2.1 j ≤ 0) → L (0,p.2) ≤ L (0,(0,p.2.2)) - c * ‖p.2.1‖) ∧
    ((∀ j, p.2.1 j ≤ 0) → L p ≤
      reducedLogObjective r s R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β τ p.2.2 -
      (Variations.balancingConstant (ι := Fin r) τ / 2) * ‖p.1‖ - c * ‖p.2.1‖)

/-- The coefficient-space equivalence, real analyticity, actual reduced
polynomials and strict replacement gains use one common reconstruction. -/
def CompleteConclusion
    (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ) (D τ : ℝ)
    (R : LocalReconstructionResult r s A β w a₀ v₀)
    (G : Parameter r s → Parameter r s) : Prop :=
  CoefficientConclusion r s A β w a₀ v₀ D τ R G ∧
  AnalyticAt ℝ (reducedLogObjective r s R.sourceRoot R.simpleCritical G
    (w-a₀) (v₀-a₀) β τ) 0 ∧
  BalancedSliceConclusion r s A β w a₀ v₀ D τ R G ∧
  RealChartConclusion r s A β w a₀ v₀ D τ R G ∧
  StrictReductionConclusion r s A β w a₀ v₀ D τ R G

/-- The complete constructed-chart conclusion of the original feasible
reduction theorem. Every hypothesis on responses refers to its own R and G. -/
def ReductionConclusion
    (r s : ℕ) (hr : 0 < r) (A : ℂ[X]) (β : Fin (s + 1) → ℂ)
    (w a₀ v₀ : ℂ) (D : ℝ) : Prop :=
  ∃ R : LocalReconstructionResult r s A β w a₀ v₀,
      (deriv (fun t => parameterLogRatios R.sourceRoot R.simpleCritical
        (w-a₀) (v₀-a₀) ((fun _ => t),β) ⟨0,hr⟩) w ≠ 0 →
        ∃ G : Parameter r s → Parameter r s,
          AnalyticAt ℂ G (0,β) ∧ G (0,β) = ((fun _ => w),β) ∧
          (∀ᶠ q in 𝓝 (((fun _ => w),β) : Parameter r s),
            G (FullRatioChart.forward r s R.sourceRoot R.simpleCritical
              (w-a₀) (v₀-a₀) q) = q) ∧
          (∀ᶠ p in 𝓝 ((0,β) : Parameter r s),
            FullRatioChart.forward r s R.sourceRoot R.simpleCritical
              (w-a₀) (v₀-a₀) (G p) = p) ∧
          (∀ τ : ℝ, 0 < τ → τ < 1 →
            deriv (fun t : ℂ =>
              (τ : ℂ) * Complex.log ((w-a₀)⁻¹ * (t-R.sourceRoot ((fun _ => t),β))) +
              (1-τ) * Complex.log ((v₀-a₀)⁻¹ *
                (R.simpleCritical ((fun _ => t),β)-R.sourceRoot ((fun _ => t),β)))) w = 0 →
            radialCondition r s R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β τ →
            CompleteConclusion r s A β w a₀ v₀ D τ R G))

/-- Theorem 5.3, with every chart constructed from the original polynomial.
The positive residual degree is written `s+1`. This loses no configuration:
the distinct simple critical point forces that degree to be positive.
The hypotheses about the diagonal and radial responses concern the constructed
functions themselves, as in the article. -/
theorem original_polynomial_feasible_reduction_positive_residual
    (r s : ℕ) (hr : 0 < r)
    (A : ℂ[X]) (β : Fin (s + 1 + 1) → ℂ) (w a₀ v₀ : ℂ) (D : ℝ)
    (hA : A.Monic) (hAd : A.natDegree = r)
    (hinterior : ∀ z, A.IsRoot z → ‖z‖ < 1)
    (hboundary : ∀ j, ‖β j‖ = 1)
    (hvalue : (A * rootPolynomial (s + 1 + 1) β).eval w ≠ 0)
    (hmult : (A * rootPolynomial (s + 1 + 1) β).derivative.rootMultiplicity w = r)
    (haRoot : A.eval a₀ = 0) (haSimple : A.derivative.eval a₀ ≠ 0)
    (hwv : v₀ ≠ w)
    (hvRoot : (A * rootPolynomial (s + 1 + 1) β).derivative.eval v₀ = 0)
    (hvSimple : (A * rootPolynomial (s + 1 + 1) β).derivative.derivative.eval v₀ ≠ 0)
    (hD : 0 < D) (hq : ‖w-a₀‖ = D) (hg : ‖v₀-a₀‖ = D)
    (hgap : ∀ z, (A * rootPolynomial (s + 1 + 1) β).derivative.IsRoot z →
      z ≠ w → z ≠ v₀ → D < ‖z-a₀‖) :
    ReductionConclusion r (s + 1) hr A β w a₀ v₀ D := by
  letI : NeZero r := ⟨Nat.ne_of_gt hr⟩
  obtain ⟨R⟩ := full_reconstruction_from_original_hypotheses r (s + 1) hr
    A β w a₀ v₀ hA hAd hinterior hboundary hvalue hmult haRoot haSimple hwv hvRoot hvSimple
  refine ⟨R,?_⟩
  intro hdiag
  have hqne : w-a₀ ≠ 0 := norm_ne_zero_iff.mp (hq ▸ hD.ne')
  have hgne : v₀-a₀ ≠ 0 := norm_ne_zero_iff.mp (hg ▸ hD.ne')
  obtain ⟨G,hG,hG0,hleft,hright,hparam,hmapG,_⟩ :=
    FullRatioChart.full_ratio_chart r (s + 1) hr A β w a₀ v₀ R hqne hgne hdiag
  refine ⟨G,hG,hG0,hleft,hright,?_⟩
  intro τ hτ hτ1 hfree hrad
  have hfree' := WeightedStationarity.free_stationarity_hasDerivAt
    R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) w β τ
    R.source_analytic R.critical_analytic hqne hgne
    (by rw [R.source_base]) (by rw [R.source_base,R.critical_base]) hfree
  have hcoeff := coefficient_space_exact_reduction r s hr A β w a₀ v₀ D τ hD hτ hτ1 R
    hboundary hq hg hgap G hG hG0 hright hparam hmapG hfree' hrad
  have hpsi := reducedLogObjective_analyticAt r (s+1) A β w a₀ v₀ R G τ hG hG0 hqne hgne
  have hbalanced := balanced_slice_geometry r s hr A β w a₀ v₀ D τ hD R
    hboundary hq hg hgap G hG hG0 hright
  have hreal := real_chart_exact_geometry r s hr A β w a₀ v₀ D τ hD R
    hboundary hq hg hgap G hG hG0 hright
  have hβne : ∀ j, β j ≠ 0 := fun j => norm_ne_zero_iff.mp (by rw [hboundary j]; norm_num)
  have hcover := coefficientRealChart_map_nhds r (s+1) A β w a₀ v₀ R hβne G hmapG
  have hstrict := actual_polynomial_replacement_bounds r s hr A β w a₀ v₀ D τ hD hτ hτ1 R
    hboundary hq hg hgap G hG hG0 hright hparam hfree' hrad
  exact ⟨hcoeff,hpsi,hbalanced,⟨hcover,hreal⟩,hstrict⟩

/-- Complete feasible reduction with the original source-list indexing.
Positivity of the residual degree is derived from the distinct simple critical
point. Thus even a single boundary copy is considered, and that impossible
case is excluded by the polynomial hypotheses rather than an extra assumption. -/
theorem original_polynomial_feasible_reduction
    (r s : ℕ) (hr : 0 < r)
    (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ) (D : ℝ)
    (hA : A.Monic) (hAd : A.natDegree = r)
    (hinterior : ∀ z, A.IsRoot z → ‖z‖ < 1)
    (hboundary : ∀ j, ‖β j‖ = 1)
    (hvalue : (A * rootPolynomial (s + 1) β).eval w ≠ 0)
    (hmult : (A * rootPolynomial (s + 1) β).derivative.rootMultiplicity w = r)
    (haRoot : A.eval a₀ = 0) (haSimple : A.derivative.eval a₀ ≠ 0)
    (hwv : v₀ ≠ w)
    (hvRoot : (A * rootPolynomial (s + 1) β).derivative.eval v₀ = 0)
    (hvSimple : (A * rootPolynomial (s + 1) β).derivative.derivative.eval v₀ ≠ 0)
    (hD : 0 < D) (hq : ‖w-a₀‖ = D) (hg : ‖v₀-a₀‖ = D)
    (hgap : ∀ z, (A * rootPolynomial (s + 1) β).derivative.IsRoot z →
      z ≠ w → z ≠ v₀ → D < ‖z-a₀‖) :
    ReductionConclusion r s hr A β w a₀ v₀ D := by
  cases s with
  | zero =>
    obtain ⟨R⟩ := full_reconstruction_from_original_hypotheses r 0 hr
      A β w a₀ v₀ hA hAd hinterior hboundary hvalue hmult haRoot haSimple hwv hvRoot hvSimple
    have hroot := R.residual_factor_root.self_of_nhds
    have hpositive := natDegree_pos_of_monic_of_aeval_eq_zero
      (monicPolynomial_monic 0 (R.family ((fun _ => w),β)).2)
      (show aeval (R.simpleCritical ((fun _ => w),β))
        (monicPolynomial 0 (R.family ((fun _ => w),β)).2) = 0 from hroot)
    simp only [monicPolynomial_natDegree, lt_self_iff_false] at hpositive
  | succ s =>
    exact original_polynomial_feasible_reduction_positive_residual r s hr
      A β w a₀ v₀ D hA hAd hinterior hboundary hvalue hmult haRoot haSimple hwv hvRoot hvSimple
      hD hq hg hgap

end PolynomialGeometry.OriginalFeasibleReduction
