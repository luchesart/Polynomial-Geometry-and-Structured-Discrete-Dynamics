import PolynomialGeometry.SelectedRecovery
import PolynomialGeometry.PolynomialRecovery

/-! # The inverse theorem from minimal realization data

The polynomial numerator identity is used through Cayley--Hamilton to
derive source orthogonality. It is not included among the realization
hypotheses.
-/

noncomputable section
open Matrix Polynomial
open scoped ComplexOrder

namespace PolynomialGeometry.InverseEquivalence

variable {ι σ : Type*} [Fintype ι] [DecidableEq ι]
  [Fintype σ] [DecidableEq σ]

omit [Fintype σ] in
theorem support_aeval_isUnit (J : Matrix ι ι ℂ) (α : σ → ℂ)
    (s : Finset σ) (hsep : ∀ j ∈ s, IsUnit (α j • (1 : Matrix ι ι ℂ) - J)) :
    IsUnit (aeval J (Source.support s α)) := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert j s hj ih =>
    rw [Source.support_insert s α j hj, map_mul]
    apply IsUnit.mul _ (ih (fun k hk => hsep k (Finset.mem_insert_of_mem hk)))
    have hh := (hsep j (Finset.mem_insert_self j s)).neg
    simpa [map_sub, aeval_X, aeval_C, Algebra.algebraMap_eq_smul_one, neg_sub] using hh

theorem numerator_resolvent_sum_zero (J : Matrix ι ι ℂ) (α ν : σ → ℂ) (n : ℂ)
    (hsep : ∀ j, IsUnit (α j • (1 : Matrix ι ι ℂ) - J))
    (hnum : Source.rawNumerator Finset.univ α ν = C n * J.charpoly) :
    (∑ j, ν j • (α j • (1 : Matrix ι ι ℂ) - J)⁻¹) = 0 := by
  let Q := aeval J (Source.support Finset.univ α)
  have hQ : IsUnit Q := support_aeval_isUnit J α _ (fun j _ => hsep j)
  have he (j : σ) :
      aeval J (Source.support (Finset.univ.erase j) α) =
        -((α j • (1 : Matrix ι ι ℂ) - J)⁻¹ * Q) := by
    have hh := congrArg (aeval J) (Source.support_erase_mul Finset.univ α (Finset.mem_univ j))
    simp only [map_mul, map_sub, aeval_X, aeval_C, Algebra.algebraMap_eq_smul_one] at hh
    have hh' : (α j • (1 : Matrix ι ι ℂ) - J) *
        aeval J (Source.support (Finset.univ.erase j) α) = -Q := by
      change _ = -(aeval J (Source.support Finset.univ α))
      rw [← hh, ← neg_sub, Matrix.neg_mul]
    have hleft := congrArg (fun T => (α j • (1 : Matrix ι ι ℂ) - J)⁻¹ * T) hh'
    dsimp only at hleft
    rw [← Matrix.mul_assoc, Matrix.nonsing_inv_mul _
      ((Matrix.isUnit_iff_isUnit_det _).mp (hsep j)), Matrix.one_mul,
      Matrix.mul_neg] at hleft
    exact hleft
  have hz := congrArg (aeval J) hnum
  simp only [Source.rawNumerator, map_sum, map_mul, aeval_C,
    Matrix.aeval_self_charpoly, mul_zero, Algebra.algebraMap_eq_smul_one,
    smul_mul_assoc, Matrix.one_mul, he, smul_neg] at hz
  have hz' : (∑ j, ν j • (α j • (1 : Matrix ι ι ℂ) - J)⁻¹) * Q = 0 :=
    neg_eq_zero.mp (by simpa only [Finset.sum_neg_distrib, ← smul_mul_assoc,
      ← Matrix.sum_mul] using hz)
  exact hQ.mul_right_cancel (hz'.trans (Matrix.zero_mul Q).symm)


/-- The rational numerator condition is equivalent to its polynomial identity. -/
theorem numerator_identity_iff (J : Matrix ι ι ℂ) (α ν : σ → ℂ) (n : ℂ) :
    Source.rawNumerator Finset.univ α ν = C n * J.charpoly ↔
      ∀ z, (∀ j, z ≠ α j) →
        (∑ j, ν j / (z - α j)) = n * J.charpoly.eval z / ∏ j, (z - α j) := by
  constructor
  · intro h z hz
    have hh := Source.rawNumerator_eq_support_mul_sourceFunction Finset.univ α ν z
      (fun j _ => hz j)
    rw [h, eval_mul, eval_C, Source.support_eval] at hh
    apply (eq_div_iff (Finset.prod_ne_zero_iff.mpr (fun j _ => sub_ne_zero.mpr (hz j)))).mpr
    simpa only [Source.sourceFunction, mul_comm] using hh.symm
  · intro h
    apply Polynomial.eq_of_infinite_eval_eq
    apply (Set.infinite_univ.diff (Set.finite_range α)).mono
    intro z hz
    have hsep : ∀ j, z ≠ α j := fun j hj => hz.2 ⟨j, hj.symm⟩
    have hp := Finset.prod_ne_zero_iff.mpr (fun j (_ : j ∈ Finset.univ) =>
      sub_ne_zero.mpr (hsep j))
    simp only [Set.mem_setOf_eq, eval_mul, eval_C]
    rw [Source.rawNumerator_eq_support_mul_sourceFunction Finset.univ α ν z
      (fun j _ => hsep j)]
    simpa only [Source.sourceFunction, Source.support_eval, mul_comm] using
      ((eq_div_iff hp).mp (h z hsep))

/-- The row formula itself implies the source equation. -/
theorem canonical_rows_source_identity (J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α b : σ → ℂ) (Y : Matrix σ ι ℂ)
    (hsep : ∀ j, IsUnit (α j • (1 : Matrix ι ι ℂ) - J))
    (hrows : ∀ j, (fun i => Y j i) = -b j •
      (star e ᵥ* (α j • (1 : Matrix ι ι ℂ) - J)⁻¹)) :
    diagonal α * Y = Y * J - vecMulVec b (star e) := by
  ext j i
  have hh := congrArg (fun v => v ᵥ* (α j • (1 : Matrix ι ι ℂ) - J)) (hrows j)
  dsimp only at hh
  rw [Matrix.smul_vecMul, Matrix.vecMul_vecMul, Matrix.nonsing_inv_mul _
    ((Matrix.isUnit_iff_isUnit_det _).mp (hsep j)), Matrix.vecMul_one] at hh
  have hi := congrFun hh i
  simp only [Matrix.vecMul_sub, Matrix.vecMul_smul, Matrix.vecMul_one,
    Pi.sub_apply, Pi.smul_apply, smul_eq_mul, neg_mul] at hi
  simp only [Matrix.diagonal_mul, Matrix.sub_apply, Matrix.vecMulVec_apply]
  change α j * Y j i = ((fun k => Y j k) ᵥ* J) i - b j * star (e i)
  linear_combination hi

/-- Completeness forces orthogonality through Cayley--Hamilton. -/
theorem canonical_rows_orthogonal (J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α b ν : σ → ℂ) (Y : Matrix σ ι ℂ) (n : ℂ)
    (hweights : ∀ j, star (b j) * b j = ν j)
    (hsep : ∀ j, IsUnit (α j • (1 : Matrix ι ι ℂ) - J))
    (hnum : Source.rawNumerator Finset.univ α ν = C n * J.charpoly)
    (hrows : ∀ j, (fun i => Y j i) = -b j •
      (star e ᵥ* (α j • (1 : Matrix ι ι ℂ) - J)⁻¹)) :
    star b ᵥ* Y = 0 := by
  have hsum := numerator_resolvent_sum_zero J α ν n hsep hnum
  funext i
  have hh := congrFun (congrArg (fun A => star e ᵥ* A) hsum) i
  simp only [Matrix.vecMul_zero, Pi.zero_apply, Matrix.vecMul_sum, Matrix.vecMul_smul,
    Finset.sum_apply, Pi.smul_apply, smul_eq_mul] at hh
  change (∑ j, star (b j) * Y j i) = 0
  have hr (j : σ) : star (b j) * Y j i =
      -(ν j * (star e ᵥ* (α j • (1 : Matrix ι ι ℂ) - J)⁻¹) i) := by
    have hi := congrFun (hrows j) i
    simp only [Pi.smul_apply, smul_eq_mul] at hi
    rw [hi, ← hweights j]
    ring
  simp only [hr, Finset.sum_neg_distrib, hh, neg_zero]


omit [DecidableEq ι] in
/-- The full Gram matrix follows from the three scalar/state blocks. -/
theorem sourceBasis_gram (b : Option ι → ℂ) (Y : Matrix (Option ι) ι ℂ)
    (H : Matrix ι ι ℂ) (n : ℝ)
    (hmass : star b ⬝ᵥ b = (n : ℂ)) (horth : star b ᵥ* Y = 0)
    (hGram : Yᴴ * Y = H) :
    (InverseCofactor.sourceBasis b Y)ᴴ * InverseCofactor.sourceBasis b Y =
      BlockMetric.metric n H := by
  ext i j
  cases i with
  | none =>
    cases j with
    | none => exact hmass
    | some j => exact congrFun horth j
  | some i =>
    cases j with
    | none =>
      have hh := congrArg star (congrFun horth i)
      simpa [Matrix.vecMul, dotProduct, map_sum, StarMul.star_mul, mul_comm,
        InverseCofactor.sourceBasis, Matrix.mul_apply, Matrix.conjTranspose_apply,
        BlockMetric.metric] using hh
    | some j => exact congrArg (fun A : Matrix ι ι ℂ => A i j) hGram

/-- The selected row forces the entire normalized border, after the
orthogonality required for the source basis has been derived. -/
theorem sourceBasis_normalized_intertwining (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α b : Option ι → ℂ) (Y : Matrix (Option ι) ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hmass : star b ⬝ᵥ b = (n : ℂ)) (horth : star b ᵥ* Y = 0)
    (hGram : Yᴴ * Y = H)
    (hsource : diagonal α * Y = Y * J - vecMulVec b (star e))
    (j₀ : Option ι) (ha : α j₀ = a) (hb : b j₀ = 1)
    (hrow : (fun i => Y j₀ i) =
      -(star e ᵥ* (a • (1 : Matrix ι ι ℂ) - J)⁻¹)) :
    diagonal α * InverseCofactor.sourceBasis b Y =
      InverseCofactor.sourceBasis b Y *
        Inverse.normalizedCompletion a n H J (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e := by
  let B := InverseCofactor.sourceBasis b Y
  let R := (a • (1 : Matrix ι ι ℂ) - J)⁻¹
  let h := Inverse.recoveryVector H R e
  let v : Option ι → ℂ := Option.rec (n : ℂ)⁻¹ (-h)
  let q : Option ι → ℂ := Pi.single j₀ 1
  let S := BlockMetric.metric n H
  let M := Inverse.normalizedCompletion a n H J R e
  have hBS : Bᴴ * B = S := sourceBasis_gram b Y H n hmass horth hGram
  have hS : S.PosDef := BlockMetric.metric_posDef n H hn hH
  have hB : IsUnit B.det := by
    have hh := (Matrix.isUnit_iff_isUnit_det _).mp (hBS ▸ hS.isUnit)
    rw [Matrix.det_mul] at hh
    exact isUnit_iff_ne_zero.mpr (fun hz => by simpa [hz] using hh.ne_zero)
  have hBstar : Function.Injective (Bᴴ).mulVec :=
    Matrix.mulVec_injective_of_isUnit (by
      apply (Matrix.isUnit_iff_isUnit_det _).mpr
      rw [Matrix.det_conjTranspose]
      exact hB.star)
  have hBV : B *ᵥ v = q := by
    apply hBstar
    rw [Matrix.mulVec_mulVec, hBS]
    funext k
    cases k with
    | none =>
      change (S *ᵥ v) none = (Bᴴ *ᵥ q) none
      rw [BlockMetric.metric_mulVec]
      change (n : ℂ) * (n : ℂ)⁻¹ = _
      rw [mul_inv_cancel₀ (by exact_mod_cast (ne_of_gt hn))]
      simp only [q, Matrix.mulVec, dotProduct, Pi.single_apply, mul_ite,
        mul_one, mul_zero, Finset.sum_ite_eq', Finset.mem_univ, ite_true,
        Matrix.conjTranspose_apply, B, InverseCofactor.sourceBasis, Option.elim_none, hb,
        star_one]
    | some i =>
      have hi := congrFun hrow i
      have hi' : star (Y j₀ i) = -((Rᴴ *ᵥ e) i) := by
        rw [hi]
        simp [R, Matrix.vecMul, Matrix.mulVec, dotProduct,
          Matrix.conjTranspose_apply, StarMul.star_mul, mul_comm]
      have hHinv := Matrix.mul_nonsing_inv H ((Matrix.isUnit_iff_isUnit_det _).mp hH.isUnit)
      rw [BlockMetric.metric_mulVec]
      change (H *ᵥ (-h)) i = ((Bᴴ) *ᵥ q) (some i)
      rw [Matrix.mulVec_neg]
      have hh : H *ᵥ h = Rᴴ *ᵥ e := by
        change H *ᵥ (H⁻¹ *ᵥ (Rᴴ *ᵥ e)) = _
        rw [Matrix.mulVec_mulVec, hHinv, Matrix.one_mulVec]
      rw [hh]
      simp only [q, Matrix.mulVec, dotProduct, Pi.single_apply, mul_ite,
        mul_one, mul_zero, Finset.sum_ite_eq', Finset.mem_univ, ite_true,
        Matrix.conjTranspose_apply, B, InverseCofactor.sourceBasis, Option.elim_some,
        Pi.neg_apply]
      exact hi'.symm
  have hMv : M *ᵥ v = a • v := by
    apply BlockMetric.coordinates.injective
    rw [map_smul]
    change BlockMetric.coordinates ((Inverse.normalizedCompletion a n H J R e) *ᵥ v) = _
    rw [Inverse.normalizedCompletion, BlockMetric.completion_action]
    exact Inverse.normalizedBorder_selected_eigenvector _ _ _ _ _
      (by exact_mod_cast (ne_of_gt hn))
  have hAq : diagonal α *ᵥ q = a • q := by
    funext j
    by_cases hj : j = j₀
    · subst j
      simp [q, ha]
    · simp [q, hj]
  have haction : (diagonal α * B) *ᵥ v = (B * M) *ᵥ v := by
    rw [← Matrix.mulVec_mulVec, hBV, hAq, ← Matrix.mulVec_mulVec,
      hMv, Matrix.mulVec_smul, hBV]
  have hstate (j : Option ι) (i : ι) :
      (diagonal α * B) j (some i) = (B * M) j (some i) := by
    have hh := congrArg (fun T : Matrix (Option ι) ι ℂ => T j i) hsource
    simp only [Matrix.diagonal_mul, Matrix.sub_apply, Matrix.vecMulVec_apply] at hh
    rw [Matrix.diagonal_mul]
    simpa only [B, M, InverseCofactor.sourceBasis, Inverse.normalizedCompletion,
      BlockMetric.completion, Matrix.diagonal_mul, Matrix.mul_apply,
      Fintype.sum_option, Option.elim_some, Option.elim_none, mul_neg,
      Pi.star_apply, sub_eq_add_neg, add_comm] using hh
  ext j k
  cases k with
  | some i => exact hstate j i
  | none =>
    have hh := congrFun haction j
    simp only [Matrix.mulVec, dotProduct, Fintype.sum_option, hstate] at hh
    have hh' := add_right_cancel hh
    change (diagonal α * B) j none * (n : ℂ)⁻¹ = (B * M) j none * (n : ℂ)⁻¹ at hh'
    exact mul_right_cancel₀ (inv_ne_zero (by exact_mod_cast (ne_of_gt hn))) hh'


/-- Minimal complete realization data. The weights are positive square
roots of the masses. Orthogonality, source equations, similarity and
normality are deliberately not fields of this proposition. -/
def CompleteRealization (a : ℂ) (n : ℝ) (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ) : Prop :=
  Function.Injective α ∧ (∀ j, 0 < ω j ∧ ‖α j‖ ≤ 1) ∧
  (∑ j, ω j ^ 2) = n ∧ (∃ j, α j = a ∧ ω j = 1) ∧ Yᴴ * Y = H ∧
  (∀ j, IsUnit (α j • (1 : Matrix ι ι ℂ) - J) ∧
    (fun i => Y j i) = -(ω j : ℂ) •
      (star e ᵥ* (α j • (1 : Matrix ι ι ℂ) - J)⁻¹)) ∧
  (∀ z, (∀ j, z ≠ α j) →
    (∑ j, (ω j : ℂ)^2 / (z - α j)) =
      (n : ℂ) * J.charpoly.eval z / ∏ j, (z - α j))

/-- The minimal realization data construct a full source/state basis. -/
theorem completeRealization_basis (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : CompleteRealization a n H J e α ω Y) :
    ∃ (q : σ ≃ Option ι) (B : Matrix (Option ι) (Option ι) ℂ),
      Bᴴ * B = BlockMetric.metric n H ∧
      diagonal (α ∘ q.symm) * B = B *
        Inverse.normalizedCompletion a n H J (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e := by
  classical
  obtain ⟨hinj, hpos, htotal, hselected, hGram, hrows, hfunction⟩ := hreal
  let b : σ → ℂ := fun j => (ω j : ℂ)
  have hnum := (numerator_identity_iff J α (fun j => (ω j : ℂ)^2) n).mpr hfunction
  have hsource := canonical_rows_source_identity J e α b Y
    (fun j => (hrows j).1) (fun j => (hrows j).2)
  have horth := canonical_rows_orthogonal J e α b (fun j => (ω j : ℂ)^2) Y n
    (by intro j; simp [b, pow_two]) (fun j => (hrows j).1) hnum
    (fun j => (hrows j).2)
  have hmass : star b ⬝ᵥ b = (n : ℂ) := by
    have hh := congrArg (fun t : ℝ => (t : ℂ)) htotal
    push_cast at hh
    simpa [b, dotProduct, pow_two] using hh
  let q : σ ≃ Option ι := Fintype.equivOfCardEq (by simpa using hdim)
  let α' : Option ι → ℂ := α ∘ q.symm
  let b' : Option ι → ℂ := b ∘ q.symm
  let Y' : Matrix (Option ι) ι ℂ := Y.submatrix q.symm id
  have hmass' : star b' ⬝ᵥ b' = (n : ℂ) := by
    exact (q.symm.sum_comp (fun j => star (b j) * b j)).trans hmass
  have horth' : star b' ᵥ* Y' = 0 := by
    funext i
    exact (q.symm.sum_comp (fun j => star (b j) * Y j i)).trans (congrFun horth i)
  have hGram' : Y'ᴴ * Y' = H := by
    ext i j
    exact (q.symm.sum_comp (fun k => star (Y k i) * Y k j)).trans
      (congrArg (fun T : Matrix ι ι ℂ => T i j) hGram)
  have hsource' : diagonal α' * Y' = Y' * J - vecMulVec b' (star e) := by
    ext j i
    have hh := congrArg (fun T : Matrix σ ι ℂ => T (q.symm j) i) hsource
    dsimp only at hh
    rw [Matrix.diagonal_mul] at hh ⊢
    simpa only [Matrix.sub_apply, Matrix.vecMulVec_apply,
      Matrix.mul_apply, α', b', Y', Matrix.submatrix_apply, Function.comp_apply, id_eq] using hh
  obtain ⟨j₀, ha, hb⟩ := hselected
  have hrow' : (fun i => Y' (q j₀) i) =
      -(star e ᵥ* (a • (1 : Matrix ι ι ℂ) - J)⁻¹) := by
    simpa only [Y', Matrix.submatrix_apply, Equiv.symm_apply_apply, id_eq, ha, hb,
      Complex.ofReal_one, neg_smul, one_smul] using (hrows j₀).2
  exact ⟨q, InverseCofactor.sourceBasis b' Y',
    sourceBasis_gram b' Y' H n hmass' horth' hGram',
    sourceBasis_normalized_intertwining a n H J e α' b' Y' hn hH
      hmass' horth' hGram' hsource' (q j₀)
      (by simpa [α'] using ha) (by simp [b', b, hb]) hrow'⟩

/-- The full completion test is necessary from minimal realization data. -/
theorem completeRealization_necessary (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : CompleteRealization a n H J e α ω Y) :
    let M := Inverse.normalizedCompletion a n H J (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e
    let S := BlockMetric.metric n H
    M * Inverse.weightedAdjoint S M = Inverse.weightedAdjoint S M * M ∧
      (S - Mᴴ * S * M).PosSemidef := by
  obtain ⟨q, B, hGram, hBM⟩ := completeRealization_basis a n H J e α ω Y hn hH hdim hreal
  exact Inverse.completion_test_of_source_basis _ _ B (α ∘ q.symm)
    (BlockMetric.metric_posDef n H hn hH) (fun j => (hreal.2.1 (q.symm j)).2) hGram hBM

/-- Every minimal realization has exactly the completion's source spectrum. -/
theorem completeRealization_support_charpoly (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : CompleteRealization a n H J e α ω Y) :
    Source.support Finset.univ α =
      (Inverse.normalizedCompletion a n H J (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e).charpoly := by
  obtain ⟨q, B, hGram, hBM⟩ := completeRealization_basis a n H J e α ω Y hn hH hdim hreal
  have hB : IsUnit B.det := by
    have hh := (Matrix.isUnit_iff_isUnit_det _).mp
      (hGram ▸ (BlockMetric.metric_posDef n H hn hH).isUnit)
    rw [Matrix.det_mul] at hh
    exact isUnit_iff_ne_zero.mpr (fun hz => by simpa [hz] using hh.ne_zero)
  have hBinv := Matrix.nonsing_inv_mul B hB
  have hBBinv := Matrix.mul_nonsing_inv B hB
  have hs := congrArg (fun T => B⁻¹ * T) hBM
  dsimp only at hs
  rw [← Matrix.mul_assoc, ← Matrix.mul_assoc, hBinv, Matrix.one_mul] at hs
  rw [← hs, Matrix.charpoly_mul_comm, ← Matrix.mul_assoc, hBBinv,
    Matrix.one_mul, Matrix.charpoly_diagonal]
  exact (q.symm.prod_comp (fun j => X - C (α j))).symm

/-- Full iff of Theorem 3.2. The observable-pair hypothesis is supplied
by `Inverse.canonical_eigenObservable` for the article's canonical chains. -/
theorem normalized_inverse_realization_iff (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ) (hn : 0 < n) (hH : H.PosDef)
    (hobs : Inverse.EigenObservable J.mulVecLin (Inverse.rowFunctional e))
    (hnorm : Inverse.normalization H (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e =
      1 - (n : ℂ)⁻¹) :
    (∃ (α : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℂ)
      (ω : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℝ)
      (Y : Matrix (Fin (Module.finrank ℂ (Option ι → ℂ))) ι ℂ),
        CompleteRealization a n H J e α ω Y) ↔
    let M := Inverse.normalizedCompletion a n H J (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e
    let S := BlockMetric.metric n H
    M * Inverse.weightedAdjoint S M = Inverse.weightedAdjoint S M * M ∧
      (S - Mᴴ * S * M).PosSemidef := by
  constructor
  · rintro ⟨α, ω, Y, hreal⟩
    exact completeRealization_necessary a n H J e α ω Y hn hH
      (by simp [Module.finrank_fintype_fun_eq_card]) hreal
  · rintro ⟨hnormal, hcontract⟩
    exact InverseBasisBridge.normalizedCompletion_complete_realization
      a n H J _ e hn hH hobs hnorm hnormal hcontract


/-- The normalized source numerator is the whole prescribed characteristic polynomial. -/
theorem completeRealization_numerator (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : n ≠ 0) (hreal : CompleteRealization a n H J e α ω Y) :
    Source.numerator Finset.univ α (fun j => (ω j : ℂ)^2) = J.charpoly := by
  obtain ⟨_, _, htotal, _, _, _, hf⟩ := hreal
  have hmass : Source.mass Finset.univ (fun j => (ω j : ℂ)^2) = (n : ℂ) := by
    have hh := congrArg (fun t : ℝ => (t : ℂ)) htotal
    push_cast at hh
    exact hh
  rw [Source.numerator, hmass, (numerator_identity_iff J α _ n).mpr hf,
    ← mul_assoc, ← C_mul, inv_mul_cancel₀ (by exact_mod_cast hn), C_1, one_mul]

/-- Residues are obtained from the minimal realization, not assumed as weights. -/
theorem completeRealization_residue (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : n ≠ 0) (hreal : CompleteRealization a n H J e α ω Y) (j : σ) :
    (ω j : ℂ)^2 = (n : ℂ) * J.charpoly.eval (α j) /
      (Source.support Finset.univ α).derivative.eval (α j) := by
  have hmass : Source.mass Finset.univ (fun j => (ω j : ℂ)^2) = (n : ℂ) := by
    have hh := congrArg (fun t : ℝ => (t : ℂ)) hreal.2.2.1
    push_cast at hh
    exact hh
  have hh := PolynomialRecovery.source_mass_residue_formula α
    (fun j => (ω j : ℂ)^2) hreal.1
    (hmass ▸ (show (n : ℂ) ≠ 0 by exact_mod_cast hn)) j
  rwa [hmass, completeRealization_numerator a n H J e α ω Y hn hreal] at hh

variable {τ : Type*} [Fintype τ] [DecidableEq τ]

theorem support_source_match {υ ν : Type*} [Fintype υ] [DecidableEq υ]
      [Fintype ν] [DecidableEq ν] (α₁ : υ → ℂ) (α₂ : ν → ℂ)
      (hs : Source.support Finset.univ α₁ = Source.support Finset.univ α₂)
      (j : υ) : ∃ k, α₂ k = α₁ j := by
  have hz : (Source.support Finset.univ α₂).eval (α₁ j) = 0 := by
    rw [← hs]
    exact Source.support_eval_at_source _ _ (Finset.mem_univ j)
  rw [Source.support_eval] at hz
  obtain ⟨k, _, hk⟩ := Finset.prod_eq_zero_iff.mp hz
  exact ⟨k, (sub_eq_zero.mp hk).symm⟩

/-- Equal simple support polynomials match source positions by a unique permutation. -/
theorem support_equiv (α : σ → ℂ) (β : τ → ℂ)
    (hα : Function.Injective α) (hβ : Function.Injective β)
    (hs : Source.support Finset.univ α = Source.support Finset.univ β) :
    ∃ q : σ ≃ τ, ∀ j, β (q j) = α j := by
  classical
  choose f hf using support_source_match α β hs
  have hfi : Function.Injective f := by
    intro i j hij
    apply hα
    rw [← hf i, ← hf j, hij]
  have hfs : Function.Surjective f := by
    intro k
    obtain ⟨j, hj⟩ := support_source_match β α hs.symm k
    exact ⟨j, hβ ((hf j).trans hj)⟩
  exact ⟨Equiv.ofBijective f ⟨hfi, hfs⟩, hf⟩

/-- Full uniqueness from the article's minimal definition. The permutation
matches positions, positive square-root masses, and every source row. In
particular it fixes the selected source, which is characterized by `α=a`. -/
theorem completeRealization_unique (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (β : τ → ℂ) (η : τ → ℝ) (Z : Matrix τ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdimσ : Fintype.card σ = Fintype.card ι + 1)
    (hdimτ : Fintype.card τ = Fintype.card ι + 1)
    (hα : CompleteRealization a n H J e α ω Y)
    (hβ : CompleteRealization a n H J e β η Z) :
    ∃ q : σ ≃ τ, ∀ j, β (q j) = α j ∧ η (q j) = ω j ∧
      ∀ i, Z (q j) i = Y j i := by
  have hs : Source.support Finset.univ α = Source.support Finset.univ β :=
    (completeRealization_support_charpoly a n H J e α ω Y hn hH hdimσ hα).trans
      (completeRealization_support_charpoly a n H J e β η Z hn hH hdimτ hβ).symm
  obtain ⟨q, hq⟩ := support_equiv α β hα.1 hβ.1 hs
  refine ⟨q, fun j => ⟨hq j, ?_⟩⟩
  have hω := completeRealization_residue a n H J e α ω Y (ne_of_gt hn) hα j
  have hη := completeRealization_residue a n H J e β η Z (ne_of_gt hn) hβ (q j)
  rw [hq j, ← hs, ← hω] at hη
  have hsq : η (q j)^2 = ω j^2 := by exact_mod_cast hη
  have heq : η (q j) = ω j := by
    have hp := (hα.2.1 j).1
    have hqpos := (hβ.2.1 (q j)).1
    nlinarith
  refine ⟨heq, ?_⟩
  intro i
  have hy := congrFun ((hα.2.2.2.2.2.1 j).2) i
  have hz := congrFun ((hβ.2.2.2.2.2.1 (q j)).2) i
  rw [hq j, heq] at hz
  exact hz.trans hy.symm


/-- Article3.2 with the canonical Jordan chains: observability is proved
from distinct critical positions, rather than left as an extra premise. -/
theorem canonical_normalized_inverse_realization_iff
    (w : σ → ℂ) (r : σ → ℕ) (hw : Function.Injective w)
    (a : ℂ) (n : ℝ)
    (H : Matrix (Confluent.ChainIndex r) (Confluent.ChainIndex r) ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hnorm : Inverse.normalization H
      (a • (1 : Matrix (Confluent.ChainIndex r) (Confluent.ChainIndex r) ℂ) -
        Confluent.jordanMatrix w r)⁻¹ (Confluent.outputVector r) = 1 - (n : ℂ)⁻¹) :
    let J := Confluent.jordanMatrix w r
    let e := Confluent.outputVector r
    (∃ (α : Fin (Module.finrank ℂ (Option (Confluent.ChainIndex r) → ℂ)) → ℂ)
      (ω : Fin (Module.finrank ℂ (Option (Confluent.ChainIndex r) → ℂ)) → ℝ)
      (Y : Matrix (Fin (Module.finrank ℂ (Option (Confluent.ChainIndex r) → ℂ)))
        (Confluent.ChainIndex r) ℂ), CompleteRealization a n H J e α ω Y) ↔
    let M := Inverse.normalizedCompletion a n H J (a • 1 - J)⁻¹ e
    let S := BlockMetric.metric n H
    M * Inverse.weightedAdjoint S M = Inverse.weightedAdjoint S M * M ∧
      (S - Mᴴ * S * M).PosSemidef :=
  normalized_inverse_realization_iff a n H _ _ hn hH
    (Inverse.canonical_eigenObservable w r hw) hnorm

/-- Existence and uniqueness are bundled for one fixed completion test. -/
theorem normalized_inverse_exists_unique (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ) (hn : 0 < n) (hH : H.PosDef)
    (hobs : Inverse.EigenObservable J.mulVecLin (Inverse.rowFunctional e))
    (hnorm : Inverse.normalization H (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e =
      1 - (n : ℂ)⁻¹)
    (htest : let M := Inverse.normalizedCompletion a n H J (a • 1 - J)⁻¹ e
      let S := BlockMetric.metric n H
      M * Inverse.weightedAdjoint S M = Inverse.weightedAdjoint S M * M ∧
        (S - Mᴴ * S * M).PosSemidef) :
    ∃ (α : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℂ)
      (ω : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℝ)
      (Y : Matrix (Fin (Module.finrank ℂ (Option ι → ℂ))) ι ℂ),
      CompleteRealization a n H J e α ω Y ∧
      ∀ (β : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℂ)
        (η : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℝ)
        (Z : Matrix (Fin (Module.finrank ℂ (Option ι → ℂ))) ι ℂ),
        CompleteRealization a n H J e β η Z →
        ∃ q : Equiv.Perm (Fin (Module.finrank ℂ (Option ι → ℂ))),
          ∀ j, β (q j) = α j ∧ η (q j) = ω j ∧ ∀ i, Z (q j) i = Y j i := by
  obtain ⟨α, ω, Y, hr⟩ :=
    (normalized_inverse_realization_iff a n H J e hn hH hobs hnorm).mpr htest
  refine ⟨α, ω, Y, hr, ?_⟩
  intro β η Z hz
  exact completeRealization_unique a n H J e α ω Y β η Z hn hH
    (by simp [Module.finrank_fintype_fun_eq_card])
    (by simp [Module.finrank_fintype_fun_eq_card]) hr hz

end PolynomialGeometry.InverseEquivalence





