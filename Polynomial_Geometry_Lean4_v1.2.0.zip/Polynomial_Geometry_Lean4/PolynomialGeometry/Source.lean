import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Algebra.Polynomial.BigOperators
import Mathlib.Algebra.Polynomial.Degree.IsMonicOfDegree
import Mathlib.Analysis.Complex.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp
import Lean.Elab.Tactic.Omega
import Mathlib.RingTheory.PowerSeries.WellKnown
import Mathlib.RingTheory.PowerSeries.Inverse

/-!
# Source polynomials and logarithmic derivatives

This file proves the polynomial identities underlying Section 2 of
*Polynomial Geometry and Structured Discrete Dynamics*.  A source weight
is an arbitrary field element in the algebraic statements. Positivity is
only used where explicitly stated. No compression characteristic-polynomial
or strict spectral assertion is assumed as a structure field.
-/

open scoped BigOperators
open Polynomial

namespace PolynomialGeometry.Source

variable {ι 𝕜 : Type*} [DecidableEq ι] [Field 𝕜]

noncomputable def support (s : Finset ι) (α : ι → 𝕜) : 𝕜[X] :=
  ∏ i ∈ s, (X - C (α i))

noncomputable def rawNumerator (s : Finset ι) (α ν : ι → 𝕜) : 𝕜[X] :=
  ∑ i ∈ s, C (ν i) * support (s.erase i) α

noncomputable def mass (s : Finset ι) (ν : ι → 𝕜) : 𝕜 := ∑ i ∈ s, ν i

noncomputable def numerator (s : Finset ι) (α ν : ι → 𝕜) : 𝕜[X] :=
  C (mass s ν)⁻¹ * rawNumerator s α ν

noncomputable def sourceFunction (s : Finset ι) (α ν : ι → 𝕜) (z : 𝕜) : 𝕜 :=
  ∑ i ∈ s, ν i / (z - α i)

noncomputable def sourcePolynomial (s : Finset ι) (α : ι → 𝕜) (m : ι → ℕ) : 𝕜[X] :=
  ∏ i ∈ s, (X - C (α i)) ^ m i

noncomputable def inheritedFactor (s : Finset ι) (α : ι → 𝕜) (m : ι → ℕ) : 𝕜[X] :=
  ∏ i ∈ s, (X - C (α i)) ^ (m i - 1)

omit [DecidableEq ι] in
@[simp] theorem support_empty (α : ι → 𝕜) : support ∅ α = 1 := by
  simp [support]

@[simp] theorem support_insert (s : Finset ι) (α : ι → 𝕜) (i : ι)
    (hi : i ∉ s) : support (insert i s) α = (X - C (α i)) * support s α := by
  simp [support, hi]

theorem support_erase_mul (s : Finset ι) (α : ι → 𝕜) {i : ι} (hi : i ∈ s) :
    (X - C (α i)) * support (s.erase i) α = support s α := by
  exact Finset.mul_prod_erase s (fun j => X - C (α j)) hi

omit [DecidableEq ι] in
@[simp] theorem support_eval (s : Finset ι) (α : ι → 𝕜) (z : 𝕜) :
    (support s α).eval z = ∏ i ∈ s, (z - α i) := by
  simp [support, eval_prod]

omit [DecidableEq ι] in
theorem support_eval_nonzero (s : Finset ι) (α : ι → 𝕜) (z : 𝕜)
    (hz : ∀ i ∈ s, z ≠ α i) : (support s α).eval z ≠ 0 := by
  rw [support_eval]
  exact Finset.prod_ne_zero_iff.mpr fun i hi => sub_ne_zero.mpr (hz i hi)

omit [DecidableEq ι] in
theorem support_eval_at_source (s : Finset ι) (α : ι → 𝕜) {i : ι} (hi : i ∈ s) :
    (support s α).eval (α i) = 0 := by
  rw [support_eval]
  exact Finset.prod_eq_zero hi (sub_self _)

theorem rawNumerator_eval_at_source (s : Finset ι) (α ν : ι → 𝕜)
    {i : ι} (hi : i ∈ s) :
    (rawNumerator s α ν).eval (α i) = ν i * (support (s.erase i) α).eval (α i) := by
  classical
  simp only [rawNumerator, eval_finset_sum, eval_mul, eval_C]
  apply Finset.sum_eq_single_of_mem i hi
  intro j hj hji
  have his : i ∈ s.erase j := Finset.mem_erase.mpr ⟨Ne.symm hji, hi⟩
  rw [support_eval_at_source _ _ his, mul_zero]

theorem numerator_eval_at_source (s : Finset ι) (α ν : ι → 𝕜)
    {i : ι} (hi : i ∈ s) :
    (numerator s α ν).eval (α i) =
      (ν i / mass s ν) * ∏ j ∈ s.erase i, (α i - α j) := by
  rw [numerator, eval_mul, eval_C, rawNumerator_eval_at_source _ _ _ hi, support_eval]
  ring

theorem numerator_ne_zero_at_source (s : Finset ι) (α ν : ι → 𝕜)
    (hα : Set.InjOn α s) (hn : mass s ν ≠ 0) {i : ι} (hi : i ∈ s)
    (hν : ν i ≠ 0) : (numerator s α ν).eval (α i) ≠ 0 := by
  rw [numerator_eval_at_source _ _ _ hi]
  refine mul_ne_zero (div_ne_zero hν hn) (Finset.prod_ne_zero_iff.mpr ?_)
  intro j hj
  exact sub_ne_zero.mpr fun hij => (Finset.mem_erase.mp hj).1 (hα (Finset.mem_of_mem_erase hj) hi hij.symm)

theorem rawNumerator_eq_support_mul_sourceFunction
    (s : Finset ι) (α ν : ι → 𝕜) (z : 𝕜) (hz : ∀ i ∈ s, z ≠ α i) :
    (rawNumerator s α ν).eval z = (support s α).eval z * sourceFunction s α ν z := by
  classical
  simp only [rawNumerator, sourceFunction, eval_finset_sum, eval_mul, eval_C, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i hi
  have hp := congrArg (fun p : 𝕜[X] => p.eval z) (support_erase_mul s α hi)
  simp only [eval_mul, eval_sub, eval_X, eval_C] at hp
  rw [← hp]
  field_simp [sub_ne_zero.mpr (hz i hi)]

theorem sourceFunction_eq_normalized_numerator
    (s : Finset ι) (α ν : ι → 𝕜) (z : 𝕜)
    (hn : mass s ν ≠ 0) (hz : ∀ i ∈ s, z ≠ α i) :
    sourceFunction s α ν z = mass s ν * (numerator s α ν).eval z / (support s α).eval z := by
  have hp := support_eval_nonzero s α z hz
  rw [numerator, eval_mul, eval_C, rawNumerator_eq_support_mul_sourceFunction s α ν z hz]
  field_simp

theorem rawNumerator_insert (s : Finset ι) (α ν : ι → 𝕜)
    {i : ι} (hi : i ∉ s) :
    rawNumerator (insert i s) α ν =
      C (ν i) * support s α + (X - C (α i)) * rawNumerator s α ν := by
  classical
  rw [rawNumerator, Finset.sum_insert hi]
  simp only [Finset.erase_insert hi]
  congr 1
  rw [rawNumerator, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j hj
  have hji : j ≠ i := ne_of_mem_of_not_mem hj hi
  rw [Finset.erase_insert_of_ne hji.symm, support_insert _ _ i (by simp [hi])]
  ring

omit [DecidableEq ι] in
theorem sourcePolynomial_factor (s : Finset ι) (α : ι → 𝕜) (m : ι → ℕ)
    (hm : ∀ i ∈ s, 0 < m i) :
    sourcePolynomial s α m = support s α * inheritedFactor s α m := by
  unfold sourcePolynomial support inheritedFactor
  rw [← Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro i hi
  have hmi := hm i hi
  rw [← pow_succ']
  congr 1
  omega

theorem derivative_sourcePolynomial (s : Finset ι) (α : ι → 𝕜) (m : ι → ℕ)
    (hm : ∀ i ∈ s, 0 < m i) :
    (sourcePolynomial s α m).derivative =
      rawNumerator s α (fun i => (m i : 𝕜)) * inheritedFactor s α m := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [sourcePolynomial, rawNumerator]
  | @insert i s hi ih =>
    have hms : ∀ j ∈ s, 0 < m j := fun j hj => hm j (Finset.mem_insert_of_mem hj)
    have hmi : 0 < m i := hm i (Finset.mem_insert_self i s)
    have hpow : (X - C (α i) : 𝕜[X]) ^ m i =
        (X - C (α i)) * (X - C (α i)) ^ (m i - 1) := by
      rw [← pow_succ']
      congr 1
      omega
    have hprod : sourcePolynomial (insert i s) α m =
        (X - C (α i)) ^ m i * sourcePolynomial s α m := by simp [sourcePolynomial, hi]
    rw [hprod, derivative_mul, derivative_pow, derivative_X_sub_C, mul_one, ih hms,
      rawNumerator_insert _ _ _ hi, sourcePolynomial_factor s α m hms, hpow]
    simp only [inheritedFactor, Finset.prod_insert hi]
    ring

theorem inherited_derivative_identity (s : Finset ι) (α : ι → 𝕜) (m : ι → ℕ)
    (hm : ∀ i ∈ s, 0 < m i) (hn : mass s (fun i => (m i : 𝕜)) ≠ 0) :
    (sourcePolynomial s α m).derivative =
      C (mass s (fun i => (m i : 𝕜))) * numerator s α (fun i => (m i : 𝕜)) *
        inheritedFactor s α m := by
  rw [derivative_sourcePolynomial s α m hm]
  simp [numerator, ← mul_assoc, ← C_mul, hn]

omit [DecidableEq ι] in
theorem support_monic (s : Finset ι) (α : ι → 𝕜) : (support s α).Monic := by
  exact monic_prod_of_monic s _ fun i _ => monic_X_sub_C (α i)

omit [DecidableEq ι] in
@[simp] theorem support_natDegree (s : Finset ι) (α : ι → 𝕜) :
    (support s α).natDegree = s.card := by
  simp [support]

theorem rawNumerator_natDegree_le (s : Finset ι) (α ν : ι → 𝕜) :
    (rawNumerator s α ν).natDegree ≤ s.card - 1 := by
  apply natDegree_sum_le_of_forall_le
  intro i hi
  calc
    (C (ν i) * support (s.erase i) α).natDegree ≤ (support (s.erase i) α).natDegree :=
      natDegree_C_mul_le _ _
    _ = s.card - 1 := by rw [support_natDegree, Finset.card_erase_of_mem hi]

theorem rawNumerator_top_coeff (s : Finset ι) (α ν : ι → 𝕜) :
    (rawNumerator s α ν).coeff (s.card - 1) = mass s ν := by
  simp only [rawNumerator, finset_sum_coeff, coeff_C_mul, mass]
  apply Finset.sum_congr rfl
  intro i hi
  have hd : (support (s.erase i) α).natDegree = s.card - 1 := by
    rw [support_natDegree, Finset.card_erase_of_mem hi]
  rw [← hd, (support_monic (s.erase i) α).coeff_natDegree, mul_one]

theorem numerator_isMonicOfDegree (s : Finset ι) (α ν : ι → 𝕜)
    (hn : mass s ν ≠ 0) :
    (numerator s α ν).IsMonicOfDegree (s.card - 1) := by
  apply (isMonicOfDegree_iff _ _).mpr
  constructor
  · exact (natDegree_C_mul_le _ _).trans (rawNumerator_natDegree_le s α ν)
  · rw [numerator, coeff_C_mul, rawNumerator_top_coeff]
    exact inv_mul_cancel₀ hn

omit [DecidableEq ι] in
theorem inheritedFactor_eval_zero_iff (s : Finset ι) (α : ι → 𝕜)
    (m : ι → ℕ) (z : 𝕜) :
    (inheritedFactor s α m).eval z = 0 ↔ ∃ i ∈ s, 1 < m i ∧ z = α i := by
  simp only [inheritedFactor, eval_prod, eval_pow, eval_sub, eval_X, eval_C,
    Finset.prod_eq_zero_iff, pow_eq_zero_iff', sub_eq_zero]
  constructor
  · rintro ⟨i, hi, hzi, hmi⟩
    exact ⟨i, hi, by omega, hzi⟩
  · rintro ⟨i, hi, hmi, hzi⟩
    exact ⟨i, hi, hzi, by omega⟩

/-- Exact separation of genuine critical roots and the inherited roots. -/
theorem derivative_eval_zero_iff (s : Finset ι) (α : ι → 𝕜) (m : ι → ℕ)
    (hm : ∀ i ∈ s, 0 < m i) (hn : mass s (fun i => (m i : 𝕜)) ≠ 0) (z : 𝕜) :
    (sourcePolynomial s α m).derivative.eval z = 0 ↔
      (numerator s α (fun i => (m i : 𝕜))).eval z = 0 ∨
        ∃ i ∈ s, 1 < m i ∧ z = α i := by
  rw [inherited_derivative_identity s α m hm hn]
  simp only [eval_mul, eval_C, mul_eq_zero, hn, false_or]
  rw [inheritedFactor_eval_zero_iff]

section FormalMoments

/-- Substitute `w - X` in a polynomial. This orientation makes the
coefficients of each reciprocal source factor exactly its positive powers. -/
noncomputable def reflectedTaylor (w : 𝕜) : 𝕜[X] →+* PowerSeries 𝕜 :=
  Polynomial.eval₂RingHom PowerSeries.C (PowerSeries.C w - PowerSeries.X)

@[simp] theorem reflectedTaylor_C (w a : 𝕜) :
    reflectedTaylor w (C a) = PowerSeries.C a := by simp [reflectedTaylor]

@[simp] theorem reflectedTaylor_factor (w a : 𝕜) :
    reflectedTaylor w (X - C a) = PowerSeries.C (w - a) - PowerSeries.X := by
  simp [reflectedTaylor]
  ring

noncomputable def reciprocalSourceSeries (w a : 𝕜) : PowerSeries 𝕜 := by
  classical
  exact if h : w ≠ a then
    PowerSeries.invUnitsSub (Units.mk0 (w - a) (sub_ne_zero.mpr h)) else 0

@[simp] theorem reciprocalSourceSeries_coeff (w a : 𝕜) (h : w ≠ a) (k : ℕ) :
    PowerSeries.coeff k (reciprocalSourceSeries w a) = 1 / (w - a) ^ (k + 1) := by
  simp [reciprocalSourceSeries, h, one_divp]

theorem reciprocalSourceSeries_mul (w a : 𝕜) (h : w ≠ a) :
    reciprocalSourceSeries w a * (PowerSeries.C (w - a) - PowerSeries.X) = 1 := by
  simpa only [reciprocalSourceSeries, dif_pos h, Units.val_mk0] using
    PowerSeries.invUnitsSub_mul_sub (Units.mk0 (w - a) (sub_ne_zero.mpr h))

/-- The formal expansion of the source function at `w - X`. -/
noncomputable def momentSeries (s : Finset ι) (α ν : ι → 𝕜) (w : 𝕜) : PowerSeries 𝕜 :=
  ∑ i ∈ s, PowerSeries.C (ν i) * reciprocalSourceSeries w (α i)

omit [DecidableEq ι] in
theorem momentSeries_coeff (s : Finset ι) (α ν : ι → 𝕜) (w : 𝕜)
    (hsep : ∀ i ∈ s, w ≠ α i) (k : ℕ) :
    PowerSeries.coeff k (momentSeries s α ν w) =
      ∑ i ∈ s, ν i / (w - α i) ^ (k + 1) := by
  simp only [momentSeries, map_sum, PowerSeries.coeff_C_mul]
  apply Finset.sum_congr rfl
  intro i hi
  rw [reciprocalSourceSeries_coeff w (α i) (hsep i hi)]
  simp [div_eq_mul_inv]

theorem reflected_support_times_moments (s : Finset ι) (α ν : ι → 𝕜) (w : 𝕜)
    (hsep : ∀ i ∈ s, w ≠ α i) :
    reflectedTaylor w (support s α) * momentSeries s α ν w =
      reflectedTaylor w (rawNumerator s α ν) := by
  simp only [momentSeries, rawNumerator, map_sum, map_mul, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i hi
  have hp := congrArg (reflectedTaylor w) (support_erase_mul s α hi)
  rw [map_mul, reflectedTaylor_factor] at hp
  rw [← hp]
  have hinv := reciprocalSourceSeries_mul w (α i) (hsep i hi)
  rw [reflectedTaylor_C]
  calc
    _ = PowerSeries.C (ν i) *
        (reciprocalSourceSeries w (α i) * (PowerSeries.C (w - α i) - PowerSeries.X)) *
        reflectedTaylor w (support (s.erase i) α) := by ring
    _ = _ := by rw [hinv]; simp

omit [DecidableEq ι] in
theorem reflected_support_isUnit (s : Finset ι) (α : ι → 𝕜) (w : 𝕜)
    (hsep : ∀ i ∈ s, w ≠ α i) :
    IsUnit (reflectedTaylor w (support s α)) := by
  rw [support, map_prod]
  apply IsUnit.prod_iff.mpr
  intro i hi
  rw [reflectedTaylor_factor]
  apply isUnit_iff_dvd_one.mpr
  refine ⟨reciprocalSourceSeries w (α i), ?_⟩
  simpa [mul_comm] using (reciprocalSourceSeries_mul w (α i) (hsep i hi)).symm

/-- Multiplicity of the numerator forces all lower reciprocal moments to
vanish. This is an algebraic coefficient proof, with no smoothness premise. -/
theorem moments_vanish_of_rawNumerator_dvd (s : Finset ι) (α ν : ι → 𝕜)
    (w : 𝕜) (r : ℕ) (hsep : ∀ i ∈ s, w ≠ α i)
    (hroot : (X - C w) ^ r ∣ rawNumerator s α ν) :
    ∀ k < r, (∑ i ∈ s, ν i / (w - α i) ^ (k + 1)) = 0 := by
  have hd := map_dvd (reflectedTaylor w) hroot
  simp only [map_pow, reflectedTaylor_factor, sub_self, map_zero, zero_sub] at hd
  rw [← neg_one_mul (PowerSeries.X : PowerSeries 𝕜), mul_pow] at hd
  have hu : IsUnit ((-1 : PowerSeries 𝕜) ^ r) := (isUnit_neg_one).pow r
  have hx : (PowerSeries.X : PowerSeries 𝕜) ^ r ∣ reflectedTaylor w (rawNumerator s α ν) :=
    hu.mul_left_dvd.mp hd
  rw [← reflected_support_times_moments s α ν w hsep] at hx
  have hm : (PowerSeries.X : PowerSeries 𝕜) ^ r ∣ momentSeries s α ν w :=
    (reflected_support_isUnit s α w hsep).dvd_mul_left.mp hx
  intro k hk
  rw [← momentSeries_coeff s α ν w hsep]
  exact PowerSeries.X_pow_dvd_iff.mp hm k hk

/-- The same moment conclusion for the normalized monic numerator `G`. -/
theorem moments_vanish_of_numerator_dvd (s : Finset ι) (α ν : ι → 𝕜)
    (w : 𝕜) (r : ℕ) (hn : mass s ν ≠ 0)
    (hsep : ∀ i ∈ s, w ≠ α i)
    (hroot : (X - C w) ^ r ∣ numerator s α ν) :
    ∀ k < r, (∑ i ∈ s, ν i / (w - α i) ^ (k + 1)) = 0 := by
  apply moments_vanish_of_rawNumerator_dvd s α ν w r hsep
  have heq : rawNumerator s α ν = C (mass s ν) * numerator s α ν := by
    simp [numerator, ← mul_assoc, ← C_mul, hn]
  rw [heq]
  exact dvd_mul_of_dvd_right hroot _

end FormalMoments

end PolynomialGeometry.Source
