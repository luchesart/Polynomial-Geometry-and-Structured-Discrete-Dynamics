import PolynomialGeometry.ReconstructionCoverage
import PolynomialGeometry.RootPermutation

/-! # Pointwise local labels of all nearby polynomial roots

The coefficient map is proper on bounded coefficient neighborhoods. Its
fibers are permutation orbits. Compactness therefore gives labels close to
any chosen base list, even when base roots coincide. No continuous or
analytic ordering of roots is asserted.
-/
noncomputable section
open Filter Polynomial
open scoped Topology

namespace PolynomialGeometry.RootLabelCoverage
open Factorization CriticalReconstruction ReconstructionCompletion RootMargins

/-- A compact set of wrong preimages cannot approach a fiber contained in
an open set. This is the topological step behind pointwise root coverage. -/
theorem compact_fiber_neighborhood {E B : Type*} [TopologicalSpace E]
    [TopologicalSpace B] [T2Space B] (f : E → B) (K U : Set E) (y : B)
    (hf : Continuous f) (hK : IsCompact K) (hU : IsOpen U)
    (hfiber : ∀ x ∈ K, f x = y → x ∈ U) :
    ∀ᶠ z in 𝓝 y, ∀ x ∈ K, f x = z → x ∈ U := by
  have hc : IsCompact (f '' (K ∩ Uᶜ)) :=
    (hK.inter_right hU.isClosed_compl).image hf
  have hn : y ∉ f '' (K ∩ Uᶜ) := by
    rintro ⟨x, hx, he⟩
    exact hx.2 (hfiber x hx.1 he)
  filter_upwards [hc.isClosed.isOpen_compl.mem_nhds hn] with z hz
  intro x hx he
  by_contra hxu
  exact hz ⟨x, ⟨hx,hxu⟩, he⟩

/-- All nearby coefficient lists have a root enumeration in any given
neighborhood of the base enumeration. Multiplicities are preserved. -/
theorem nearby_root_labels (n : ℕ) (α₀ : Fin n → ℂ)
    (U : Set (Fin n → ℂ)) (hU : IsOpen U) (hα₀ : α₀ ∈ U) :
    ∀ᶠ c in 𝓝 (rootCoefficients n α₀),
      ∃ α ∈ U, rootCoefficients n α = c := by
  let W : Set (Fin n → ℂ) := {α | ∃ σ : Equiv.Perm (Fin n), α ∘ σ ∈ U}
  have hW : IsOpen W := by
    have he : W = ⋃ σ : Equiv.Perm (Fin n), (fun α : Fin n → ℂ => α ∘ σ) ⁻¹' U := by
      ext α
      simp [W]
    rw [he]
    apply isOpen_iUnion
    intro σ
    exact hU.preimage (continuous_pi fun j => continuous_apply (σ j))
  let c₀ := rootCoefficients n α₀
  let R : ℝ := ‖c₀‖ + 2
  let K : Set (Fin n → ℂ) := Metric.closedBall 0 R
  have hcoeff : Continuous (rootCoefficients n) :=
    continuous_iff_continuousAt.mpr fun α => (rootCoefficients_analyticAt n α).continuousAt
  have hfiber : ∀ α ∈ K, rootCoefficients n α = c₀ → α ∈ W := by
    intro α _ he
    have hp : rootPolynomial n α₀ = rootPolynomial n α := by
      rw [← monicPolynomial_rootCoefficients n α₀,
        ← monicPolynomial_rootCoefficients n α, he]
    obtain ⟨σ,hσ⟩ := (RootPermutation.rootPolynomial_eq_iff_perm n α₀ α).mp hp
    exact ⟨σ, hσ ▸ hα₀⟩
  have hnear := compact_fiber_neighborhood (rootCoefficients n) K W c₀ hcoeff
    (isCompact_closedBall 0 R) hW hfiber
  have hb : ∀ᶠ c : Fin n → ℂ in 𝓝 c₀, ‖c‖ < ‖c₀‖ + 1 :=
    continuous_norm.continuousAt.eventually (gt_mem_nhds (by linarith))
  filter_upwards [hnear,hb] with c hc hbound
  obtain ⟨α,hα⟩ := monic_has_labelled_roots (monicPolynomial n c) n
    (monicPolynomial_monic n c) (monicPolynomial_natDegree n c)
  have hαc : rootCoefficients n α = c := by
    ext j
    change (rootPolynomial n α).coeff j = c j
    rw [hα, monicPolynomial_coeff]
  have hαK : α ∈ K := by
    change dist α 0 ≤ R
    rw [dist_zero_right]
    apply (pi_norm_le_iff_of_nonneg (by dsimp [R]; positivity)).mpr
    intro j
    have hj : (monicPolynomial n c).IsRoot (α j) := by
      rw [← hα]
      exact rootPolynomial_eval_copy n α j
    have hn := monic_root_norm_bound n c (α j) hj
    dsimp [R]
    linarith
  obtain ⟨σ,hσ⟩ := hc α hαK hαc
  exact ⟨α ∘ σ, hσ, (rootCoefficients_comp_perm n α σ).trans hαc⟩

end PolynomialGeometry.RootLabelCoverage
