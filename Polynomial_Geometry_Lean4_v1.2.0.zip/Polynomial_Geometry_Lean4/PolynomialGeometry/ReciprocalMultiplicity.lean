import PolynomialGeometry.ReciprocalSpectrum
import Mathlib.Algebra.Polynomial.Splits

/-!
# Reciprocal determinants and algebraic multiplicities

The full characteristic polynomial is transported, not merely the set of
eigenvalues. Thus repeated critical positions keep their multiplicities.
-/

noncomputable section
open Matrix Polynomial
open scoped ComplexOrder
namespace PolynomialGeometry.ReciprocalMultiplicity

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The exact determinant formula for the actual source reciprocal matrix. -/
theorem source_reciprocal_determinant (a : ℝ) (u α : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (t : ℂ) :
    (1 + t • Geometry.reciprocal u (Geometry.sourceResolvent a α)).det =
      (Geometry.compressed a u (diagonal α)).charpoly.eval (a+t) /
        (Geometry.compressed a u (diagonal α)).charpoly.eval (a : ℂ) := by
  have hi := Geometry.source_reciprocal_isUnit a u α hsep
  have he := Geometry.source_compression_reciprocal a u α hsep
  have hu : IsUnit ((a : ℂ) • (1 : Matrix ι ι ℂ) -
      Geometry.compressed a u (diagonal α)) := by
    rw [he]
    exact Matrix.isUnit_nonsing_inv_iff.mpr hi
  have h := ReciprocalSpectrum.resolvent_determinant
    (Geometry.compressed a u (diagonal α)) (a : ℂ) t hu
  rw [he] at h
  letI := hi.invertible
  simpa only [Matrix.inv_inv_of_invertible] using h


/-- An invertible intertwiner preserves the full characteristic polynomial. -/
theorem intertwining_charpoly (A J P : Matrix ι ι ℂ)
    (hP : IsUnit P) (hAP : A * P = P * J) : J.charpoly = A.charpoly := by
  letI := hP.invertible
  have hJ : J = P⁻¹ * A * P := by
    have hh := congrArg (fun M => P⁻¹ * M) hAP
    simpa only [← Matrix.mul_assoc, Matrix.inv_mul_of_invertible, Matrix.one_mul] using hh.symm
  rw [hJ, Matrix.charpoly_mul_comm, ← Matrix.mul_assoc, Matrix.mul_inv_of_invertible, Matrix.one_mul]

/-- The source bridge identifies this determinant with the prescribed
spectral numerator, including parameters where rational source terms have poles. -/
theorem source_bridge_determinant (a : ℝ) (u α : ι → ℂ)
    (J : Matrix ι ι ℂ) (Y : Matrix (Unit ⊕ ι) ι ℂ) (e : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j)
    (hY : ∀ j, star (Geometry.massVector u) ⬝ᵥ (fun i => Y i j) = 0)
    (hGram : (Yᴴ * Y).PosDef)
    (hSource : Geometry.sourceOperator a (diagonal α) * Y =
      Y * J - vecMulVec (Geometry.massVector u) e) (t : ℂ) :
    (1 + t • Geometry.reciprocal u (Geometry.sourceResolvent a α)).det =
      J.charpoly.eval (a+t) / J.charpoly.eval (a : ℂ) := by
  obtain ⟨P, ⟨_,hP,_,hAP,_⟩,_⟩ := Geometry.coordinate_bridge a u α J Y e hsep hY hGram hSource
  have hchar := intertwining_charpoly (Geometry.compressed a u (diagonal α)) J P hP hAP
  rw [hchar]
  exact source_reciprocal_determinant a u α hsep t

/-- Clearing one reciprocal factor gives the corresponding eigenvalue factor. -/
theorem reciprocal_factor (a w z : ℂ) (hz : z ≠ 0) (hw : a-w ≠ 0) :
    z * ((a + -z⁻¹ - w) / (a-w)) = z - (a-w)⁻¹ := by
  field_simp
  ring

/-- Transport of the complete root product, including repeated entries. -/
theorem reciprocal_root_product (S : Multiset ℂ) (a z : ℂ)
    (hz : z ≠ 0) (hsep : ∀ w ∈ S, a-w ≠ 0) :
    z^S.card * ((S.map (fun w => a + -z⁻¹ - w)).prod /
      (S.map (fun w => a-w)).prod) =
        (S.map (fun w => z - (a-w)⁻¹)).prod := by
  induction S using Multiset.induction_on with
  | empty => simp
  | @cons w S ih =>
      have hw := hsep w (Multiset.mem_cons_self w S)
      have hS : ∀ v ∈ S, a-v ≠ 0 := fun v hv => hsep v (Multiset.mem_cons_of_mem hv)
      simp only [Multiset.card_cons, Multiset.map_cons, Multiset.prod_cons, pow_succ]
      rw [mul_div_mul_comm]
      calc
        z ^ S.card * z * ((a + -z⁻¹ - w) / (a-w) *
            ((S.map (fun v => a + -z⁻¹-v)).prod / (S.map (fun v => a-v)).prod)) =
            (z * ((a + -z⁻¹-w)/(a-w))) *
              (z^S.card * ((S.map (fun v => a + -z⁻¹-v)).prod / (S.map (fun v => a-v)).prod)) := by ring
        _ = _ := by rw [reciprocal_factor a w z hz hw, ih hS]

/-- The actual reciprocal matrix has the mapped root multiset, not just the
mapped spectrum as a set. -/
theorem resolvent_charpoly (A : Matrix ι ι ℂ) (a : ℂ)
    (ha : IsUnit (a • (1 : Matrix ι ι ℂ) - A)) :
    ((a • (1 : Matrix ι ι ℂ) - A)⁻¹).charpoly =
      (A.charpoly.roots.map (fun w => X - C ((a-w)⁻¹))).prod := by
  let R := (a • (1 : Matrix ι ι ℂ) - A)⁻¹
  have hsep : ∀ w ∈ A.charpoly.roots, a-w ≠ 0 := by
    intro w hw he
    have hroot := (Polynomial.mem_roots A.charpoly_monic.ne_zero).mp hw
    have heq : a = w := sub_eq_zero.mp he
    have hnot : a ∉ spectrum ℂ A := by
      apply spectrum.notMem_iff.mpr
      simpa only [Algebra.algebraMap_eq_smul_one] using ha
    exact hnot (heq ▸ Matrix.mem_spectrum_iff_isRoot_charpoly.mpr hroot)
  have hcard : A.charpoly.roots.card = Fintype.card ι := by
    rw [splits_iff_card_roots.mp (IsAlgClosed.splits A.charpoly), A.charpoly_natDegree_eq_dim]
  have heval (z : ℂ) (hz : z ≠ 0) :
      R.charpoly.eval z = ((A.charpoly.roots.map (fun w => X-C ((a-w)⁻¹))).prod).eval z := by
    have he : z • (1 + (-z⁻¹) • R) = z • (1 : Matrix ι ι ℂ) - R := by
      rw [smul_add, smul_smul]
      simp [hz, sub_eq_add_neg]
    have hdet := congrArg Matrix.det he
    rw [Matrix.det_smul] at hdet
    have hc : R.charpoly.eval z = z ^ Fintype.card ι * (1 + (-z⁻¹) • R).det := by
      rw [Matrix.eval_charpoly]
      have hscalar : Matrix.scalar ι z = z • (1 : Matrix ι ι ℂ) := by
        ext i j
        simp [Matrix.scalar_apply, Matrix.one_apply, Matrix.diagonal_apply]
      rw [hscalar]
      exact hdet.symm
    rw [hc, ReciprocalSpectrum.resolvent_determinant A a (-z⁻¹) ha]
    rw [Polynomial.eval_eq_prod_roots_sub_of_monic_of_splits_id A.charpoly_monic (IsAlgClosed.splits A.charpoly),
      Polynomial.eval_eq_prod_roots_sub_of_monic_of_splits_id A.charpoly_monic (IsAlgClosed.splits A.charpoly), ← hcard]
    rw [reciprocal_root_product A.charpoly.roots a z hz hsep]
    simp [Polynomial.eval_multiset_prod, Multiset.map_map ]
  apply Polynomial.eq_of_infinite_eval_eq
  apply ((Set.infinite_univ : (Set.univ : Set ℂ).Infinite).diff (Set.finite_singleton 0)).mono
  intro z hz
  exact heval z (by simpa using hz.2)


/-- All eigenvalues are transported with their algebraic multiplicities. -/
theorem resolvent_roots (A : Matrix ι ι ℂ) (a : ℂ)
    (ha : IsUnit (a • (1 : Matrix ι ι ℂ) - A)) :
    ((a • (1 : Matrix ι ι ℂ) - A)⁻¹).charpoly.roots =
      A.charpoly.roots.map (fun w => (a-w)⁻¹) := by
  rw [resolvent_charpoly A a ha]
  have h := Polynomial.roots_multiset_prod_X_sub_C (A.charpoly.roots.map (fun w => (a-w)⁻¹))
  simpa only [Multiset.map_map, Function.comp_def] using h

/-- Root multiplicity is exactly preserved at each reciprocal critical mode. -/
theorem resolvent_rootMultiplicity (A : Matrix ι ι ℂ) (a : ℂ)
    (ha : IsUnit (a • (1 : Matrix ι ι ℂ) - A)) (w : ℂ) :
    ((a • (1 : Matrix ι ι ℂ) - A)⁻¹).charpoly.rootMultiplicity ((a-w)⁻¹) =
      A.charpoly.rootMultiplicity w := by
  classical
  have hinj : Function.Injective (fun z : ℂ => (a-z)⁻¹) := by
    intro x y h
    exact sub_right_injective (inv_injective h)
  rw [← Polynomial.count_roots, resolvent_roots A a ha,
    Multiset.count_map_eq_count' _ _ hinj, Polynomial.count_roots]

/-- The actual source reciprocal matrix keeps every algebraic multiplicity. -/
theorem source_reciprocal_roots (a : ℝ) (u α : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j) :
    (Geometry.reciprocal u (Geometry.sourceResolvent a α)).charpoly.roots =
      (Geometry.compressed a u (diagonal α)).charpoly.roots.map (fun w => ((a : ℂ)-w)⁻¹) := by
  have hi := Geometry.source_reciprocal_isUnit a u α hsep
  have he := Geometry.source_compression_reciprocal a u α hsep
  have hu : IsUnit ((a : ℂ) • (1 : Matrix ι ι ℂ) -
      Geometry.compressed a u (diagonal α)) := by
    rw [he]
    exact Matrix.isUnit_nonsing_inv_iff.mpr hi
  have h := resolvent_roots (Geometry.compressed a u (diagonal α)) (a : ℂ) hu
  rw [he] at h
  letI := hi.invertible
  simpa only [Matrix.inv_inv_of_invertible] using h

/-- The bridge transfers prescribed spectral multiplicities to the actual
source reciprocal matrix. -/
theorem source_bridge_roots (a : ℝ) (u α : ι → ℂ)
    (J : Matrix ι ι ℂ) (Y : Matrix (Unit ⊕ ι) ι ℂ) (e : ι → ℂ)
    (hsep : ∀ j, (a : ℂ) ≠ α j)
    (hY : ∀ j, star (Geometry.massVector u) ⬝ᵥ (fun i => Y i j) = 0)
    (hGram : (Yᴴ * Y).PosDef)
    (hSource : Geometry.sourceOperator a (diagonal α) * Y =
      Y * J - vecMulVec (Geometry.massVector u) e) :
    (Geometry.reciprocal u (Geometry.sourceResolvent a α)).charpoly.roots =
      J.charpoly.roots.map (fun w => ((a : ℂ)-w)⁻¹) := by
  obtain ⟨P, ⟨_,hP,_,hAP,_⟩,_⟩ := Geometry.coordinate_bridge a u α J Y e hsep hY hGram hSource
  rw [intertwining_charpoly (Geometry.compressed a u (diagonal α)) J P hP hAP]
  exact source_reciprocal_roots a u α hsep

/-- The full equal-copy compression includes inherited critical multiplicities. -/
theorem full_reciprocal_critical_multiplicity (d : ℕ) (α : Fin (d+1) → ℂ)
    (Q : Matrix (Fin (d+1)) (Fin d) ℂ) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (CompressionDet.normalizedSource d (fun _ => 1) i) * Q i j = 0)
    (a : ℂ) (ha : (Source.support Finset.univ α).derivative.eval a ≠ 0) (w : ℂ) :
    ((a • (1 : Matrix (Fin d) (Fin d) ℂ) - Qᴴ * diagonal α * Q)⁻¹).charpoly.rootMultiplicity ((a-w)⁻¹) =
      (Source.support Finset.univ α).derivative.rootMultiplicity w := by
  let A := Qᴴ * diagonal α * Q
  have hp := ReciprocalSpectrum.equal_copy_derivative d α Q hQ hbQ
  have hn : (d+1 : ℂ) ≠ 0 := by exact_mod_cast Nat.succ_ne_zero d
  have hca : A.charpoly.eval a ≠ 0 := by
    intro h
    apply ha
    change (Qᴴ * diagonal α * Q).charpoly.eval a = 0 at h
    simp only [hp, Polynomial.eval_mul, Polynomial.eval_C, h, mul_zero]
  have hu : IsUnit (a • (1 : Matrix (Fin d) (Fin d) ℂ) - A) := by
    simpa only [Algebra.algebraMap_eq_smul_one] using
      spectrum.notMem_iff.mp (fun h => hca (Matrix.mem_spectrum_iff_isRoot_charpoly.mp h))
  rw [resolvent_rootMultiplicity A a hu w, hp]
  rw [Polynomial.rootMultiplicity_mul (mul_ne_zero (Polynomial.C_ne_zero.mpr hn) A.charpoly_monic.ne_zero),
    Polynomial.rootMultiplicity_C, zero_add]

end PolynomialGeometry.ReciprocalMultiplicity
