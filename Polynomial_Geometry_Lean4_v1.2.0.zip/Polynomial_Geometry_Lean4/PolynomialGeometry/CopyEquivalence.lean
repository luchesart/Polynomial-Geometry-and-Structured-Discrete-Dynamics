import PolynomialGeometry.Copies

/-!
# An explicit unitary equivalence for repeated copies

The equivalence is bundled as a complex linear equivalence and its
Hermitian-form identity. It does not depend on arbitrary choices of bases
within the inherited spaces.
-/

noncomputable section
open Matrix
open scoped BigOperators

namespace PolynomialGeometry.CopyEquivalence
open Copies

variable {ι : Type*} [Fintype ι]

def inheritedSpace (m : ι → ℕ) : Submodule ℂ (CopyIndex m → ℂ) where
  carrier := {x | groupReduce m x = 0}
  zero_mem' := by ext j; simp [groupReduce]
  add_mem' hx hy := by
    change groupReduce m (_ + _) = 0
    rw [groupReduce_add, hx, hy, add_zero]
  smul_mem' c x hx := by
    ext j
    have h := congrFun hx j
    simp only [groupReduce, Pi.zero_apply] at h ⊢
    simp only [Pi.smul_apply, smul_eq_mul, ← Finset.mul_sum, mul_div_assoc, h, mul_zero]

def zeroOutputSpace (m : ι → ℕ) (b : ι → ℂ) : Submodule ℂ (CopyIndex m → ℂ) where
  carrier := {x | star (groupLift m b) ⬝ᵥ x = 0}
  zero_mem' := dotProduct_zero _
  add_mem' hx hy := by
    change star (groupLift m b) ⬝ᵥ (_ + _) = 0
    rw [dotProduct_add, hx, hy, add_zero]
  smul_mem' c x hx := by
    change star (groupLift m b) ⬝ᵥ (c • x) = 0
    rw [dotProduct_smul, hx, smul_zero]

def copyCoordinateEquiv (d : ℕ) (m : Fin (d + 1) → ℕ)
    (b : Fin (d + 1) → ℂ) (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hb : ∑ i, star (b i) * b i = 1) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (b i) * Q i j = 0) :
    ((Fin d → ℂ) × inheritedSpace m) ≃ₗ[ℂ] zeroOutputSpace m b where
  toFun x := ⟨groupLift m (Q *ᵥ x.1) + x.2.1,
    copy_coordinates_zero_output d m b Q hbQ x.1 x.2.1 x.2.2⟩
  invFun x := (Qᴴ *ᵥ groupReduce m x.1, ⟨groupResidual m x.1,
    groupResidual_reduce_zero m x.1⟩)
  left_inv x := by
    have hx : groupReduce m x.2.1 = 0 := x.2.2
    apply Prod.ext
    · simp only [groupReduce_add, groupReduce_groupLift, hx, add_zero,
        Matrix.mulVec_mulVec, hQ, Matrix.one_mulVec]
    · apply Subtype.ext
      simp only [groupResidual, groupReduce_add, groupReduce_groupLift,
        hx, add_zero]
      abel
  right_inv x := by
    apply Subtype.ext
    change groupLift m (Q *ᵥ (Qᴴ *ᵥ groupReduce m x.1)) + groupResidual m x.1 = x.1
    have hx : star (groupLift m b) ⬝ᵥ x.1 = 0 := x.2
    rw [grouped_coordinate_reconstruction d b Q hb hQ hbQ _
      (by simpa only [groupLift_adjoint] using hx)]
    exact (copy_orthogonal_decomposition m x.1).symm
  map_add' x y := by
    apply Subtype.ext
    change groupLift m (Q *ᵥ (x.1 + y.1)) + (x.2.1 + y.2.1) = _
    rw [Matrix.mulVec_add, groupLift_add]
    change (groupLift m (Q *ᵥ x.1) + groupLift m (Q *ᵥ y.1)) + (x.2.1 + y.2.1) =
      (groupLift m (Q *ᵥ x.1) + x.2.1) + (groupLift m (Q *ᵥ y.1) + y.2.1)
    abel
  map_smul' c x := by
    apply Subtype.ext
    change groupLift m (Q *ᵥ (c • x.1)) + c • x.2.1 = _
    rw [Matrix.mulVec_smul, groupLift_smul, ← smul_add]
    rfl

/-- The constructed linear equivalence is unitary for the usual complex
Euclidean Hermitian forms and their orthogonal sum. -/
theorem copyCoordinateEquiv_unitary (d : ℕ) (m : Fin (d + 1) → ℕ)
    (b : Fin (d + 1) → ℂ) (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hb : ∑ i, star (b i) * b i = 1) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (b i) * Q i j = 0)
    (x y : (Fin d → ℂ) × inheritedSpace m) :
    star (copyCoordinateEquiv d m b Q hb hQ hbQ x).1 ⬝ᵥ
        (copyCoordinateEquiv d m b Q hb hQ hbQ y).1 =
      star x.1 ⬝ᵥ y.1 + star x.2.1 ⬝ᵥ y.2.1 :=
  copy_coordinates_isometry d m Q hQ x.1 y.1 x.2.1 y.2.1 x.2.2 y.2.2

/-- Under this same unitary equivalence the operator is exactly the
grouped compression plus the inherited scalar action. -/
theorem copyCoordinateEquiv_block_action (d : ℕ) (m : Fin (d + 1) → ℕ)
    (α b : Fin (d + 1) → ℂ) (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hb : ∑ i, star (b i) * b i = 1) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (b i) * Q i j = 0)
    (x : (Fin d → ℂ) × inheritedSpace m) :
    copyZeroAction m α b (copyCoordinateEquiv d m b Q hb hQ hbQ x).1 =
      (copyCoordinateEquiv d m b Q hb hQ hbQ
        ((Qᴴ * diagonal α * Q) *ᵥ x.1,
          ⟨copyAction m α x.2.1, inherited_invariant m α x.2.1 x.2.2⟩)).1 :=
  copy_compression_block_action d m α b Q hb hQ hbQ x.1 x.2.1 x.2.2

end PolynomialGeometry.CopyEquivalence
