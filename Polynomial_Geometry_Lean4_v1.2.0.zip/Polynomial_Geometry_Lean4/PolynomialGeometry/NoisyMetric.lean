import PolynomialGeometry.RecoveryCompletion
import Mathlib.Analysis.CStarAlgebra.Matrix
import Mathlib.Tactic.GCongr
import Mathlib.Topology.Instances.Matrix
import Mathlib.Topology.Order.Compact

/-! # Metric uncertainty in normalized inverse recovery

All matrix norms in this file are explicitly induced by the Euclidean norm.
The adjugate formula is valid even on the critical spectrum. -/

noncomputable section

open Matrix Polynomial WithLp
open scoped ComplexOrder

namespace PolynomialGeometry.NoisyMetric

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Fixed resolvent column independent of the observed inverse metric. -/
def metricVector (a : ℂ) (J : Matrix ι ι ℂ) (e : ι → ℂ) : ι → ℂ :=
  ((a • (1 : Matrix ι ι ℂ) - J)⁻¹)ᴴ *ᵥ e

/-- Polynomial reconstructed from an arbitrary inverse metric and fixed column. -/
def supportPoly (J : Matrix ι ι ℂ) (e : ι → ℂ) (F : Matrix ι ι ℂ)
    (v : ι → ℂ) (n : ℝ) : ℂ[X] :=
  SelectedRecovery.selectedPolynomial J e (F *ᵥ v) (n : ℂ)

/-- For a promised complete realization the polynomial used in the perturbation
bound is exactly the simple support away from the marked source. -/
theorem supportPoly_eq_product {σ : Type*} [Fintype σ] [DecidableEq σ]
    (a : ℂ) (n : ℝ) (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y)
    (j₀ : σ) (ha : α j₀ = a) :
    supportPoly J e H⁻¹ (metricVector a J e) n =
      ∏ j : {j : σ // j ≠ j₀}, (X - C (α j)) :=
  RecoveryCompletion.completeRealization_selected_polynomial
    a n H J e α ω Y hn hH hdim hreal j₀ ha

/-- The adjugate form, with constant input and output vectors, as a polynomial. -/
private def adjPoly (J : Matrix ι ι ℂ) (e h : ι → ℂ) : ℂ[X] :=
  ∑ i, ∑ j, C (star (e i)) * J.charmatrix.adjugate i j * C (h j)

private theorem adjPoly_eval (J : Matrix ι ι ℂ) (e h : ι → ℂ) (z : ℂ) :
    (adjPoly J e h).eval z =
    star e ⬝ᵥ ((z • (1 : Matrix ι ι ℂ) - J).adjugate *ᵥ h) := by
  have hchar : (evalRingHom z).mapMatrix J.charmatrix = z • (1 : Matrix ι ι ℂ) - J := by
    ext i j
    obtain rfl | hij := eq_or_ne i j <;> simp [Matrix.charmatrix, *]
  have hadj := (evalRingHom z).map_adjugate J.charmatrix
  rw [hchar] at hadj
  have hentry (i j : ι) : (J.charmatrix.adjugate i j).eval z =
      (z • (1 : Matrix ι ι ℂ) - J).adjugate i j :=
    congrArg (fun M : Matrix ι ι ℂ => M i j) hadj
  simp [adjPoly, Polynomial.eval_finset_sum, Matrix.mulVec, dotProduct, Finset.mul_sum, mul_assoc, hentry]

/-- Adjugate evaluation of the existing characteristic-polynomial realization,
including points at which the resolvent does not exist. -/
theorem selectedPolynomial_eval_adjugate (J : Matrix ι ι ℂ) (e h : ι → ℂ) (n z : ℂ) :
    (SelectedRecovery.selectedPolynomial J e h n).eval z =
      J.charpoly.eval z + n * (star e ⬝ᵥ ((z • (1 : Matrix ι ι ℂ) - J).adjugate *ᵥ h)) := by
  have hp : SelectedRecovery.selectedPolynomial J e h n = J.charpoly + C n * adjPoly J e h := by
    apply Polynomial.eq_of_infinite_eval_eq
    apply (Set.infinite_univ.diff (Polynomial.finite_setOf_isRoot (Matrix.charpoly_monic J).ne_zero)).mono
    intro u hu
    have hnon : J.charpoly.eval u ≠ 0 := hu.2
    let A : Matrix ι ι ℂ := u • 1 - J
    have hdet : J.charpoly.eval u = A.det := by
      rw [Matrix.eval_charpoly, Matrix.scalar_apply, ← Matrix.smul_one_eq_diagonal]
    have hU : IsUnit A.det := isUnit_iff_ne_zero.mpr (hdet ▸ hnon)
    have hcol : A.det • (A⁻¹ *ᵥ h) = A.adjugate *ᵥ h := by
      rw [Matrix.det_smul_inv_mulVec_eq_cramer _ _ hU,
        Matrix.cramer_eq_adjugate_mulVec]
    have hrow := congrArg (fun v => star e ⬝ᵥ v) hcol
    simp only [dotProduct_smul, smul_eq_mul] at hrow
    change (SelectedRecovery.selectedPolynomial J e h n).eval u = _
    rw [SelectedRecovery.selectedPolynomial_eval J e h n u ((Matrix.isUnit_iff_isUnit_det _).mpr hU),
      Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_C, adjPoly_eval, hdet]
    change A.det * (1 + n * (star e ⬝ᵥ (A⁻¹ *ᵥ h))) =
      A.det + n * (star e ⬝ᵥ (A.adjugate *ᵥ h))
    rw [← hrow]
    ring
  rw [hp, Polynomial.eval_add, Polynomial.eval_mul, Polynomial.eval_C, adjPoly_eval]

/-- Euclidean operator norm of a square complex matrix. -/
def opNorm₂ (F : Matrix ι ι ℂ) : ℝ := ‖Matrix.toEuclideanCLM (n := ι) (𝕜 := ℂ) F‖

/-- Euclidean covector norm of the row e* adj(zI-J), written on its Riesz column. -/
def adjRowNorm (J : Matrix ι ι ℂ) (e : ι → ℂ) (z : ℂ) : ℝ :=
  ‖toLp 2 (star (star e ᵥ* (z • (1 : Matrix ι ι ℂ) - J).adjugate))‖

/-- Coordinate formula for the row norm with no conjugation in the entries. -/
theorem adjRowNorm_eq (J : Matrix ι ι ℂ) (e : ι → ℂ) (z : ℂ) :
    adjRowNorm J e z = ‖toLp 2 (star e ᵥ* (z • (1 : Matrix ι ι ℂ) - J).adjugate)‖ := by
  simp [adjRowNorm, EuclideanSpace.norm_eq]

/-- Exact metric perturbation times the output and input Euclidean norms. -/
theorem supportPoly_gap (J F Fhat : Matrix ι ι ℂ) (e v : ι → ℂ) (n : ℝ) (hn : 0 ≤ n)
    (z : ℂ) :
    ‖(supportPoly J e F v n).eval z - (supportPoly J e Fhat v n).eval z‖ ≤
      n * opNorm₂ (F - Fhat) * ‖toLp 2 v‖ * adjRowNorm J e z := by
  let row := star e ᵥ* (z • (1 : Matrix ι ι ℂ) - J).adjugate
  let D := F - Fhat
  have hid : (supportPoly J e F v n).eval z - (supportPoly J e Fhat v n).eval z =
      (n : ℂ) * (row ⬝ᵥ (D *ᵥ v)) := by
    rw [show D *ᵥ v = F *ᵥ v - Fhat *ᵥ v from Matrix.sub_mulVec F Fhat v,
      dotProduct_sub]
    simp only [supportPoly, selectedPolynomial_eval_adjugate, Matrix.dotProduct_mulVec]
    dsimp [row]
    ring
  have hinner : row ⬝ᵥ (D *ᵥ v) =
      inner ℂ (toLp 2 (star row)) (toLp 2 (D *ᵥ v)) := by
    rw [EuclideanSpace.inner_toLp_toLp, star_star, dotProduct_comm]
  have hvec : ‖toLp 2 (D *ᵥ v)‖ ≤ opNorm₂ D * ‖toLp 2 v‖ :=
    (Matrix.toEuclideanCLM (n := ι) (𝕜 := ℂ) D).le_opNorm (toLp 2 v)
  rw [hid, norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hn, hinner]
  calc
    _ ≤ n * (‖toLp 2 (star row)‖ * ‖toLp 2 (D *ᵥ v)‖) :=
      mul_le_mul_of_nonneg_left (norm_inner_le_norm _ _) hn
    _ ≤ n * (‖toLp 2 (star row)‖ * (opNorm₂ D * ‖toLp 2 v‖)) := by
      gcongr
    _ = _ := by dsimp [row, D, adjRowNorm]; ring

/-- A uniform bound usable with any contour. The row-norm bound may be its
actual supremum or any certified upper bound. -/
theorem supportPoly_uniform_gap (J F Fhat : Matrix ι ι ℂ) (e v : ι → ℂ) (n ε L : ℝ)
    (hn : 0 ≤ n) (hF : opNorm₂ (F - Fhat) ≤ ε) (S : Set ℂ)
    (hrow : ∀ z ∈ S, adjRowNorm J e z ≤ L) (z : ℂ) (hz : z ∈ S) :
    ‖(supportPoly J e F v n).eval z - (supportPoly J e Fhat v n).eval z‖ ≤
      n * ε * ‖toLp 2 v‖ * L := by
  apply (supportPoly_gap J F Fhat e v n hn z).trans
  have ha : 0 ≤ adjRowNorm J e z := norm_nonneg _
  have hε : 0 ≤ ε := (norm_nonneg _).trans hF
  gcongr
  exact hrow z hz

/-- Continuity makes the row supremum finite on every compact circle. -/
theorem continuous_adjRowNorm (J : Matrix ι ι ℂ) (e : ι → ℂ) :
    Continuous (adjRowNorm J e) := by
  have hA : Continuous (fun z : ℂ => z • (1 : Matrix ι ι ℂ) - J) :=
    (continuous_id.smul continuous_const).sub continuous_const
  exact ((PiLp.continuous_toLp 2 (fun _ : ι => ℂ)).comp
    (continuous_const.matrix_vecMul hA.matrix_adjugate).star).norm

/-- The exact supremum in the paper, including circles through critical eigenvalues. -/
theorem supportPoly_circle_gap (J F Fhat : Matrix ι ι ℂ) (e v : ι → ℂ) (n ε : ℝ)
    (hn : 0 ≤ n) (hF : opNorm₂ (F - Fhat) ≤ ε) (c : ℂ) (r : ℝ)
    (z : ℂ) (hz : z ∈ Metric.sphere c r) :
    ‖(supportPoly J e F v n).eval z - (supportPoly J e Fhat v n).eval z‖ ≤
      n * ε * ‖toLp 2 v‖ * sSup (adjRowNorm J e '' Metric.sphere c r) := by
  apply supportPoly_uniform_gap J F Fhat e v n ε _ hn hF (Metric.sphere c r) _ z hz
  intro x hx
  exact le_csSup ((isCompact_sphere c r).bddAbove_image
    (continuous_adjRowNorm J e).continuousOn) ⟨x, hx, rfl⟩

/-- The corresponding actual infimum and supremum for polynomial values. -/
theorem circle_eval_bounds (Q G : ℂ[X]) (c : ℂ) (r : ℝ)
    (z : ℂ) (hz : z ∈ Metric.sphere c r) :
    sInf ((fun x => ‖Q.eval x‖) '' Metric.sphere c r) ≤ ‖Q.eval z‖ ∧
    ‖G.eval z‖ ≤ sSup ((fun x => ‖G.eval x‖) '' Metric.sphere c r) := by
  exact ⟨csInf_le ((isCompact_sphere c r).bddBelow_image
    Q.continuous.norm.continuousOn) ⟨z, hz, rfl⟩,
    le_csSup ((isCompact_sphere c r).bddAbove_image
    G.continuous.norm.continuousOn) ⟨z, hz, rfl⟩⟩

/-- Positive lower bounds for both perturbed denominators on the contour. -/
theorem rational_gap (A B g w : ℂ) (n d m η M : ℝ)
    (hw : d ≤ ‖w‖) (hB : m ≤ ‖B‖) (hg : ‖g‖ ≤ M)
    (herr : ‖A-B‖ ≤ η) (hηm : η < m) (hd : 0 < d) (hn : 0 ≤ n) :
    ‖(n:ℂ)*g/(w*A) - (n:ℂ)*g/(w*B)‖ ≤ n*M*η/(d*m*(m-η)) := by
  have hη : 0 ≤ η := (norm_nonneg _).trans herr
  have hm : 0 < m := hη.trans_lt hηm
  have hA : m-η ≤ ‖A‖ := by
    have ht := norm_sub_norm_le B A
    rw [norm_sub_rev B A] at ht
    linarith
  have hAn : A ≠ 0 := norm_pos_iff.mp ((sub_pos.mpr hηm).trans_le hA)
  have hBn : B ≠ 0 := norm_pos_iff.mp (hm.trans_le hB)
  have hwn : w ≠ 0 := norm_pos_iff.mp (hd.trans_le hw)
  have hid : (n:ℂ)*g/(w*A) - (n:ℂ)*g/(w*B) = ((n:ℂ)*g*(B-A))/(w*B*A) := by
    field_simp
  rw [hid, norm_div, norm_mul, norm_mul, norm_mul, norm_mul, Complex.norm_real,
    Real.norm_eq_abs, abs_of_nonneg hn, norm_sub_rev B A]
  have hM : 0 ≤ M := (norm_nonneg _).trans hg
  have hdiff : 0 < m-η := sub_pos.mpr hηm
  apply div_le_div₀
  · positivity
  · gcongr
  · positivity
  · gcongr

/-- An error strictly below one half yields an explicit integer decoder
from the real part of the observed complex residue. -/
theorem round_mass_of_half_error (k : ℕ) (νhat : ℂ)
    (herr : ‖(k : ℂ) - νhat‖ < 1/2) :
    ⌊νhat.re + 1/2⌋ = (k : ℤ) := by
  have hh : |(k : ℝ) - νhat.re| < 1/2 := by
    simpa using (Complex.abs_re_le_norm ((k : ℂ) - νhat)).trans_lt herr
  obtain ⟨hl, hu⟩ := abs_lt.mp hh
  apply Int.floor_eq_iff.mpr
  push_cast
  constructor <;> linarith

/-- A realization induced by an ordinary polynomial has the unique positive
integer contained in the reported closed mass disk. -/
theorem certified_integer_mass {σ : Type*} [Fintype σ] [DecidableEq σ]
    (a : ℂ) (n : ℝ) (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y)
    (hpoly : ∃ P : ℂ[X], P.Monic ∧ ∀ z, P.eval z ≠ 0 → (∀ j, z ≠ α j) →
      P.derivative.eval z / P.eval z = ∑ j, (ω j : ℂ)^2 / (z - α j))
    (j : σ) (νhat : ℂ) (E : ℝ) (k : ℕ)
    (herror : ‖(ω j : ℂ)^2 - νhat‖ ≤ E)
    (hisolate : ∀ t : ℕ, 0 < t → ‖(t : ℂ) - νhat‖ ≤ E → t = k) :
    ω j ^ 2 = (k : ℝ) := by
  obtain ⟨mass, hm, heq⟩ :=
    (RecoveryCompletion.completeRealization_integer_iff a n H J e α ω Y hreal).mp hpoly
  have hc : (ω j : ℂ)^2 = (mass j : ℂ) := by exact_mod_cast heq j
  rw [hc] at herror
  exact (heq j).trans (congrArg (fun t : ℕ => (t : ℝ)) (hisolate _ (hm j) herror))

end PolynomialGeometry.NoisyMetric
