import PolynomialGeometry.CriticalReconstruction
import PolynomialGeometry.SimpleRoot
import PolynomialGeometry.Source

/-!
# Reconstruction from polynomial multiplicity and explicit diagonal Taylor data

The input is a monic polynomial and the multiplicity of its actual derivative.
No residual factorization is assumed. Formal Taylor coefficients of the reciprocal
source factor determine the diagonal reconstructed polynomial uniquely.
-/

noncomputable section
namespace PolynomialGeometry.ReconstructionCompletion
open Polynomial Filter
open PolynomialGeometry.Factorization PolynomialGeometry.CriticalReconstruction
open PolynomialGeometry.Variations
open scoped BigOperators Topology

/-- Coefficients recover every monic polynomial of the prescribed degree. -/
theorem monicPolynomial_coefficients (P : ℂ[X]) (n : ℕ)
    (hP : P.Monic) (hn : P.natDegree = n) :
    monicPolynomial n (fun k : Fin n => P.coeff k) = P := by
  apply monic_eq_of_low_coeff _ _ n (monicPolynomial_monic _ _) hP
    (monicPolynomial_natDegree _ _) hn
  intro k
  exact monicPolynomial_coeff _ _ k

/-- The derivative of a monic degree `n+1` polynomial has degree `n` and
leading coefficient `n+1`. -/
theorem monic_derivative_data (P : ℂ[X]) (n : ℕ)
    (hP : P.Monic) (hn : P.natDegree = n + 1) :
    P.derivative.natDegree = n ∧ P.derivative.leadingCoeff = (n + 1 : ℂ) := by
  have hpos : 0 < P.natDegree := by omega
  have hd : P.derivative.degree = (n : WithBot ℕ) := by
    simpa only [hn, Nat.add_sub_cancel] using degree_derivative_eq P hpos
  have hnd := natDegree_eq_of_degree_eq_some hd
  refine ⟨hnd, ?_⟩
  rw [leadingCoeff, hnd, coeff_derivative]
  have hc : P.coeff (n + 1) = 1 := by simpa [hn] using hP.coeff_natDegree
  simp [hc]

/-- Exact derivative multiplicity produces the monic nonvanishing residual
factor required by the square analytic reconstruction system. -/
theorem residual_from_exact_multiplicity (P : ℂ[X]) (r s : ℕ) (w : ℂ)
    (hP : P.Monic) (hdeg : P.natDegree = r + s + 1)
    (hmult : P.derivative.rootMultiplicity w = r) :
    ∃ U : ℂ[X], U.Monic ∧ U.natDegree = s ∧ U.eval w ≠ 0 ∧
      P.derivative = C (r + s + 1 : ℂ) * (X - C w) ^ r * U := by
  let N : ℂ := r + s + 1
  have hN : N ≠ 0 := by dsimp [N]; exact_mod_cast (by omega : r + s + 1 ≠ 0)
  have ⟨hdd, hdl⟩ := monic_derivative_data P (r + s) hP hdeg
  have hdp : P.derivative ≠ 0 := by
    intro hz
    have hl := congrArg leadingCoeff hz
    rw [hdl, leadingCoeff_zero] at hl
    exact hN (by simpa [N, Nat.cast_add] using hl)
  obtain ⟨V, hV, hndvd⟩ := P.derivative.exists_eq_pow_rootMultiplicity_mul_and_not_dvd hdp w
  rw [hmult] at hV
  let U := C N⁻¹ * V
  have hVne : V ≠ 0 := by intro hz; simp [hz] at hV; exact hdp hV
  have hUn : U ≠ 0 := mul_ne_zero (C_ne_zero.mpr (inv_ne_zero hN)) hVne
  have heq : P.derivative = C N * (X - C w) ^ r * U := by
    rw [hV]
    dsimp [U]
    calc
      (X - C w) ^ r * V = (C N * C N⁻¹) * ((X - C w) ^ r * V) := by
        rw [← C_mul, mul_inv_cancel₀ hN, C_1, one_mul]
      _ = C N * (X - C w) ^ r * (C N⁻¹ * V) := by ring
  have hVm : V.leadingCoeff = N := by
    have hh := congrArg leadingCoeff hV
    rw [leadingCoeff_mul, (monic_X_sub_C w).pow r |>.leadingCoeff, one_mul] at hh
    exact hh.symm.trans (by simpa [N, Nat.cast_add] using hdl)
  have hUm : U.Monic := by
    apply monic_C_mul_of_mul_leadingCoeff_eq_one
    rw [hVm, inv_mul_cancel₀ hN]
  have hUd : U.natDegree = s := by
    have hd := congrArg natDegree heq
    rw [hdd, natDegree_mul (mul_ne_zero (C_ne_zero.mpr hN)
      ((monic_X_sub_C w).pow r).ne_zero) hUn,
      natDegree_C_mul hN, natDegree_pow, natDegree_X_sub_C, mul_one] at hd
    omega
  refine ⟨U, hUm, hUd, ?_, heq⟩
  have hVw : V.eval w ≠ 0 := by
    simpa only [dvd_iff_isRoot, Polynomial.IsRoot] using hndvd
  simp only [U, eval_mul, eval_C]
  exact mul_ne_zero (inv_ne_zero hN) hVw

/-- The normalized residual coefficient vector is constructed from exact
multiplicity. This is the original-polynomial to coefficient-data bridge. -/
theorem reconstruction_data_from_multiplicity (r s : ℕ)
    (A : ℂ[X]) (α : Fin (s + 1) → ℂ) (w : ℂ)
    (hA : A.Monic) (hAd : A.natDegree = r)
    (hmult : (A * rootPolynomial (s + 1) α).derivative.rootMultiplicity w = r) :
    ∃ a : Unknown r s,
      monicPolynomial r a.1 = A ∧
      (monicPolynomial s a.2).eval w ≠ 0 ∧
      (monicPolynomial r a.1 * rootPolynomial (s + 1) α).derivative =
        C (r + s + 1 : ℂ) * (X - C w) ^ r * monicPolynomial s a.2 := by
  have hP := hA.mul (rootPolynomial_monic (s + 1) α)
  have hd : (A * rootPolynomial (s + 1) α).natDegree = r + s + 1 := by
    rw [natDegree_mul hA.ne_zero (rootPolynomial_monic _ _).ne_zero, hAd,
      rootPolynomial_natDegree]
    omega
  obtain ⟨U, hU, hUd, hUw, hident⟩ :=
    residual_from_exact_multiplicity _ r s w hP hd hmult
  refine ⟨((fun k => A.coeff k), (fun k => U.coeff k)), ?_, ?_, ?_⟩
  · exact monicPolynomial_coefficients A r hA hAd
  · simpa only [monicPolynomial_coefficients U s hU hUd] using hUw
  · simpa only [monicPolynomial_coefficients A r hA hAd,
      monicPolynomial_coefficients U s hU hUd] using hident

/-- The reciprocal source Taylor coefficients, defined without making any
choice of a reconstructed interior factor. -/
def reciprocalTaylorCoeff (M : ℂ[X]) (w : ℂ) (k : ℕ) : ℂ :=
  PowerSeries.coeff k ((taylor w M : PowerSeries ℂ)⁻¹)

/-- Polynomial compatibility identifies every reciprocal Taylor coefficient
through order `r`. -/
theorem diagonal_reciprocal_coefficients (A M : ℂ[X]) (w : ℂ) (r : ℕ)
    (hM : M.eval w ≠ 0)
    (hcrit : (X - C w) ^ r ∣ (A * M).derivative) :
    ∀ k ≤ r, (taylor w A).coeff k =
      (A * M).eval w * reciprocalTaylorCoeff M w k := by
  obtain ⟨Q, hQ⟩ := derivative_divisibility_constant_jet (A * M) w r hcrit
  have ht := congrArg (taylor w) hQ
  simp only [map_sub, taylor_mul, taylor_C, taylor_pow, taylor_X,
    add_sub_cancel_right] at ht
  let T : PowerSeries ℂ := taylor w M
  have hT : PowerSeries.constantCoeff T ≠ 0 := by
    simpa only [T, ← PowerSeries.coeff_zero_eq_constantCoeff_apply,
      Polynomial.coeff_coe, taylor_coeff_zero] using hM
  have hinv : T * T⁻¹ = 1 := PowerSeries.mul_inv_cancel T hT
  have hseries : (taylor w A : PowerSeries ℂ) -
      PowerSeries.C ((A * M).eval w) * T⁻¹ =
      PowerSeries.X ^ (r + 1) * ((taylor w Q : PowerSeries ℂ) * T⁻¹) := by
    have he := congrArg (fun p : ℂ[X] => (p : PowerSeries ℂ)) ht
    simp only [Polynomial.coe_sub, Polynomial.coe_mul, Polynomial.coe_C,
      Polynomial.coe_pow, Polynomial.coe_X] at he
    have hm := congrArg (fun p : PowerSeries ℂ => p * T⁻¹) he
    change (((taylor w A : PowerSeries ℂ) * T - PowerSeries.C ((A * M).eval w)) * T⁻¹) = _ at hm
    simpa only [sub_mul, mul_assoc, hinv, mul_one] using hm
  intro k hk
  have he := congrArg (PowerSeries.coeff k) hseries
  simp only [map_sub, Polynomial.coeff_coe, PowerSeries.coeff_C_mul,
    PowerSeries.coeff_X_pow_mul', show ¬ r + 1 ≤ k by omega, if_false] at he
  exact sub_eq_zero.mp he

/-- The top reciprocal Taylor coefficient cannot vanish in the actual
monic critical configuration. -/
theorem diagonal_top_coefficient (A M : ℂ[X]) (w : ℂ) (r : ℕ)
    (hA : A.Monic) (hd : A.natDegree = r) (hM : M.eval w ≠ 0)
    (hcrit : (X - C w) ^ r ∣ (A * M).derivative) :
    (A * M).eval w * reciprocalTaylorCoeff M w r = 1 ∧
      reciprocalTaylorCoeff M w r ≠ 0 := by
  have he := diagonal_reciprocal_coefficients A M w r hM hcrit r le_rfl
  have hc : (taylor w A).coeff r = 1 := by
    rw [← hd, coeff_taylor_natDegree, hA.leadingCoeff]
  have hp : (A * M).eval w * reciprocalTaylorCoeff M w r = 1 := he.symm.trans hc
  exact ⟨hp, by intro hz; simp [hz] at hp⟩

/-- Exact diagonal reconstruction as the normalized reciprocal Taylor
polynomial. The coefficients depend only on `M,w`. -/
theorem diagonal_reciprocal_taylor_formula (A M : ℂ[X]) (w : ℂ) (r : ℕ)
    (hA : A.Monic) (hd : A.natDegree = r) (hM : M.eval w ≠ 0)
    (hcrit : (X - C w) ^ r ∣ (A * M).derivative) (z : ℂ) :
    A.eval z = (reciprocalTaylorCoeff M w r)⁻¹ *
      ∑ k ∈ Finset.range (r + 1), reciprocalTaylorCoeff M w k * (z - w) ^ k := by
  obtain ⟨hprod, hf⟩ := diagonal_top_coefficient A M w r hA hd hM hcrit
  have hval : (A * M).eval w = (reciprocalTaylorCoeff M w r)⁻¹ := by
    apply (mul_right_cancel₀ hf)
    rw [hprod, inv_mul_cancel₀ hf]
  rw [← taylor_eval_sub w A z, eval_eq_sum_range' (n := r + 1) (by simp [hd])]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k hk
  rw [diagonal_reciprocal_coefficients A M w r hM hcrit k (by simpa only [Finset.mem_range, Nat.lt_succ_iff] using hk), hval]
  ring

end PolynomialGeometry.ReconstructionCompletion
