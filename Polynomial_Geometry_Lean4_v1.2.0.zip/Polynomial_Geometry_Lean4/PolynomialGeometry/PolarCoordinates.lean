import PolynomialGeometry.RatioCoordinates

/-! # Actual polar coordinates near boundary source roots

The inverse coordinates are constructed with the local logarithm. Their
continuity supplies the local-coverage implication, including source copies
that coincide at the base point.
-/
noncomputable section
open Complex Filter
open scoped Topology

namespace PolynomialGeometry.PolarCoordinates

variable {ι : Type*} [Fintype ι]

def logCoordinates (β α : ι → ℂ) : ι → ℂ := fun j => Complex.log (α j / β j)

def polarSources (β : ι → ℂ) (p : (ι → ℝ) × (ι → ℝ)) : ι → ℂ :=
  fun j => β j * Complex.exp (p.1 j + p.2 j * Complex.I)

def realCoordinates (β α : ι → ℂ) : (ι → ℝ) × (ι → ℝ) :=
  (fun j => (logCoordinates β α j).re, fun j => (logCoordinates β α j).im)

theorem logCoordinates_analytic (β : ι → ℂ) (hβ : ∀ j, β j ≠ 0) :
    AnalyticAt ℂ (logCoordinates β) β := by
  apply AnalyticAt.pi
  intro j
  apply RatioCoordinates.analyticAt_log_comp
    (((ContinuousLinearMap.proj j : (ι → ℂ) →L[ℂ] ℂ).analyticAt β).div
      analyticAt_const (hβ j))
  simp [hβ j]

omit [Fintype ι] in
@[simp] theorem logCoordinates_base (β : ι → ℂ) (hβ : ∀ j, β j ≠ 0) :
    logCoordinates β β = 0 := by
  ext j
  simp [logCoordinates, hβ j]

omit [Fintype ι] in
@[simp] theorem realCoordinates_base (β : ι → ℂ) (hβ : ∀ j, β j ≠ 0) :
    realCoordinates β β = 0 := by
  apply Prod.ext <;> ext j <;> simp [realCoordinates, logCoordinates_base β hβ]

theorem realCoordinates_continuous (β : ι → ℂ) (hβ : ∀ j, β j ≠ 0) :
    ContinuousAt (realCoordinates β) β := by
  have hc := (logCoordinates_analytic β hβ).continuousAt
  apply ContinuousAt.prodMk
  · exact continuousAt_pi.mpr fun j => Complex.continuous_re.continuousAt.comp
      ((continuous_apply j).continuousAt.comp hc)
  · exact continuousAt_pi.mpr fun j => Complex.continuous_im.continuousAt.comp
      ((continuous_apply j).continuousAt.comp hc)

omit [Fintype ι] in
theorem polarSources_continuous (β : ι → ℂ) : Continuous (polarSources β) := by
  apply continuous_pi
  intro j
  exact continuous_const.mul (Complex.continuous_exp.comp
    (((Complex.continuous_ofReal.comp (continuous_apply j |>.comp continuous_fst))).add
      ((Complex.continuous_ofReal.comp (continuous_apply j |>.comp continuous_snd)).mul
        continuous_const)))

omit [Fintype ι] in
@[simp] theorem polarSources_zero (β : ι → ℂ) : polarSources β 0 = β := by
  ext j
  simp [polarSources]

omit [Fintype ι] in
/-- Exact reconstruction from the inverse coordinates. -/
theorem polarSources_realCoordinates (β α : ι → ℂ)
    (hβ : ∀ j, β j ≠ 0) (hα : ∀ j, α j ≠ 0) :
    polarSources β (realCoordinates β α) = α := by
  ext j
  change β j * Complex.exp ((logCoordinates β α j).re +
    (logCoordinates β α j).im * Complex.I) = α j
  rw [Complex.re_add_im, logCoordinates, Complex.exp_log (div_ne_zero (hα j) (hβ j))]
  exact mul_div_cancel₀ _ (hβ j)

/-- The inverse is genuinely local: its coordinates tend to zero and its
forward exponential recovers every nearby source list. -/
theorem local_polar_inverse (β : ι → ℂ) (hβ : ∀ j, β j ≠ 0) :
    Tendsto (realCoordinates β) (𝓝 β) (𝓝 0) ∧
      ∀ᶠ α in 𝓝 β, polarSources β (realCoordinates β α) = α := by
  refine ⟨by simpa only [realCoordinates_base β hβ] using
    (realCoordinates_continuous β hβ).tendsto, ?_⟩
  have hn : ∀ᶠ α : ι → ℂ in 𝓝 β, ∀ j, α j ≠ 0 :=
    eventually_all.mpr fun j => (continuousAt_apply j β).eventually_ne (hβ j)
  exact hn.mono fun α hα => polarSources_realCoordinates β α hβ hα

omit [Fintype ι] in
/-- Disk feasibility is exactly the nonpositive real logarithmic coordinate. -/
theorem disk_iff_radial (β α : ι → ℂ) (hβ : ∀ j, ‖β j‖ = 1) :
    (∀ j, ‖α j‖ ≤ 1) ↔ ∀ j, (realCoordinates β α).1 j ≤ 0 := by
  apply forall_congr'
  intro j
  simp only [realCoordinates, logCoordinates, Complex.log_re, norm_div, hβ j, div_one]
  exact (Real.log_nonpos_iff (norm_nonneg (α j))).symm

omit [Fintype ι] in
/-- On the principal angle strip, the other composite is also the identity. -/
theorem realCoordinates_polarSources (β : ι → ℂ) (hβ : ∀ j, β j ≠ 0)
    (p : (ι → ℝ) × (ι → ℝ))
    (hp : ∀ j, -Real.pi < p.2 j ∧ p.2 j ≤ Real.pi) :
    realCoordinates β (polarSources β p) = p := by
  have hlog (j : ι) : logCoordinates β (polarSources β p) j =
      (p.1 j : ℂ) + p.2 j * Complex.I := by
    simp only [logCoordinates, polarSources, mul_div_cancel_left₀ _ (hβ j)]
    apply Complex.log_exp
    · simpa using (hp j).1
    · simpa using (hp j).2
  apply Prod.ext
  · ext j
    simp [realCoordinates, hlog]
  · ext j
    simp [realCoordinates, hlog]

end PolynomialGeometry.PolarCoordinates
