import PolynomialGeometry.ReconstructionCoverage
import PolynomialGeometry.CriticalFactorUniqueness

/-! # Interior-factor uniqueness without an assumed nearby residual factor -/
noncomputable section
namespace PolynomialGeometry.ReconstructionCompletion
open Polynomial Filter
open PolynomialGeometry.Factorization PolynomialGeometry.CriticalReconstruction
open scoped BigOperators Topology

/-- The local uniqueness of the square factor system implies uniqueness in
`A` alone. The actual residual of the candidate derivative is constructed
analytically, and its separation from the prescribed copies is proved. -/
theorem interior_factor_unique_from_divisibility (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (x : Domain r s) (β : Fin (s + 1) → ℂ) (w : ℂ)
    (R : Parameter r s → Unknown r s)
    (hcrit : monicPolynomial r x.2.1 = (X - C w) ^ r)
    (hsource : monicPolynomial (s + 1) x.2.2 = rootPolynomial (s + 1) β)
    (hU : (monicPolynomial s x.1.2).eval w ≠ 0)
    (hid : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative =
      C (r + s + 1 : ℂ) * monicPolynomial r x.2.1 * monicPolynomial s x.1.2)
    (hunique : ∀ᶠ z : Unknown r s × Parameter r s in 𝓝 (x.1, ((fun _ => w), β)),
      (monicPolynomial r z.1.1 * rootPolynomial (s + 1) z.2.2).derivative =
        C (r + s + 1 : ℂ) * rootPolynomial r z.2.1 * monicPolynomial s z.1.2 →
      R z.2 = z.1) :
    ∀ᶠ y : (Fin r → ℂ) × Parameter r s in 𝓝 (x.1.1, ((fun _ => w), β)),
      rootPolynomial r y.2.1 ∣
        (monicPolynomial r y.1 * rootPolynomial (s + 1) y.2.2).derivative →
      (R y.2).1 = y.1 := by
  let y₀ : (Fin r → ℂ) × Parameter r s := (x.1.1, ((fun _ => w), β))
  let B : ((Fin r → ℂ) × Parameter r s) → Parameter r s :=
    fun y => (y.1, rootCoefficients (s + 1) y.2.2)
  have hm : rootCoefficients (s + 1) β = x.2.2 := by
    ext k
    change (rootPolynomial (s + 1) β).coeff k = _
    rw [← hsource, monicPolynomial_coeff]
  have hB0 : B y₀ = (x.1.1, x.2.2) := by simp only [B, y₀, hm]
  have hB : ContinuousAt B y₀ := continuousAt_fst.prodMk
    ((rootCoefficients_analyticAt (s + 1) β).continuousAt.comp_of_eq
      (continuousAt_snd.snd) rfl)
  obtain ⟨H, hH, hH0, hHpoly⟩ := actual_critical_factorization r s hr hs x w hcrit hU hid
  let J : ((Fin r → ℂ) × Parameter r s) → Unknown r s := H ∘ B
  have hJ : ContinuousAt J y₀ := hH.continuousAt.comp_of_eq hB hB0
  have hJ0 : J y₀ = (x.2.1, x.1.2) := by dsimp [J]; rw [hB0, hH0]
  have hnonzero : ∀ᶠ y in 𝓝 y₀, ∀ i : Fin r,
      (monicPolynomial s (J y).2).eval (y.2.1 i) ≠ 0 := by
    apply Filter.eventually_all.mpr
    intro i
    have hc : ContinuousAt (fun y : (Fin r → ℂ) × Parameter r s =>
        ((J y).2, y.2.1 i)) y₀ := hJ.snd.prodMk
      (((continuous_apply i).comp (continuous_fst.comp continuous_snd)).continuousAt)
    have he := (monicPolynomial_eval_analyticAt s (x.1.2, w)).continuousAt.comp_of_eq hc
      (by simp only [hJ0, y₀])
    exact he.eventually_ne (by simpa only [Function.comp_apply, hJ0, y₀] using hU)
  let T : ((Fin r → ℂ) × Parameter r s) → Unknown r s × Parameter r s :=
    fun y => ((y.1, (J y).2), y.2)
  have hT : ContinuousAt T y₀ := (continuousAt_fst.prodMk hJ.snd).prodMk continuousAt_snd
  have hT0 : T y₀ = (x.1, ((fun _ => w), β)) := by simp only [T, hJ0, y₀]
  have ht : Tendsto T (𝓝 y₀) (𝓝 (x.1, ((fun _ => w), β))) := hT0 ▸ hT
  have hb : Tendsto B (𝓝 y₀) (𝓝 (x.1.1, x.2.2)) := hB0 ▸ hB
  filter_upwards [ht.eventually hunique, hb.eventually hHpoly, hnonzero] with y hy hp hn
  intro hdiv
  have hpoly : (monicPolynomial r y.1 * rootPolynomial (s + 1) y.2.2).derivative =
      C (r + s + 1 : ℂ) * monicPolynomial r (J y).1 * monicPolynomial s (J y).2 := by
    simpa only [B, J, Function.comp_apply, monicPolynomial_rootCoefficients] using hp
  have hN : (r + s + 1 : ℂ) ≠ 0 := by exact_mod_cast (by omega : r + s + 1 ≠ 0)
  have hc : monicPolynomial r (J y).1 = rootPolynomial r y.2.1 := by
    rw [hpoly] at hdiv
    exact PolynomialGeometry.CriticalFactorUniqueness.prescribed_factor_unique
      r y.2.1 (r + s + 1 : ℂ) (monicPolynomial r (J y).1) (monicPolynomial s (J y).2)
      hN (monicPolynomial_monic _ _) (monicPolynomial_natDegree _ _) hn hdiv
  have he := hy (by simpa only [T, hc] using hpoly)
  exact congrArg Prod.fst he

end PolynomialGeometry.ReconstructionCompletion
