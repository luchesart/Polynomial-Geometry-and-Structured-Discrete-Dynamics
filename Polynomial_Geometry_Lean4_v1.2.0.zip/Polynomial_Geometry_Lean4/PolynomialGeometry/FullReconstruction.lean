import PolynomialGeometry.ReconstructionCoverage
import PolynomialGeometry.RootLabelCoverage
import PolynomialGeometry.InteriorUniqueness

/-! # Full local labelled reconstruction, including every nearby polynomial

The polynomial coefficient inverse, actual factorization, pointwise labels,
local uniqueness, exact cluster and marked simple-root branches are composed.
Repeated roots are never assumed to have analytic individual labels.
-/

noncomputable section
namespace PolynomialGeometry.ReconstructionCompletion
open Polynomial Filter
open PolynomialGeometry.Factorization PolynomialGeometry.CriticalReconstruction
open PolynomialGeometry.SimpleRoot
open scoped BigOperators Topology

/-- The actual critical chart covers all nearby polynomials with labels in
any prescribed neighborhoods of the base source and critical copies. -/
theorem labelled_chart_with_full_coverage (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (x : Domain r s) (β : Fin (s + 1) → ℂ) (w : ℂ)
    (hcrit : monicPolynomial r x.2.1 = (X - C w) ^ r)
    (hsource : monicPolynomial (s + 1) x.2.2 = rootPolynomial (s + 1) β)
    (hM : (monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hvalue : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hU : (monicPolynomial s x.1.2).eval w ≠ 0)
    (hcop : IsCoprime (monicPolynomial r x.1.1) (monicPolynomial (s + 1) x.2.2))
    (hid : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative =
      C (r + s + 1 : ℂ) * monicPolynomial r x.2.1 * monicPolynomial s x.1.2) :
    ∃ R : Parameter r s → Unknown r s,
      AnalyticAt ℂ R ((fun _ => w), β) ∧ R ((fun _ => w), β) = x.1 ∧
      (∀ᶠ q in 𝓝 (((fun _ => w), β) : Parameter r s),
        (reconstructedPolynomial r s R q).derivative =
          C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s (R q).2) ∧
      (∀ (σ : Equiv.Perm (Fin r)) (π : Equiv.Perm (Fin (s + 1))) q,
        R (q.1 ∘ σ, q.2 ∘ π) = R q) ∧
      (∀ᶠ z : Unknown r s × Parameter r s in 𝓝 (x.1, ((fun _ => w), β)),
        (monicPolynomial r z.1.1 * rootPolynomial (s + 1) z.2.2).derivative =
          C (r + s + 1 : ℂ) * rootPolynomial r z.2.1 * monicPolynomial s z.1.2 →
        R z.2 = z.1) ∧
      (∀ (U : Set (Fin r → ℂ)) (V : Set (Fin (s + 1) → ℂ)),
        IsOpen U → (fun _ => w) ∈ U → IsOpen V → β ∈ V →
        ∀ᶠ p in 𝓝 (factorCoefficientMap r (s + 1) (x.1.1, x.2.2)),
          ∃ q : Parameter r s, q.1 ∈ U ∧ q.2 ∈ V ∧
            reconstructedPolynomial r s R q = monicPolynomial (r + (s + 1)) p) := by
  obtain ⟨F, H, G, hF, hF0, hH, hH0, hG, hG0, hGforward, hGuniq, hcoverage⟩ :=
    nearby_polynomial_coverage r s hr hs x w hcrit hM hvalue hU hcop hid
  let q₀ : Parameter r s := ((fun _ => w), β)
  let T : Parameter r s → Parameter r s :=
    fun q => (rootCoefficients r q.1, rootCoefficients (s + 1) q.2)
  have hc : rootCoefficients r (fun _ => w) = x.2.1 := by
    ext k
    change (rootPolynomial r (fun _ => w)).coeff k = _
    rw [rootPolynomial_const, ← hcrit, monicPolynomial_coeff]
  have hm : rootCoefficients (s + 1) β = x.2.2 := by
    ext k
    change (rootPolynomial (s + 1) β).coeff k = _
    rw [← hsource, monicPolynomial_coeff]
  have hT0 : T q₀ = x.2 := Prod.ext hc hm
  have hT : AnalyticAt ℂ T q₀ :=
    ((rootCoefficients_analyticAt r q₀.1).comp analyticAt_fst).prod
      ((rootCoefficients_analyticAt (s + 1) q₀.2).comp analyticAt_snd)
  let R := G ∘ T
  have hR : AnalyticAt ℂ R q₀ := hG.comp_of_eq hT hT0
  have hR0 : R q₀ = x.1 := (congrArg G hT0).trans hG0
  have ht : Tendsto T (𝓝 q₀) (𝓝 x.2) := hT0 ▸ hT.continuousAt
  refine ⟨R, hR, hR0, ?_, ?_, ?_, ?_⟩
  · filter_upwards [ht.eventually hGforward] with q hq
    simpa only [T, R, Function.comp_apply, monicPolynomial_rootCoefficients,
      reconstructedPolynomial] using hq
  · intro σ π q
    simp [R, T]
  · have hf : ContinuousAt (fun z : Unknown r s × Parameter r s => (z.1, T z.2))
        (x.1, q₀) := continuousAt_fst.prodMk
          (hT.continuousAt.comp_of_eq continuousAt_snd rfl)
    have hf0 : (x.1, T q₀) = x := by rw [hT0]
    have hft : Tendsto (fun z : Unknown r s × Parameter r s => (z.1, T z.2))
        (𝓝 (x.1, q₀)) (𝓝 x) := hf0 ▸ hf
    filter_upwards [hft.eventually hGuniq] with z hz
    simpa only [T, R, Function.comp_apply, monicPolynomial_rootCoefficients] using hz
  · intro U V hUo hw hVo hβ
    have hzlabels := PolynomialGeometry.RootLabelCoverage.nearby_root_labels r
      (fun _ => w) U hUo hw
    have hαlabels := PolynomialGeometry.RootLabelCoverage.nearby_root_labels (s + 1)
      β V hVo hβ
    have hhc : ContinuousAt (fun p => (H p).1)
        (factorCoefficientMap r (s + 1) (x.1.1, x.2.2)) := hH.continuousAt.fst
    have hfc : ContinuousAt (fun p => (F p).2)
        (factorCoefficientMap r (s + 1) (x.1.1, x.2.2)) := hF.continuousAt.snd
    have hzbase : (H (factorCoefficientMap r (s + 1) (x.1.1, x.2.2))).1 =
        rootCoefficients r (fun _ => w) := by rw [hH0]; exact hc.symm
    have hαbase : (F (factorCoefficientMap r (s + 1) (x.1.1, x.2.2))).2 =
        rootCoefficients (s + 1) β := by rw [hF0]; exact hm.symm
    have hzt : Tendsto (fun p => (H p).1)
        (𝓝 (factorCoefficientMap r (s + 1) (x.1.1, x.2.2)))
        (𝓝 (rootCoefficients r (fun _ => w))) := hzbase ▸ hhc
    have hαt : Tendsto (fun p => (F p).2)
        (𝓝 (factorCoefficientMap r (s + 1) (x.1.1, x.2.2)))
        (𝓝 (rootCoefficients (s + 1) β)) := hαbase ▸ hfc
    filter_upwards [hcoverage, hzt.eventually hzlabels, hαt.eventually hαlabels] with p hp hz hα
    obtain ⟨z, hzU, hzc⟩ := hz
    obtain ⟨α, hαV, hαc⟩ := hα
    refine ⟨(z, α), hzU, hαV, ?_⟩
    change monicPolynomial r (G (rootCoefficients r z, rootCoefficients (s + 1) α)).1 *
      rootPolynomial (s + 1) α = _
    rw [hzc, hαc, hp.1, ← monicPolynomial_rootCoefficients, hαc]
    exact hp.2.1

/-- A reconstructed family contains precisely its prescribed critical cluster
in one fixed disk, with the exact multiplicities of every labelled copy. -/
theorem exact_cluster_from_chart (r s : ℕ) (R : Parameter r s → Unknown r s)
    (β : Fin (s + 1) → ℂ) (w : ℂ)
    (hR : AnalyticAt ℂ R (((fun _ => w), β) : Parameter r s))
    (hU : (monicPolynomial s (R ((fun _ => w), β)).2).eval w ≠ 0)
    (hidentity : ∀ᶠ q in 𝓝 (((fun _ => w), β) : Parameter r s),
      (reconstructedPolynomial r s R q).derivative =
        C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s (R q).2) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ᶠ q in 𝓝 (((fun _ => w), β) : Parameter r s),
      (∀ i : Fin r, q.1 i ∈ Metric.ball w ε) ∧
      (∀ z ∈ Metric.ball w ε,
        (reconstructedPolynomial r s R q).derivative.IsRoot z ↔
          (rootPolynomial r q.1).IsRoot z) ∧
      (∀ i : Fin r,
        (reconstructedPolynomial r s R q).derivative.rootMultiplicity (q.1 i) =
          (rootPolynomial r q.1).rootMultiplicity (q.1 i)) := by
  obtain ⟨ε, hε, hnonzero⟩ := residual_factor_nonzero_on_disk s
    (fun q => (R q).2) ((fun _ => w), β) w hR.continuousAt.snd hU
  have hcopies : ∀ᶠ q in 𝓝 (((fun _ => w), β) : Parameter r s),
      ∀ i : Fin r, q.1 i ∈ Metric.ball w ε := by
    apply Filter.eventually_all.mpr
    intro i
    have hc : Continuous (fun q : Parameter r s => q.1 i) :=
      (continuous_apply i).comp continuous_fst
    exact hc.continuousAt.eventually (Metric.ball_mem_nhds w hε)
  refine ⟨ε, hε, ?_⟩
  filter_upwards [hidentity, hnonzero, hcopies] with q hid hq hc
  refine ⟨hc, reconstructed_cluster_exact_on_disk r s (R q) q w ε hid hq, ?_⟩
  intro i
  exact reconstructed_critical_multiplicity r s (R q) q hid i (hq _ (hc i))

/-- The explicit analytic Taylor formula holds throughout the diagonal slice
of the same reconstructed family, not just at its base polynomial. -/
theorem diagonal_formula_on_chart (r s : ℕ) (R : Parameter r s → Unknown r s)
    (β : Fin (s + 1) → ℂ) (w : ℂ)
    (hM : (rootPolynomial (s + 1) β).eval w ≠ 0)
    (hidentity : ∀ᶠ q in 𝓝 (((fun _ => w), β) : Parameter r s),
      (reconstructedPolynomial r s R q).derivative =
        C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s (R q).2) :
    ∀ᶠ p : ℂ × (Fin (s + 1) → ℂ) in 𝓝 (w, β),
      let q : Parameter r s := ((fun _ => p.1), p.2)
      let f := fun k => (k.factorial : ℂ)⁻¹ *
        iteratedDeriv k (fun y => ((rootPolynomial (s + 1) p.2).eval y)⁻¹) p.1
      f r ≠ 0 ∧ ∀ z : ℂ, (monicPolynomial r (R q).1).eval z =
        (f r)⁻¹ * ∑ k ∈ Finset.range (r + 1), f k * (z - p.1) ^ k := by
  let D : ℂ × (Fin (s + 1) → ℂ) → Parameter r s := fun p => ((fun _ => p.1), p.2)
  have hD : Continuous D := by fun_prop
  have hMe : Continuous (fun p : ℂ × (Fin (s + 1) → ℂ) =>
      (rootPolynomial (s + 1) p.2).eval p.1) := by
    simp only [rootPolynomial, eval_prod, eval_sub, eval_X, eval_C]
    fun_prop
  filter_upwards [hD.continuousAt.eventually hidentity, hMe.continuousAt.eventually_ne hM]
    with p hp hm
  have hdiv : (X - C p.1) ^ r ∣
      (monicPolynomial r (R (D p)).1 * rootPolynomial (s + 1) p.2).derivative := by
    change (X - C p.1) ^ r ∣ (reconstructedPolynomial r s R (D p)).derivative
    rw [hp]
    dsimp [D]
    rw [rootPolynomial_const]
    exact dvd_mul_of_dvd_left (dvd_mul_left _ _) _
  have hformula := diagonal_analytic_taylor_formula (monicPolynomial r (R (D p)).1)
    (rootPolynomial (s + 1) p.2) p.1 r (monicPolynomial_monic _ _)
    (monicPolynomial_natDegree _ _) hm hdiv
  exact ⟨(hformula p.1).1, fun z => (hformula z).2⟩

/-- The outputs of Lemma 5.1 and its local coverage assertion. This is an
output record: the theorem below constructs every proof field from original
polynomial hypotheses. It is never assumed as input to that theorem. -/
structure LocalReconstructionResult (r s : ℕ) (A : ℂ[X])
    (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ) where
  family : Parameter r s → Unknown r s
  sourceRoot : Parameter r s → ℂ
  simpleCritical : Parameter r s → ℂ
  family_analytic : AnalyticAt ℂ family ((fun _ => w), β)
  family_base : monicPolynomial r (family ((fun _ => w), β)).1 = A
  source_analytic : AnalyticAt ℂ sourceRoot ((fun _ => w), β)
  source_base : sourceRoot ((fun _ => w), β) = a₀
  critical_analytic : AnalyticAt ℂ simpleCritical ((fun _ => w), β)
  critical_base : simpleCritical ((fun _ => w), β) = v₀
  identities : ∀ᶠ q in 𝓝 (((fun _ => w), β) : Parameter r s),
    (reconstructedPolynomial r s family q).derivative =
      C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s (family q).2 ∧
    (reconstructedPolynomial r s family q).eval (sourceRoot q) = 0 ∧
    (reconstructedPolynomial r s family q).derivative.eval (simpleCritical q) = 0
  residual_base_nonzero : (monicPolynomial s (family ((fun _ => w), β)).2).eval w ≠ 0
  residual_base_simple : (monicPolynomial s (family ((fun _ => w), β)).2).derivative.eval v₀ ≠ 0
  source_base_simple : (monicPolynomial r (family ((fun _ => w), β)).1).derivative.eval a₀ ≠ 0
  source_factor_root : ∀ᶠ q in 𝓝 (((fun _ => w), β) : Parameter r s),
    (monicPolynomial r (family q).1).eval (sourceRoot q) = 0
  residual_factor_root : ∀ᶠ q in 𝓝 (((fun _ => w), β) : Parameter r s),
    (monicPolynomial s (family q).2).eval (simpleCritical q) = 0
  root_fiber_invariance : ∀ q q', family q = family q' →
    sourceRoot q = sourceRoot q' ∧ simpleCritical q = simpleCritical q'
  interior_roots : ∀ᶠ q in 𝓝 (((fun _ => w), β) : Parameter r s),
    ∀ z, (monicPolynomial r (family q).1).IsRoot z → ‖z‖ < 1
  permutation_invariance :
    ∀ (σ : Equiv.Perm (Fin r)) (π : Equiv.Perm (Fin (s + 1))) q,
      family (q.1 ∘ σ, q.2 ∘ π) = family q ∧
      sourceRoot (q.1 ∘ σ, q.2 ∘ π) = sourceRoot q ∧
      simpleCritical (q.1 ∘ σ, q.2 ∘ π) = simpleCritical q
  local_uniqueness :
    ∀ᶠ z : Unknown r s × Parameter r s in
      𝓝 (family ((fun _ => w), β), ((fun _ => w), β)),
      (monicPolynomial r z.1.1 * rootPolynomial (s + 1) z.2.2).derivative =
        C (r + s + 1 : ℂ) * rootPolynomial r z.2.1 * monicPolynomial s z.1.2 →
      family z.2 = z.1
  interior_factor_unique :
    ∀ᶠ y : (Fin r → ℂ) × Parameter r s in
      𝓝 ((family ((fun _ => w), β)).1, ((fun _ => w), β)),
      rootPolynomial r y.2.1 ∣
        (monicPolynomial r y.1 * rootPolynomial (s + 1) y.2.2).derivative →
      (family y.2).1 = y.1
  exact_cluster : ∃ ε : ℝ, 0 < ε ∧ ∀ᶠ q in 𝓝 (((fun _ => w), β) : Parameter r s),
    (∀ i : Fin r, q.1 i ∈ Metric.ball w ε) ∧
    (∀ z ∈ Metric.ball w ε,
      (reconstructedPolynomial r s family q).derivative.IsRoot z ↔
        (rootPolynomial r q.1).IsRoot z) ∧
    (∀ i : Fin r,
      (reconstructedPolynomial r s family q).derivative.rootMultiplicity (q.1 i) =
        (rootPolynomial r q.1).rootMultiplicity (q.1 i))
  full_coverage : ∀ (U : Set (Fin r → ℂ)) (V : Set (Fin (s + 1) → ℂ)),
    IsOpen U → (fun _ => w) ∈ U → IsOpen V → β ∈ V →
    ∀ᶠ p in 𝓝 (fun k : Fin (r + (s + 1)) => (A * rootPolynomial (s + 1) β).coeff k),
      ∃ q : Parameter r s, q.1 ∈ U ∧ q.2 ∈ V ∧
        reconstructedPolynomial r s family q = monicPolynomial (r + (s + 1)) p
  diagonal_formula : ∀ᶠ p : ℂ × (Fin (s + 1) → ℂ) in 𝓝 (w, β),
    let q : Parameter r s := ((fun _ => p.1), p.2)
    let f := fun k => (k.factorial : ℂ)⁻¹ *
      iteratedDeriv k (fun y => ((rootPolynomial (s + 1) p.2).eval y)⁻¹) p.1
    f r ≠ 0 ∧ ∀ z : ℂ, (monicPolynomial r (family q).1).eval z =
      (f r)⁻¹ * ∑ k ∈ Finset.range (r + 1), f k * (z - p.1) ^ k

/-- Complete constructive Lemma 5.1. Only original polynomial hypotheses
are inputs. The residual factor, source/critical charts, all pointwise labels,
marked root branches and actual analytic reciprocal Taylor formula are outputs.
The existence of the other critical point derives positivity of the residual
degree, so no extra positive-degree hypothesis is needed. -/
theorem full_reconstruction_from_original_hypotheses (r s : ℕ) (hr : 0 < r)
    (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ)
    (hA : A.Monic) (hAd : A.natDegree = r)
    (hinterior : ∀ z, A.IsRoot z → ‖z‖ < 1) (hboundary : ∀ i, ‖β i‖ = 1)
    (hvalue : (A * rootPolynomial (s + 1) β).eval w ≠ 0)
    (hmult : (A * rootPolynomial (s + 1) β).derivative.rootMultiplicity w = r)
    (haRoot : A.eval a₀ = 0) (haSimple : A.derivative.eval a₀ ≠ 0)
    (hwv : v₀ ≠ w)
    (hvRoot : (A * rootPolynomial (s + 1) β).derivative.eval v₀ = 0)
    (hvSimple : (A * rootPolynomial (s + 1) β).derivative.derivative.eval v₀ ≠ 0) :
    Nonempty (LocalReconstructionResult r s A β w a₀ v₀) := by
  obtain ⟨x, hxA, hxM, hxC, hM, hvalue', hU, hcop, hid⟩ :=
    original_configuration_supplies_reconstruction_inputs r s A β w hA hAd hvalue
      hmult hinterior hboundary
  have hvr := residual_simple_root_of_derivative (A * rootPolynomial (s + 1) β)
    (monicPolynomial s x.1.2) r s w v₀ hwv
    (by simpa only [hxA, hxM, hxC] using hid) hvRoot hvSimple
  have hs : 0 < s := by
    have hh : 0 < (monicPolynomial s x.1.2).natDegree :=
      natDegree_pos_of_monic_of_aeval_eq_zero (monicPolynomial_monic _ _)
        (show aeval v₀ (monicPolynomial s x.1.2) = 0 from hvr.1)
    simpa only [monicPolynomial_natDegree] using hh
  obtain ⟨R, hR, hR0, hRidentity, hRperm, hRunique, hRcoverage⟩ :=
    labelled_chart_with_full_coverage r s hr hs x β w hxC hxM hM hvalue' hU hcop hid
  obtain ⟨za, hza, hza0, hzaroot, _, hzaFiber⟩ :=
    source_factor_simple_root r s R ((fun _ => w), β) a₀ hR
      (by simpa only [hR0, hxA] using haRoot)
      (by simpa only [hR0, hxA] using haSimple)
  obtain ⟨zv, hzv, hzv0, hzvroot, _, hzvFiber⟩ :=
    residual_factor_simple_root r s R ((fun _ => w), β) v₀ hR
      (by simpa only [hR0] using hvr.1)
      (by simpa only [hR0] using hvr.2) hRidentity
  refine ⟨{
    family := R
    sourceRoot := za
    simpleCritical := zv
    family_analytic := hR
    family_base := ?_
    source_analytic := hza
    source_base := hza0
    critical_analytic := hzv
    critical_base := hzv0
    identities := ?_
    residual_base_nonzero := by simpa only [hR0] using hU
    residual_base_simple := by simpa only [hR0] using hvr.2
    source_base_simple := by simpa only [hR0, hxA] using haSimple
    source_factor_root := ?_
    residual_factor_root := ?_
    root_fiber_invariance := ?_
    interior_roots := ?_
    permutation_invariance := ?_
    local_uniqueness := ?_
    interior_factor_unique := ?_
    exact_cluster := ?_
    full_coverage := ?_
    diagonal_formula := ?_ }⟩
  · simpa only [hR0] using hxA
  · filter_upwards [hRidentity, hzaroot, hzvroot] with q hp ha hv
    exact ⟨hp, ha.2, hv.2⟩
  · filter_upwards [hzaroot] with q hq using hq.1
  · filter_upwards [hzvroot] with q hq using hq.1
  · intro q q' hq
    exact ⟨hzaFiber q q' hq, hzvFiber q q' hq⟩
  · apply PolynomialGeometry.RootMargins.interior_roots_persist r (fun q => (R q).1)
      ((fun _ => w), β) hR.continuousAt.fst
    simpa only [hR0, hxA] using hinterior
  · intro σ π q
    exact ⟨hRperm σ π q, hzaFiber _ _ (hRperm σ π q), hzvFiber _ _ (hRperm σ π q)⟩
  · simpa only [hR0] using hRunique
  · simpa only [hR0] using interior_factor_unique_from_divisibility r s hr hs x β w R
      hxC hxM hU hid hRunique
  · exact exact_cluster_from_chart r s R β w hR (by simpa only [hR0] using hU) hRidentity
  · intro U V hUo hw hVo hβ
    have hc := hRcoverage U V hUo hw hVo hβ
    have hb : factorCoefficientMap r (s + 1) (x.1.1, x.2.2) =
        (fun k : Fin (r + (s + 1)) => (A * rootPolynomial (s + 1) β).coeff k) := by
      ext k
      simp only [factorCoefficientMap, hxA, hxM]
    simpa only [hb] using hc
  · exact diagonal_formula_on_chart r s R β w (by simpa only [hxM] using hM) hRidentity

end PolynomialGeometry.ReconstructionCompletion
