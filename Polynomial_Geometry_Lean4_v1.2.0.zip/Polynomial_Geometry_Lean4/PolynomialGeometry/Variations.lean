import Mathlib.Analysis.Calculus.FDeriv.Analytic
import Mathlib.Analysis.Calculus.InverseFunctionTheorem.FDeriv
import Mathlib.Topology.Algebra.Module.FiniteDimension
import Mathlib.Analysis.Calculus.FDeriv.Basic
import Mathlib.Analysis.Calculus.FDeriv.Prod
import Mathlib.Analysis.InnerProductSpace.Basic
import Mathlib.Analysis.Normed.Group.Constructions
import Mathlib.Algebra.Polynomial.FieldDivision
import Mathlib.Algebra.Polynomial.Taylor
import Mathlib.Data.Finset.Max
import Mathlib.RingTheory.Polynomial.Basic
import Mathlib.LinearAlgebra.FiniteDimensional.Basic
import Mathlib.Algebra.Polynomial.AlgebraMap
import Mathlib.Tactic

/-!
# Exact components of admissible spectral variation

This file proves the finite minimum penalty and the balancing mechanism used in
Theorem 5.3, together with exact quadratic and quartic partial-maximization
identities used in Lemma 5.5.  The local polynomial chart is not assumed as an
opaque structure, and these components are not claimed to construct that chart.
-/

noncomputable section

namespace PolynomialGeometry.Variations

open scoped BigOperators Topology
open Filter Finset

section Balancing

variable {ι : Type*} [Fintype ι]

/-- The minimum of zero and all active real logarithmic ratios. -/
def minZero (x : ι → ℝ) : ℝ :=
  (insert 0 (Finset.univ.image x)).min' (by simp)

theorem minZero_le_zero (x : ι → ℝ) : minZero x ≤ 0 := by
  classical
  exact Finset.min'_le _ _ (by simp)

theorem minZero_le_apply (x : ι → ℝ) (i : ι) : minZero x ≤ x i := by
  classical
  exact Finset.min'_le _ _ (by simp)

@[simp] theorem minZero_zero : minZero (0 : ι → ℝ) = 0 := by
  classical
  apply le_antisymm (minZero_le_zero _)
  unfold minZero
  apply Finset.le_min'
  intro y hy
  rcases Finset.mem_insert.mp hy with h | h
  · exact h ▸ le_rfl
  · obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp h
    exact le_rfl

variable [Nonempty ι]

/-- The exact nonsmooth penalty in equation (5.14), with its sign reversed. -/
def penalty (τ : ℝ) (x : ι → ℝ) : ℝ :=
  (τ / Fintype.card ι) * (∑ i, x i) - minZero x

def balancingConstant (τ : ℝ) : ℝ := min (1 - τ) (τ / Fintype.card ι)

theorem balancingConstant_pos {τ : ℝ} (hτ : 0 < τ) (hτ1 : τ < 1) :
    0 < balancingConstant (ι := ι) τ := by
  have hn : (0 : ℝ) < Fintype.card ι := by
    exact_mod_cast Fintype.card_pos
  exact lt_min (sub_pos.mpr hτ1) (div_pos hτ hn)

theorem penalty_decomposition (τ : ℝ) (x : ι → ℝ) :
    penalty τ x = (1 - τ) * (-minZero x) +
      (τ / Fintype.card ι) * ∑ i, (x i - minZero x) := by
  have hn : (Fintype.card ι : ℝ) ≠ 0 := by
    exact_mod_cast (Fintype.card_ne_zero : Fintype.card ι ≠ 0)
  simp only [penalty, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ,
    nsmul_eq_mul]
  field_simp
  ring

theorem penalty_nonneg {τ : ℝ} (hτ : 0 ≤ τ) (hτ1 : τ ≤ 1) (x : ι → ℝ) :
    0 ≤ penalty τ x := by
  rw [penalty_decomposition]
  exact add_nonneg
    (mul_nonneg (sub_nonneg.mpr hτ1) (neg_nonneg.mpr (minZero_le_zero x)))
    (mul_nonneg (div_nonneg hτ (Nat.cast_nonneg _))
      (Finset.sum_nonneg fun i _ => sub_nonneg.mpr (minZero_le_apply x i)))

/-- The kink dominates every active coordinate with one uniform constant. -/
theorem penalty_ge_coordinate {τ : ℝ} (hτ : 0 < τ) (hτ1 : τ < 1)
    (x : ι → ℝ) (j : ι) :
    balancingConstant (ι := ι) τ * |x j| ≤ penalty τ x := by
  let c := balancingConstant (ι := ι) τ
  let k := τ / (Fintype.card ι : ℝ)
  let m := minZero x
  have hc : 0 ≤ c := (balancingConstant_pos hτ hτ1).le
  have hck : c ≤ k := min_le_right _ _
  have hcτ : c ≤ 1 - τ := min_le_left _ _
  have hk : 0 ≤ k := div_nonneg hτ.le (Nat.cast_nonneg _)
  have hm : m ≤ 0 := minZero_le_zero x
  have hxi : ∀ i, 0 ≤ x i - m := fun i => sub_nonneg.mpr (minZero_le_apply x i)
  have hsum : x j - m ≤ ∑ i, (x i - m) :=
    Finset.single_le_sum (fun i _ => hxi i) (Finset.mem_univ j)
  have hsum0 : 0 ≤ ∑ i, (x i - m) := Finset.sum_nonneg fun i _ => hxi i
  rw [penalty_decomposition]
  change c * |x j| ≤ (1 - τ) * (-m) + k * ∑ i, (x i - m)
  by_cases hj : 0 ≤ x j
  · rw [abs_of_nonneg hj]
    have h1 : c * x j ≤ c * (x j - m) := mul_le_mul_of_nonneg_left (by linarith) hc
    have h2 : c * (x j - m) ≤ k * (x j - m) := mul_le_mul_of_nonneg_right hck (hxi j)
    have h3 : k * (x j - m) ≤ k * ∑ i, (x i - m) := mul_le_mul_of_nonneg_left hsum hk
    have h4 : 0 ≤ (1 - τ) * (-m) := mul_nonneg (by linarith) (by linarith)
    linarith
  · have hj' : x j ≤ 0 := (lt_of_not_ge hj).le
    rw [abs_of_nonpos hj']
    have h1 : -x j ≤ -m := neg_le_neg (minZero_le_apply x j)
    have h2 : c * (-x j) ≤ c * (-m) := mul_le_mul_of_nonneg_left h1 hc
    have h3 : c * (-m) ≤ (1 - τ) * (-m) := mul_le_mul_of_nonneg_right hcτ (by linarith)
    have h4 : 0 ≤ k * ∑ i, (x i - m) := mul_nonneg hk hsum0
    linarith

/-- The quantitative finite-dimensional lower bound used in Theorem 5.3. -/
theorem penalty_ge_norm {τ : ℝ} (hτ : 0 < τ) (hτ1 : τ < 1) (x : ι → ℝ) :
    balancingConstant (ι := ι) τ * ‖x‖ ≤ penalty τ x := by
  have hc := balancingConstant_pos (ι := ι) hτ hτ1
  have hp := penalty_nonneg hτ.le hτ1.le x
  have hnorm : ‖x‖ ≤ penalty τ x / balancingConstant (ι := ι) τ := by
    apply (pi_norm_le_iff_of_nonneg (div_nonneg hp hc.le)).mpr
    intro j
    rw [Real.norm_eq_abs]
    apply (le_div_iff₀ hc).mpr
    simpa [mul_comm] using penalty_ge_coordinate hτ hτ1 x j
  simpa [mul_comm] using (le_div_iff₀ hc).mp hnorm

omit [Nonempty ι] in
@[simp] theorem penalty_zero (τ : ℝ) : penalty τ (0 : ι → ℝ) = 0 := by
  simp [penalty]

/-- A small smooth change cannot oppose the exact active-distance penalty. -/
theorem balancing_improvement {τ : ℝ} (hτ : 0 < τ) (hτ1 : τ < 1)
    (f : (ι → ℝ) → ℝ) (x : ι → ℝ)
    (hf : |f x - f 0| ≤ (balancingConstant (ι := ι) τ / 2) * ‖x‖) :
    f x + minZero x - (τ / Fintype.card ι) * (∑ i, x i) ≤
      f 0 - (balancingConstant (ι := ι) τ / 2) * ‖x‖ := by
  have h := penalty_ge_norm hτ hτ1 x
  have hfx := (abs_le.mp hf).2
  unfold penalty at h
  linarith

theorem balancing_strict_improvement {τ : ℝ} (hτ : 0 < τ) (hτ1 : τ < 1)
    (f : (ι → ℝ) → ℝ) {x : ι → ℝ} (hx : x ≠ 0)
    (hf : |f x - f 0| ≤ (balancingConstant (ι := ι) τ / 2) * ‖x‖) :
    f x + minZero x - (τ / Fintype.card ι) * (∑ i, x i) < f 0 := by
  have h := balancing_improvement hτ hτ1 f x hf
  have hc := balancingConstant_pos (ι := ι) hτ hτ1
  have hxnorm := norm_pos_iff.mpr hx
  have : 0 < (balancingConstant (ι := ι) τ / 2) * ‖x‖ := mul_pos (by linarith) hxnorm
  linarith

/-- A zero derivative supplies the required small-error bound locally.
This proves the balancing step on any already constructed coordinate slice. -/
theorem local_balancing_of_zero_derivative {τ : ℝ} (hτ : 0 < τ) (hτ1 : τ < 1)
    {f : (ι → ℝ) → ℝ} (hf : HasFDerivAt f (0 : (ι → ℝ) →L[ℝ] ℝ) 0) :
    ∀ᶠ x in 𝓝 (0 : ι → ℝ),
      f x + minZero x - (τ / Fintype.card ι) * (∑ i, x i) ≤
        f 0 - (balancingConstant (ι := ι) τ / 2) * ‖x‖ := by
  have hc : 0 < balancingConstant (ι := ι) τ / 2 :=
    half_pos (balancingConstant_pos hτ hτ1)
  have hb := hf.isLittleO.bound hc
  filter_upwards [hb] with x hx
  apply balancing_improvement hτ hτ1 f x
  simpa using hx

/-- Uniform balancing with auxiliary coordinates. Strict differentiability
gives the small remainder simultaneously for the original and balanced
points, even while the auxiliary parameters vary. -/
theorem local_uniform_balancing
    {V : Type*} [NormedAddCommGroup V] [NormedSpace ℝ V]
    {τ : ℝ} (hτ : 0 < τ) (hτ1 : τ < 1)
    {F : ((ι → ℝ) × V) → ℝ} {L : ((ι → ℝ) × V) →L[ℝ] ℝ}
    (hF : HasStrictFDerivAt F L 0) (hL : ∀ x : ι → ℝ, L (x, 0) = 0) :
    ∀ᶠ p in 𝓝 (0 : (ι → ℝ) × V),
      F p + minZero p.1 - (τ / Fintype.card ι) * (∑ i, p.1 i) ≤
        F (0, p.2) - (balancingConstant (ι := ι) τ / 2) * ‖p.1‖ := by
  let φ : ((ι → ℝ) × V) → (((ι → ℝ) × V) × ((ι → ℝ) × V)) :=
    fun p => (p, (0, p.2))
  have hφ : Continuous φ := by fun_prop
  have ht : Tendsto φ (𝓝 0) (𝓝 (0, 0)) := by
    simpa [φ] using hφ.continuousAt.tendsto (x := (0 : (ι → ℝ) × V))
  have hc : 0 < balancingConstant (ι := ι) τ / 2 :=
    half_pos (balancingConstant_pos hτ hτ1)
  have hb := ht.eventually (hF.isLittleO.bound hc)
  filter_upwards [hb] with p hp
  have hdiff : p - (0, p.2) = (p.1, 0) := by ext <;> simp
  have hLP : L (p - (0, p.2)) = 0 := by rw [hdiff, hL]
  apply balancing_improvement hτ hτ1 (fun x => F (x, p.2)) p.1
  simpa [φ, hLP, hdiff, hL, Prod.norm_def] using hp

end Balancing

section PartialMaximization

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

local notation "⟪" x ", " y "⟫" => inner ℝ x y

/-- A quadratic slice with a positive eliminated Hessian. -/
def quadraticSlice (P : E →ₗ[ℝ] E) (b : ℝ) (t s : E) : ℝ :=
  b + ⟪t, s⟫ - (1 / 2 : ℝ) * ⟪s, P s⟫

theorem quadratic_complete_square (P : E →ₗ[ℝ] E) (b : ℝ) (t θ s : E)
    (hP : ∀ x y, ⟪x, P y⟫ = ⟪P x, y⟫) (hθ : P θ = t) :
    quadraticSlice P b t s = quadraticSlice P b t θ -
      (1 / 2 : ℝ) * ⟪s - θ, P (s - θ)⟫ := by
  unfold quadraticSlice
  rw [map_sub, inner_sub_left, inner_sub_right, inner_sub_right]
  have hcross : ⟪θ, P s⟫ = ⟪t, s⟫ := by rw [hP, hθ]
  rw [hθ, hcross, real_inner_comm s t]
  rw [real_inner_comm t θ]
  ring

theorem quadratic_partial_maximum (P : E →ₗ[ℝ] E) (b : ℝ) (t θ s : E)
    (hP : ∀ x y, ⟪x, P y⟫ = ⟪P x, y⟫) (hθ : P θ = t)
    (hpos : ∀ x, 0 ≤ ⟪x, P x⟫) :
    quadraticSlice P b t s ≤ quadraticSlice P b t θ := by
  rw [quadratic_complete_square P b t θ s hP hθ]
  have := hpos (s - θ)
  linarith

theorem quadratic_partial_maximum_strict (P : E →ₗ[ℝ] E) (b : ℝ) (t θ s : E)
    (hP : ∀ x y, ⟪x, P y⟫ = ⟪P x, y⟫) (hθ : P θ = t)
    (hpos : ∀ x, x ≠ 0 → 0 < ⟪x, P x⟫) (hs : s ≠ θ) :
    quadraticSlice P b t s < quadraticSlice P b t θ := by
  rw [quadratic_complete_square P b t θ s hP hθ]
  have := hpos (s - θ) (sub_ne_zero.mpr hs)
  linarith

/-- Exact value of the quartic-order response term when `P θ = t`. -/
theorem compensated_quartic_identity (P : E →ₗ[ℝ] E) (t θ : E) (hθ : P θ = t) :
    -(1 / 2 : ℝ) * ⟪(1 / 2 : ℝ) • θ, P ((1 / 2 : ℝ) • θ)⟫ +
      (1 / 2 : ℝ) * ⟪t, (1 / 2 : ℝ) • θ⟫ = (1 / 8 : ℝ) * ⟪t, θ⟫ := by
  rw [map_smul, hθ, real_inner_smul_left, real_inner_smul_right, real_inner_smul_right,
    real_inner_comm θ t]
  ring

end PartialMaximization

section PedagogicalModel

def quarticModel (γ x s : ℝ) : ℝ := -x ^ 4 + γ * x ^ 2 * s - s ^ 2 / 2

theorem quarticModel_complete_square (γ x s : ℝ) :
    quarticModel γ x s = (-1 + γ ^ 2 / 2) * x ^ 4 - (s - γ * x ^ 2) ^ 2 / 2 := by
  unfold quarticModel
  ring

theorem quarticModel_optimum (γ x : ℝ) :
    quarticModel γ x (γ * x ^ 2) = (-1 + γ ^ 2 / 2) * x ^ 4 := by
  rw [quarticModel_complete_square]
  ring

theorem quarticModel_le_optimum (γ x s : ℝ) :
    quarticModel γ x s ≤ quarticModel γ x (γ * x ^ 2) := by
  rw [quarticModel_complete_square, quarticModel_optimum]
  nlinarith [sq_nonneg (s - γ * x ^ 2)]

theorem quarticModel_fixed_negative (γ x : ℝ) (hx : x ≠ 0) :
    quarticModel γ x 0 < 0 := by
  have h4 : 0 < x ^ 4 := by simpa [← pow_mul] using pow_pos (sq_pos_of_ne_zero hx) 2
  simpa [quarticModel] using neg_neg_of_pos h4

theorem quarticModel_response_positive {γ x : ℝ} (hγ : 2 < γ ^ 2) (hx : x ≠ 0) :
    0 < quarticModel γ x (γ * x ^ 2) := by
  rw [quarticModel_optimum]
  have h4 : 0 < x ^ 4 := by simpa [← pow_mul] using pow_pos (sq_pos_of_ne_zero hx) 2
  exact mul_pos (by linarith) h4

end PedagogicalModel

section CopySymmetry

variable {ι : Type*} [Fintype ι] [Nonempty ι]

/-- A permutation-invariant linear functional has no centered-copy
component. This proves the algebraic symmetry mechanism in Proposition 5.4. -/
theorem invariant_linear_vanishes_centered (L : (ι → ℝ) →ₗ[ℝ] ℝ)
    (hperm : ∀ (σ : Equiv.Perm ι) x, L (x ∘ σ) = L x)
    (x : ι → ℝ) (hx : ∑ i, x i = 0) : L x = 0 := by
  classical
  let e : ι → ι → ℝ := fun i j => if i = j then 1 else 0
  let i₀ : ι := Classical.arbitrary ι
  have hc (i : ι) : L (e i) = L (e i₀) := by
    have he : e i ∘ Equiv.swap i i₀ = e i₀ := by
      ext k
      by_cases hk : k = i
      · subst k
        simp [e, eq_comm]
      · by_cases hk' : k = i₀
        · subst k
          simp [e]
        · simp [e, Equiv.swap_apply_def, hk, hk', Ne.symm hk,
            Ne.symm hk']
    have hh := hperm (Equiv.swap i i₀) (e i)
    rw [he] at hh
    exact hh.symm
  calc
    L x = L (∑ i, x i • e i) := congrArg L (pi_eq_sum_univ x)
    _ = ∑ i, x i * L (e i₀) := by simp [hc]
    _ = (∑ i, x i) * L (e i₀) := (Finset.sum_mul ..).symm
    _ = 0 := by rw [hx, zero_mul]

/-- Independent permutation symmetry in one block annihilates every
mixed bilinear term containing a centered vector from that block. -/
theorem invariant_bilinear_vanishes_centered {E : Type*}
    [AddCommMonoid E] [Module ℝ E]
    (B : (ι → ℝ) →ₗ[ℝ] E →ₗ[ℝ] ℝ)
    (hperm : ∀ (σ : Equiv.Perm ι) x y, B (x ∘ σ) y = B x y)
    (x : ι → ℝ) (hx : ∑ i, x i = 0) (y : E) : B x y = 0 :=
  invariant_linear_vanishes_centered (B.flip y) (fun σ z => hperm σ z y) x hx

omit [Nonempty ι] in
/-- The common-diagonal/common-off-diagonal form of an exchangeable
Hessian has an exact scalar restriction to the centered subspace. -/
theorem exchangeable_quadratic_identity [DecidableEq ι] (d e : ℝ) (x : ι → ℝ) :
    (∑ i, ∑ j, x i * (if i = j then d else e) * x j) =
      (d - e) * (∑ i, (x i) ^ 2) + e * (∑ i, x i) ^ 2 := by
  have hrow (i : ι) : (∑ j, x i * (if i = j then d else e) * x j) =
      (d - e) * (x i) ^ 2 + e * x i * (∑ j, x j) := by
    calc
      (∑ j, x i * (if i = j then d else e) * x j) =
          ∑ j, ((if i = j then (d - e) * (x i) ^ 2 else 0) + e * x i * x j) := by
        apply Finset.sum_congr rfl
        intro j _
        by_cases h : i = j
        · subst j
          simp only [if_true]
          ring
        · simp only [h, if_false, zero_add]
          ring
      _ = (d - e) * (x i) ^ 2 + e * x i * (∑ j, x j) := by
        simp [Finset.sum_add_distrib, ← Finset.mul_sum]
  simp_rw [hrow]
  rw [Finset.sum_add_distrib, Finset.mul_sum]
  congr 1
  rw [← Finset.sum_mul, ← Finset.mul_sum]
  ring

omit [Nonempty ι] in
theorem exchangeable_quadratic_centered [DecidableEq ι]
    (d e : ℝ) (x : ι → ℝ) (hx : ∑ i, x i = 0) :
    (∑ i, ∑ j, x i * (if i = j then d else e) * x j) =
      (d - e) * (∑ i, (x i) ^ 2) := by
  rw [exchangeable_quadratic_identity, hx]
  ring

end CopySymmetry

section CenteredCollective

variable {ι : Type*} [Fintype ι] [Nonempty ι]

/-- Average of a labelled copy block. -/
def copyMean (x : ι → ℂ) : ℂ := (∑ i, x i) / Fintype.card ι

@[simp] theorem copyMean_const (c : ℂ) : copyMean (fun _ : ι => c) = c := by
  have hn : (Fintype.card ι : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  simp [copyMean, hn]

omit [Nonempty ι] in
@[simp] theorem copyMean_add (x y : ι → ℂ) :
    copyMean (x + y) = copyMean x + copyMean y := by
  simp [copyMean, Finset.sum_add_distrib, add_div]

omit [Nonempty ι] in
@[simp] theorem copyMean_smul (c : ℂ) (x : ι → ℂ) :
    copyMean (c • x) = c * copyMean x := by
  simp [copyMean, ← Finset.mul_sum, mul_div_assoc]

/-- The exact centered/collective derivative from Lemma 5.2: the
centered space has multiplier `κ`, and the common-shift line has `μ`. -/
def centeredCollectiveMap (κ μ : ℂ) : (ι → ℂ) →ₗ[ℂ] (ι → ℂ) where
  toFun x i := κ * (x i - copyMean x) + μ * copyMean x
  map_add' x y := by
    ext i
    simp only [Pi.add_apply, copyMean_add]
    ring
  map_smul' c x := by
    ext i
    simp only [Pi.smul_apply, smul_eq_mul, copyMean_smul, RingHom.id_apply]
    ring

theorem copyMean_centeredCollectiveMap (κ μ : ℂ) (x : ι → ℂ) :
    copyMean (centeredCollectiveMap κ μ x) = μ * copyMean x := by
  have he : centeredCollectiveMap κ μ x =
      κ • x + (fun _ : ι => (μ - κ) * copyMean x) := by
    ext i
    simp only [centeredCollectiveMap, LinearMap.coe_mk, AddHom.coe_mk,
      Pi.add_apply, Pi.smul_apply, smul_eq_mul]
    ring
  rw [he, copyMean_add, copyMean_smul, copyMean_const]
  ring

/-- The two nonzero mode multipliers give an explicit inverse, without
any matrix or dimension-counting hypothesis. -/
theorem centeredCollectiveMap_inverse (κ μ : ℂ) (hκ : κ ≠ 0) (hμ : μ ≠ 0)
    (x : ι → ℂ) :
    centeredCollectiveMap κ⁻¹ μ⁻¹ (centeredCollectiveMap κ μ x) = x := by
  ext i
  change κ⁻¹ * ((κ * (x i - copyMean x) + μ * copyMean x) -
    copyMean (centeredCollectiveMap κ μ x)) +
    μ⁻¹ * copyMean (centeredCollectiveMap κ μ x) = x i
  rw [copyMean_centeredCollectiveMap]
  field_simp
  ring

theorem centeredCollectiveMap_bijective (κ μ : ℂ) (hκ : κ ≠ 0) (hμ : μ ≠ 0) :
    Function.Bijective (centeredCollectiveMap κ μ : (ι → ℂ) →ₗ[ℂ] (ι → ℂ)) := by
  refine ⟨?_, ?_⟩
  · exact Function.LeftInverse.injective (centeredCollectiveMap_inverse κ μ hκ hμ)
  · intro y
    refine ⟨centeredCollectiveMap κ⁻¹ μ⁻¹ y, ?_⟩
    simpa using centeredCollectiveMap_inverse κ⁻¹ μ⁻¹ (inv_ne_zero hκ) (inv_ne_zero hμ) y

end CenteredCollective

section PolynomialJets

open Polynomial

variable {K : Type*} [Field K]

/-- A derivative zero of order at least `r` gives a constant jet through
degree `r`. This is the first exact algebraic step of Lemma 5.1. -/
theorem derivative_divisibility_constant_jet [CharZero K] (p : K[X]) (w : K) (r : ℕ)
    (h : (X - C w) ^ r ∣ p.derivative) :
    (X - C w) ^ (r + 1) ∣ p - C (p.eval w) := by
  by_cases hp' : p.derivative = 0
  · have hp := Polynomial.eq_C_of_derivative_eq_zero hp'
    rw [hp]
    simp
  let q := p - C (p.eval w)
  have hq' : q.derivative = p.derivative := by simp [q]
  have hqne : q ≠ 0 := by
    intro heq
    apply hp'
    rw [← hq', heq]
    simp
  have hqroot : q.IsRoot w := by simp [q, Polynomial.IsRoot]
  have hmult : r ≤ p.derivative.rootMultiplicity w :=
    (Polynomial.le_rootMultiplicity_iff hp').mpr h
  have hqm : q.derivative.rootMultiplicity w = q.rootMultiplicity w - 1 :=
    Polynomial.derivative_rootMultiplicity_of_root hqroot
  have hqpos : 0 < q.rootMultiplicity w :=
    (Polynomial.rootMultiplicity_pos hqne).mpr hqroot
  have hrl : r + 1 ≤ q.rootMultiplicity w := by
    rw [hq'] at hqm
    omega
  exact (Polynomial.le_rootMultiplicity_iff hqne).mp hrl

/-- A source factor nonzero at the critical point is coprime to every
power of the critical linear factor. -/
theorem critical_power_coprime (M : K[X]) (w : K) (r : ℕ) (hM : M.eval w ≠ 0) :
    IsCoprime ((X - C w) ^ r) M := by
  have hndvd : ¬ X - C w ∣ M := by
    simpa [Polynomial.dvd_iff_isRoot, Polynomial.IsRoot] using hM
  exact ((Polynomial.irreducible_X_sub_C w).coprime_iff_not_dvd.mpr hndvd).pow_left

/-- The square tangent map in the Taylor reconstruction has trivial
kernel. No local chart or inverse map is assumed in this assertion. -/
theorem polynomial_jet_kernel_trivial (A M Q : K[X]) (w : K) (r : ℕ)
    (hA : A.Monic) (hdegA : A.natDegree = r) (hdegQ : Q.natDegree < r)
    (hM : M.eval w ≠ 0) (hvalue : (A * M).eval w ≠ 0)
    (hjetA : (X - C w) ^ (r + 1) ∣ A * M - C ((A * M).eval w))
    (hjetQ : (X - C w) ^ (r + 1) ∣ Q * M - C ((Q * M).eval w)) :
    Q = 0 := by
  let ca := (A * M).eval w
  let cq := (Q * M).eval w
  let R := C ca * Q - C cq * A
  have hprod : (X - C w) ^ (r + 1) ∣ R * M := by
    have hlin := dvd_sub (hjetQ.mul_left (C ca)) (hjetA.mul_left (C cq))
    convert hlin using 1
    dsimp [R, ca, cq]
    ring
  have hdiv : (X - C w) ^ (r + 1) ∣ R :=
    (critical_power_coprime M w (r + 1) hM).dvd_of_dvd_mul_right hprod
  have hRdeg : R.natDegree ≤ r := by
    apply (Polynomial.natDegree_sub_le _ _).trans
    apply max_le
    · exact (Polynomial.natDegree_C_mul_le ca Q).trans hdegQ.le
    · exact (Polynomial.natDegree_C_mul_le cq A).trans hdegA.le
  have hRzero : R = 0 := by
    apply Polynomial.eq_zero_of_dvd_of_natDegree_lt hdiv
    simp only [Polynomial.natDegree_pow, Polynomial.natDegree_X_sub_C, mul_one]
    omega
  have hcoeff := congrArg (fun p : K[X] => p.coeff r) hRzero
  have hAcoeff : A.coeff r = 1 := by simpa [hdegA] using hA.coeff_natDegree
  have hQcoeff : Q.coeff r = 0 := Polynomial.coeff_eq_zero_of_natDegree_lt hdegQ
  have hcq : cq = 0 := by
    simpa [R, Polynomial.coeff_sub, Polynomial.coeff_C_mul, hAcoeff, hQcoeff] using hcoeff
  have hCQ : C ca * Q = 0 := by simpa [R, hcq] using hRzero
  exact (mul_eq_zero.mp hCQ).resolve_left (Polynomial.C_ne_zero.mpr hvalue)

/-- The same kernel assertion stated directly through derivative
divisibility, as needed by the critical-factor coefficient map. -/
theorem polynomial_derivative_jet_kernel [CharZero K] (A M Q : K[X]) (w : K) (r : ℕ)
    (hA : A.Monic) (hdegA : A.natDegree = r) (hdegQ : Q.natDegree < r)
    (hM : M.eval w ≠ 0) (hvalue : (A * M).eval w ≠ 0)
    (hA' : (X - C w) ^ r ∣ (A * M).derivative)
    (hQ' : (X - C w) ^ r ∣ (Q * M).derivative) : Q = 0 :=
  polynomial_jet_kernel_trivial A M Q w r hA hdegA hdegQ hM hvalue
    (derivative_divisibility_constant_jet (A * M) w r hA')
    (derivative_divisibility_constant_jet (Q * M) w r hQ')


/-- The actual square linear map of low Taylor coefficients of `(QM)'`,
with the coefficients of the lower-degree tangent polynomial as inputs. -/
def derivativeJetMap (M : K[X]) (w : K) (r : ℕ) :
    (Fin r → K) →ₗ[K] (Fin r → K) where
  toFun a i := (taylor w
    ((((degreeLTEquiv K r).symm a : degreeLT K r) : K[X]) * M).derivative).coeff i
  map_add' a b := by
    ext i
    simp [add_mul]
  map_smul' c a := by
    ext i
    simp [mul_add]

/-- Zero output of the square jet map is exactly the required derivative
multiplicity condition. -/
theorem derivativeJetMap_eq_zero_iff (M : K[X]) (w : K) (r : ℕ) (a : Fin r → K) :
    derivativeJetMap M w r a = 0 ↔
      (X - C w) ^ r ∣
        ((((degreeLTEquiv K r).symm a : degreeLT K r) : K[X]) * M).derivative := by
  rw [X_sub_C_pow_dvd_iff, X_pow_dvd_iff]
  constructor
  · intro h d hd
    have hi := congrFun h ⟨d, hd⟩
    simpa [derivativeJetMap, taylor_apply] using hi
  · intro h
    ext i
    exact h i i.isLt

/-- Polynomial compatibility forces the square Taylor-coefficient map to
be invertible. This establishes the algebraic full-rank assertion underlying
Lemma 5.1; construction of the holomorphic local inverse is separate. -/
theorem derivativeJetMap_bijective [CharZero K] (A M : K[X]) (w : K) (r : ℕ)
    (hA : A.Monic) (hdegA : A.natDegree = r)
    (hM : M.eval w ≠ 0) (hvalue : (A * M).eval w ≠ 0)
    (hA' : (X - C w) ^ r ∣ (A * M).derivative) :
    Function.Bijective (derivativeJetMap M w r) := by
  have hinj : Function.Injective (derivativeJetMap M w r) := by
    apply LinearMap.ker_eq_bot.mp
    apply LinearMap.ker_eq_bot'.mpr
    intro a ha
    let q := (degreeLTEquiv K r).symm a
    have hqzero : (q : K[X]) = 0 := by
      by_cases hq : (q : K[X]) = 0
      · exact hq
      apply polynomial_derivative_jet_kernel A M q w r hA hdegA
      · exact (natDegree_lt_iff_degree_lt hq).mpr (mem_degreeLT.mp q.property)
      · exact hM
      · exact hvalue
      · exact hA'
      · exact (derivativeJetMap_eq_zero_iff M w r a).mp ha
    apply (degreeLTEquiv K r).symm.injective
    apply Subtype.ext
    simpa [q] using hqzero
  exact ⟨hinj, LinearMap.injective_iff_surjective.mp hinj⟩


/-- The full-rank jet map has a continuous linear inverse over `ℂ`, so
its prescribed-jet reconstruction is holomorphic on the entire coefficient
space. This is a fixed-factor jet reconstruction, not the moving-cluster chart. -/
theorem analytic_prescribed_jet_reconstruction (A M : ℂ[X]) (w : ℂ) (r : ℕ)
    (hA : A.Monic) (hdegA : A.natDegree = r)
    (hM : M.eval w ≠ 0) (hvalue : (A * M).eval w ≠ 0)
    (hA' : (X - C w) ^ r ∣ (A * M).derivative) :
    ∃ R : (Fin r → ℂ) → (Fin r → ℂ),
      AnalyticOnNhd ℂ R Set.univ ∧
      (∀ j, derivativeJetMap M w r (R j) = j) ∧
      (∀ a, R (derivativeJetMap M w r a) = a) := by
  let e := (LinearEquiv.ofBijective (derivativeJetMap M w r)
    (derivativeJetMap_bijective A M w r hA hdegA hM hvalue hA')).toContinuousLinearEquiv
  refine ⟨e.symm, e.symm.toContinuousLinearMap.analyticOnNhd Set.univ, ?_, ?_⟩
  · intro j
    exact e.apply_symm_apply j
  · intro a
    exact e.symm_apply_apply a

/-- An analytic coefficient map whose derivative is the computed square
jet map admits a holomorphic local inverse. The polynomial constraints supply
invertibility; no inverse or local chart is among the hypotheses. This is an
inverse criterion, not a construction of the moving critical-factor map. -/
theorem analytic_local_inverse_of_polynomial_jacobian
    (A M : ℂ[X]) (w : ℂ) (r : ℕ)
    (hA : A.Monic) (hdegA : A.natDegree = r)
    (hM : M.eval w ≠ 0) (hvalue : (A * M).eval w ≠ 0)
    (hA' : (X - C w) ^ r ∣ (A * M).derivative)
    (F : (Fin r → ℂ) → (Fin r → ℂ)) (a₀ : Fin r → ℂ)
    (hF : AnalyticAt ℂ F a₀)
    (hD : (fderiv ℂ F a₀ : (Fin r → ℂ) →ₗ[ℂ] (Fin r → ℂ)) =
      derivativeJetMap M w r) :
    ∃ G : (Fin r → ℂ) → (Fin r → ℂ),
      AnalyticAt ℂ G (F a₀) ∧ G (F a₀) = a₀ ∧
      (∀ᶠ a in 𝓝 a₀, G (F a) = a) ∧
      (∀ᶠ j in 𝓝 (F a₀), F (G j) = j) := by
  let e := (LinearEquiv.ofBijective (derivativeJetMap M w r)
    (derivativeJetMap_bijective A M w r hA hdegA hM hvalue hA')).toContinuousLinearEquiv
  have hde : fderiv ℂ F a₀ = (e : (Fin r → ℂ) →L[ℂ] (Fin r → ℂ)) := by
    apply ContinuousLinearMap.ext
    intro x
    exact congrArg (fun L : (Fin r → ℂ) →ₗ[ℂ] (Fin r → ℂ) => L x) hD
  have hf : HasStrictFDerivAt F (e : (Fin r → ℂ) →L[ℂ] (Fin r → ℂ)) a₀ := by
    rw [← hde]
    exact hF.hasStrictFDerivAt
  have han : AnalyticAt ℂ (hf.localInverse F e a₀) (F a₀) := by
    exact (hf.toOpenPartialHomeomorph F).analyticAt_symm'
      hf.mem_toOpenPartialHomeomorph_source hF hde
  exact ⟨hf.localInverse F e a₀, han, hf.localInverse_apply_image,
    hf.eventually_left_inverse, hf.eventually_right_inverse⟩

end PolynomialJets

end PolynomialGeometry.Variations
