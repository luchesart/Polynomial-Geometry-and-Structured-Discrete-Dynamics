import Mathlib.Analysis.Complex.Norm
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Tactic

/-!
# Strict localization of genuine weighted critical points

This file proves the strict disk localization used in Theorems 2.1 and 4.1
directly from the positive source partial-fraction equation. It does not
assume a matrix compression or its spectral conclusion.
-/

namespace PolynomialGeometry.Compression

open scoped BigOperators
open Complex

/-- Outside the source disk, every logarithmic-derivative summand has a
strictly positive radial component. The denominator must be nonzero. -/
theorem radial_div_re_pos (w a : ℂ) (hne : w ≠ a)
    (hsize : Complex.normSq a ≤ Complex.normSq w) :
    0 < (w / (w - a)).re := by
  have hd : 0 < Complex.normSq (w - a) :=
    Complex.normSq_pos.mpr (sub_ne_zero.mpr hne)
  have hn : 0 < w.re * (w.re - a.re) + w.im * (w.im - a.im) := by
    simp only [Complex.normSq_apply, Complex.sub_re, Complex.sub_im] at hd hsize
    nlinarith
  rw [Complex.div_re, Complex.sub_re, Complex.sub_im, ← add_div]
  exact div_pos hn hd

/-- A zero of a positive weighted source sum, distinct from every source
in the closed unit disk, lies strictly in the open disk. Nonempty sources
are enough; no separation of source positions is required for this lemma. -/
theorem source_zero_norm_lt_one {ι : Type*} [Fintype ι] [Nonempty ι]
    (α : ι → ℂ) (ν : ι → ℝ) (w : ℂ)
    (hν : ∀ j, 0 < ν j) (hα : ∀ j, ‖α j‖ ≤ 1)
    (hsep : ∀ j, w ≠ α j)
    (hzero : (∑ j, (ν j : ℂ) / (w - α j)) = 0) :
    ‖w‖ < 1 := by
  classical
  by_contra h
  have hw : 1 ≤ ‖w‖ := le_of_not_gt h
  have hsize : ∀ j, Complex.normSq (α j) ≤ Complex.normSq w := by
    intro j
    rw [Complex.normSq_eq_norm_sq, Complex.normSq_eq_norm_sq]
    have hj := hα j
    have hnonneg := norm_nonneg (α j)
    nlinarith
  have hpos : ∀ j, 0 < ν j * (w / (w - α j)).re := by
    intro j
    exact mul_pos (hν j) (radial_div_re_pos w (α j) (hsep j) (hsize j))
  have hsumpos : 0 < ∑ j, ν j * (w / (w - α j)).re := by
    exact Finset.sum_pos (fun j _ => hpos j) Finset.univ_nonempty
  have heq : (∑ j, (ν j : ℂ) * (w / (w - α j))) = 0 := by
    calc
      _ = w * ∑ j, (ν j : ℂ) / (w - α j) := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro j _
        ring
      _ = 0 := by rw [hzero, mul_zero]
  have hre := congrArg Complex.re heq
  simp only [Complex.re_sum, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
    zero_mul, sub_zero, Complex.zero_re] at hre
  linarith

end PolynomialGeometry.Compression
