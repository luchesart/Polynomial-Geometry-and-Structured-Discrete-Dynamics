import PolynomialGeometry.SchurHessian
import Mathlib.Analysis.InnerProductSpace.Projection.FiniteDimensional

noncomputable section
open scoped Topology
open Filter

namespace PolynomialGeometry.KernelMaximum
open PartialMaximum UniformPartialMaximum SchurHessian

section Bilinear
variable {V : Type*} [NormedAddCommGroup V] [NormedSpace ℝ V]

/-- For a negative semidefinite symmetric form, a zero quadratic value
implies membership in the full bilinear kernel. -/
theorem negative_form_zero_implies_kernel (H : V →L[ℝ] V →L[ℝ] ℝ)
    (hsymm : ∀ u v, H u v = H v u) (hneg : ∀ u, H u u ≤ 0)
    (v : V) (hv : H v v = 0) : H v = 0 := by
  apply ContinuousLinearMap.ext
  intro w
  by_contra hn
  change H v w ≠ 0 at hn
  let t : ℝ := (1 - H w w) / (2 * H v w)
  have hb := hneg (w + t • v)
  simp only [map_add, map_smul, ContinuousLinearMap.add_apply,
    ContinuousLinearMap.smul_apply, smul_eq_mul, hv, mul_zero, add_zero] at hb
  rw [hsymm w v] at hb
  have ht : t * (2 * H v w) = 1 - H w w :=
    div_mul_cancel₀ _ (mul_ne_zero (by norm_num) hn)
  nlinarith

end Bilinear

section Blocks
variable {E T : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [FiniteDimensional ℝ E] [NormedAddCommGroup T] [InnerProductSpace ℝ T]
  [FiniteDimensional ℝ T]

omit [FiniteDimensional ℝ E] in
/-- The positive eliminated operator is extracted from the actual Hessian.
The two subspaces form a kernel/complement splitting, expressed intrinsically. -/
theorem extract_positive_eliminated_operator (F : E × T → ℝ)
    (hF : AnalyticAt ℝ F 0)
    (hneg : ∀ u : E × T, fderiv ℝ (fderiv ℝ F) 0 u u ≤ 0)
    (hker : ∀ x : E, fderiv ℝ (fderiv ℝ F) 0 (x, 0) = 0)
    (hcompl : ∀ s : T, fderiv ℝ (fderiv ℝ F) 0 (0, s) = 0 → s = 0) :
    ∃ P : T →L[ℝ] T,
      (∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s)) ∧
      (∀ u v : E × T, fderiv ℝ (fderiv ℝ F) 0 u v = -inner ℝ u.2 (P v.2)) := by
  let H := fderiv ℝ (fderiv ℝ F) 0
  let P : T →L[ℝ] T := -(fderiv ℝ (partialGradient F) 0).comp (ContinuousLinearMap.inr ℝ E T)
  have hsymm : ∀ u v, H u v = H v u := hF.contDiffAt.isSymmSndFDerivAt_of_omega
  have hPpair (s t : T) : inner ℝ s (P t) = -H (0, t) (0, s) := by
    change inner ℝ s (-(fderiv ℝ (partialGradient F) 0 (0, t))) = _
    rw [inner_neg_right, real_inner_comm (fderiv ℝ (partialGradient F) 0 (0, t)) s, partialGradient_hessian_pairing F hF]
  refine ⟨P, ?_, ?_⟩
  · intro s hs
    rw [hPpair]
    have hh := hneg (0, s)
    apply neg_pos.mpr
    apply lt_of_le_of_ne hh
    intro hz
    exact hs (hcompl s (negative_form_zero_implies_kernel H hsymm hneg (0, s) hz))
  · intro u v
    rw [hPpair, neg_neg, hsymm (0, v.2) (0, u.2)]
    have hu : H u = H (0, u.2) := by
      calc
        H u = H ((u.1, 0) + (0, u.2)) := by simp
        _ = H (0, u.2) := by rw [map_add, hker, zero_add]
    rw [hu, hsymm (0, u.2) v]
    have hv : H v = H (0, v.2) := by
      calc
        H v = H ((v.1, 0) + (0, v.2)) := by simp
        _ = H (0, v.2) := by rw [map_add, hker, zero_add]
    rw [hv, hsymm]

end Blocks

section Canonical
variable {W : Type*} [NormedAddCommGroup W] [InnerProductSpace ℝ W]
  [FiniteDimensional ℝ W]

/-- The kernel of the actual scalar Hessian at the origin. -/
def hessianKernel (F : W → ℝ) : Submodule ℝ W :=
  LinearMap.ker (fderiv ℝ (fderiv ℝ F) 0)

/-- The canonical complete linear coordinates given by the Hessian kernel
and its orthogonal complement. -/
def kernelCoordinates (F : W → ℝ) :
    (hessianKernel F × (hessianKernel F)ᗮ) ≃L[ℝ] W :=
  (Submodule.prodEquivOfIsCompl (hessianKernel F) (hessianKernel F)ᗮ
    Submodule.isCompl_orthogonal_of_hasOrthogonalProjection).toContinuousLinearEquiv

@[simp] theorem kernelCoordinates_apply (F : W → ℝ)
    (p : hessianKernel F × (hessianKernel F)ᗮ) :
    kernelCoordinates F p = (p.1 : W) + (p.2 : W) := rfl

theorem kernel_coordinate_analytic (F : W → ℝ) (hF : AnalyticAt ℝ F 0) :
    AnalyticAt ℝ (fun p => F (kernelCoordinates F p)) 0 :=
  hF.comp_of_eq' ((kernelCoordinates F).toContinuousLinearMap.analyticAt 0)
    (map_zero (kernelCoordinates F))

theorem kernel_coordinate_zero_derivative (F : W → ℝ) (hF : AnalyticAt ℝ F 0)
    (hF0 : fderiv ℝ F 0 = 0) :
    fderiv ℝ (fun p => F (kernelCoordinates F p)) 0 = 0 := by
  have hd : HasFDerivAt F (fderiv ℝ F 0) (kernelCoordinates F 0) := by
    simpa only [map_zero] using hF.differentiableAt.hasFDerivAt
  have hc := hd.comp 0 (kernelCoordinates F).hasFDerivAt
  simpa only [hF0, ContinuousLinearMap.zero_comp] using hc.fderiv

/-- Canonical kernel coordinates preserve arbitrarily nearby positive values
in both directions, since their inverse is continuous at the origin. -/
theorem kernel_coordinate_frequently_positive_iff (F : W → ℝ) :
    (∃ᶠ p : hessianKernel F × (hessianKernel F)ᗮ in 𝓝 0,
      0 < F (kernelCoordinates F p)) ↔ (∃ᶠ w : W in 𝓝 0, 0 < F w) := by
  constructor
  · intro hp
    have ht : Tendsto (kernelCoordinates F) (𝓝 0) (𝓝 (0 : W)) := by
      simpa only [map_zero] using (kernelCoordinates F).continuous.continuousAt.tendsto (x := 0)
    exact ht.frequently hp
  · intro hp
    have ht : Tendsto (kernelCoordinates F).symm (𝓝 0)
        (𝓝 (0 : hessianKernel F × (hessianKernel F)ᗮ)) := by
      simpa only [map_zero] using (kernelCoordinates F).symm.continuous.continuousAt.tendsto (x := 0)
    apply ht.frequently
    simpa only [ContinuousLinearEquiv.apply_symm_apply] using hp

theorem kernel_coordinate_local_max_iff (F : W → ℝ) :
    IsLocalMax (fun p => F (kernelCoordinates F p)) 0 ↔ IsLocalMax F 0 := by
  constructor
  · intro h
    have h' : IsLocalMax (fun p => F (kernelCoordinates F p)) ((kernelCoordinates F).symm 0) := by
      simpa only [map_zero] using h
    have hi := h'.comp_continuous (kernelCoordinates F).symm.continuous.continuousAt
    simpa only [Function.comp_def, ContinuousLinearEquiv.apply_symm_apply] using hi
  · intro h
    have h' : IsLocalMax F (kernelCoordinates F 0) := by simpa only [map_zero] using h
    exact h'.comp_continuous (kernelCoordinates F).continuous.continuousAt

/-- The actual second derivative in canonical kernel coordinates. -/
theorem kernel_coordinate_hessian (F : W → ℝ) (hF : AnalyticAt ℝ F 0)
    (u v : hessianKernel F × (hessianKernel F)ᗮ) :
    fderiv ℝ (fderiv ℝ (fun p => F (kernelCoordinates F p))) 0 u v =
      fderiv ℝ (fderiv ℝ F) 0 (kernelCoordinates F u) (kernelCoordinates F v) := by
  have h := second_fderiv_comp (kernelCoordinates F) F 0
    ((kernelCoordinates F).toContinuousLinearMap.analyticAt 0)
    (by simpa using hF) u v
  have hJ : fderiv ℝ (kernelCoordinates F) = fun _ => (kernelCoordinates F).toContinuousLinearMap :=
    funext fun _ => (kernelCoordinates F).fderiv
  rw [hJ] at h
  simpa only [ContinuousLinearEquiv.map_zero, ContinuousLinearEquiv.coe_coe,
    fderiv_fun_const, Pi.zero_apply, ContinuousLinearMap.zero_apply, map_zero, add_zero] using h

/-- Negative semidefiniteness alone supplies the positive operator on the
orthogonal complement of the full Hessian kernel. The spaces and all
coordinate identities are constructed from F. -/
theorem canonical_kernel_block_data (F : W → ℝ) (hF : AnalyticAt ℝ F 0)
    (hneg : ∀ u : W, fderiv ℝ (fderiv ℝ F) 0 u u ≤ 0) :
    ∃ P : (hessianKernel F)ᗮ →L[ℝ] (hessianKernel F)ᗮ,
      (∀ s : (hessianKernel F)ᗮ, s ≠ 0 → 0 < inner ℝ s (P s)) ∧
      (∀ u v : hessianKernel F × (hessianKernel F)ᗮ,
        fderiv ℝ (fderiv ℝ (fun p => F (kernelCoordinates F p))) 0 u v =
          -inner ℝ u.2 (P v.2)) := by
  let J := kernelCoordinates F
  let G := fun p => F (J p)
  have hG : AnalyticAt ℝ G 0 := hF.comp_of_eq' (J.toContinuousLinearMap.analyticAt 0) (map_zero J)
  apply extract_positive_eliminated_operator G hG
  · intro u
    rw [kernel_coordinate_hessian F hF]
    exact hneg (J u)
  · intro x
    apply ContinuousLinearMap.ext
    intro v
    rw [kernel_coordinate_hessian F hF]
    have hx : fderiv ℝ (fderiv ℝ F) 0 (x : W) = 0 := x.property
    simp only [kernelCoordinates_apply, Submodule.coe_zero, add_zero, hx,
      ContinuousLinearMap.zero_apply]
  · intro s hs
    have hsK : (s : W) ∈ hessianKernel F := by
      change fderiv ℝ (fderiv ℝ F) 0 (s : W) = 0
      apply ContinuousLinearMap.ext
      intro w
      obtain ⟨v, rfl⟩ := J.surjective w
      have hh := congrArg (fun L => L v) hs
      change fderiv ℝ (fderiv ℝ (fun p => F (kernelCoordinates F p))) 0 (0, s) v = 0 at hh
      rw [kernel_coordinate_hessian F hF] at hh
      simpa [J] using hh
    have hz : (s : W) = 0 := inner_self_eq_zero.mp (s.property (s : W) hsK)
    exact Subtype.ext hz

end Canonical

end PolynomialGeometry.KernelMaximum
