import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic
import Mathlib.LinearAlgebra.Matrix.Charpoly.Eigs
import Mathlib.Analysis.Normed.Algebra.Spectrum
import Mathlib.Order.ConditionallyCompleteLattice.Finset
import Mathlib.LinearAlgebra.Matrix.Adjugate
import Mathlib.LinearAlgebra.Matrix.NonsingularInverse
import Mathlib.Analysis.Complex.Basic
import Mathlib.Tactic
import PolynomialGeometry.Source
import PolynomialGeometry.Compression

/-!
# Determinant formula for a diagonal-source compression

The algebraic part of Theorem 2.1 is proved for a supplied unitary
coordinate matrix. Its first column is the normalized source direction;
the other columns give the compression basis. No characteristic-polynomial
identity is assumed.
-/

open scoped BigOperators Matrix ENNReal NNReal
open Matrix Polynomial

namespace PolynomialGeometry.CompressionDet

variable {ι R : Type*} [Fintype ι] [DecidableEq ι] [CommRing R]

theorem adjugate_conjugation (A U V : Matrix ι ι R)
    (hUV : U * V = 1) (hVU : V * U = 1) :
    (V * A * U).adjugate = V * A.adjugate * U := by
  have hU : U.adjugate = U.det • V := by
    calc
      U.adjugate = U.adjugate * (U * V) := by rw [hUV, Matrix.mul_one]
      _ = (U.adjugate * U) * V := by rw [Matrix.mul_assoc]
      _ = U.det • V := by rw [Matrix.adjugate_mul, Matrix.smul_mul, Matrix.one_mul]
  have hV : V.adjugate = V.det • U := by
    calc
      V.adjugate = V.adjugate * (V * U) := by rw [hVU, Matrix.mul_one]
      _ = (V.adjugate * V) * U := by rw [Matrix.mul_assoc]
      _ = V.det • U := by rw [Matrix.adjugate_mul, Matrix.smul_mul, Matrix.one_mul]
  have hd : U.det * V.det = 1 := by
    rw [← Matrix.det_mul, hUV, Matrix.det_one]
  rw [Matrix.adjugate_mul_distrib, Matrix.adjugate_mul_distrib, hU, hV]
  simp only [Matrix.smul_mul, Matrix.mul_smul, smul_smul]
  rw [mul_comm V.det U.det, hd, one_smul, ← Matrix.mul_assoc]

theorem cofactor_zero_eq_charpoly (d : ℕ) (A : Matrix (Fin (d + 1)) (Fin (d + 1)) R) :
    A.charmatrix.adjugate 0 0 = (A.submatrix Fin.succ Fin.succ).charpoly := by
  rw [Matrix.adjugate_fin_succ_eq_det_submatrix]
  simp only [Fin.val_zero, add_zero, pow_zero, one_mul]
  congr 1
  ext i j : 1
  by_cases hij : i = j
  · subst j
    simp [Fin.succAbove_zero]
  · simp [Fin.succAbove_zero, hij]

theorem charmatrix_conjugation (A U V : Matrix ι ι R)
    (hVU : V * U = 1) :
    (V * A * U).charmatrix =
      V.map C * A.charmatrix * U.map C := by
  have hmap : V.map C * U.map C = (1 : Matrix ι ι R[X]) := by
    rw [← Matrix.map_mul]
    simp [hVU]
  simp only [Matrix.charmatrix, RingHom.mapMatrix_apply, Matrix.map_mul,
    Matrix.mul_sub, Matrix.sub_mul]
  congr 1
  rw [Matrix.scalar_apply, ← Matrix.smul_one_eq_diagonal,
    Matrix.mul_smul, Matrix.mul_one, Matrix.smul_mul, hmap]

/-- The compressed characteristic polynomial is the cofactor selected by
the distinguished source column. This identity holds over any commutative
ring and does not require distinct source positions. -/
theorem charpoly_compression_diagonal (d : ℕ)
    (α : Fin (d + 1) → R)
    (U V : Matrix (Fin (d + 1)) (Fin (d + 1)) R)
    (hUV : U * V = 1) (hVU : V * U = 1) :
    ((V * diagonal α * U).submatrix Fin.succ Fin.succ).charpoly =
      ∑ j, C (V 0 j * U j 0) *
        ∏ k ∈ Finset.univ.erase j, (X - C (α k)) := by
  have hUVc : U.map C * V.map C = (1 : Matrix (Fin (d + 1)) (Fin (d + 1)) R[X]) := by
    rw [← Matrix.map_mul]
    simp [hUV]
  have hVUc : V.map C * U.map C = (1 : Matrix (Fin (d + 1)) (Fin (d + 1)) R[X]) := by
    rw [← Matrix.map_mul]
    simp [hVU]
  rw [← cofactor_zero_eq_charpoly, charmatrix_conjugation _ _ _ hVU,
    adjugate_conjugation _ _ _ hUVc hVUc,
    Matrix.charmatrix_diagonal, Matrix.adjugate_diagonal, Matrix.mul_apply]
  simp only [Matrix.mul_diagonal, Matrix.map_apply]
  apply Finset.sum_congr rfl
  intro j hj
  rw [map_mul]
  ring

/-- Put the normalized source direction first and the compression columns after it. -/
def sourceCoordinates (d : ℕ) (b : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ) :
    Matrix (Fin (d + 1)) (Fin (d + 1)) ℂ :=
  fun i j => Fin.cases (b i) (fun k => Q i k) j

@[simp] theorem sourceCoordinates_zero (d : ℕ) (b : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ) (i : Fin (d + 1)) :
    sourceCoordinates d b Q i 0 = b i := rfl

@[simp] theorem sourceCoordinates_succ (d : ℕ) (b : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ) (i : Fin (d + 1)) (j : Fin d) :
    sourceCoordinates d b Q i j.succ = Q i j := rfl

/-- A normalized column and orthonormal orthogonal complement form unitary coordinates. -/
theorem sourceCoordinates_unitary (d : ℕ) (b : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hb : ∑ i, star (b i) * b i = 1)
    (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (b i) * Q i j = 0) :
    (sourceCoordinates d b Q)ᴴ * sourceCoordinates d b Q = 1 := by
  ext i j
  refine Fin.cases ?_ (fun i => ?_) i
  · refine Fin.cases ?_ (fun j => ?_) j
    · simpa [Matrix.mul_apply, Matrix.conjTranspose_apply] using hb
    · simpa [Matrix.mul_apply, Matrix.conjTranspose_apply] using hbQ j
  · refine Fin.cases ?_ (fun j => ?_) j
    · have h := congrArg star (hbQ i)
      simpa [Matrix.mul_apply, Matrix.conjTranspose_apply, star_sum, mul_comm] using h
    · simpa [Matrix.mul_apply, Matrix.conjTranspose_apply, Matrix.one_apply] using
        congrFun (congrFun hQ i) j

/-- Deleting the source coordinate gives the usual matrix compression. -/
theorem sourceCoordinates_minor (d : ℕ) (α b : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ) :
    (((sourceCoordinates d b Q)ᴴ * diagonal α * sourceCoordinates d b Q).submatrix Fin.succ Fin.succ) = Qᴴ * diagonal α * Q := by
  ext i j
  simp [Matrix.submatrix_apply, Matrix.mul_apply, Matrix.conjTranspose_apply ]

/-- Weighted derivative compression in the source weights `conj bⱼ * bⱼ`.
Only normalization and orthogonality are hypotheses. The polynomial identity
is the conclusion, including at the source positions. -/
theorem weighted_compression_charpoly (d : ℕ) (α b : Fin (d + 1) → ℂ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hb : ∑ i, star (b i) * b i = 1)
    (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (b i) * Q i j = 0) :
    (Qᴴ * diagonal α * Q).charpoly =
      ∑ j, C (star (b j) * b j) *
        ∏ k ∈ Finset.univ.erase j, (X - C (α k)) := by
  have hVU := sourceCoordinates_unitary d b Q hb hQ hbQ
  have hUV := Matrix.mul_eq_one_comm.mp hVU
  have h := charpoly_compression_diagonal d α (sourceCoordinates d b Q)
    (sourceCoordinates d b Q)ᴴ hUV hVU
  rw [sourceCoordinates_minor] at h
  simpa only [Matrix.conjTranspose_apply, sourceCoordinates_zero] using h

/-- The concrete source direction used in the paper. -/
noncomputable def normalizedSource (d : ℕ) (ν : Fin (d + 1) → ℝ) :
    Fin (d + 1) → ℂ :=
  fun j => ((Real.sqrt (ν j) / Real.sqrt (∑ k, ν k) : ℝ) : ℂ)

theorem totalMass_pos (d : ℕ) (ν : Fin (d + 1) → ℝ)
    (hν : ∀ j, 0 < ν j) : 0 < ∑ j, ν j :=
  Finset.sum_pos (fun j _ => hν j) Finset.univ_nonempty

theorem normalizedSource_weight (d : ℕ) (ν : Fin (d + 1) → ℝ)
    (hν : ∀ j, 0 < ν j) (j : Fin (d + 1)) :
    star (normalizedSource d ν j) * normalizedSource d ν j =
      (ν j : ℂ) / ((∑ k, ν k : ℝ) : ℂ) := by
  have hr : (Real.sqrt (ν j) / Real.sqrt (∑ k, ν k)) *
      (Real.sqrt (ν j) / Real.sqrt (∑ k, ν k)) = ν j / ∑ k, ν k := by
    rw [div_mul_div_comm, Real.mul_self_sqrt (hν j).le,
      Real.mul_self_sqrt (totalMass_pos d ν hν).le]
  simpa only [normalizedSource, Complex.star_def, Complex.conj_ofReal,
    ← Complex.ofReal_mul, ← Complex.ofReal_div] using congrArg Complex.ofReal hr

theorem normalizedSource_normalized (d : ℕ) (ν : Fin (d + 1) → ℝ)
    (hν : ∀ j, 0 < ν j) :
    ∑ j, star (normalizedSource d ν j) * normalizedSource d ν j = 1 := by
  simp only [normalizedSource_weight d ν hν]
  rw [← Finset.sum_div, ← Complex.ofReal_sum, div_self]
  exact_mod_cast ne_of_gt (totalMass_pos d ν hν)

/-- The determinant part of weighted derivative compression, with exactly
the positive real masses and square-root source column of the article. -/
theorem positive_weight_compression_charpoly (d : ℕ) (α : Fin (d + 1) → ℂ)
    (ν : Fin (d + 1) → ℝ) (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hν : ∀ j, 0 < ν j) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (normalizedSource d ν i) * Q i j = 0) :
    (Qᴴ * diagonal α * Q).charpoly =
      Source.numerator Finset.univ α (fun j => (ν j : ℂ)) := by
  rw [weighted_compression_charpoly d α (normalizedSource d ν) Q
    (normalizedSource_normalized d ν hν) hQ hbQ]
  simp only [normalizedSource_weight d ν hν]
  simp only [Source.numerator, Source.rawNumerator, Source.support, Source.mass]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j hj
  rw [div_eq_mul_inv, map_mul]
  simp only [Complex.ofReal_sum]
  ring

/-- Every root of the grouped compression polynomial lies strictly inside
the disk. Distinctness is used to rule out an inherited source root. -/
theorem positive_weight_compression_root_norm_lt_one (d : ℕ)
    (α : Fin (d + 1) → ℂ) (ν : Fin (d + 1) → ℝ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hν : ∀ j, 0 < ν j) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (normalizedSource d ν i) * Q i j = 0)
    (hα : Function.Injective α) (hdisk : ∀ j, ‖α j‖ ≤ 1)
    (w : ℂ) (hw : (Qᴴ * diagonal α * Q).charpoly.IsRoot w) : ‖w‖ < 1 := by
  have hn : Source.mass Finset.univ (fun j => (ν j : ℂ)) ≠ 0 := by
    simp only [Source.mass, ← Complex.ofReal_sum]
    exact_mod_cast ne_of_gt (totalMass_pos d ν hν)
  have hzero : (Source.numerator Finset.univ α (fun j => (ν j : ℂ))).eval w = 0 := by
    simpa only [positive_weight_compression_charpoly d α ν Q hν hQ hbQ] using hw
  have hsep : ∀ j, w ≠ α j := by
    intro j h
    have hj := Source.numerator_ne_zero_at_source Finset.univ α (fun j => (ν j : ℂ))
      (fun _ _ _ _ hij => hα hij) hn (Finset.mem_univ j)
      (by change (ν j : ℂ) ≠ 0; exact_mod_cast ne_of_gt (hν j))
    exact hj (h ▸ hzero)
  have hf := Source.sourceFunction_eq_normalized_numerator Finset.univ α
    (fun j => (ν j : ℂ)) w hn (fun j _ => hsep j)
  rw [hzero, mul_zero, zero_div] at hf
  exact Compression.source_zero_norm_lt_one α ν w hν hdisk hsep hf

/-- Finite matrices have a finite spectrum, so strict root bounds give a
strict spectral-radius bound without an extra uniform-margin hypothesis. -/
theorem spectralRadius_lt_one_of_charpoly_roots {n : Type*} [Fintype n] [DecidableEq n]
    (A : Matrix n n ℂ) (hroot : ∀ w, A.charpoly.IsRoot w → ‖w‖ < 1) :
    spectralRadius ℂ A < 1 := by
  have hfin : (spectrum ℂ A).Finite := by
    simpa only [← Matrix.mem_spectrum_iff_isRoot_charpoly] using
      Polynomial.finite_setOf_isRoot A.charpoly_monic.ne_zero
  rcases Set.eq_empty_or_nonempty (spectrum ℂ A) with hempty | hne
  · simp [spectralRadius, hempty]
  · obtain ⟨w, hw, heq⟩ := hfin.ciSup_mem_image
      (f := fun z : ℂ => (‖z‖₊ : ℝ≥0∞))
      (by obtain ⟨z, hz⟩ := hne; exact ⟨z, hz, by simp⟩)
    change (‖w‖₊ : ℝ≥0∞) = spectralRadius ℂ A at heq
    rw [← heq]
    exact_mod_cast hroot w (Matrix.mem_spectrum_iff_isRoot_charpoly.mp hw)

/-- The strict spectral-radius conclusion of weighted derivative compression. -/
theorem positive_weight_compression_spectralRadius_lt_one (d : ℕ)
    (α : Fin (d + 1) → ℂ) (ν : Fin (d + 1) → ℝ)
    (Q : Matrix (Fin (d + 1)) (Fin d) ℂ)
    (hν : ∀ j, 0 < ν j) (hQ : Qᴴ * Q = 1)
    (hbQ : ∀ j, ∑ i, star (normalizedSource d ν i) * Q i j = 0)
    (hα : Function.Injective α) (hdisk : ∀ j, ‖α j‖ ≤ 1) :
    spectralRadius ℂ (Qᴴ * diagonal α * Q) < 1 := by
  apply spectralRadius_lt_one_of_charpoly_roots
  exact positive_weight_compression_root_norm_lt_one d α ν Q hν hQ hbQ hα hdisk

end PolynomialGeometry.CompressionDet
