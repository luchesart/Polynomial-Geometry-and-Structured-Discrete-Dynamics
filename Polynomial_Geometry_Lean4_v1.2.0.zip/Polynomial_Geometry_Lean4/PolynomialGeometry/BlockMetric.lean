import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Analysis.Complex.Order
import Mathlib.Tactic

/-! # The concrete block metric for the normalized completion -/
noncomputable section
open scoped ComplexOrder
open Matrix Complex
namespace PolynomialGeometry.BlockMetric
variable {ι : Type*} [Fintype ι]

/-- Scalar completion coordinate followed by the prescribed state coordinates. -/
def coordinates : (Option ι → ℂ) ≃ₗ[ℂ] ℂ × (ι → ℂ) where
  toFun x := (x none, fun j => x (some j))
  invFun x := Option.rec x.1 x.2
  left_inv x := by funext j; cases j <;> rfl
  right_inv x := rfl
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

/-- The article's exact matrix `diag(n,H)`. -/
def metric (n : ℝ) (H : Matrix ι ι ℂ) : Matrix (Option ι) (Option ι) ℂ
  | none, none => n
  | some i, some j => H i j
  | _, _ => 0

theorem metric_mulVec (n : ℝ) (H : Matrix ι ι ℂ) (x : Option ι → ℂ) :
    (metric n H).mulVec x = Option.rec ((n : ℂ) * x none)
      (H.mulVec (fun j => x (some j))) := by
  funext j
  cases j <;> simp [Matrix.mulVec, dotProduct, Fintype.sum_option, metric]

theorem metric_inner (n : ℝ) (H : Matrix ι ι ℂ) (x y : Option ι → ℂ) :
    star x ⬝ᵥ (metric n H).mulVec y =
      star (x none) * (n : ℂ) * y none +
        star (fun j => x (some j)) ⬝ᵥ H.mulVec (fun j => y (some j)) := by
  rw [metric_mulVec]
  simp [dotProduct, Fintype.sum_option, mul_assoc]

omit [Fintype ι] in
theorem metric_hermitian (n : ℝ) (H : Matrix ι ι ℂ) (hH : H.IsHermitian) :
    (metric n H).IsHermitian := by
  ext i j
  cases i <;> cases j <;> simp [metric, Matrix.conjTranspose_apply, hH.apply]

/-- Positivity is proved for the actual block matrix, not imposed separately. -/
theorem metric_posDef (n : ℝ) (H : Matrix ι ι ℂ) (hn : 0 < n) (hH : H.PosDef) :
    (metric n H).PosDef := by
  refine ⟨metric_hermitian n H hH.1, ?_⟩
  intro x hx
  rw [metric_inner]
  have hnC : (0 : ℂ) < (n : ℂ) := by exact_mod_cast hn
  have hfirst : 0 ≤ star (x none) * (n : ℂ) * x none := by
    have he : star (x none) * (n : ℂ) * x none =
        (n : ℂ) * (normSq (x none) : ℂ) := by
      rw [Complex.normSq_eq_conj_mul_self]
      change star (x none) * (n : ℂ) * x none = (n : ℂ) * (star (x none) * x none)
      ring
    rw [he]
    exact mul_nonneg hnC.le (by exact_mod_cast normSq_nonneg (x none))
  by_cases hs : (fun j => x (some j)) = 0
  · have hnone : x none ≠ 0 := by
      intro he
      apply hx
      funext j
      cases j with
      | none => exact he
      | some j => exact congrFun hs j
    have hpos : 0 < star (x none) * (n : ℂ) * x none := by
      have he : star (x none) * (n : ℂ) * x none =
          (n : ℂ) * (normSq (x none) : ℂ) := by
        rw [Complex.normSq_eq_conj_mul_self]
        change star (x none) * (n : ℂ) * x none = (n : ℂ) * (star (x none) * x none)
        ring
      rw [he]
      exact mul_pos hnC (by exact_mod_cast normSq_pos.mpr hnone)
    simpa [hs] using hpos
  · exact add_pos_of_nonneg_of_pos hfirst (hH.2 _ hs)

/-- Concrete completed operator, with the negative observed top row. -/
def completion (J : Matrix ι ι ℂ) (e : ι → ℂ) (γ : ℂ) (d : ι → ℂ) :
    Matrix (Option ι) (Option ι) ℂ
  | none, none => γ
  | none, some j => -star (e j)
  | some i, none => d i
  | some i, some j => J i j

/-- The matrix acts exactly as the scalar/state border in the article. -/
theorem completion_action (J : Matrix ι ι ℂ) (e : ι → ℂ) (γ : ℂ) (d : ι → ℂ)
    (x : Option ι → ℂ) :
    coordinates ((completion J e γ d).mulVec x) =
      (γ * x none - star e ⬝ᵥ (fun j => x (some j)),
        (x none) • d + J.mulVec (fun j => x (some j))) := by
  apply Prod.ext
  · simp [coordinates, completion, Matrix.mulVec, dotProduct, Fintype.sum_option,
      sub_eq_add_neg, Finset.sum_neg_distrib]
  · funext i
    simp [coordinates, completion, Matrix.mulVec, dotProduct, Fintype.sum_option, mul_comm]

variable [DecidableEq ι]

def firstVector : Option ι → ℂ := Pi.single none 1

def stateVector (i : ι) : Option ι → ℂ := Pi.single (some i) 1

theorem firstVector_energy (n : ℝ) (H : Matrix ι ι ℂ) :
    star (firstVector : Option ι → ℂ) ⬝ᵥ (metric n H).mulVec firstVector = n := by
  simp [firstVector, ← Pi.single_star, metric]

theorem stateVectors_gram (n : ℝ) (H : Matrix ι ι ℂ) (i j : ι) :
    star (stateVector i) ⬝ᵥ (metric n H).mulVec (stateVector j) = H i j := by
  simp [stateVector, ← Pi.single_star, metric]

theorem first_state_orthogonal (n : ℝ) (H : Matrix ι ι ℂ) (i : ι) :
    star (firstVector : Option ι → ℂ) ⬝ᵥ (metric n H).mulVec (stateVector i) = 0 := by
  simp [firstVector, stateVector, ← Pi.single_star, metric]

end PolynomialGeometry.BlockMetric
