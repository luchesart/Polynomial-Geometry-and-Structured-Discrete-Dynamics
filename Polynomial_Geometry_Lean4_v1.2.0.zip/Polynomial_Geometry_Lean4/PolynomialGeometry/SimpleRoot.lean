import PolynomialGeometry.CriticalReconstruction
import Mathlib.Analysis.Calculus.Deriv.Polynomial

/-! # Holomorphic continuation of a simple root

A triangular analytic inverse constructs the root function. In particular, the
root function and its local uniqueness are conclusions, not hypotheses.
-/

noncomputable section
open Filter Polynomial
open scoped Topology
namespace PolynomialGeometry.SimpleRoot

section Analytic
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]
  [FiniteDimensional ℂ E]

/-- The analytic implicit function theorem for one scalar unknown, with a
nonzero actual partial derivative and an explicit local uniqueness conclusion. -/
theorem analytic_simple_root (f : E × ℂ → ℂ) (x₀ : E) (z₀ : ℂ)
    (hf : AnalyticAt ℂ f (x₀, z₀)) (hzero : f (x₀, z₀) = 0)
    (hsimple : (fderiv ℂ f (x₀, z₀)) (0, 1) ≠ 0) :
    ∃ g : E → ℂ, AnalyticAt ℂ g x₀ ∧ g x₀ = z₀ ∧
      (∀ᶠ x in 𝓝 x₀, f (x, g x) = 0) ∧
      (∀ᶠ p : E × ℂ in 𝓝 (x₀, z₀), f p = 0 → p.2 = g p.1) := by
  let L := fderiv ℂ f (x₀, z₀)
  let F : E × ℂ → E × ℂ := fun p => (p.1, f p)
  let H : (E × ℂ) →L[ℂ] (E × ℂ) := (ContinuousLinearMap.fst ℂ E ℂ).prod L
  have hHinj : Function.Injective H := by
    apply LinearMap.ker_eq_bot.mp
    apply LinearMap.ker_eq_bot'.mpr
    intro y hy
    have hy₁ : y.1 = 0 := congrArg Prod.fst hy
    have hy₂ : L y = 0 := congrArg Prod.snd hy
    have he : y = y.2 • ((0, 1) : E × ℂ) := by
      apply Prod.ext
      · simpa using hy₁
      · simp
    rw [he, map_smul, smul_eq_mul] at hy₂
    have hyz : y.2 = 0 := (mul_eq_zero.mp hy₂).resolve_right hsimple
    exact Prod.ext hy₁ hyz
  have hHbij : Function.Bijective H :=
    ⟨hHinj, (LinearMap.injective_iff_surjective_of_finrank_eq_finrank rfl).mp hHinj⟩
  let e := (LinearEquiv.ofBijective H.toLinearMap hHbij).toContinuousLinearEquiv
  have hF : AnalyticAt ℂ F (x₀,z₀) := analyticAt_fst.prod hf
  have hFd : HasFDerivAt F (e : (E × ℂ) →L[ℂ] (E × ℂ)) (x₀,z₀) :=
    hasFDerivAt_fst.prodMk hf.differentiableAt.hasFDerivAt
  have hFs : HasStrictFDerivAt F (e : (E × ℂ) →L[ℂ] (E × ℂ)) (x₀,z₀) := by
    rw [← hFd.fderiv]
    exact hF.hasStrictFDerivAt
  let G := hFs.localInverse F e (x₀,z₀)
  have hG : AnalyticAt ℂ G (F (x₀,z₀)) :=
    (hFs.toOpenPartialHomeomorph F).analyticAt_symm'
      hFs.mem_toOpenPartialHomeomorph_source hF hFd.fderiv
  have hFbase : F (x₀,z₀) = (x₀,0) := by simp [F,hzero]
  have hGbase : G (x₀,0) = (x₀,z₀) := by
    rw [← hFbase]
    exact hFs.localInverse_apply_image
  let g : E → ℂ := fun x => (G (x,0)).2
  have hg : AnalyticAt ℂ g x₀ := by
    apply analyticAt_snd.comp
    exact (hFbase ▸ hG).comp_of_eq
      (show AnalyticAt ℂ (fun x : E => (x, (0 : ℂ))) x₀ from
        analyticAt_id.prod analyticAt_const) rfl
  refine ⟨g, hg, congrArg Prod.snd hGbase, ?_, ?_⟩
  · have hright : ∀ᶠ x in 𝓝 x₀, F (G (x,0)) = (x,0) := by
      exact (continuousAt_id.prodMk continuousAt_const).tendsto.eventually
        (hFbase ▸ hFs.eventually_right_inverse)
    filter_upwards [hright] with x hx
    have hfirst : (G (x,0)).1 = x := congrArg Prod.fst hx
    have hsecond : f (G (x,0)) = 0 := congrArg Prod.snd hx
    have hpair : (x,g x) = G (x,0) := Prod.ext hfirst.symm rfl
    rw [hpair]
    exact hsecond
  · filter_upwards [hFs.eventually_left_inverse] with p hp
    intro hfp
    have hh : G (p.1,0) = p := by simpa only [F, hfp] using hp
    exact (congrArg Prod.snd hh).symm

end Analytic
open PolynomialGeometry.Factorization PolynomialGeometry.CriticalReconstruction

/-- The actual partial derivative of coefficient evaluation is the polynomial derivative. -/
theorem monic_eval_partial_derivative (n : ℕ) (a : Fin n → ℂ) (z : ℂ) :
    (fderiv ℂ (fun y : (Fin n → ℂ) × ℂ => (monicPolynomial n y.1).eval y.2)
      (a,z)) (0,1) = (monicPolynomial n a).derivative.eval z := by
  have h := ((monicPolynomial_eval_analyticAt n (a,z)).differentiableAt.hasFDerivAt.comp z
    (hasFDerivAt_prodMk_right a z)).hasDerivAt
  simpa using h.unique ((monicPolynomial n a).hasDerivAt z)

/-- A marked simple root continues holomorphically with all lower coefficients,
and is the unique nearby root. -/
theorem monic_simple_root (n : ℕ) (a₀ : Fin n → ℂ) (z₀ : ℂ)
    (hzero : (monicPolynomial n a₀).eval z₀ = 0)
    (hsimple : (monicPolynomial n a₀).derivative.eval z₀ ≠ 0) :
    ∃ g : (Fin n → ℂ) → ℂ, AnalyticAt ℂ g a₀ ∧ g a₀ = z₀ ∧
      (∀ᶠ a in 𝓝 a₀, (monicPolynomial n a).eval (g a) = 0) ∧
      (∀ᶠ p : (Fin n → ℂ) × ℂ in 𝓝 (a₀,z₀),
        (monicPolynomial n p.1).eval p.2 = 0 → p.2 = g p.1) := by
  apply analytic_simple_root _ a₀ z₀ (monicPolynomial_eval_analyticAt n (a₀,z₀)) hzero
  rw [monic_eval_partial_derivative]
  exact hsimple

/-- The continuation theorem composed with any analytic finite coefficient family.
This applies to the polynomial coefficients produced by local reconstruction. -/
theorem analytic_family_simple_root_fiberwise {E : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]
    (n : ℕ) (c : E → (Fin n → ℂ)) (x₀ : E) (z₀ : ℂ)
    (hc : AnalyticAt ℂ c x₀) (hzero : (monicPolynomial n (c x₀)).eval z₀ = 0)
    (hsimple : (monicPolynomial n (c x₀)).derivative.eval z₀ ≠ 0) :
    ∃ g : E → ℂ, AnalyticAt ℂ g x₀ ∧ g x₀ = z₀ ∧
      (∀ᶠ x in 𝓝 x₀, (monicPolynomial n (c x)).eval (g x) = 0) ∧
      (∀ᶠ p : E × ℂ in 𝓝 (x₀,z₀),
        (monicPolynomial n (c p.1)).eval p.2 = 0 → p.2 = g p.1) ∧
      (∀ x y, c x = c y → g x = g y) := by
  obtain ⟨g, hg, hg0, heval, huniq⟩ := monic_simple_root n (c x₀) z₀ hzero hsimple
  refine ⟨g ∘ c, hg.comp hc, hg0, ?_, ?_, ?_⟩
  · exact hc.continuousAt.eventually heval
  · have hmap : ContinuousAt (fun p : E × ℂ => (c p.1,p.2)) (x₀,z₀) :=
      (hc.continuousAt.comp continuousAt_fst).prodMk continuousAt_snd
    exact hmap.eventually huniq
  · intro x y hxy
    exact congrArg g hxy

/-- Analytic continuation for a coefficient family, without retaining its
additional equality-on-coefficient-fibers conclusion. -/
theorem analytic_family_simple_root {E : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]
    (n : ℕ) (c : E → (Fin n → ℂ)) (x₀ : E) (z₀ : ℂ)
    (hc : AnalyticAt ℂ c x₀) (hzero : (monicPolynomial n (c x₀)).eval z₀ = 0)
    (hsimple : (monicPolynomial n (c x₀)).derivative.eval z₀ ≠ 0) :
    ∃ g : E → ℂ, AnalyticAt ℂ g x₀ ∧ g x₀ = z₀ ∧
      (∀ᶠ x in 𝓝 x₀, (monicPolynomial n (c x)).eval (g x) = 0) ∧
      (∀ᶠ p : E × ℂ in 𝓝 (x₀,z₀),
        (monicPolynomial n (c p.1)).eval p.2 = 0 → p.2 = g p.1) := by
  obtain ⟨g, hg, hg0, heval, huniq, _⟩ :=
    analytic_family_simple_root_fiberwise n c x₀ z₀ hc hzero hsimple
  exact ⟨g, hg, hg0, heval, huniq⟩

/-- The actual polynomial produced by labelled critical/source reconstruction. -/
def reconstructedPolynomial (r s : ℕ) (G : Parameter r s → Unknown r s)
    (q : Parameter r s) : ℂ[X] :=
  monicPolynomial r (G q).1 * rootPolynomial (s + 1) q.2

/-- A simple interior-factor root continues as a root of the actual reconstructed polynomial. -/
theorem source_factor_simple_root (r s : ℕ) (G : Parameter r s → Unknown r s)
    (q₀ : Parameter r s) (z₀ : ℂ) (hG : AnalyticAt ℂ G q₀)
    (hzero : (monicPolynomial r (G q₀).1).eval z₀ = 0)
    (hsimple : (monicPolynomial r (G q₀).1).derivative.eval z₀ ≠ 0) :
    ∃ g : Parameter r s → ℂ, AnalyticAt ℂ g q₀ ∧ g q₀ = z₀ ∧
      (∀ᶠ q in 𝓝 q₀, (monicPolynomial r (G q).1).eval (g q) = 0 ∧
        (reconstructedPolynomial r s G q).eval (g q) = 0) ∧
      (∀ᶠ p : Parameter r s × ℂ in 𝓝 (q₀,z₀),
        (monicPolynomial r (G p.1).1).eval p.2 = 0 → p.2 = g p.1) ∧
      (∀ q q', G q = G q' → g q = g q') := by
  obtain ⟨g, hg, hg0, hroot, huniq, hfiber⟩ :=
    analytic_family_simple_root_fiberwise r (fun q => (G q).1) q₀ z₀
      (analyticAt_fst.comp hG) hzero hsimple
  refine ⟨g, hg, hg0, ?_, huniq, ?_⟩
  · filter_upwards [hroot] with q hq
    exact ⟨hq, by simp only [reconstructedPolynomial, eval_mul, hq, zero_mul]⟩
  · intro q q' hq
    exact hfiber q q' (congrArg Prod.fst hq)

/-- A simple residual-factor root continues as a critical point of the actual polynomial. -/
theorem residual_factor_simple_root (r s : ℕ) (G : Parameter r s → Unknown r s)
    (q₀ : Parameter r s) (v₀ : ℂ) (hG : AnalyticAt ℂ G q₀)
    (hzero : (monicPolynomial s (G q₀).2).eval v₀ = 0)
    (hsimple : (monicPolynomial s (G q₀).2).derivative.eval v₀ ≠ 0)
    (hidentity : ∀ᶠ q in 𝓝 q₀, (reconstructedPolynomial r s G q).derivative =
      C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s (G q).2) :
    ∃ g : Parameter r s → ℂ, AnalyticAt ℂ g q₀ ∧ g q₀ = v₀ ∧
      (∀ᶠ q in 𝓝 q₀, (monicPolynomial s (G q).2).eval (g q) = 0 ∧
        (reconstructedPolynomial r s G q).derivative.eval (g q) = 0) ∧
      (∀ᶠ p : Parameter r s × ℂ in 𝓝 (q₀,v₀),
        (monicPolynomial s (G p.1).2).eval p.2 = 0 → p.2 = g p.1) ∧
      (∀ q q', G q = G q' → g q = g q') := by
  obtain ⟨g, hg, hg0, hroot, huniq, hfiber⟩ :=
    analytic_family_simple_root_fiberwise s (fun q => (G q).2) q₀ v₀
      (analyticAt_snd.comp hG) hzero hsimple
  refine ⟨g, hg, hg0, ?_, huniq, ?_⟩
  · filter_upwards [hroot, hidentity] with q hq hi
    exact ⟨hq, by simp only [hi, eval_mul, hq, mul_zero]⟩
  · intro q q' hq
    exact hfiber q q' (congrArg Prod.snd hq)

/-- Full labelled reconstruction together with holomorphic continuations of a
marked simple source and a marked simple residual critical point. The factor
identity and both actual polynomial-root equations are proved simultaneously. -/
theorem splitting_reconstruction_with_marked_roots
    (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (a : Unknown r s) (α : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ)
    (hM : (rootPolynomial (s + 1) α).eval w ≠ 0)
    (hvalue : (monicPolynomial r a.1 * rootPolynomial (s + 1) α).eval w ≠ 0)
    (hidentity : (monicPolynomial r a.1 * rootPolynomial (s + 1) α).derivative =
      C (r + s + 1 : ℂ) * (X - C w) ^ r * monicPolynomial s a.2)
    (haRoot : (monicPolynomial r a.1).eval a₀ = 0)
    (haSimple : (monicPolynomial r a.1).derivative.eval a₀ ≠ 0)
    (hvRoot : (monicPolynomial s a.2).eval v₀ = 0)
    (hvSimple : (monicPolynomial s a.2).derivative.eval v₀ ≠ 0) :
    ∃ (G : Parameter r s → Unknown r s) (za zv : Parameter r s → ℂ),
      AnalyticAt ℂ G ((fun _ => w), α) ∧ G ((fun _ => w), α) = a ∧
      AnalyticAt ℂ za ((fun _ => w), α) ∧ za ((fun _ => w), α) = a₀ ∧
      AnalyticAt ℂ zv ((fun _ => w), α) ∧ zv ((fun _ => w), α) = v₀ ∧
      (∀ᶠ q in 𝓝 (((fun _ => w), α) : Parameter r s),
        (reconstructedPolynomial r s G q).derivative =
          C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s (G q).2 ∧
        (reconstructedPolynomial r s G q).eval (za q) = 0 ∧
        (reconstructedPolynomial r s G q).derivative.eval (zv q) = 0) ∧
      (∀ᶠ p : Parameter r s × ℂ in 𝓝 ((((fun _ => w), α) : Parameter r s),a₀),
        (monicPolynomial r (G p.1).1).eval p.2 = 0 → p.2 = za p.1) ∧
      (∀ᶠ p : Parameter r s × ℂ in 𝓝 ((((fun _ => w), α) : Parameter r s),v₀),
        (monicPolynomial s (G p.1).2).eval p.2 = 0 → p.2 = zv p.1) ∧
      (∀ (σ : Equiv.Perm (Fin r)) (π : Equiv.Perm (Fin (s + 1))) q,
        za (q.1 ∘ σ, q.2 ∘ π) = za q ∧ zv (q.1 ∘ σ, q.2 ∘ π) = zv q) := by
  obtain ⟨G, hG, hG0, hpoly, hGperm⟩ :=
    splitting_critical_factor_reconstruction r s hr hs a α w hM hvalue hidentity
  obtain ⟨za, hza, hza0, hzaRoot, hzaUnique, hzaFiber⟩ :=
    source_factor_simple_root r s G ((fun _ => w), α) a₀ hG
      (by simpa only [hG0] using haRoot) (by simpa only [hG0] using haSimple)
  obtain ⟨zv, hzv, hzv0, hzvRoot, hzvUnique, hzvFiber⟩ :=
    residual_factor_simple_root r s G ((fun _ => w), α) v₀ hG
      (by simpa only [hG0] using hvRoot) (by simpa only [hG0] using hvSimple) hpoly
  refine ⟨G, za, zv, hG, hG0, hza, hza0, hzv, hzv0, ?_, hzaUnique, hzvUnique, ?_⟩
  · filter_upwards [hpoly, hzaRoot, hzvRoot] with q hq ha hv
    exact ⟨hq, ha.2, hv.2⟩
  · intro σ π q
    exact ⟨hzaFiber _ _ (hGperm σ π q), hzvFiber _ _ (hGperm σ π q)⟩

end PolynomialGeometry.SimpleRoot
