import PolynomialGeometry.UniformPartialMaximum
import Mathlib.Analysis.Calculus.FDeriv.Symmetric

noncomputable section
open scoped Topology
open Filter

namespace PolynomialGeometry.SchurHessian

open PartialMaximum UniformPartialMaximum

section Composition
variable {A B C : Type*} [NormedAddCommGroup A] [NormedSpace ℝ A]
  [NormedAddCommGroup B] [NormedSpace ℝ B] [CompleteSpace B]
  [NormedAddCommGroup C] [NormedSpace ℝ C] [CompleteSpace C]

/-- The second-order chain rule in evaluated Fréchet form. -/
theorem second_fderiv_comp (f : A → B) (g : B → C) (a : A)
    (hf : AnalyticAt ℝ f a) (hg : AnalyticAt ℝ g (f a)) (x y : A) :
    fderiv ℝ (fderiv ℝ (fun z => g (f z))) a x y =
      fderiv ℝ (fderiv ℝ g) (f a) (fderiv ℝ f a x) (fderiv ℝ f a y) +
      fderiv ℝ g (f a) (fderiv ℝ (fderiv ℝ f) a x y) := by
  have hnear : fderiv ℝ (fun z => g (f z)) =ᶠ[𝓝 a]
      fun z => (fderiv ℝ g (f z)).comp (fderiv ℝ f z) := by
    filter_upwards [hf.eventually_analyticAt, hf.continuousAt.eventually hg.eventually_analyticAt]
      with z hz hgz
    exact fderiv_comp' z hgz.differentiableAt hz.differentiableAt
  rw [hnear.fderiv_eq]
  have hcg : HasFDerivAt (fun z => fderiv ℝ g (f z))
      ((fderiv ℝ (fderiv ℝ g) (f a)).comp (fderiv ℝ f a)) a :=
    hg.fderiv.differentiableAt.hasFDerivAt.comp a hf.differentiableAt.hasFDerivAt
  have hd := hcg.clm_comp hf.fderiv.differentiableAt.hasFDerivAt
  rw [hd.fderiv]
  simp only [ContinuousLinearMap.add_apply, ContinuousLinearMap.comp_apply,
    ContinuousLinearMap.compL_apply, ContinuousLinearMap.flip_apply]
  exact add_comm _ _

end Composition

variable {E T : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [FiniteDimensional ℝ E] [NormedAddCommGroup T] [InnerProductSpace ℝ T]
  [FiniteDimensional ℝ T]

omit [FiniteDimensional ℝ E] in
/-- Differentiating the Riesz definition identifies the actual mixed Hessian. -/
theorem partialGradient_hessian_pairing (F : E × T → ℝ) (hF : AnalyticAt ℝ F 0)
    (u : E × T) (v : T) :
    inner ℝ (fderiv ℝ (partialGradient F) 0 u) v =
      fderiv ℝ (fderiv ℝ F) 0 u (0, v) := by
  have hd := (partialGradientMap (E := E) (T := T)).hasFDerivAt.comp (0 : E × T)
    hF.fderiv.differentiableAt.hasFDerivAt
  change HasFDerivAt (partialGradient F)
    ((partialGradientMap (E := E) (T := T)).comp (fderiv ℝ (fderiv ℝ F) 0)) 0 at hd
  rw [hd.fderiv]
  exact InnerProductSpace.toDual_symm_apply

omit [FiniteDimensional ℝ E] in
/-- The envelope identity eliminates the derivative of the response exactly,
because it is a stationary response of the same objective. -/
theorem reduced_fderiv_eventually (F : E × T → ℝ) (hF : AnalyticAt ℝ F 0)
    (θ : E → T) (hθ : AnalyticAt ℝ θ 0) (hθ0 : θ 0 = 0)
    (hstat : ∀ᶠ x in 𝓝 (0 : E), partialGradient F (x, θ x) = 0) :
    fderiv ℝ (fun x => F (x, θ x)) =ᶠ[𝓝 0]
      fun x => (fderiv ℝ F (x, θ x)).comp (ContinuousLinearMap.inl ℝ E T) := by
  have hgraph : ContinuousAt (fun x : E => (x, θ x)) 0 := continuousAt_id.prodMk hθ.continuousAt
  have hFnear : ∀ᶠ x in 𝓝 (0 : E), AnalyticAt ℝ F (x, θ x) :=
    hgraph.eventually (by simpa [hθ0] using hF.eventually_analyticAt)
  filter_upwards [hFnear, hθ.eventually_analyticAt, hstat] with x hxF hxθ hxstat
  have hd := hxF.differentiableAt.hasFDerivAt.comp x
    ((hasFDerivAt_id x).prodMk hxθ.differentiableAt.hasFDerivAt)
  dsimp only [Function.comp_def, id_eq] at hd
  rw [hd.fderiv]
  ext v
  change fderiv ℝ F (x, θ x) (v, fderiv ℝ θ x v) = fderiv ℝ F (x, θ x) (v, 0)
  have hs : fderiv ℝ F (x, θ x) (0, fderiv ℝ θ x v) = 0 := by
    rw [← partialGradient_pairing, hxstat, inner_zero_left]
  calc
    _ = fderiv ℝ F (x, θ x) ((v, 0) + (0, fderiv ℝ θ x v)) := by simp
    _ = _ := by rw [map_add, hs, add_zero]

omit [FiniteDimensional ℝ E] in
/-- The Hessian of the reduced objective, as an actual second Fréchet derivative. -/
theorem reduced_hessian (F : E × T → ℝ) (hF : AnalyticAt ℝ F 0)
    (θ : E → T) (hθ : AnalyticAt ℝ θ 0) (hθ0 : θ 0 = 0)
    (hstat : ∀ᶠ x in 𝓝 (0 : E), partialGradient F (x, θ x) = 0)
    (x y : E) :
    fderiv ℝ (fderiv ℝ (fun x => F (x, θ x))) 0 x y =
      fderiv ℝ (fderiv ℝ F) 0 (x, 0) (y, 0) +
      inner ℝ (fderiv ℝ (partialGradient F) 0 (y, 0)) (fderiv ℝ θ 0 x) := by
  have heq := reduced_fderiv_eventually F hF θ hθ hθ0 hstat
  rw [heq.fderiv_eq]
  have hg : HasFDerivAt (fun x : E => (x, θ x))
      ((ContinuousLinearMap.id ℝ E).prod (fderiv ℝ θ 0)) 0 :=
    (hasFDerivAt_id 0).prodMk hθ.differentiableAt.hasFDerivAt
  have hdF : HasFDerivAt (fderiv ℝ F) (fderiv ℝ (fderiv ℝ F) 0) ((0 : E), θ 0) := by
    simpa [hθ0] using hF.fderiv.differentiableAt.hasFDerivAt
  let restriction : ((E × T) →L[ℝ] ℝ) →L[ℝ] (E →L[ℝ] ℝ) :=
    (ContinuousLinearMap.compL ℝ E (E × T) ℝ).flip (ContinuousLinearMap.inl ℝ E T)
  have hdg := HasFDerivAt.comp (f := fun x : E => (x, θ x)) (g := fderiv ℝ F) (0 : E) hdF hg
  dsimp only [Function.comp_def] at hdg
  have hd := (ContinuousLinearMap.hasFDerivAt restriction (x := fderiv ℝ F (0, θ 0))).comp (0 : E) hdg
  change HasFDerivAt (fun x : E => (fderiv ℝ F (x, θ x)).comp (ContinuousLinearMap.inl ℝ E T))
      (restriction.comp ((fderiv ℝ (fderiv ℝ F) 0).comp
        ((ContinuousLinearMap.id ℝ E).prod (fderiv ℝ θ 0)))) 0 at hd
  rw [hd.fderiv]
  change fderiv ℝ (fderiv ℝ F) 0 (x, fderiv ℝ θ 0 x) (y, 0) = _
  have hsymm : IsSymmSndFDerivAt ℝ F 0 := hF.contDiffAt.isSymmSndFDerivAt_of_omega
  calc
    _ = fderiv ℝ (fderiv ℝ F) 0 ((x, 0) + (0, fderiv ℝ θ 0 x)) (y, 0) := by simp
    _ = fderiv ℝ (fderiv ℝ F) 0 (x, 0) (y, 0) +
        fderiv ℝ (fderiv ℝ F) 0 (0, fderiv ℝ θ 0 x) (y, 0) := by simp only [map_add, ContinuousLinearMap.add_apply]
    _ = _ := by rw [hsymm (0, fderiv ℝ θ 0 x) (y, 0), ← partialGradient_hessian_pairing F hF]

omit [FiniteDimensional ℝ E] in
/-- Schur's formula for the actual analytic reduction. The mixed map is
extracted from the Hessian of F, and P is the negative eliminated block. -/
theorem reduced_hessian_schur (F : E × T → ℝ) (hF : AnalyticAt ℝ F 0)
    (θ : E → T) (hθ : AnalyticAt ℝ θ 0) (hθ0 : θ 0 = 0)
    (hstat : ∀ᶠ x in 𝓝 (0 : E), partialGradient F (x, θ x) = 0)
    (P : T →L[ℝ] T) (hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s))
    (hDθ : HasFDerivAt θ ((positiveHessianEquiv P hP).symm.toContinuousLinearMap.comp
      ((fderiv ℝ (partialGradient F) 0).comp (ContinuousLinearMap.inl ℝ E T))) 0)
    (x y : E) :
    fderiv ℝ (fderiv ℝ (fun x => F (x, θ x))) 0 x y =
      fderiv ℝ (fderiv ℝ F) 0 (x, 0) (y, 0) +
      inner ℝ (fderiv ℝ (partialGradient F) 0 (y, 0))
        ((positiveHessianEquiv P hP).symm (fderiv ℝ (partialGradient F) 0 (x, 0))) := by
  rw [reduced_hessian F hF θ hθ hθ0 hstat, hDθ.fderiv]
  rfl

/-- The constructed analytic partial maximum and its actual Schur Hessian.
All conclusions concern one and the same stationary response. -/
theorem analytic_partial_maximum_with_schur (F : E × T → ℝ)
    (hF : AnalyticAt ℝ F 0) (hF0 : fderiv ℝ F 0 = 0)
    (P : T →L[ℝ] T) (hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s))
    (hss : (fderiv ℝ (partialGradient F) 0).comp (ContinuousLinearMap.inr ℝ E T) = -P) :
    ∃ θ : E → T, AnalyticAt ℝ θ 0 ∧ θ 0 = 0 ∧
      AnalyticAt ℝ (fun x => F (x, θ x)) 0 ∧
      HasFDerivAt θ ((positiveHessianEquiv P hP).symm.toContinuousLinearMap.comp
        ((fderiv ℝ (partialGradient F) 0).comp (ContinuousLinearMap.inl ℝ E T))) 0 ∧
      (∀ᶠ x in 𝓝 (0 : E), partialGradient F (x, θ x) = 0) ∧
      (∀ᶠ p : E × T in 𝓝 0, partialGradient F p = 0 → p.2 = θ p.1) ∧
      (∃ c : ℝ, 0 < c ∧ ∀ᶠ p : E × T in 𝓝 0,
        F p ≤ F (p.1, θ p.1) - c * ‖p.2 - θ p.1‖ ^ 2) ∧
      ((∃ᶠ p : E × T in 𝓝 0, 0 < F p) ↔
        (∃ᶠ x : E in 𝓝 0, 0 < F (x, θ x))) ∧
      (∀ x y : E, fderiv ℝ (fderiv ℝ (fun x => F (x, θ x))) 0 x y =
        fderiv ℝ (fderiv ℝ F) 0 (x, 0) (y, 0) +
        inner ℝ (fderiv ℝ (partialGradient F) 0 (y, 0))
          ((positiveHessianEquiv P hP).symm (fderiv ℝ (partialGradient F) 0 (x, 0)))) := by
  obtain ⟨θ, hθ, hθ0, hDθ, hs, hu, hd, hp⟩ := analytic_partial_maximum F hF hF0 P hP hss
  have hG : AnalyticAt ℝ (fun x => F (x, θ x)) 0 :=
    hF.comp_of_eq' (analyticAt_id.prod hθ) (by simp [hθ0])
  exact ⟨θ, hθ, hθ0, hG, hDθ, hs, hu, hd, hp,
    reduced_hessian_schur F hF θ hθ hθ0 hs P hP hDθ⟩

omit [FiniteDimensional ℝ E] [FiniteDimensional ℝ T] in
/-- A Hessian supported on the eliminated block makes P symmetric. -/
theorem eliminated_operator_symmetric (F : E × T → ℝ) (hF : AnalyticAt ℝ F 0)
    (P : T →L[ℝ] T)
    (hH : ∀ u v : E × T, fderiv ℝ (fderiv ℝ F) 0 u v = -inner ℝ u.2 (P v.2)) :
    ∀ s t : T, inner ℝ (P s) t = inner ℝ s (P t) := by
  have hsymm : IsSymmSndFDerivAt ℝ F 0 := hF.contDiffAt.isSymmSndFDerivAt_of_omega
  intro s t
  have hh := hsymm (0, s) (0, t)
  rw [hH, hH] at hh
  rw [real_inner_comm t (P s)]
  linarith

omit [FiniteDimensional ℝ E] in
/-- The actual partial gradient has no first-order retained component when
the retained space is a Hessian-kernel factor. -/
theorem flat_partialGradient_derivative (F : E × T → ℝ) (hF : AnalyticAt ℝ F 0)
    (P : T →L[ℝ] T)
    (hH : ∀ u v : E × T, fderiv ℝ (fderiv ℝ F) 0 u v = -inner ℝ u.2 (P v.2)) :
    fderiv ℝ (partialGradient F) 0 = -P.comp (ContinuousLinearMap.snd ℝ E T) := by
  apply ContinuousLinearMap.ext
  intro u
  apply ext_inner_right ℝ
  intro s
  rw [partialGradient_hessian_pairing F hF, hH]
  change -inner ℝ u.2 (P s) = inner ℝ (-(P u.2)) s
  rw [inner_neg_left, eliminated_operator_symmetric F hF P hH]

/-- Kernel splitting constructs a flat analytic maximum response. In
particular Dθ(0)=0 is a conclusion of the actual scalar Hessian identity. -/
theorem flat_analytic_partial_maximum (F : E × T → ℝ)
    (hF : AnalyticAt ℝ F 0) (hF0 : fderiv ℝ F 0 = 0)
    (P : T →L[ℝ] T) (hP : ∀ s : T, s ≠ 0 → 0 < inner ℝ s (P s))
    (hH : ∀ u v : E × T, fderiv ℝ (fderiv ℝ F) 0 u v = -inner ℝ u.2 (P v.2)) :
    ∃ θ : E → T, AnalyticAt ℝ θ 0 ∧ θ 0 = 0 ∧ fderiv ℝ θ 0 = 0 ∧
      AnalyticAt ℝ (fun x => F (x, θ x)) 0 ∧
      (∀ᶠ x in 𝓝 (0 : E), partialGradient F (x, θ x) = 0) ∧
      (∀ᶠ p : E × T in 𝓝 0, partialGradient F p = 0 → p.2 = θ p.1) ∧
      (∃ c : ℝ, 0 < c ∧ ∀ᶠ p : E × T in 𝓝 0,
        F p ≤ F (p.1, θ p.1) - c * ‖p.2 - θ p.1‖ ^ 2) ∧
      ((∃ᶠ p : E × T in 𝓝 0, 0 < F p) ↔
        (∃ᶠ x : E in 𝓝 0, 0 < F (x, θ x))) ∧
      fderiv ℝ (fderiv ℝ (fun x => F (x, θ x))) 0 = 0 := by
  have hDg := flat_partialGradient_derivative F hF P hH
  have hss : (fderiv ℝ (partialGradient F) 0).comp (ContinuousLinearMap.inr ℝ E T) = -P := by
    rw [hDg]
    ext s
    rfl
  obtain ⟨θ, hθ, hθ0, hG, hθD, hs, hu, hdom, hp, hschur⟩ :=
    analytic_partial_maximum_with_schur F hF hF0 P hP hss
  have hθD0 : fderiv ℝ θ 0 = 0 := by
    rw [hθD.fderiv, hDg]
    ext x
    simp
  refine ⟨θ, hθ, hθ0, hθD0, hG, hs, hu, hdom, hp, ?_⟩
  ext x y
  rw [hschur, hH, hDg]
  simp

end PolynomialGeometry.SchurHessian
