import Mathlib.Analysis.Normed.Algebra.GelfandFormula
import Mathlib.Analysis.Matrix
import PolynomialGeometry.CompressionDet
import Mathlib.Tactic

/-!
# From strict spectral inclusion to asymptotic decay

Gelfand's formula supplies the missing analytic connection between a
finite-dimensional spectral statement and decay of the actual trajectories.
No decay assumption is inserted into the source theorem.
-/

noncomputable section
open scoped Topology NNReal ENNReal
open Filter Matrix

namespace PolynomialGeometry.Stability

/-- A spectral gap gives an eventual geometric bound for the norms of powers. -/
theorem power_norm_eventually_geometric {A : Type*} [NormedRing A] [NormedAlgebra ℂ A]
    [CompleteSpace A] (a : A) (h : spectralRadius ℂ a < 1) :
    ∃ r : ℝ, 0 ≤ r ∧ r < 1 ∧ ∀ᶠ n : ℕ in atTop, ‖a ^ n‖ ≤ r ^ n := by
  obtain ⟨r, hr, hr1⟩ := ENNReal.lt_iff_exists_nnreal_btwn.mp h
  have hevent : ∀ᶠ n : ℕ in atTop,
      (‖a ^ n‖₊ : ℝ≥0∞) ^ (1 / n : ℝ) < r :=
    (spectrum.gelfand_formula a).eventually (eventually_lt_nhds hr)
  refine ⟨r, r.coe_nonneg, by exact_mod_cast hr1, ?_⟩
  filter_upwards [hevent, eventually_gt_atTop 0] with n hn hn0
  have hp := pow_le_pow_left' hn.le n
  have hb : (‖a ^ n‖₊ : ℝ≥0∞) ≤ (r : ℝ≥0∞) ^ n := by
    simpa only [one_div, ENNReal.rpow_inv_natCast_pow (Nat.ne_of_gt hn0)] using hp
  exact_mod_cast hb

/-- Strict spectral radius implies decay of powers in a complex Banach algebra. -/
theorem powers_tendsto_zero {A : Type*} [NormedRing A] [NormedAlgebra ℂ A]
    [CompleteSpace A] (a : A) (h : spectralRadius ℂ a < 1) :
    Tendsto (fun n : ℕ => a ^ n) atTop (𝓝 0) := by
  obtain ⟨r, hr, hr1, hb⟩ := power_norm_eventually_geometric a h
  exact tendsto_zero_iff_norm_tendsto_zero.mpr
    (squeeze_zero' (Eventually.of_forall fun _ => norm_nonneg _) hb
      (tendsto_pow_atTop_nhds_zero_of_lt_one hr hr1))

section Matrix
variable {ι : Type*} [Fintype ι] [DecidableEq ι]
attribute [local instance] Matrix.linftyOpNormedRing Matrix.linftyOpNormedAlgebra

/-- The actual state sequence tends to zero under strict spectral inclusion. -/
theorem states_tendsto_zero (T : Matrix ι ι ℂ)
    (h : ∀ z : ℂ, T.charpoly.IsRoot z → ‖z‖ < 1) (x : ι → ℂ) :
    Tendsto (fun n : ℕ => (T ^ n).mulVec x) atTop (𝓝 0) := by
  have hp := powers_tendsto_zero T (CompressionDet.spectralRadius_lt_one_of_charpoly_roots T h)
  apply tendsto_zero_iff_norm_tendsto_zero.mpr
  have hb : ∀ n : ℕ, ‖(T ^ n).mulVec x‖ ≤ ‖T ^ n‖ * ‖x‖ :=
    fun n => Matrix.linfty_opNorm_mulVec _ _
  exact squeeze_zero (fun _ => norm_nonneg _) hb (by
    simpa using hp.norm.mul_const ‖x‖)

end Matrix
end PolynomialGeometry.Stability
