import PolynomialGeometry.SimpleRoot
import PolynomialGeometry.RatioCoordinates

/-!
# Logarithmic-ratio coordinates for the actual reconstructed polynomial

This composes the moving critical-factor reconstruction, its marked simple
roots, and the computed logarithmic-ratio inverse. The diagonal response
condition is imposed on the constructed branches themselves.
-/
noncomputable section
open Polynomial Filter
open scoped Topology
namespace PolynomialGeometry.ReconstructionRatios
open PolynomialGeometry.CriticalReconstruction
open PolynomialGeometry.Factorization
open PolynomialGeometry.SimpleRoot
open PolynomialGeometry.RatioCoordinates

/-- The actual reconstructed polynomial admits full labelled logarithmic-ratio
coordinates whenever its actual common-shift response is nonzero. Neither
analytic root branches nor their permutation symmetry are hypotheses here. -/
theorem reconstructed_logarithmic_ratio_coordinates
    (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (a : Unknown r s) (α : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ)
    (hM : (rootPolynomial (s + 1) α).eval w ≠ 0)
    (hvalue : (monicPolynomial r a.1 * rootPolynomial (s + 1) α).eval w ≠ 0)
    (hidentity : (monicPolynomial r a.1 * rootPolynomial (s + 1) α).derivative =
      C (r + s + 1 : ℂ) * (X - C w) ^ r * monicPolynomial s a.2)
    (haRoot : (monicPolynomial r a.1).eval a₀ = 0)
    (haSimple : (monicPolynomial r a.1).derivative.eval a₀ ≠ 0)
    (hvRoot : (monicPolynomial s a.2).eval v₀ = 0)
    (hvSimple : (monicPolynomial s a.2).derivative.eval v₀ ≠ 0)
    (hq : w - a₀ ≠ 0) (hg : v₀ - a₀ ≠ 0) :
    ∃ (G : Parameter r s → Unknown r s) (za zv : Parameter r s → ℂ),
      AnalyticAt ℂ G ((fun _ => w), α) ∧ G ((fun _ => w), α) = a ∧
      AnalyticAt ℂ za ((fun _ => w), α) ∧ za ((fun _ => w), α) = a₀ ∧
      AnalyticAt ℂ zv ((fun _ => w), α) ∧ zv ((fun _ => w), α) = v₀ ∧
      (∀ᶠ q in 𝓝 (((fun _ => w), α) : Parameter r s),
        (reconstructedPolynomial r s G q).derivative =
          C (r + s + 1 : ℂ) * rootPolynomial r q.1 * monicPolynomial s (G q).2 ∧
        (reconstructedPolynomial r s G q).eval (za q) = 0 ∧
        (reconstructedPolynomial r s G q).derivative.eval (zv q) = 0) ∧
      (∀ (σ : Equiv.Perm (Fin r)) (π : Equiv.Perm (Fin (s + 1))) q,
        za (q.1 ∘ σ, q.2 ∘ π) = za q ∧ zv (q.1 ∘ σ, q.2 ∘ π) = zv q) ∧
      (deriv (fun t => parameterLogRatios za zv (w - a₀) (v₀ - a₀)
          ((fun _ => t), α) ⟨0, hr⟩) w ≠ 0 →
        ∃ H : Parameter r s → Parameter r s,
          AnalyticAt ℂ H (0, α) ∧ H (0, α) = ((fun _ => w), α) ∧
          (∀ᶠ q in 𝓝 (((fun _ => w), α) : Parameter r s),
            H (parameterLogRatios za zv (w - a₀) (v₀ - a₀) q, q.2) = q) ∧
          (∀ᶠ Z in 𝓝 ((0, α) : Parameter r s),
            (parameterLogRatios za zv (w - a₀) (v₀ - a₀) (H Z), (H Z).2) = Z)) := by
  letI : NeZero r := ⟨Nat.ne_of_gt hr⟩
  obtain ⟨G, za, zv, hG, hG0, hza, hza0, hzv, hzv0, hpoly, _, _, hperm⟩ :=
    splitting_reconstruction_with_marked_roots r s hr hs a α w a₀ v₀
      hM hvalue hidentity haRoot haSimple hvRoot hvSimple
  refine ⟨G, za, zv, hG, hG0, hza, hza0, hzv, hzv0, hpoly, hperm, ?_⟩
  intro hdiag
  apply parameter_logRatios_local_inverse za zv (w - a₀) (v₀ - a₀) w α ⟨0, hr⟩
    hza hzv hq hg
  · rw [hza0]
  · rw [hza0, hzv0]
  · intro σ
    apply Filter.Eventually.of_forall
    intro z
    simpa using (hperm σ (Equiv.refl _) (z, α)).1
  · intro σ
    apply Filter.Eventually.of_forall
    intro z
    simpa using (hperm σ (Equiv.refl _) (z, α)).2
  · exact hdiag

end PolynomialGeometry.ReconstructionRatios
