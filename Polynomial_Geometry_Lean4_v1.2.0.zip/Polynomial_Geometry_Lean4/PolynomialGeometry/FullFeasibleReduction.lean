import PolynomialGeometry.FullReconstruction
import PolynomialGeometry.ChartTransport
import PolynomialGeometry.PolynomialFeasibleChart
import PolynomialGeometry.RealBoundaryCoverage
import PolynomialGeometry.FullRatioChart
import PolynomialGeometry.WeightedBoundaryStrict

/-! # Transport of the exact feasible reduction to all nearby polynomials

The coefficient chart is constructed from the same labelled reconstruction.
Its neighborhood surjectivity follows from the proved full coverage theorem.
The selected root is independently continued in coefficient space and is
identified with the reconstructed selected root by local uniqueness.
-/
noncomputable section
open Polynomial Filter
open scoped Topology

namespace PolynomialGeometry.FullFeasibleReduction
open Factorization CriticalReconstruction SimpleRoot ReconstructionCompletion
open ChartTransport PolynomialFeasibleChart FeasibleReduction

abbrev Coefficients (r s : ℕ) := Fin (r + (s + 1)) → ℂ

/-- Coefficients of the actual reconstructed polynomial. -/
def coefficientChart (r s : ℕ) (R : Parameter r s → Unknown r s)
    (q : Parameter r s) : Coefficients r s :=
  factorCoefficientMap r (s + 1) ((R q).1, rootCoefficients (s + 1) q.2)

theorem monic_coefficientChart (r s : ℕ) (R : Parameter r s → Unknown r s)
    (q : Parameter r s) :
    monicPolynomial (r + (s + 1)) (coefficientChart r s R q) =
      reconstructedPolynomial r s R q := by
  rw [coefficientChart, monicPolynomial_factorCoefficientMap, monicPolynomial_rootCoefficients]
  rfl

theorem coefficientChart_analytic (r s : ℕ) (R : Parameter r s → Unknown r s)
    (q₀ : Parameter r s) (hR : AnalyticAt ℂ R q₀) :
    AnalyticAt ℂ (coefficientChart r s R) q₀ := by
  apply (factorCoefficientMap_analyticAt r (s + 1) _).comp
  exact (analyticAt_fst.comp hR).prod
    ((rootCoefficients_analyticAt (s + 1) q₀.2).comp analyticAt_snd)

def baseCoefficients (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ) : Coefficients r s :=
  fun k => (A * rootPolynomial (s + 1) β).coeff k

theorem coefficientChart_base (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ)
    (w a₀ v₀ : ℂ) (R : LocalReconstructionResult r s A β w a₀ v₀) :
    coefficientChart r s R.family ((fun _ => w), β) = baseCoefficients r s A β := by
  ext k
  simp only [coefficientChart, factorCoefficientMap, monicPolynomial_rootCoefficients,
    R.family_base, baseCoefficients]

/-- Full polynomial coverage becomes exact equality of neighborhood filters,
including at collisions of both labelled lists. -/
theorem coefficientChart_map_nhds (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ)
    (w a₀ v₀ : ℂ) (R : LocalReconstructionResult r s A β w a₀ v₀) :
    Filter.map (coefficientChart r s R.family) (𝓝 (((fun _ => w), β) : Parameter r s)) =
      𝓝 (baseCoefficients r s A β) := by
  apply map_nhds_of_rectangular_coverage _ (fun _ => w) β _
    (coefficientChart_analytic r s R.family _ R.family_analytic).continuousAt
    (coefficientChart_base r s A β w a₀ v₀ R)
  intro U V hU hw hV hβ
  filter_upwards [R.full_coverage U V hU hw hV hβ] with p hp
  obtain ⟨q, hqU, hqV, hqp⟩ := hp
  refine ⟨q, hqU, hqV, ?_⟩
  ext k
  have hh := congrArg (fun P : ℂ[X] => P.coeff k)
    ((monic_coefficientChart r s R.family q).trans hqp)
  simpa only [monicPolynomial_coeff] using hh

theorem basePolynomial_eq (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ)
    (w a₀ v₀ : ℂ) (R : LocalReconstructionResult r s A β w a₀ v₀) :
    monicPolynomial (r + (s + 1)) (baseCoefficients r s A β) =
      A * rootPolynomial (s + 1) β := by
  rw [← coefficientChart_base r s A β w a₀ v₀ R, monic_coefficientChart]
  simp only [reconstructedPolynomial, R.family_base]

/-- The selected simple source is a genuine coefficient-space branch, and
its value agrees locally with the branch of the same reconstructed family. -/
theorem selected_root_descends_to_coefficients
    (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ)
    (R : LocalReconstructionResult r s A β w a₀ v₀)
    (haRoot : A.eval a₀ = 0) (haSimple : A.derivative.eval a₀ ≠ 0)
    (haInterior : ‖a₀‖ < 1) (hboundary : ∀ j, ‖β j‖ = 1) :
    ∃ a : Coefficients r s → ℂ,
      AnalyticAt ℂ a (baseCoefficients r s A β) ∧
      a (baseCoefficients r s A β) = a₀ ∧
      (∀ᶠ p in 𝓝 (baseCoefficients r s A β),
        (monicPolynomial (r + (s + 1)) p).eval (a p) = 0) ∧
      (∀ᶠ q in 𝓝 (((fun _ => w), β) : Parameter r s),
        a (coefficientChart r s R.family q) = R.sourceRoot q) := by
  have hM : (rootPolynomial (s + 1) β).eval a₀ ≠ 0 := by
    simp only [rootPolynomial, eval_prod, eval_sub, eval_X, eval_C]
    apply Finset.prod_ne_zero_iff.mpr
    intro j _
    apply sub_ne_zero.mpr
    intro heq
    have hh := hboundary j
    rw [← heq] at hh
    linarith
  have hbase := basePolynomial_eq r s A β w a₀ v₀ R
  have hz : (monicPolynomial (r + (s + 1)) (baseCoefficients r s A β)).eval a₀ = 0 := by
    rw [hbase, eval_mul, haRoot, zero_mul]
  have hsimple : (monicPolynomial (r + (s + 1)) (baseCoefficients r s A β)).derivative.eval a₀ ≠ 0 := by
    rw [hbase, derivative_mul, eval_add, eval_mul, eval_mul, haRoot, zero_mul, add_zero]
    exact mul_ne_zero haSimple hM
  obtain ⟨a, ha, ha0, haroot, haunique⟩ :=
    monic_simple_root (r + (s + 1)) (baseCoefficients r s A β) a₀ hz hsimple
  refine ⟨a, ha, ha0, haroot, ?_⟩
  have hc := (coefficientChart_analytic r s R.family _ R.family_analytic).continuousAt
  have hp : ContinuousAt (fun q => (coefficientChart r s R.family q, R.sourceRoot q))
      (((fun _ => w), β) : Parameter r s) := hc.prodMk R.source_analytic.continuousAt
  have hp0 : (coefficientChart r s R.family ((fun _ => w), β),
      R.sourceRoot ((fun _ => w), β)) = (baseCoefficients r s A β, a₀) := by
    rw [coefficientChart_base, R.source_base]
  have hpu := hp.eventually (by simpa only [hp0] using haunique)
  filter_upwards [hpu, R.identities] with q hq hid
  apply (hq ?_).symm
  rw [monic_coefficientChart]
  exact hid.2.1


/-- The ball definition of arbitrarily nearby improvement is exactly filter
frequency at the origin. -/
theorem arbitrarilyNearPositive_iff_frequently {E : Type*} [NormedAddCommGroup E]
    (f : E → ℝ) (feasible : E → Prop) :
    arbitrarilyNearPositive f feasible ↔ ∃ᶠ x in 𝓝 (0 : E), feasible x ∧ 0 < f x := by
  rw [Metric.nhds_basis_ball.frequently_iff]
  simp only [arbitrarilyNearPositive, Metric.mem_ball, dist_zero_right]

/-- The strict inactive gap and disk equivalence are obtained for the same
full covering reconstruction, from the original polynomial's gap. -/
theorem full_chart_geometry
    (r s : ℕ) (hr : 0 < r) (A : ℂ[X]) (β : Fin (s + 1 + 1) → ℂ)
    (w a₀ v₀ : ℂ) (D : ℝ) (hD : 0 < D)
    (R : LocalReconstructionResult r (s + 1) A β w a₀ v₀)
    (hq : ‖w-a₀‖ = D) (hg : ‖v₀-a₀‖ = D)
    (hgap : ∀ z, (A * rootPolynomial (s + 1 + 1) β).derivative.IsRoot z →
      z ≠ w → z ≠ v₀ → D < ‖z-a₀‖) :
    ∀ᶠ q in 𝓝 (((fun _ => w), β) : Parameter r (s + 1)),
      (rootsInDisk (reconstructedPolynomial r (s + 1) R.family q) ↔
        ∀ j, ‖q.2 j‖ ≤ 1) ∧
      criticalDistance (reconstructedPolynomial r (s + 1) R.family q) (R.sourceRoot q) =
        activeDistance (R.sourceRoot q) (R.simpleCritical q) q.1 ∧
      R.simpleCritical q - R.sourceRoot q ≠ 0 ∧
      (∀ i, q.1 i - R.sourceRoot q ≠ 0) := by
  letI : NeZero r := ⟨Nat.ne_of_gt hr⟩
  let q₀ : Parameter r (s + 1) := ((fun _ => w), β)
  have hc : (r + (s + 1) + 1 : ℂ) ≠ 0 := by
    exact_mod_cast (by omega : r + (s + 1) + 1 ≠ 0)
  have hid0 := (R.identities.self_of_nhds).1
  have hidbase : (A * rootPolynomial (s + 1 + 1) β).derivative =
      C (r + (s + 1) + 1 : ℂ) * rootPolynomial r (fun _ => w) *
        monicPolynomial (s + 1) (R.family q₀).2 := by
    simpa only [reconstructedPolynomial, R.family_base, q₀, Nat.cast_add, Nat.cast_one] using hid0
  have hgu : ∀ z, (monicPolynomial (s + 1) (R.family q₀).2).IsRoot z →
      z ≠ R.simpleCritical q₀ → D < ‖z - R.sourceRoot q₀‖ := by
    intro z hz hneq
    rw [R.source_base]
    apply hgap z
    · rw [Polynomial.IsRoot, hidbase, eval_mul, hz, mul_zero]
    · intro hzw
      subst z
      exact R.residual_base_nonzero hz
    · simpa only [q₀, R.critical_base] using hneq
  have hgeom := reconstructed_family_geometry r s (s + 1 + 1)
    (fun q : Parameter r (s + 1) => (R.family q).1)
    (fun q => (R.family q).2) Prod.fst Prod.snd R.sourceRoot R.simpleCritical q₀
    (r + (s + 1) + 1) (w-a₀) (v₀-a₀) D 0
    R.family_analytic.continuousAt.fst R.family_analytic.continuousAt.snd
    continuousAt_fst R.source_analytic.continuousAt R.critical_analytic.continuousAt
    hc hD hq hg (fun i => by simp [q₀, R.source_base])
    (by simp [q₀, R.source_base, R.critical_base])
    R.interior_roots.self_of_nhds
    (by simpa only [q₀, R.critical_base] using R.residual_base_simple)
    R.residual_factor_root.self_of_nhds hgu
    (R.identities.mono fun _ h => by simpa only [reconstructedPolynomial, Nat.cast_add, Nat.cast_one] using h.1) R.residual_factor_root
  have hqne : w-a₀ ≠ 0 := norm_ne_zero_iff.mp (hq ▸ hD.ne')
  have hgne : v₀-a₀ ≠ 0 := norm_ne_zero_iff.mp (hg ▸ hD.ne')
  have hnv : ∀ᶠ q in 𝓝 q₀, R.simpleCritical q - R.sourceRoot q ≠ 0 :=
    (R.critical_analytic.continuousAt.sub R.source_analytic.continuousAt).eventually_ne
      (by simpa only [q₀, R.source_base, R.critical_base] using hgne)
  have hnz : ∀ᶠ q in 𝓝 q₀, ∀ i, q.1 i - R.sourceRoot q ≠ 0 := by
    apply Filter.eventually_all.mpr
    intro i
    exact (((continuous_apply i).continuousAt.comp continuousAt_fst).sub
      R.source_analytic.continuousAt).eventually_ne
      (by simpa only [q₀, R.source_base] using hqne)
  filter_upwards [hgeom, hnv, hnz] with q hq hv hz
  exact ⟨hq.1, hq.2.1, hv, hz⟩


/-- The actual reduced objective on the balanced boundary slice. -/
def reducedLogObjective (r s : ℕ) (a v : Parameter r s → ℂ)
    (G : Parameter r s → Parameter r s) (q g : ℂ)
    (β : Fin (s + 1) → ℂ) (τ : ℝ)
    (u : (Fin r → ℝ) × (Fin (s + 1) → ℝ)) : ℝ :=
  (WeightedStationarity.weightedLog a v q g τ (G
    (fun i => Complex.I * u.1 i,
      fun j => β j * Complex.exp (Complex.I * u.2 j)))).re

/-- The explicit strict outward derivative condition on the actual chart. -/
def radialCondition (r s : ℕ) (a v : Parameter r s → ℂ)
    (G : Parameter r s → Parameter r s) (q g : ℂ)
    (β : Fin (s + 1) → ℂ) (τ : ℝ) : Prop :=
  ∀ j, 0 < fderiv ℝ (RealBoundaryChart.smoothObjective
    (fun p => WeightedStationarity.weightedLog a v q g τ (G p)) β) 0
      (0, (Pi.single j 1, 0))

/-- The original one-complex-variable free-stationarity condition. -/
def freeStationarity (r s : ℕ) (a v : Parameter r s → ℂ)
    (q g w : ℂ) (β : Fin (s + 1) → ℂ) (τ : ℝ) : Prop :=
  HasDerivAt (fun t : ℂ =>
    (τ : ℂ) * Complex.log (q⁻¹ * (t-a ((fun _ => t),β))) +
    (1-τ) * Complex.log (g⁻¹ * (v ((fun _ => t),β)-a ((fun _ => t),β)))) 0 w

set_option maxHeartbeats 2000000 in
/-- Exact transport of the distance reduction to every nearby coefficient
vector. The selected source is constructed in coefficient space, and all
objective and feasibility identifications are proved from the same family. -/
theorem coefficient_space_exact_reduction
    (r s : ℕ) (hr : 0 < r) (A : ℂ[X]) (β : Fin (s + 1 + 1) → ℂ)
    (w a₀ v₀ : ℂ) (D τ : ℝ) (hD : 0 < D) (hτ : 0 < τ) (hτ1 : τ < 1)
    (R : LocalReconstructionResult r (s + 1) A β w a₀ v₀)
    (hboundary : ∀ j, ‖β j‖ = 1) (hq : ‖w-a₀‖ = D) (hg : ‖v₀-a₀‖ = D)
    (hgap : ∀ z, (A * rootPolynomial (s + 1 + 1) β).derivative.IsRoot z →
      z ≠ w → z ≠ v₀ → D < ‖z-a₀‖)
    (G : Parameter r (s + 1) → Parameter r (s + 1))
    (hG : AnalyticAt ℂ G (0,β)) (hG0 : G (0,β) = ((fun _ => w),β))
    (hright : ∀ᶠ p in 𝓝 ((0,β) : Parameter r (s + 1)),
      FullRatioChart.forward r (s + 1) R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) (G p) = p)
    (hparam : ∀ᶠ p in 𝓝 ((0,β) : Parameter r (s + 1)), (G p).2 = p.2)
    (hmapG : Filter.map G (𝓝 ((0,β) : Parameter r (s + 1))) =
      𝓝 (((fun _ => w),β) : Parameter r (s + 1)))
    (hfree : freeStationarity r (s + 1) R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) w β τ)
    (hrad : radialCondition r (s + 1) R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β τ) :
    ∃ a : Coefficients r (s + 1) → ℂ,
      AnalyticAt ℂ a (baseCoefficients r (s + 1) A β) ∧
      a (baseCoefficients r (s + 1) A β) = a₀ ∧
      (∀ᶠ p in 𝓝 (baseCoefficients r (s + 1) A β),
        (monicPolynomial (r + (s + 1 + 1)) p).eval (a p) = 0) ∧
      ((∃ᶠ p in 𝓝 (baseCoefficients r (s + 1) A β),
          rootsInDisk (monicPolynomial (r + (s + 1 + 1)) p) ∧
          D < criticalDistance (monicPolynomial (r + (s + 1 + 1)) p) (a p)) ↔
        arbitrarilyNearPositive
          (reducedLogObjective r (s + 1) R.sourceRoot R.simpleCritical G
            (w-a₀) (v₀-a₀) β τ) (fun _ => True)) := by
  letI : NeZero r := ⟨Nat.ne_of_gt hr⟩
  have haRoot : A.eval a₀ = 0 := by
    simpa only [R.family_base, R.source_base] using R.source_factor_root.self_of_nhds
  have haSimple : A.derivative.eval a₀ ≠ 0 := by
    simpa only [R.family_base] using R.source_base_simple
  have haInterior : ‖a₀‖ < 1 := by
    have hi := R.interior_roots.self_of_nhds
    rw [R.family_base] at hi
    exact hi a₀ haRoot
  obtain ⟨a, ha, ha0, haroot, haeq⟩ :=
    selected_root_descends_to_coefficients r (s + 1) A β w a₀ v₀ R
      haRoot haSimple haInterior hboundary
  refine ⟨a, ha, ha0, haroot, ?_⟩
  let C := RealBoundaryChart.Coordinates (ι := Fin r) (κ := Fin (s + 1 + 1))
  let T : C → Parameter r (s + 1) := fun p => G (RealBoundaryChart.chart β p)
  let Φ : C → Coefficients r (s + 1) := fun p => coefficientChart r (s + 1) R.family (T p)
  let F := RealBoundaryChart.smoothObjective
    (fun p => WeightedStationarity.weightedLog R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) τ (G p)) β
  have hβne : ∀ j, β j ≠ 0 := fun j => norm_ne_zero_iff.mp (by rw [hboundary j]; norm_num)
  have hmapC := RealBoundaryCoverage.chart_map_nhds (ι := Fin r) β hβne
  have hmapT : Filter.map T (𝓝 0) = 𝓝 (((fun _ => w),β) : Parameter r (s + 1)) := by
    rw [show T = G ∘ RealBoundaryChart.chart β from rfl, ← Filter.map_map, hmapC, hmapG]
  have hmapΦ : Filter.map Φ (𝓝 0) = 𝓝 (baseCoefficients r (s + 1) A β) := by
    rw [show Φ = coefficientChart r (s + 1) R.family ∘ T from rfl,
      ← Filter.map_map, hmapT, coefficientChart_map_nhds]
  have hT : Tendsto T (𝓝 0) (𝓝 (((fun _ => w),β) : Parameter r (s + 1))) := hmapT.le
  have hchart : Tendsto (RealBoundaryChart.chart (ι := Fin r) β) (𝓝 0)
      (𝓝 ((0,β) : Parameter r (s + 1))) := hmapC.le
  have hgeom := hT.eventually (full_chart_geometry r s hr A β w a₀ v₀ D hD R hq hg hgap)
  have hroot := hT.eventually haeq
  have hright' := hchart.eventually hright
  have hfeas : ∀ᶠ p : C in 𝓝 0,
      rootsInDisk (monicPolynomial (r + (s + 1 + 1)) (Φ p)) ↔ ∀ j, p.2.1 j ≤ 0 := by
    filter_upwards [hgeom, hright'] with p hp hrightp
    change rootsInDisk (monicPolynomial _ (coefficientChart _ _ R.family (T p))) ↔ _
    rw [monic_coefficientChart, hp.1]
    have hsnd := congrArg (fun q : Parameter r (s + 1) => q.2) hrightp
    change (T p).2 = (RealBoundaryChart.chart β p).2 at hsnd
    rw [hsnd]
    exact RealBoundaryChart.chart_sources_disk_iff β hboundary p
  have hpos : ∀ᶠ p : C in 𝓝 0,
      0 < Real.log (criticalDistance (monicPolynomial (r + (s + 1 + 1)) (Φ p)) (a (Φ p)) / D) ↔
        0 < objective F τ p := by
    filter_upwards [hgeom, hroot, hright'] with p hp harp hrightp
    change 0 < Real.log (criticalDistance (monicPolynomial _
      (coefficientChart _ _ R.family (T p))) (a (coefficientChart _ _ R.family (T p))) / D) ↔ _
    rw [monic_coefficientChart, harp, hp.2.1]
    have he := WeightedStationarity.inverse_chart_distance_objective
      R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β D τ p hD hq hg
      hp.2.2.1 hp.2.2.2 (congrArg (fun q : Parameter r (s + 1) => q.1) hrightp)
    rw [he]
  have htransport := nearby_improvement_transport Φ (0 : C) (baseCoefficients r (s + 1) A β)
    hmapΦ (fun p => Real.log (criticalDistance (monicPolynomial (r + (s + 1 + 1)) p) (a p) / D))
    (objective F τ) (fun p => rootsInDisk (monicPolynomial (r + (s + 1 + 1)) p))
    (fun p => ∀ j, p.2.1 j ≤ 0) hfeas hpos
  have hleft : (∃ᶠ p in 𝓝 (baseCoefficients r (s + 1) A β),
      rootsInDisk (monicPolynomial (r + (s + 1 + 1)) p) ∧
      D < criticalDistance (monicPolynomial (r + (s + 1 + 1)) p) (a p)) ↔
    (∃ᶠ p : C in 𝓝 0, (∀ j, p.2.1 j ≤ 0) ∧ 0 < objective F τ p) := by
    simpa only [criticalDistance_log_positive_iff _ _ D hD] using htransport
  rw [hleft, ← arbitrarilyNearPositive_iff_frequently]
  apply WeightedStationarity.weighted_boundary_reduction R.sourceRoot R.simpleCritical G
    (w-a₀) (v₀-a₀) w β τ hτ hτ1 R.source_analytic R.critical_analytic
    (norm_ne_zero_iff.mp (hq ▸ hD.ne')) (norm_ne_zero_iff.mp (hg ▸ hD.ne'))
    (by rw [R.source_base]) (by rw [R.source_base, R.critical_base])
    (fun σ z => by simpa using (R.permutation_invariance σ (Equiv.refl _) (z,β)).2.1)
    (fun σ z => by simpa using (R.permutation_invariance σ (Equiv.refl _) (z,β)).2.2)
    hG hG0 hparam hfree hrad


/-- Labelled roots on the balanced boundary slice of the same inverse chart. -/
def balancedLabels (r s : ℕ) (G : Parameter r s → Parameter r s)
    (β : Fin (s + 1) → ℂ) (u : (Fin r → ℝ) × (Fin (s + 1) → ℝ)) : Parameter r s :=
  G (RealBoundaryChart.chart β (0, (0, u)))

set_option maxHeartbeats 1000000 in
/-- The reduced slice consists of actual disk polynomials. Every boundary
copy stays on the circle, every interior root stays strictly interior, all
active distances agree, and the reduced objective is their exact log gain. -/
theorem balanced_slice_geometry
    (r s : ℕ) (hr : 0 < r) (A : ℂ[X]) (β : Fin (s + 1 + 1) → ℂ)
    (w a₀ v₀ : ℂ) (D τ : ℝ) (hD : 0 < D)
    (R : LocalReconstructionResult r (s + 1) A β w a₀ v₀)
    (hboundary : ∀ j, ‖β j‖ = 1) (hq : ‖w-a₀‖ = D) (hg : ‖v₀-a₀‖ = D)
    (hgap : ∀ z, (A * rootPolynomial (s + 1 + 1) β).derivative.IsRoot z →
      z ≠ w → z ≠ v₀ → D < ‖z-a₀‖)
    (G : Parameter r (s + 1) → Parameter r (s + 1))
    (hG : AnalyticAt ℂ G (0,β)) (hG0 : G (0,β) = ((fun _ => w),β))
    (hright : ∀ᶠ p in 𝓝 ((0,β) : Parameter r (s + 1)),
      FullRatioChart.forward r (s + 1) R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) (G p) = p) :
    ∀ᶠ u : (Fin r → ℝ) × (Fin (s + 1 + 1) → ℝ) in 𝓝 0,
      let t := balancedLabels r (s + 1) G β u
      rootsInDisk (reconstructedPolynomial r (s + 1) R.family t) ∧
      (∀ j, ‖t.2 j‖ = 1) ∧
      (∀ z, (monicPolynomial r (R.family t).1).IsRoot z → ‖z‖ < 1) ∧
      (∀ i, ‖t.1 i - R.sourceRoot t‖ = ‖R.simpleCritical t - R.sourceRoot t‖) ∧
      criticalDistance (reconstructedPolynomial r (s + 1) R.family t) (R.sourceRoot t) =
        ‖R.simpleCritical t - R.sourceRoot t‖ ∧
      Real.log (criticalDistance (reconstructedPolynomial r (s + 1) R.family t) (R.sourceRoot t) / D) =
        reducedLogObjective r (s + 1) R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β τ u := by
  letI : NeZero r := ⟨Nat.ne_of_gt hr⟩
  let U := (Fin r → ℝ) × (Fin (s + 1 + 1) → ℝ)
  let C := RealBoundaryChart.Coordinates (ι := Fin r) (κ := Fin (s + 1 + 1))
  let inc : U → C := fun u => (0, (0, u))
  have hi : Tendsto inc (𝓝 0) (𝓝 0) :=
    (continuous_const.prodMk (continuous_const.prodMk continuous_id)).continuousAt.tendsto
  have hc : Tendsto (RealBoundaryChart.chart (ι := Fin r) β) (𝓝 0)
      (𝓝 ((0,β) : Parameter r (s + 1))) := by
    simpa only [RealBoundaryChart.chart_zero] using (RealBoundaryChart.chart_analyticAt (ι := Fin r) β 0).continuousAt.tendsto
  have hGt : Tendsto G (𝓝 ((0,β) : Parameter r (s + 1)))
      (𝓝 (((fun _ => w),β) : Parameter r (s + 1))) := by
    simpa only [hG0] using hG.continuousAt.tendsto
  have ht : Tendsto (balancedLabels r (s + 1) G β) (𝓝 0)
      (𝓝 (((fun _ => w),β) : Parameter r (s + 1))) := hGt.comp (hc.comp hi)
  have hgeom := ht.eventually (full_chart_geometry r s hr A β w a₀ v₀ D hD R hq hg hgap)
  have hI := ht.eventually R.interior_roots
  have hright' := (hc.comp hi).eventually hright
  filter_upwards [hgeom, hI, hright'] with u hu hIu hru
  let t := balancedLabels r (s + 1) G β u
  have hratio := congrArg (fun q : Parameter r (s + 1) => q.1) hru
  have hsnd := congrArg (fun q : Parameter r (s + 1) => q.2) hru
  change t.2 = (RealBoundaryChart.chart β (0,(0,u))).2 at hsnd
  have hcircle : ∀ j, ‖t.2 j‖ = 1 := by
    rw [hsnd]
    exact RealBoundaryChart.chart_sources_on_circle β hboundary (0,(0,u)) rfl
  have heq := WeightedStationarity.inverse_chart_balanced_distances_equal
    R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β D (0,(0,u)) hD hq hg rfl
    hu.2.2.1 hu.2.2.2 hratio
  change ∀ i, ‖t.1 i - R.sourceRoot t‖ = ‖R.simpleCritical t - R.sourceRoot t‖ at heq
  have hdisk : rootsInDisk (reconstructedPolynomial r (s + 1) R.family t) :=
    hu.1.mpr (fun j => (hcircle j).le)
  have hactive : activeDistance (R.sourceRoot t) (R.simpleCritical t) t.1 =
      ‖R.simpleCritical t - R.sourceRoot t‖ := by
    classical
    simp only [activeDistance, heq, Finset.image_const Finset.univ_nonempty]
    simp
  have hlog := WeightedStationarity.inverse_chart_distance_objective
    R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β D τ (0,(0,u)) hD hq hg
    hu.2.2.1 hu.2.2.2 hratio
  refine ⟨hdisk, hcircle, hIu, heq, hu.2.1.trans hactive, ?_⟩
  rw [hu.2.1]
  dsimp only [balancedLabels]
  rw [hlog]
  simp only [objective, Variations.penalty_zero, sub_zero,
    RealBoundaryChart.reduced_objective]
  rfl


/-- The real-coordinate chart covers every sufficiently near coefficient
vector; no labelled perturbation is being substituted for coefficient space. -/
theorem coefficientRealChart_map_nhds
    (r s : ℕ) (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ)
    (R : LocalReconstructionResult r s A β w a₀ v₀)
    (hβ : ∀ j, β j ≠ 0) (G : Parameter r s → Parameter r s)
    (hmapG : Filter.map G (𝓝 ((0,β) : Parameter r s)) =
      𝓝 (((fun _ => w),β) : Parameter r s)) :
    Filter.map (fun p : RealBoundaryChart.Coordinates (ι := Fin r) (κ := Fin (s + 1)) =>
      coefficientChart r s R.family (G (RealBoundaryChart.chart β p))) (𝓝 0) =
        𝓝 (baseCoefficients r s A β) := by
  have hC := RealBoundaryCoverage.chart_map_nhds (ι := Fin r) β hβ
  change Filter.map (coefficientChart r s R.family ∘ G ∘ RealBoundaryChart.chart β) _ = _
  rw [← Filter.map_map, ← Filter.map_map, hC, hmapG, coefficientChart_map_nhds]

/-- Exact gain of the actual polynomial, including every critical point. -/
def reconstructedLogGain (r s : ℕ) (R : Parameter r s → Unknown r s)
    (a : Parameter r s → ℂ) (G : Parameter r s → Parameter r s)
    (β : Fin (s + 1) → ℂ) (D : ℝ)
    (p : RealBoundaryChart.Coordinates (ι := Fin r) (κ := Fin (s + 1))) : ℝ :=
  let t := G (RealBoundaryChart.chart β p)
  Real.log (criticalDistance (reconstructedPolynomial r s R t) (a t) / D)

/-- The displayed exact gain formula and all disk constraints hold on a
whole real-coordinate neighborhood of the same reconstruction and inverse. -/
theorem real_chart_exact_geometry
    (r s : ℕ) (hr : 0 < r) (A : ℂ[X]) (β : Fin (s + 1 + 1) → ℂ)
    (w a₀ v₀ : ℂ) (D τ : ℝ) (hD : 0 < D)
    (R : LocalReconstructionResult r (s + 1) A β w a₀ v₀)
    (hboundary : ∀ j, ‖β j‖ = 1) (hq : ‖w-a₀‖ = D) (hg : ‖v₀-a₀‖ = D)
    (hgap : ∀ z, (A * rootPolynomial (s + 1 + 1) β).derivative.IsRoot z →
      z ≠ w → z ≠ v₀ → D < ‖z-a₀‖)
    (G : Parameter r (s + 1) → Parameter r (s + 1))
    (hG : AnalyticAt ℂ G (0,β)) (hG0 : G (0,β) = ((fun _ => w),β))
    (hright : ∀ᶠ p in 𝓝 ((0,β) : Parameter r (s + 1)),
      FullRatioChart.forward r (s + 1) R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) (G p) = p) :
    ∀ᶠ p : RealBoundaryChart.Coordinates (ι := Fin r) (κ := Fin (s + 1 + 1)) in 𝓝 0,
      let t := G (RealBoundaryChart.chart β p)
      (rootsInDisk (reconstructedPolynomial r (s + 1) R.family t) ↔ ∀ j, p.2.1 j ≤ 0) ∧
      (∀ z, (monicPolynomial r (R.family t).1).IsRoot z → ‖z‖ < 1) ∧
      (reconstructedPolynomial r (s + 1) R.family t).eval (R.sourceRoot t) = 0 ∧
      reconstructedLogGain r (s + 1) R.family R.sourceRoot G β D p =
        objective (RealBoundaryChart.smoothObjective
          (fun q => WeightedStationarity.weightedLog R.sourceRoot R.simpleCritical
            (w-a₀) (v₀-a₀) τ (G q)) β) τ p := by
  letI : NeZero r := ⟨Nat.ne_of_gt hr⟩
  have hc : Tendsto (RealBoundaryChart.chart (ι := Fin r) β) (𝓝 0)
      (𝓝 ((0,β) : Parameter r (s + 1))) := by
    simpa only [RealBoundaryChart.chart_zero] using
      (RealBoundaryChart.chart_analyticAt (ι := Fin r) β 0).continuousAt.tendsto
  have hGt : Tendsto G (𝓝 ((0,β) : Parameter r (s + 1)))
      (𝓝 (((fun _ => w),β) : Parameter r (s + 1))) := by
    simpa only [hG0] using hG.continuousAt.tendsto
  have ht := hGt.comp hc
  have hgeom := ht.eventually (full_chart_geometry r s hr A β w a₀ v₀ D hD R hq hg hgap)
  filter_upwards [hgeom, ht.eventually R.interior_roots,
    ht.eventually R.identities, hc.eventually hright] with p hp hI hident hrightp
  dsimp only [Function.comp_apply] at hp
  have hsnd := congrArg (fun q : Parameter r (s + 1) => q.2) hrightp
  have hratio := congrArg (fun q : Parameter r (s + 1) => q.1) hrightp
  change (G (RealBoundaryChart.chart β p)).2 = (RealBoundaryChart.chart β p).2 at hsnd
  refine ⟨?_, hI, hident.2.1, ?_⟩
  · rw [hp.1, hsnd]
    exact RealBoundaryChart.chart_sources_disk_iff β hboundary p
  · dsimp only [reconstructedLogGain]
    rw [hp.2.1]
    exact WeightedStationarity.inverse_chart_distance_objective
      R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β D τ p hD hq hg
      hp.2.2.1 hp.2.2.2 hratio

/-- Quantitative improvement under each replacement, now stated for the
actual all-critical-point distance of the reconstructed polynomial. -/
theorem actual_polynomial_replacement_bounds
    (r s : ℕ) (hr : 0 < r) (A : ℂ[X]) (β : Fin (s + 1 + 1) → ℂ)
    (w a₀ v₀ : ℂ) (D τ : ℝ) (hD : 0 < D) (hτ : 0 < τ) (hτ1 : τ < 1)
    (R : LocalReconstructionResult r (s + 1) A β w a₀ v₀)
    (hboundary : ∀ j, ‖β j‖ = 1) (hq : ‖w-a₀‖ = D) (hg : ‖v₀-a₀‖ = D)
    (hgap : ∀ z, (A * rootPolynomial (s + 1 + 1) β).derivative.IsRoot z →
      z ≠ w → z ≠ v₀ → D < ‖z-a₀‖)
    (G : Parameter r (s + 1) → Parameter r (s + 1))
    (hG : AnalyticAt ℂ G (0,β)) (hG0 : G (0,β) = ((fun _ => w),β))
    (hright : ∀ᶠ p in 𝓝 ((0,β) : Parameter r (s + 1)),
      FullRatioChart.forward r (s + 1) R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) (G p) = p)
    (hparam : ∀ᶠ p in 𝓝 ((0,β) : Parameter r (s + 1)), (G p).2 = p.2)
    (hfree : freeStationarity r (s + 1) R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) w β τ)
    (hrad : radialCondition r (s + 1) R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β τ) :
    let L := reconstructedLogGain r (s + 1) R.family R.sourceRoot G β D
    ∃ c : ℝ, 0 < c ∧
      ∀ᶠ p : RealBoundaryChart.Coordinates (ι := Fin r) (κ := Fin (s + 1 + 1)) in 𝓝 0,
        (L p ≤ L (0,p.2) - (Variations.balancingConstant (ι := Fin r) τ / 2) * ‖p.1‖) ∧
        ((∀ j, p.2.1 j ≤ 0) → L (0,p.2) ≤ L (0,(0,p.2.2)) - c * ‖p.2.1‖) ∧
        ((∀ j, p.2.1 j ≤ 0) → L p ≤
          reducedLogObjective r (s + 1) R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) β τ p.2.2 -
          (Variations.balancingConstant (ι := Fin r) τ / 2) * ‖p.1‖ - c * ‖p.2.1‖) := by
  letI : NeZero r := ⟨Nat.ne_of_gt hr⟩
  obtain ⟨c,hc,hbound⟩ := WeightedBoundaryStrict.weighted_boundary_strict
    R.sourceRoot R.simpleCritical G (w-a₀) (v₀-a₀) w β τ hτ hτ1
    R.source_analytic R.critical_analytic
    (norm_ne_zero_iff.mp (hq ▸ hD.ne')) (norm_ne_zero_iff.mp (hg ▸ hD.ne'))
    (by rw [R.source_base]) (by rw [R.source_base, R.critical_base])
    (fun σ z => by simpa using (R.permutation_invariance σ (Equiv.refl _) (z,β)).2.1)
    (fun σ z => by simpa using (R.permutation_invariance σ (Equiv.refl _) (z,β)).2.2)
    hG hG0 hparam hfree hrad
  have hlog := real_chart_exact_geometry r s hr A β w a₀ v₀ D τ hD R
    hboundary hq hg hgap G hG hG0 hright
  let C := RealBoundaryChart.Coordinates (ι := Fin r) (κ := Fin (s + 1 + 1))
  have hb : Tendsto (fun p : C => (0,p.2) : C → C) (𝓝 0) (𝓝 0) :=
    (continuous_const.prodMk continuous_snd).continuousAt.tendsto
  have hbr : Tendsto (fun p : C => (0,(0,p.2.2)) : C → C) (𝓝 0) (𝓝 0) :=
    (continuous_const.prodMk (continuous_const.prodMk (continuous_snd.comp continuous_snd))).continuousAt.tendsto
  refine ⟨c,hc,?_⟩
  filter_upwards [hbound, hlog, hb.eventually hlog, hbr.eventually hlog] with p hp hpL hbL hbrL
  rw [hpL.2.2.2, hbL.2.2.2, hbrL.2.2.2]
  simpa only [objective, Variations.penalty_zero, sub_zero,
    RealBoundaryChart.reduced_objective, reducedLogObjective] using hp

end PolynomialGeometry.FullFeasibleReduction



