import PolynomialGeometry.Variations
import PolynomialGeometry.RatioCoordinates
import Mathlib.Analysis.SpecialFunctions.Complex.Log

/-! # Exact feasible reduction of logarithmic distance objectives

The nonsmooth active-distance objective and the radial constraint are exact.
Strict differentiability supplies uniform estimates while all other parameters
move. No desired monotonicity or improvement estimate is assumed.
-/
noncomputable section
open scoped BigOperators Topology
open Filter Finset
namespace PolynomialGeometry.FeasibleReduction
open PolynomialGeometry.Variations

section Distance
variable {ι : Type*} [Fintype ι]

/-- Minimum distance to the displayed active critical points. -/
def activeDistance (a v : ℂ) (z : ι → ℂ) : ℝ :=
  (insert ‖v-a‖ (Finset.univ.image fun i => ‖z i-a‖)).min' (by simp)

/-- Nonzero active gaps make their finite nearest distance strictly positive. -/
theorem activeDistance_pos (a v : ℂ) (z : ι → ℂ)
    (hv : v-a ≠ 0) (hz : ∀ i, z i-a ≠ 0) : 0 < activeDistance a v z := by
  classical
  apply (Finset.lt_min'_iff _ _).mpr
  intro d hd
  rcases Finset.mem_insert.mp hd with rfl | hd
  · exact norm_pos_iff.mpr hv
  · obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hd
    exact norm_pos_iff.mpr (hz i)

/-- Taking the logarithm preserves the strict improvement test. -/
theorem logarithmic_improvement_iff (d D : ℝ) (hd : 0 < d) (hD : 0 < D) :
    0 < Real.log (d/D) ↔ D < d := by
  rw [Real.log_pos_iff (div_pos hd hD).le, lt_div_iff₀ hD, one_mul]

/-- Real logarithmic ratios measure exactly the ratios of distances. -/
theorem real_log_ratio (u q : ℂ) :
    (Complex.log (q⁻¹ * u)).re = Real.log (‖u‖ / ‖q‖) := by
  rw [Complex.log_re, norm_mul, norm_inv]
  congr 1
  ring

/-- A finite minimum commutes with the exponential change of coordinates. -/
theorem activeDistance_of_exponential (a v : ℂ) (z : ι → ℂ)
    (D b : ℝ) (hD : 0 < D) (x : ι → ℝ)
    (hv : ‖v-a‖ = D * Real.exp b)
    (hz : ∀ i, ‖z i-a‖ = D * Real.exp (b+x i)) :
    activeDistance a v z = D * Real.exp (b+minZero x) := by
  classical
  let S := insert 0 (Finset.univ.image x)
  let f : ℝ → ℝ := fun t => D * Real.exp (b+t)
  have hf : Monotone f := by
    intro t u htu
    exact mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by linarith)) hD.le
  have heq : insert ‖v-a‖ (Finset.univ.image fun i => ‖z i-a‖) = S.image f := by
    simp only [S, Finset.image_insert, Finset.image_image]
    simp only [f, add_zero, hv, hz, Function.comp_def]
  unfold activeDistance
  simp only [heq]
  rw [Finset.min'_image hf]
  rfl

/-- The exact nonsmooth objective, with no Taylor approximation. -/
theorem logarithmic_distance_identity [Nonempty ι]
    (a v : ℂ) (z : ι → ℂ) (q g : ℂ) (D τ : ℝ)
    (hD : 0 < D) (hq : ‖q‖ = D) (hg : ‖g‖ = D)
    (hv : v-a ≠ 0) (hz : ∀ i, z i-a ≠ 0) :
    let L := Complex.log (g⁻¹ * (v-a))
    let Z := fun i => Complex.log (q⁻¹ * (z i-a)) - L
    let H := L + (τ / Fintype.card ι : ℝ) • ∑ i, Z i
    Real.log (activeDistance a v z / D) =
      H.re + minZero (fun i => (Z i).re) -
        (τ / Fintype.card ι) * ∑ i, (Z i).re := by
  dsimp only
  let L := Complex.log (g⁻¹ * (v-a))
  let Z := fun i => Complex.log (q⁻¹ * (z i-a)) - L
  have hL : L.re = Real.log (‖v-a‖ / D) := by simp only [L, real_log_ratio, hg]
  have hZ (i : ι) : L.re + (Z i).re = Real.log (‖z i-a‖ / D) := by
    simp only [Z, Complex.sub_re]
    simp only [real_log_ratio, hq]
    ring
  have heV : ‖v-a‖ = D * Real.exp L.re := by
    rw [hL, Real.exp_log (div_pos (norm_pos_iff.mpr hv) hD)]
    field_simp
  have heZ (i : ι) : ‖z i-a‖ = D * Real.exp (L.re + (Z i).re) := by
    rw [hZ, Real.exp_log (div_pos (norm_pos_iff.mpr (hz i)) hD)]
    field_simp
  rw [activeDistance_of_exponential a v z D L.re hD (fun i => (Z i).re) heV heZ]
  rw [mul_div_cancel_left₀ _ hD.ne', Real.log_exp]
  change L.re + minZero (fun i => (Z i).re) =
    (L + (τ / Fintype.card ι : ℝ) • ∑ i, Z i).re +
      minZero (fun i => (Z i).re) - (τ / Fintype.card ι) * ∑ i, (Z i).re
  simp only [Complex.add_re, Complex.smul_re, Complex.re_sum, smul_eq_mul]
  ring

/-- The exponential boundary chart converts disk feasibility to a half-space. -/
theorem boundary_disk_iff (β : ℂ) (hβ : ‖β‖ = 1) (ρ θ : ℝ) :
    ‖β * Complex.exp (ρ + θ * Complex.I)‖ ≤ 1 ↔ ρ ≤ 0 := by
  rw [norm_mul, hβ, one_mul, Complex.norm_exp]
  simp only [Complex.add_re, Complex.ofReal_re, Complex.mul_re,
    Complex.I_re, mul_zero, Complex.ofReal_im, Complex.I_im, zero_mul, sub_self,
    add_zero]
  exact Real.exp_le_one_iff

omit [Fintype ι] in
/-- Balanced complex ratios give equality of all active distances. -/
theorem active_distances_equal_of_real_ratios_zero
    (a v : ℂ) (z : ι → ℂ) (q g : ℂ) (D : ℝ)
    (hD : 0 < D) (hq : ‖q‖ = D) (hg : ‖g‖ = D)
    (hv : v-a ≠ 0) (hz : ∀ i, z i-a ≠ 0)
    (hZ : ∀ i, (Complex.log (q⁻¹ * (z i-a)) -
      Complex.log (g⁻¹ * (v-a))).re = 0) :
    ∀ i, ‖z i-a‖ = ‖v-a‖ := by
  intro i
  have h := hZ i
  simp only [Complex.sub_re, real_log_ratio, hq, hg] at h
  have heq := (Real.log_injOn_pos (div_pos (norm_pos_iff.mpr (hz i)) hD)
    (div_pos (norm_pos_iff.mpr hv) hD)) (sub_eq_zero.mp h)
  exact (div_left_inj' hD.ne').mp heq

/-- Distance from the marked source to the critical set of a polynomial. -/
def criticalDistance (p : Polynomial ℂ) (a : ℂ) : ℝ :=
  sInf {d : ℝ | ∃ w : ℂ, p.derivative.IsRoot w ∧ d = ‖w-a‖}

omit [Fintype ι] in
/-- Critical distance is nonnegative, including the empty-critical-set convention. -/
theorem criticalDistance_nonneg (p : Polynomial ℂ) (a : ℂ) :
    0 ≤ criticalDistance p a := by
  apply Real.sInf_nonneg
  intro d hd
  obtain ⟨w,_,rfl⟩ := hd
  exact norm_nonneg _

omit [Fintype ι] in
/-- Exact equivalence between positive logarithmic objective and improving
critical distance, without an additional positivity assumption on the latter. -/
theorem criticalDistance_log_positive_iff (p : Polynomial ℂ) (a : ℂ)
    (D : ℝ) (hD : 0 < D) :
    0 < Real.log (criticalDistance p a / D) ↔ D < criticalDistance p a := by
  rw [Real.log_pos_iff (div_nonneg (criticalDistance_nonneg p a) hD.le),
    lt_div_iff₀ hD, one_mul]

/-- Exact derivative factorization and the strict inactive gap identify the
nearest critical distance with the displayed active minimum. -/
theorem criticalDistance_eq_active
    (p Q : Polynomial ℂ) (a v c : ℂ) (z : ι → ℂ)
    (hc : c ≠ 0)
    (hfactor : p.derivative = Polynomial.C c * (Polynomial.X-Polynomial.C v) *
      (∏ i, (Polynomial.X-Polynomial.C (z i))) * Q)
    (hgap : ∀ w, Q.IsRoot w → ‖v-a‖ < ‖w-a‖) :
    criticalDistance p a = activeDistance a v z := by
  classical
  have hroots (w : ℂ) : p.derivative.IsRoot w ↔
      w = v ∨ (∃ i, w = z i) ∨ Q.IsRoot w := by
    rw [hfactor]
    simp only [Polynomial.IsRoot, Polynomial.eval_mul, Polynomial.eval_C,
      Polynomial.eval_sub, Polynomial.eval_X, Polynomial.eval_prod, mul_eq_zero,
      hc, false_or, Finset.prod_eq_zero_iff, Finset.mem_univ, true_and, sub_eq_zero]
    tauto
  have hvroot : p.derivative.IsRoot v := (hroots v).mpr (Or.inl rfl)
  have hzroot (i : ι) : p.derivative.IsRoot (z i) :=
    (hroots (z i)).mpr (Or.inr (Or.inl ⟨i,rfl⟩))
  have hleast : IsLeast {d : ℝ | ∃ w : ℂ, p.derivative.IsRoot w ∧ d = ‖w-a‖}
      (activeDistance a v z) := by
    constructor
    · have hm := Finset.min'_mem (insert ‖v-a‖ (Finset.univ.image fun i => ‖z i-a‖))
        (by simp)
      rcases Finset.mem_insert.mp hm with hv | hz
      · exact ⟨v,hvroot,hv⟩
      · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp hz
        exact ⟨z i,hzroot i,hi.symm⟩
    · intro d hd
      obtain ⟨w,hw,rfl⟩ := hd
      rcases (hroots w).mp hw with rfl | ⟨i,rfl⟩ | hQ
      · exact Finset.min'_le _ _ (Finset.mem_insert_self _ _)
      · exact Finset.min'_le _ _ (by simp)
      · exact (Finset.min'_le _ _ (Finset.mem_insert_self _ _)).trans (hgap w hQ).le
  exact hleast.csInf_eq
end Distance

section Radial
variable {ι V : Type*} [Fintype ι] [Nonempty ι] [DecidableEq ι]
  [NormedAddCommGroup V] [NormedSpace ℝ V]

omit [Nonempty ι] in
/-- A positive linear radial response controls the full inward displacement. -/
theorem positive_radial_response_bound (L : ((ι → ℝ) × V) →L[ℝ] ℝ)
    (c : ℝ) (hc : 0 ≤ c)
    (hcoeff : ∀ i, c ≤ L (Pi.single i 1, 0))
    (ρ : ι → ℝ) (hρ : ∀ i, ρ i ≤ 0) :
    c * ‖ρ‖ ≤ -L (ρ, 0) := by
  classical
  have hsum : L (ρ, 0) = ∑ i, ρ i * L (Pi.single i 1, 0) := by
    have heq : (ρ, (0 : V)) = ∑ i, ρ i • ((Pi.single i 1 : ι → ℝ), (0 : V)) := by
      apply Prod.ext
      · ext j
        simp [Prod.fst_sum, Finset.sum_apply, Pi.single_apply]
      · simp [Prod.snd_sum]
    rw [heq, map_sum]
    simp only [map_smul, smul_eq_mul]
  have hnonneg (i : ι) : 0 ≤ -(ρ i * L (Pi.single i 1, 0)) :=
    neg_nonneg.mpr (mul_nonpos_of_nonpos_of_nonneg (hρ i) (hc.trans (hcoeff i)))
  have hcoord (i : ι) : c * |ρ i| ≤ -L (ρ, 0) := by
    rw [abs_of_nonpos (hρ i), hsum, ← Finset.sum_neg_distrib]
    calc
      c * -ρ i ≤ -(ρ i * L (Pi.single i 1, 0)) := by
        have := mul_le_mul_of_nonneg_left (hcoeff i) (neg_nonneg.mpr (hρ i))
        nlinarith
      _ ≤ ∑ j, -(ρ j * L (Pi.single j 1, 0)) :=
        Finset.single_le_sum (fun j _ => hnonneg j) (Finset.mem_univ i)
  by_cases hc0 : c = 0
  · rw [hc0, zero_mul]
    rw [hsum, ← Finset.sum_neg_distrib]
    exact Finset.sum_nonneg fun i _ => hnonneg i
  · have hc' : 0 < c := lt_of_le_of_ne hc (Ne.symm hc0)
    have hn : ‖ρ‖ ≤ -L (ρ,0) / c := by
      apply (pi_norm_le_iff_of_nonneg (div_nonneg (by
        rw [hsum, ← Finset.sum_neg_distrib]
        exact Finset.sum_nonneg fun i _ => hnonneg i) hc)).mpr
      intro i
      rw [Real.norm_eq_abs]
      exact (le_div_iff₀ hc').mpr (by simpa [mul_comm] using hcoord i)
    simpa only [mul_comm] using (le_div_iff₀ hc').mp hn

/-- Strict positive coordinate responses have a common positive lower bound. -/
theorem exists_uniform_radial_response
    (L : ((ι → ℝ) × V) →L[ℝ] ℝ)
    (hL : ∀ i, 0 < L (Pi.single i 1, 0)) :
    ∃ c : ℝ, 0 < c ∧ ∀ i, c ≤ L (Pi.single i 1, 0) := by
  classical
  let S := Finset.univ.image fun i => L (Pi.single i 1, 0)
  have hS : S.Nonempty := Finset.univ_nonempty.image _
  refine ⟨S.min' hS, ?_, ?_⟩
  · obtain ⟨i, _, hi⟩ := Finset.mem_image.mp (Finset.min'_mem S hS)
    rw [← hi]
    exact hL i
  · intro i
    exact Finset.min'_le S _ (Finset.mem_image.mpr ⟨i, Finset.mem_univ i, rfl⟩)

/-- All nonpositive radial coordinates can be set to zero with a uniform,
strict gain. The estimate is derived from strict differentiability. -/
theorem local_uniform_radial_improvement
    {F : ((ι → ℝ) × V) → ℝ} {L : ((ι → ℝ) × V) →L[ℝ] ℝ}
    (hF : HasStrictFDerivAt F L 0)
    (hL : ∀ i, 0 < L (Pi.single i 1, 0)) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ p in 𝓝 (0 : (ι → ℝ) × V),
      (∀ i, p.1 i ≤ 0) → F p ≤ F (0,p.2) - c * ‖p.1‖ := by
  obtain ⟨c, hc, hcoeff⟩ := exists_uniform_radial_response L hL
  let φ : ((ι → ℝ) × V) → (((ι → ℝ) × V) × ((ι → ℝ) × V)) :=
    fun p => (p, (0,p.2))
  have hφ : Continuous φ := by fun_prop
  have ht : Tendsto φ (𝓝 0) (𝓝 (0,0)) := by
    simpa [φ] using hφ.continuousAt.tendsto (x := (0 : (ι → ℝ) × V))
  have hb := ht.eventually (hF.isLittleO.bound (half_pos hc))
  refine ⟨c/2, half_pos hc, ?_⟩
  filter_upwards [hb] with p hp hρ
  have hdiff : p - (0,p.2) = (p.1,0) := by ext <;> simp
  have hr := positive_radial_response_bound L c hc.le hcoeff p.1 hρ
  have he : |F p - F (0,p.2) - L (p.1,0)| ≤ c/2 * ‖p.1‖ := by
    simpa [φ, hdiff, Prod.norm_def] using hp
  have := (abs_le.mp he).2
  linarith
end Radial

section Stationarity
variable {ι : Type*} [Fintype ι] [Nonempty ι]

/-- Free complex stationarity of the diagonal annihilates the entire
copy differential, because the objective itself is permutation invariant. -/
theorem diagonal_stationarity_gives_zero_differential
    (H : (ι → ℂ) → ℂ) (w : ℂ)
    (hH : DifferentiableAt ℂ H (fun _ => w))
    (hsym : ∀ σ : Equiv.Perm ι,
      (fun z => H (z ∘ σ)) =ᶠ[𝓝 (fun _ => w)] H)
    (hdiag : HasDerivAt (fun t : ℂ => H (fun _ => t)) 0 w) :
    fderiv ℂ H (fun _ => w) = 0 := by
  have hin : HasDerivAt (fun t : ℂ => (fun _ : ι => t)) (fun _ => 1) w := by
    let d : ℂ →L[ℂ] (ι → ℂ) := ContinuousLinearMap.pi fun _ => ContinuousLinearMap.id ℂ ℂ
    exact d.hasFDerivAt.hasDerivAt
  have hd := hH.hasFDerivAt.comp_hasDerivAt w hin
  have hzero : fderiv ℂ H (fun _ => w) (fun _ => 1) = 0 := hd.unique hdiag
  have hperm := PolynomialGeometry.RatioCoordinates.differential_permutation_invariant H w hH hsym
  ext x
  change fderiv ℂ H (fun _ => w) x = 0
  have hh := PolynomialGeometry.RatioCoordinates.invariant_linear_formula
    (fderiv ℂ H (fun _ => w)).toLinearMap hperm x
  change fderiv ℂ H (fun _ => w) x =
    copyMean x * fderiv ℂ H (fun _ => w) (fun _ => 1) at hh
  simpa only [hzero, mul_zero] using hh

/-- The zero derivative survives a differentiable change to ratio coordinates. -/
theorem stationarity_under_coordinates
    {ι : Type*} [Fintype ι] {H : (ι → ℂ) → ℂ} {G : (ι → ℂ) → (ι → ℂ)}
    {z Z : ι → ℂ} (hH : HasFDerivAt H (0 : (ι → ℂ) →L[ℂ] ℂ) z)
    (hG : DifferentiableAt ℂ G Z) (hGZ : G Z = z) :
    HasFDerivAt (fun t => H (G t)) (0 : (ι → ℂ) →L[ℂ] ℂ) Z := by
  rw [← hGZ] at hH
  have h := hH.comp Z hG.hasFDerivAt
  simpa using h
end Stationarity


section ExactReduction
variable {ι κ V : Type*} [Fintype ι] [Nonempty ι]
  [Fintype κ] [Nonempty κ] [DecidableEq κ]
  [NormedAddCommGroup V] [NormedSpace ℝ V]

/-- The active logarithmic objective in real ratio and radial coordinates. -/
def objective (F : ((ι → ℝ) × ((κ → ℝ) × V)) → ℝ) (τ : ℝ)
    (p : (ι → ℝ) × ((κ → ℝ) × V)) : ℝ := F p - penalty τ p.1

/-- Positive feasible values exist in every neighborhood of the base point. -/
def arbitrarilyNearPositive {E : Type*} [NormedAddCommGroup E]
    (f : E → ℝ) (feasible : E → Prop) : Prop :=
  ∀ ε : ℝ, 0 < ε → ∃ x : E, ‖x‖ < ε ∧ feasible x ∧ 0 < f x

/-- The balancing and radial steps give simultaneous strict gains for the
actual smooth part of the objective. -/
theorem local_exact_reduction
    {F : ((ι → ℝ) × ((κ → ℝ) × V)) → ℝ}
    {L : ((ι → ℝ) × ((κ → ℝ) × V)) →L[ℝ] ℝ}
    {τ : ℝ} (hτ : 0 < τ) (hτ1 : τ < 1)
    (hF : HasStrictFDerivAt F L 0)
    (hx : ∀ x : ι → ℝ, L (x,0) = 0)
    (hr : ∀ j, 0 < L (0,(Pi.single j 1,0))) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ p in 𝓝 (0 : (ι → ℝ) × ((κ → ℝ) × V)),
      (∀ j, p.2.1 j ≤ 0) →
      objective F τ p ≤ F (0,(0,p.2.2)) -
        (balancingConstant (ι := ι) τ / 2) * ‖p.1‖ - c * ‖p.2.1‖ := by
  let J : ((κ → ℝ) × V) →L[ℝ] ((ι → ℝ) × ((κ → ℝ) × V)) :=
    ContinuousLinearMap.inr ℝ (ι → ℝ) ((κ → ℝ) × V)
  have hslice : HasStrictFDerivAt (fun p : (κ → ℝ) × V => F (0,p)) (L.comp J) 0 :=
    hF.comp 0 J.hasStrictFDerivAt
  obtain ⟨c,hc,hR⟩ := local_uniform_radial_improvement hslice hr
  have hB := local_uniform_balancing hτ hτ1 hF hx
  have hproj : Tendsto (fun p : (ι → ℝ) × ((κ → ℝ) × V) => p.2) (𝓝 0) (𝓝 0) :=
    continuous_snd.continuousAt.tendsto
  refine ⟨c,hc,?_⟩
  filter_upwards [hB, hproj.eventually hR] with p hbp hrp hfeas
  have hrad := hrp hfeas
  unfold objective penalty
  linarith

/-- Nearby feasible improvement is equivalent to nearby positive values of
one smooth boundary function. Both replacement and inclusion tend to zero. -/
theorem arbitrarily_near_improvement_iff
    {F : ((ι → ℝ) × ((κ → ℝ) × V)) → ℝ}
    {L : ((ι → ℝ) × ((κ → ℝ) × V)) →L[ℝ] ℝ}
    {τ : ℝ} (hτ : 0 < τ) (hτ1 : τ < 1)
    (hF : HasStrictFDerivAt F L 0)
    (hx : ∀ x : ι → ℝ, L (x,0) = 0)
    (hr : ∀ j, 0 < L (0,(Pi.single j 1,0))) :
    arbitrarilyNearPositive (objective F τ) (fun p => ∀ j, p.2.1 j ≤ 0) ↔
      arbitrarilyNearPositive (fun u : V => F (0,(0,u))) (fun _ => True) := by
  obtain ⟨c,hc,hdom⟩ := local_exact_reduction hτ hτ1 hF hx hr
  obtain ⟨δ,hδ,hball⟩ := Metric.eventually_nhds_iff.mp hdom
  constructor
  · intro h ε hε
    obtain ⟨p,hp,hfeas,hpos⟩ := h (min ε δ) (lt_min hε hδ)
    have hnorm : ‖p.2.2‖ ≤ ‖p‖ := (norm_snd_le p.2).trans (norm_snd_le p)
    have hsmall : dist p 0 < δ := by simpa using lt_of_lt_of_le hp (min_le_right ε δ)
    have hh := hball hsmall hfeas
    have hb0 : 0 ≤ (balancingConstant (ι := ι) τ / 2) * ‖p.1‖ :=
      mul_nonneg (half_pos (balancingConstant_pos hτ hτ1)).le (norm_nonneg _)
    have hr0 : 0 ≤ c * ‖p.2.1‖ := mul_nonneg hc.le (norm_nonneg _)
    refine ⟨p.2.2, hnorm.trans_lt (hp.trans_le (min_le_left ε δ)), trivial, ?_⟩
    linarith
  · intro h ε hε
    obtain ⟨u,hu,_,hpos⟩ := h ε hε
    refine ⟨(0,(0,u)), ?_, ?_, ?_⟩
    · simpa [Prod.norm_def] using hu
    · intro j; simp
    · simpa [objective] using hpos
end ExactReduction

end PolynomialGeometry.FeasibleReduction
