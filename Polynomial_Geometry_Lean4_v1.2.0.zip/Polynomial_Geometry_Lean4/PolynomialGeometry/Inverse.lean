import Mathlib.LinearAlgebra.Matrix.ToLin
import Mathlib.LinearAlgebra.Matrix.Hermitian
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Analysis.InnerProductSpace.Adjoint
import PolynomialGeometry.Confluent
import PolynomialGeometry.NormalSpectrum
import PolynomialGeometry.BlockMetric
import Mathlib.Tactic.Abel
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Module
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NoncommRing

/-!
# Algebra of the normalized inverse realization

This file formalizes the forced bordered operator, constructive normalized
source realization, spectral-source uniqueness, and recovery identities used
in Theorem 3.2 and Corollary 3.3 of
*Polynomial Geometry and Structured Discrete Dynamics*.

The block coordinates `ℂ × V` are the scalar source coordinate followed by
the genuine critical coordinates. The vector called `h` below is the paper's
`H⁻¹ R* e`. The normal spectral theorem constructs the eigenbasis, and
`normalizedCompletion_realization` constructs the actual source positions,
positive masses and canonical rows with the prescribed Gram matrix.
`completion_test_of_source_basis` proves the converse matrix test from a
source basis. The full scalar numerator identity and the assembly from the
article's minimal realization definition are separate from these statements;
this file does not assert the complete article equivalence as one theorem.
-/

noncomputable section

open Matrix Module
open scoped ComplexOrder

namespace PolynomialGeometry.Inverse

section Border

variable {V : Type*} [AddCommGroup V] [Module ℂ V]

/-- The bordered action `[[γ,-e*],[d,J]]` in scalar/product coordinates. -/
def border (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ) (γ : ℂ) (d : V) :
    (ℂ × V) →ₗ[ℂ] (ℂ × V) where
  toFun x := (γ * x.1 - ell x.2, x.1 • d + J x.2)
  map_add' x y := by
    apply Prod.ext
    · simp only [Prod.fst_add, Prod.snd_add, map_add]
      ring
    · simp only [Prod.fst_add, Prod.snd_add, map_add, add_smul]
      abel
  map_smul' c x := by
    apply Prod.ext
    · simp only [Prod.smul_fst, Prod.smul_snd, map_smul, RingHom.id_apply, smul_eq_mul]
      ring
    · simp only [Prod.smul_fst, Prod.smul_snd, map_smul, RingHom.id_apply, smul_add,
        smul_eq_mul, MulAction.mul_smul]

@[simp] theorem border_fst (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ)
    (γ : ℂ) (d : V) (x : ℂ × V) :
    (border J ell γ d x).1 = γ * x.1 - ell x.2 := rfl

@[simp] theorem border_snd (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ)
    (γ : ℂ) (d : V) (x : ℂ × V) :
    (border J ell γ d x).2 = x.1 • d + J x.2 := rfl

/-- The uniquely prescribed upper-left entry. -/
def normalizedScalar (a n : ℂ) (ell : V →ₗ[ℂ] ℂ) (h : V) : ℂ :=
  a - n * ell h

/-- The uniquely prescribed lower-left column. -/
def normalizedColumn (a n : ℂ) (J : V →ₗ[ℂ] V) (h : V) : V :=
  -n • (a • h - J h)

/-- The selected source has coordinate vector `(1/n, -H⁻¹R*e)`. -/
def selectedVector (n : ℂ) (h : V) : ℂ × V := (n⁻¹, -h)

theorem normalizedBorder_selected_eigenvector
    (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ) (a n : ℂ) (h : V)
    (hn : n ≠ 0) :
    border J ell (normalizedScalar a n ell h) (normalizedColumn a n J h)
        (selectedVector n h) = a • selectedVector n h := by
  apply Prod.ext
  · simp only [border_fst, selectedVector, normalizedScalar, map_neg,
      Prod.smul_fst, smul_eq_mul]
    field_simp
    ring
  · change n⁻¹ • (-n • (a • h - J h)) + J (-h) = a • (-h)
    rw [neg_smul, smul_neg, smul_smul, inv_mul_cancel₀ hn, one_smul,
      map_neg, smul_neg]
    abel

omit [Module ℂ V] in
theorem selectedVector_ne_zero (n : ℂ) (h : V) (hn : n ≠ 0) :
    selectedVector n h ≠ 0 := by
  intro hz
  have := congrArg Prod.fst hz
  simp [selectedVector, hn] at this

/-- A selected eigenvector fixes the scalar border, without any normality assumption. -/
theorem scalar_forced_by_selected_eigenvector
    (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ) (a n γ : ℂ) (h d : V)
    (hn : n ≠ 0)
    (hv : border J ell γ d (selectedVector n h) = a • selectedVector n h) :
    γ = normalizedScalar a n ell h := by
  have hf := congrArg Prod.fst hv
  simp only [border_fst, selectedVector, Prod.smul_fst, map_neg, smul_eq_mul] at hf
  dsimp [normalizedScalar]
  have hh := congrArg (fun z : ℂ => z * n) hf
  field_simp at hh
  linear_combination hh

/-- The lower border is fixed by the same eigenvector equation. -/
theorem column_forced_by_selected_eigenvector
    (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ) (a n γ : ℂ) (h d : V)
    (hn : n ≠ 0)
    (hv : border J ell γ d (selectedVector n h) = a • selectedVector n h) :
    d = normalizedColumn a n J h := by
  have hs := congrArg Prod.snd hv
  simp only [border_snd, selectedVector, Prod.smul_snd, map_neg, smul_neg] at hs
  have hh := congrArg (fun z : V => n • z) hs
  simp only [smul_add, smul_neg, smul_smul, mul_inv_cancel₀ hn, one_smul] at hh
  calc
    d = -((n * a) • h) + n • J h := by
      apply eq_add_of_sub_eq
      simpa only [sub_eq_add_neg] using hh
    _ = normalizedColumn a n J h := by
      dsimp [normalizedColumn]
      module

/-- Exact uniqueness of the candidate border for the prescribed selected vector. -/
theorem normalizedBorder_unique
    (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ) (a n γ : ℂ) (h d : V)
    (hn : n ≠ 0)
    (hv : border J ell γ d (selectedVector n h) = a • selectedVector n h) :
    γ = normalizedScalar a n ell h ∧ d = normalizedColumn a n J h :=
  ⟨scalar_forced_by_selected_eigenvector J ell a n γ h d hn hv,
    column_forced_by_selected_eigenvector J ell a n γ h d hn hv⟩

/-- The forced border is an if-and-only-if algebraic characterization. -/
theorem selected_eigenvector_iff_normalizedBorder
    (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ) (a n γ : ℂ) (h d : V)
    (hn : n ≠ 0) :
    border J ell γ d (selectedVector n h) = a • selectedVector n h ↔
      γ = normalizedScalar a n ell h ∧ d = normalizedColumn a n J h := by
  constructor
  · exact normalizedBorder_unique J ell a n γ h d hn
  · rintro ⟨rfl, rfl⟩
    exact normalizedBorder_selected_eigenvector J ell a n h hn

end Border

section ObservableBorder

variable {V : Type*} [AddCommGroup V] [Module ℂ V]

/-- An output sees every eigenvector. In the paper this property is proved
for the canonical complete Jordan pair `(J,e*)`. -/
def EigenObservable (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ) : Prop :=
  ∀ (μ : ℂ) (y : V), J y = μ • y → ell y = 0 → y = 0

/-- No eigenvector of the completed operator can have zero scalar source
coordinate, provided the genuine pair is eigen-observable. -/
theorem border_eigenvector_eq_zero_of_first_eq_zero
    (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ) (γ : ℂ) (d : V)
    (hobs : EigenObservable J ell) (μ : ℂ) (x : ℂ × V)
    (hx : border J ell γ d x = μ • x) (hfirst : x.1 = 0) : x = 0 := by
  have h1 := congrArg Prod.fst hx
  have h2 := congrArg Prod.snd hx
  simp only [border_fst, Prod.smul_fst, hfirst, mul_zero, smul_zero,
    zero_sub, neg_eq_zero] at h1
  simp only [border_snd, Prod.smul_snd, hfirst, zero_smul, zero_add] at h2
  exact Prod.ext hfirst (hobs μ x.2 h2 h1)

theorem border_eigenvector_first_ne_zero
    (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ) (γ : ℂ) (d : V)
    (hobs : EigenObservable J ell) (μ : ℂ) (x : ℂ × V)
    (hx : border J ell γ d x = μ • x) (hne : x ≠ 0) : x.1 ≠ 0 := by
  intro h0
  exact hne (border_eigenvector_eq_zero_of_first_eq_zero J ell γ d hobs μ x hx h0)

/-- Any two vectors in the same eigenspace are proportional after cross
multiplication of their scalar source coordinates. -/
theorem border_eigenvectors_cross_proportional
    (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ) (γ : ℂ) (d : V)
    (hobs : EigenObservable J ell) (μ : ℂ) (x y : ℂ × V)
    (hx : border J ell γ d x = μ • x)
    (hy : border J ell γ d y = μ • y) :
    x.1 • y = y.1 • x := by
  let z := x.1 • y - y.1 • x
  have hz : border J ell γ d z = μ • z := by
    dsimp [z]
    simp only [map_sub, map_smul, hx, hy, smul_sub]
    module
  have hzfirst : z.1 = 0 := by
    dsimp [z]
    ring
  have hzero := border_eigenvector_eq_zero_of_first_eq_zero
    J ell γ d hobs μ z hz hzfirst
  exact sub_eq_zero.mp hzero

/-- A nonzero eigenvector spans its complete eigenspace. This is the
geometric simplicity step, before using normality to obtain a basis. -/
theorem border_eigenvector_span
    (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ) (γ : ℂ) (d : V)
    (hobs : EigenObservable J ell) (μ : ℂ) (x y : ℂ × V)
    (hx : border J ell γ d x = μ • x)
    (hy : border J ell γ d y = μ • y) (hne : x ≠ 0) :
    y = (y.1 / x.1) • x := by
  have hfirst := border_eigenvector_first_ne_zero J ell γ d hobs μ x hx hne
  have hcross := border_eigenvectors_cross_proportional J ell γ d hobs μ x y hx hy
  have h := congrArg (fun z : ℂ × V => x.1⁻¹ • z) hcross
  simpa only [smul_smul, inv_mul_cancel₀ hfirst, one_smul, div_eq_mul_inv,
    mul_comm] using h

/-- Once an eigenbasis has been constructed, observability forces its
eigenvalues to be distinct. The eigenbasis itself is not assumed to
follow from these algebraic hypotheses. -/
theorem border_eigenbasis_distinct {κ : Type*}
    (J : V →ₗ[ℂ] V) (ell : V →ₗ[ℂ] ℂ) (γ : ℂ) (d : V)
    (hobs : EigenObservable J ell) (b : Basis κ ℂ (ℂ × V)) (μ : κ → ℂ)
    (hb : ∀ i, border J ell γ d (b i) = μ i • b i) :
    Function.Injective μ := by
  classical
  intro i j hij
  by_contra hne
  have hj : border J ell γ d (b j) = μ i • b j := by simpa [hij] using hb j
  have hcross := border_eigenvectors_cross_proportional J ell γ d hobs (μ i)
    (b i) (b j) (hb i) hj
  have hcoord := congrArg (fun x => b.repr x i) hcross
  have hnz := border_eigenvector_first_ne_zero J ell γ d hobs (μ j) (b j)
    (hb j) (b.ne_zero j)
  simp [hne] at hcoord
  exact hnz hcoord.symm

end ObservableBorder

section MatrixNormalization

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The canonical output row `e*`, represented as a linear functional. -/
def rowFunctional (e : ι → ℂ) : (ι → ℂ) →ₗ[ℂ] ℂ :=
  dotProductBilin ℂ ℂ (star e)

omit [DecidableEq ι] in
@[simp] theorem rowFunctional_apply (e x : ι → ℂ) :
    rowFunctional e x = star e ⬝ᵥ x := rfl

/-- The vector occurring in the normalized inverse border. -/
def recoveryVector (H R : Matrix ι ι ℂ) (e : ι → ℂ) : ι → ℂ :=
  H⁻¹ *ᵥ (Rᴴ *ᵥ e)

/-- The selected-source normalization, with the exact matrix order. -/
def normalization (H R : Matrix ι ι ℂ) (e : ι → ℂ) : ℂ :=
  star e ⬝ᵥ (R *ᵥ recoveryVector H R e)

/-- The source Gram form on the completed scalar/product coordinates. -/
def weightedPair (n : ℝ) (H : Matrix ι ι ℂ)
    (x y : ℂ × (ι → ℂ)) : ℂ :=
  star x.1 * (n : ℂ) * y.1 + star x.2 ⬝ᵥ (H *ᵥ y.2)

/-- The Gram energy of `H⁻¹R*e` is exactly the normalization kernel. -/
theorem recoveryVector_energy (H R : Matrix ι ι ℂ) (e : ι → ℂ)
    (hH : H.IsHermitian) (hdet : IsUnit H.det) :
    star (recoveryVector H R e) ⬝ᵥ (H *ᵥ recoveryVector H R e) =
      normalization H R e := by
  dsimp [normalization, recoveryVector]
  have hcancel : H *ᵥ (H⁻¹ *ᵥ (Rᴴ *ᵥ e)) = Rᴴ *ᵥ e := by
    rw [Matrix.mulVec_mulVec, Matrix.mul_nonsing_inv H hdet, Matrix.one_mulVec]
  rw [hcancel]
  rw [Matrix.star_mulVec, hH.inv.eq, ← Matrix.dotProduct_mulVec,
    Matrix.star_mulVec, Matrix.conjTranspose_conjTranspose, ← Matrix.dotProduct_mulVec]

/-- Normalization makes the explicitly selected vector have unit source energy. -/
theorem selectedVector_unit_energy (n : ℝ) (H R : Matrix ι ι ℂ)
    (e : ι → ℂ) (hn : n ≠ 0) (hH : H.IsHermitian) (hdet : IsUnit H.det)
    (hnorm : normalization H R e = 1 - (n : ℂ)⁻¹) :
    weightedPair n H (selectedVector (n : ℂ) (recoveryVector H R e))
      (selectedVector (n : ℂ) (recoveryVector H R e)) = 1 := by
  have hnC : (n : ℂ) ≠ 0 := by exact_mod_cast hn
  dsimp [weightedPair, selectedVector]
  simp only [star_neg, Matrix.mulVec_neg, neg_dotProduct, dotProduct_neg, neg_neg,
    map_inv₀, Complex.conj_ofReal]
  rw [recoveryVector_energy H R e hH hdet, hnorm]
  field_simp
  ring

/-- The scalar source basis vector. -/
def firstCoordinate : ℂ × (ι → ℂ) := (1, 0)

omit [DecidableEq ι] in
theorem firstCoordinate_energy (n : ℝ) (H : Matrix ι ι ℂ) :
    weightedPair n H firstCoordinate firstCoordinate = (n : ℂ) := by
  simp [weightedPair, firstCoordinate]

omit [DecidableEq ι] in
theorem selected_firstCoordinate_pair (n : ℝ) (H : Matrix ι ι ℂ)
    (h : ι → ℂ) (hn : n ≠ 0) :
    weightedPair n H (selectedVector (n : ℂ) h) firstCoordinate = 1 := by
  have hnC : (n : ℂ) ≠ 0 := by exact_mod_cast hn
  simp [weightedPair, selectedVector, firstCoordinate, hnC]

end MatrixNormalization

section CanonicalObservability

variable {σ : Type*} [Fintype σ] [DecidableEq σ]

/-- The canonical complete Jordan coordinates satisfy the observability
property used by the bordered inverse construction. -/
theorem canonical_eigenObservable (w : σ → ℂ) (r : σ → ℕ)
    (hw : Function.Injective w) :
    EigenObservable (Confluent.jordanMatrix w r).mulVecLin
      (rowFunctional (Confluent.outputVector r)) := by
  intro μ x hx hout
  exact Confluent.canonical_eigenvector_observable_dotProduct w r hw μ x hx hout

end CanonicalObservability

section WeightedSimilarity

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The adjoint in the source Gram metric. -/
def weightedAdjoint (S M : Matrix ι ι ℂ) : Matrix ι ι ℂ := S⁻¹ * Mᴴ * S

/-- Changing from source coordinates to a nonorthonormal basis changes
the adjoint by the same similarity. -/
theorem weightedAdjoint_similarity (A B : Matrix ι ι ℂ) (hB : IsUnit B.det) :
    weightedAdjoint (Bᴴ * B) (B⁻¹ * A * B) = B⁻¹ * Aᴴ * B := by
  have hBstar : IsUnit Bᴴ.det := by
    rw [Matrix.det_conjTranspose]
    exact hB.star
  have hcancel := Matrix.nonsing_inv_mul Bᴴ hBstar
  dsimp [weightedAdjoint]
  rw [Matrix.mul_inv_rev, Matrix.conjTranspose_mul, Matrix.conjTranspose_mul,
    Matrix.conjTranspose_nonsing_inv]
  calc
    B⁻¹ * Bᴴ⁻¹ * (Bᴴ * (Aᴴ * Bᴴ⁻¹)) * (Bᴴ * B) =
        B⁻¹ * (Bᴴ⁻¹ * Bᴴ) * Aᴴ * (Bᴴ⁻¹ * Bᴴ) * B := by noncomm_ring
    _ = B⁻¹ * Aᴴ * B := by simp only [hcancel, Matrix.mul_one]

/-- Normality of the original source matrix gives weighted normality
of its expression in the complete source/critical basis. -/
theorem weightedNormal_similarity (A B : Matrix ι ι ℂ) (hB : IsUnit B.det)
    (hA : A * Aᴴ = Aᴴ * A) :
    (B⁻¹ * A * B) * weightedAdjoint (Bᴴ * B) (B⁻¹ * A * B) =
      weightedAdjoint (Bᴴ * B) (B⁻¹ * A * B) * (B⁻¹ * A * B) := by
  rw [weightedAdjoint_similarity A B hB]
  have hcancel := Matrix.mul_nonsing_inv B hB
  calc
    (B⁻¹ * A * B) * (B⁻¹ * Aᴴ * B) =
        B⁻¹ * (A * (B * B⁻¹) * Aᴴ) * B := by noncomm_ring
    _ = B⁻¹ * (A * Aᴴ) * B := by simp only [hcancel, Matrix.mul_one]
    _ = B⁻¹ * (Aᴴ * A) * B := by rw [hA]
    _ = B⁻¹ * (Aᴴ * (B * B⁻¹) * A) * B := by
      simp only [hcancel, Matrix.mul_one]
    _ = (B⁻¹ * Aᴴ * B) * (B⁻¹ * A * B) := by noncomm_ring

/-- The completed weighted contraction defect is exactly a source
defect transported by congruence. -/
theorem contractionDefect_similarity (A B : Matrix ι ι ℂ)
    (hB : IsUnit B.det) :
    Bᴴ * B - (B⁻¹ * A * B)ᴴ * (Bᴴ * B) * (B⁻¹ * A * B) =
      Bᴴ * (1 - Aᴴ * A) * B := by
  have hcancel := Matrix.mul_nonsing_inv B hB
  have hstar : (B⁻¹)ᴴ * Bᴴ = 1 := by
    simpa only [Matrix.conjTranspose_mul, Matrix.conjTranspose_one] using
      congrArg Matrix.conjTranspose hcancel
  rw [Matrix.conjTranspose_mul, Matrix.conjTranspose_mul]
  calc
    Bᴴ * B - Bᴴ * (Aᴴ * (B⁻¹)ᴴ) * (Bᴴ * B) * (B⁻¹ * A * B) =
      Bᴴ * B - Bᴴ * Aᴴ * ((B⁻¹)ᴴ * Bᴴ) * (B * B⁻¹) * A * B := by
        noncomm_ring
    _ = Bᴴ * (1 - Aᴴ * A) * B := by
      rw [hstar, hcancel]
      noncomm_ring

theorem weightedContraction_similarity (A B : Matrix ι ι ℂ)
    (hB : IsUnit B.det) (hA : (1 - Aᴴ * A).PosSemidef) :
    (Bᴴ * B - (B⁻¹ * A * B)ᴴ * (Bᴴ * B) * (B⁻¹ * A * B)).PosSemidef := by
  rw [contractionDefect_similarity A B hB]
  exact hA.conjTranspose_mul_mul_same B

/-- The formula `S⁻¹ M* S` is the actual Hilbert-space adjoint in the
inner product induced by the positive source metric. -/
theorem weightedAdjoint_is_adjoint (S M : Matrix ι ι ℂ) (hS : S.PosDef) :
    letI := Matrix.NormedAddCommGroup.ofMatrix hS
    letI := Matrix.InnerProductSpace.ofMatrix hS
    (weightedAdjoint S M).mulVecLin = M.mulVecLin.adjoint := by
  letI := Matrix.NormedAddCommGroup.ofMatrix hS
  letI := Matrix.InnerProductSpace.ofMatrix hS
  apply (LinearMap.eq_adjoint_iff _ _).mpr
  intro x y
  change (S *ᵥ y) ⬝ᵥ star (weightedAdjoint S M *ᵥ x) =
    (S *ᵥ (M *ᵥ y)) ⬝ᵥ star x
  have hcancel := Matrix.nonsing_inv_mul S ((Matrix.isUnit_iff_isUnit_det S).mp hS.isUnit)
  have hadj : (weightedAdjoint S M)ᴴ * S = S * M := by
    simp only [weightedAdjoint, Matrix.conjTranspose_mul,
      hS.isHermitian.eq, Matrix.conjTranspose_nonsing_inv,
      Matrix.conjTranspose_conjTranspose]
    calc
      S * (M * S⁻¹) * S = S * M * (S⁻¹ * S) := by noncomm_ring
      _ = S * M := by rw [hcancel, Matrix.mul_one]
  rw [Matrix.star_mulVec, dotProduct_comm, ← Matrix.dotProduct_mulVec,
    Matrix.mulVec_mulVec, hadj, ← Matrix.mulVec_mulVec, dotProduct_comm]

/-- Weighted matrix normality is exactly enough to obtain normality of
the actual operator in the source inner product. -/
theorem weightedNormal_isStarNormal (S M : Matrix ι ι ℂ) (hS : S.PosDef)
    (hM : M * weightedAdjoint S M = weightedAdjoint S M * M) :
    letI := Matrix.NormedAddCommGroup.ofMatrix hS
    letI := Matrix.InnerProductSpace.ofMatrix hS
    IsStarNormal M.mulVecLin := by
  letI := Matrix.NormedAddCommGroup.ofMatrix hS
  letI := Matrix.InnerProductSpace.ofMatrix hS
  constructor
  change M.mulVecLin.adjoint * M.mulVecLin = M.mulVecLin * M.mulVecLin.adjoint
  rw [← weightedAdjoint_is_adjoint S M hS]
  simpa only [Matrix.mulVecLin_mul, Module.End.mul_eq_comp] using
    congrArg Matrix.mulVecLin hM.symm

omit [DecidableEq ι] in
/-- The quadratic contraction inequality gives contraction of the
actual source energy. This statement avoids choosing an ambient norm. -/
theorem weightedContraction_energy (S M : Matrix ι ι ℂ)
    (hM : (S - Mᴴ * S * M).PosSemidef) (x : ι → ℂ) :
    RCLike.re (star (M *ᵥ x) ⬝ᵥ (S *ᵥ (M *ᵥ x))) ≤
      RCLike.re (star x ⬝ᵥ (S *ᵥ x)) := by
  have hquad : star x ⬝ᵥ ((Mᴴ * S * M) *ᵥ x) =
      star (M *ᵥ x) ⬝ᵥ (S *ᵥ (M *ᵥ x)) := by
    rw [← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec,
      Matrix.dotProduct_mulVec, ← Matrix.star_mulVec]
  have hn := hM.re_dotProduct_nonneg x
  rw [Matrix.sub_mulVec, dotProduct_sub, map_sub, hquad] at hn
  exact sub_nonneg.mp hn

omit [DecidableEq ι] in
/-- Every eigenvalue of a positive-metric contraction belongs to the
closed unit disk. Normality is unnecessary for this bound. -/
theorem weightedContraction_eigenvalue (S M : Matrix ι ι ℂ) (hS : S.PosDef)
    (hM : (S - Mᴴ * S * M).PosSemidef) (μ : ℂ) (x : ι → ℂ)
    (hx : x ≠ 0) (heig : M *ᵥ x = μ • x) : ‖μ‖ ≤ 1 := by
  have hn := weightedContraction_energy S M hM x
  rw [heig] at hn
  have hq : star (μ • x) ⬝ᵥ (S *ᵥ (μ • x)) =
      (Complex.normSq μ : ℂ) * (star x ⬝ᵥ (S *ᵥ x)) := by
    rw [Complex.normSq_eq_conj_mul_self]
    simp only [star_smul, Matrix.mulVec_smul, smul_dotProduct, dotProduct_smul,
      smul_eq_mul, Complex.star_def]
    ring
  rw [hq] at hn
  have hnr : Complex.normSq μ * RCLike.re (star x ⬝ᵥ (S *ᵥ x)) ≤
      RCLike.re (star x ⬝ᵥ (S *ᵥ x)) := by
    simpa only [RCLike.re_to_complex, Complex.mul_re, Complex.ofReal_re,
      Complex.ofReal_im, zero_mul, sub_zero] using hn
  have hpos := hS.re_dotProduct_pos hx
  have hs : Complex.normSq μ ≤ 1 :=
    (mul_le_mul_iff_left₀ hpos).mp (by simpa only [one_mul] using hnr)
  rw [Complex.normSq_eq_norm_sq] at hs
  nlinarith [norm_nonneg μ]

/-- Weighted normality constructs the full orthonormal eigenbasis;
the contraction inequality simultaneously confines its eigenvalues
to the source disk. No diagonalization is an input hypothesis. -/
theorem weightedNormalContraction_eigenbasis (S M : Matrix ι ι ℂ)
    (hS : S.PosDef)
    (hnormal : M * weightedAdjoint S M = weightedAdjoint S M * M)
    (hcontract : (S - Mᴴ * S * M).PosSemidef) :
    letI := Matrix.NormedAddCommGroup.ofMatrix hS
    letI := Matrix.InnerProductSpace.ofMatrix hS
    ∃ (b : OrthonormalBasis (Fin (Module.finrank ℂ (ι → ℂ))) ℂ (ι → ℂ))
      (μ : Fin (Module.finrank ℂ (ι → ℂ)) → ℂ),
      (∀ i, M *ᵥ b i = μ i • b i) ∧ (∀ i, ‖μ i‖ ≤ 1) := by
  letI := Matrix.NormedAddCommGroup.ofMatrix hS
  letI := Matrix.InnerProductSpace.ofMatrix hS
  obtain ⟨b, μ, heig⟩ := NormalSpectrum.exists_orthonormal_eigenbasis M.mulVecLin
    (weightedNormal_isStarNormal S M hS hnormal)
  refine ⟨b, μ, heig, fun i => ?_⟩
  exact weightedContraction_eigenvalue S M hS hcontract (μ i) (b i)
    (b.toBasis.ne_zero i) (heig i)

theorem diagonal_normal (α : ι → ℂ) :
    Matrix.diagonal α * (Matrix.diagonal α)ᴴ =
      (Matrix.diagonal α)ᴴ * Matrix.diagonal α := by
  simp [Matrix.diagonal_conjTranspose, Matrix.diagonal_mul_diagonal, mul_comm]

theorem diagonal_contraction (α : ι → ℂ) (hα : ∀ i, ‖α i‖ ≤ 1) :
    (1 - (Matrix.diagonal α)ᴴ * Matrix.diagonal α).PosSemidef := by
  rw [Matrix.diagonal_conjTranspose, Matrix.diagonal_mul_diagonal,
    ← Matrix.diagonal_one, Matrix.diagonal_sub]
  apply Matrix.PosSemidef.diagonal
  intro i
  have hsq : Complex.normSq (α i) ≤ 1 := by
    rw [Complex.normSq_eq_norm_sq]
    nlinarith [hα i, norm_nonneg (α i)]
  change (0 : ℂ) ≤ 1 - star (α i) * α i
  have he : 1 - star (α i) * α i = ((1 - Complex.normSq (α i) : ℝ) : ℂ) := by
    rw [Complex.ofReal_sub, Complex.ofReal_one, Complex.normSq_eq_conj_mul_self]
    rfl
  rw [he]
  exact_mod_cast sub_nonneg.mpr hsq

/-- Necessity of the completion test from a genuine diagonal source
basis. Invertibility of the basis is derived from its positive Gram
matrix, rather than assumed separately. -/
theorem completion_test_of_source_basis (S M B : Matrix ι ι ℂ) (α : ι → ℂ)
    (hS : S.PosDef) (hα : ∀ i, ‖α i‖ ≤ 1)
    (hGram : Bᴴ * B = S) (hintertwine : Matrix.diagonal α * B = B * M) :
    M * weightedAdjoint S M = weightedAdjoint S M * M ∧
      (S - Mᴴ * S * M).PosSemidef := by
  have hB : IsUnit B.det := by
    have hu : IsUnit (Bᴴ * B).det := by
      rw [hGram]
      exact (Matrix.isUnit_iff_isUnit_det S).mp hS.isUnit
    rw [Matrix.det_mul] at hu
    exact isUnit_iff_ne_zero.mpr (fun hz => by simpa [hz] using hu.ne_zero)
  have hsimilar : B⁻¹ * Matrix.diagonal α * B = M := by
    calc
      B⁻¹ * Matrix.diagonal α * B = B⁻¹ * (Matrix.diagonal α * B) := by noncomm_ring
      _ = B⁻¹ * (B * M) := by rw [hintertwine]
      _ = M := by rw [← Matrix.mul_assoc, Matrix.nonsing_inv_mul B hB, Matrix.one_mul]
  constructor
  · have hh := weightedNormal_similarity (Matrix.diagonal α) B hB (diagonal_normal α)
    rwa [hsimilar, hGram] at hh
  · have hh := weightedContraction_similarity (Matrix.diagonal α) B hB (diagonal_contraction α hα)
    rwa [hsimilar, hGram] at hh

end WeightedSimilarity

section SpectralSources

variable {E κ : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]
  [Fintype κ]

/-- The observation functional associated with the distinguished source
vector. It is linear in the state, with the inner product linear on the right. -/
def innerOutput (f : E) : E →ₗ[ℂ] ℂ := (innerSL ℂ f).toLinearMap

/-- The mass of a source recovered from an orthonormal eigenvector. -/
def spectralMass (b : OrthonormalBasis κ ℂ E) (f : E) (i : κ) : ℝ :=
  ‖inner ℂ (b i) f‖ ^ 2

/-- An observed eigenvector cannot be orthogonal to the source vector. -/
theorem spectralMass_pos (T : E →ₗ[ℂ] E) (f : E)
    (hobs : EigenObservable T (innerOutput f))
    (b : OrthonormalBasis κ ℂ E) (μ : κ → ℂ)
    (heig : ∀ i, T (b i) = μ i • b i) (i : κ) :
    0 < spectralMass b f i := by
  apply pow_pos
  apply norm_pos_iff.mpr
  intro hz
  have hzero : innerOutput f (b i) = 0 := (inner_eq_zero_symm).mp hz
  exact b.toBasis.ne_zero i (hobs (μ i) (b i) (heig i) hzero)

/-- Parseval's identity fixes the total recovered source mass. -/
theorem spectralMass_total (b : OrthonormalBasis κ ℂ E) (f : E) :
    ∑ i, spectralMass b f i = ‖f‖ ^ 2 :=
  b.sum_sq_norm_inner_right f

theorem spectralMass_total_inner (b : OrthonormalBasis κ ℂ E) (f : E) :
    ∑ i, spectralMass b f i = RCLike.re (inner ℂ f f) := by
  rw [spectralMass_total, norm_sq_eq_re_inner (𝕜 := ℂ)]

/-- Observability makes every eigenspace one-dimensional. -/
theorem observable_eigenvectors_cross_proportional
    (T : E →ₗ[ℂ] E) (ell : E →ₗ[ℂ] ℂ) (hobs : EigenObservable T ell)
    (μ : ℂ) (x y : E) (hx : T x = μ • x) (hy : T y = μ • y) :
    ell x • y = ell y • x := by
  let z := ell x • y - ell y • x
  have hz : T z = μ • z := by
    dsimp [z]
    simp only [map_sub, map_smul, hx, hy, smul_sub]
    module
  have hout : ell z = 0 := by
    dsimp [z]
    simp only [map_sub, map_smul, smul_eq_mul]
    ring
  exact sub_eq_zero.mp (hobs μ z hz hout)

omit [Fintype κ] in
/-- The observed normal operator has distinct source positions. -/
theorem observable_eigenbasis_distinct
    (T : E →ₗ[ℂ] E) (ell : E →ₗ[ℂ] ℂ) (hobs : EigenObservable T ell)
    (b : Basis κ ℂ E) (μ : κ → ℂ) (hb : ∀ i, T (b i) = μ i • b i) :
    Function.Injective μ := by
  classical
  intro i j hij
  by_contra hne
  have hj : T (b j) = μ i • b j := by simpa [hij] using hb j
  have hcross := observable_eigenvectors_cross_proportional T ell hobs (μ i)
    (b i) (b j) (hb i) hj
  have hcoord := congrArg (fun x => b.repr x i) hcross
  simp [hne] at hcoord
  exact b.ne_zero j (hobs (μ j) (b j) (hb j) hcoord.symm)

/-- A normal operator observed by one source vector determines a full
set of distinct spectral positions with strictly positive masses and
the prescribed total mass. This is the spectral part of sufficiency. -/
theorem exists_positive_spectral_sources [FiniteDimensional ℂ E]
    (T : E →ₗ[ℂ] E) (hT : IsStarNormal T) (f : E)
    (hobs : EigenObservable T (innerOutput f)) :
    ∃ (b : OrthonormalBasis (Fin (Module.finrank ℂ E)) ℂ E)
      (μ : Fin (Module.finrank ℂ E) → ℂ),
      (∀ i, T (b i) = μ i • b i) ∧ Function.Injective μ ∧
      (∀ i, 0 < spectralMass b f i) ∧
      ∑ i, spectralMass b f i = ‖f‖ ^ 2 := by
  obtain ⟨b, μ, heig⟩ := NormalSpectrum.exists_orthonormal_eigenbasis T hT
  exact ⟨b, μ, heig, observable_eigenbasis_distinct T (innerOutput f) hobs
    b.toBasis μ heig, spectralMass_pos T f hobs b μ heig, spectralMass_total b f⟩

/-- Rotation of an eigen-coordinate that makes its source coordinate
real and positive. -/
def sourcePhase (z : ℂ) : ℂ := (‖z‖ : ℂ) / z

theorem sourcePhase_mul (z : ℂ) (hz : z ≠ 0) :
    sourcePhase z * z = (‖z‖ : ℂ) := by
  exact div_mul_cancel₀ _ hz

theorem sourcePhase_unit (z : ℂ) (hz : z ≠ 0) :
    star (sourcePhase z) * sourcePhase z = 1 := by
  have hn : (‖z‖ : ℂ) * (‖z‖ : ℂ) = star z * z := by
    rw [← Complex.ofReal_mul, Complex.norm_mul_self_eq_normSq,
      Complex.normSq_eq_conj_mul_self]
    rfl
  dsimp [sourcePhase]
  rw [map_div₀, Complex.conj_ofReal, div_mul_div_comm, hn]
  change (star z * z) / (star z * z) = 1
  exact div_self (mul_ne_zero (star_ne_zero.mpr hz) hz)

/-- The actual source-coordinate transformation constructed from the
orthonormal spectral basis, with positive source entries. -/
def sourceCoordinates (b : OrthonormalBasis κ ℂ E) (f : E) : E →ₗ[ℂ] (κ → ℂ) :=
  LinearMap.pi fun i => sourcePhase (inner ℂ (b i) f) • innerOutput (b i)

@[simp] theorem sourceCoordinates_apply (b : OrthonormalBasis κ ℂ E) (f x : E) (i : κ) :
    sourceCoordinates b f x i = sourcePhase (inner ℂ (b i) f) * inner ℂ (b i) x := rfl

theorem sourceCoordinates_source (b : OrthonormalBasis κ ℂ E) (f : E)
    (hnz : ∀ i, inner ℂ (b i) f ≠ 0) (i : κ) :
    sourceCoordinates b f f i = (‖inner ℂ (b i) f‖ : ℂ) :=
  sourcePhase_mul _ (hnz i)

/-- The reconstructed transformation preserves the complete Gram form,
not just the norm of each column separately. -/
theorem sourceCoordinates_inner (b : OrthonormalBasis κ ℂ E) (f : E)
    (hnz : ∀ i, inner ℂ (b i) f ≠ 0) (x y : E) :
    star (sourceCoordinates b f x) ⬝ᵥ sourceCoordinates b f y = inner ℂ x y := by
  calc
    star (sourceCoordinates b f x) ⬝ᵥ sourceCoordinates b f y =
        ∑ i, inner ℂ x (b i) * inner ℂ (b i) y := by
      apply Finset.sum_congr rfl
      intro i hi
      simp only [Pi.star_apply, sourceCoordinates_apply, StarMul.star_mul]
      calc
        star (inner ℂ (b i) x) * star (sourcePhase (inner ℂ (b i) f)) *
            (sourcePhase (inner ℂ (b i) f) * inner ℂ (b i) y) =
          (star (sourcePhase (inner ℂ (b i) f)) * sourcePhase (inner ℂ (b i) f)) *
            (star (inner ℂ (b i) x) * inner ℂ (b i) y) := by ring
        _ = inner ℂ x (b i) * inner ℂ (b i) y := by
          rw [sourcePhase_unit _ (hnz i), one_mul]
          exact congrArg (fun z => z * inner ℂ (b i) y) (inner_conj_symm _ _)
    _ = inner ℂ x y := b.sum_inner_mul_inner x y

theorem sourceCoordinates_injective (b : OrthonormalBasis κ ℂ E) (f : E)
    (hnz : ∀ i, inner ℂ (b i) f ≠ 0) : Function.Injective (sourceCoordinates b f) := by
  apply LinearMap.ker_eq_bot.mp
  apply LinearMap.ker_eq_bot'.mpr
  intro x hx
  have h := sourceCoordinates_inner b f hnz x x
  rw [hx, star_zero, zero_dotProduct] at h
  exact inner_self_eq_zero.mp h.symm

/-- Every coordinate of the transformed operator is diagonal. -/
theorem eigenbasis_inner_map (T : E →ₗ[ℂ] E) (b : OrthonormalBasis κ ℂ E)
    (μ : κ → ℂ) (heig : ∀ i, T (b i) = μ i • b i) (x : E) (i : κ) :
    inner ℂ (b i) (T x) = μ i * inner ℂ (b i) x := by
  classical
  nth_rw 1 [← b.sum_repr' x]
  simp only [map_sum, map_smul, heig, inner_sum, inner_smul_right, smul_smul]
  simp [orthonormal_iff_ite.mp b.orthonormal, mul_comm]

theorem sourceCoordinates_intertwines (T : E →ₗ[ℂ] E)
    (b : OrthonormalBasis κ ℂ E) (μ : κ → ℂ)
    (heig : ∀ i, T (b i) = μ i • b i) (f x : E) (i : κ) :
    sourceCoordinates b f (T x) i = μ i * sourceCoordinates b f x i := by
  simp only [sourceCoordinates_apply, eigenbasis_inner_map T b μ heig, mul_left_comm]

/-- The positive square-root masses in the reconstructed source coordinates. -/
def recoveredWeights (b : OrthonormalBasis κ ℂ E) (f : E) : κ → ℂ :=
  fun i => (‖inner ℂ (b i) f‖ : ℂ)

/-- Images of the prescribed genuine-coordinate columns in source space. -/
def recoveredColumns {ι : Type*} (b : OrthonormalBasis κ ℂ E) (f : E)
    (p : ι → E) : Matrix κ ι ℂ := fun j i => sourceCoordinates b f (p i) j

theorem recoveredColumns_gram {ι : Type*} (b : OrthonormalBasis κ ℂ E)
    (f : E) (hnz : ∀ i, inner ℂ (b i) f ≠ 0) (p : ι → E)
    (H : Matrix ι ι ℂ) (hH : ∀ i j, inner ℂ (p i) (p j) = H i j) :
    (recoveredColumns b f p)ᴴ * recoveredColumns b f p = H := by
  ext i j
  exact (sourceCoordinates_inner b f hnz (p i) (p j)).trans (hH i j)

theorem recoveredColumns_source_orthogonal {ι : Type*}
    (b : OrthonormalBasis κ ℂ E) (f : E)
    (hnz : ∀ i, inner ℂ (b i) f ≠ 0) (p : ι → E)
    (hortho : ∀ i, inner ℂ f (p i) = 0) :
    star (recoveredWeights b f) ᵥ* recoveredColumns b f p = 0 := by
  have hweight : sourceCoordinates b f f = recoveredWeights b f :=
    funext (sourceCoordinates_source b f hnz)
  ext i
  change star (recoveredWeights b f) ⬝ᵥ sourceCoordinates b f (p i) = 0
  rw [← hweight, sourceCoordinates_inner b f hnz, hortho]

/-- The reconstructed sources satisfy the original source equations,
including all Jordan-chain columns, whenever the completed operator
has the prescribed bordered action on those coordinate columns. -/
theorem recoveredColumns_source_identity {ι : Type*} [Fintype ι] [DecidableEq κ]
    (T : E →ₗ[ℂ] E) (b : OrthonormalBasis κ ℂ E) (μ : κ → ℂ)
    (heig : ∀ i, T (b i) = μ i • b i) (f : E)
    (hnz : ∀ i, inner ℂ (b i) f ≠ 0) (p : ι → E)
    (J : Matrix ι ι ℂ) (e : ι → ℂ)
    (hcol : ∀ i, T (p i) = (∑ l, J l i • p l) - star (e i) • f) :
    Matrix.diagonal μ * recoveredColumns b f p =
      recoveredColumns b f p * J - Matrix.vecMulVec (recoveredWeights b f) (star e) := by
  ext j i
  have hh := congrArg (fun x => sourceCoordinates b f x j) (hcol i)
  dsimp only at hh
  rw [sourceCoordinates_intertwines T b μ heig] at hh
  simp only [map_sub, map_sum, map_smul, Pi.sub_apply, Finset.sum_apply,
    Pi.smul_apply, smul_eq_mul, sourceCoordinates_source b f hnz] at hh
  rw [Matrix.diagonal_mul]
  simpa only [Matrix.sub_apply, Matrix.mul_apply,
    Matrix.vecMulVec_apply, Pi.star_apply, recoveredColumns, recoveredWeights,
    mul_comm] using hh

/-- A nonzero selected eigenvector appears among the recovered sources. -/
theorem eigenvalue_eq_basis_value (T : E →ₗ[ℂ] E)
    (b : OrthonormalBasis κ ℂ E) (μ : κ → ℂ)
    (heig : ∀ i, T (b i) = μ i • b i) (a : ℂ) (v : E)
    (hv : T v = a • v) (hv0 : v ≠ 0) : ∃ i, μ i = a := by
  classical
  by_contra hnone
  have hz : ∀ i, inner ℂ (b i) v = 0 := by
    intro i
    have hh := eigenbasis_inner_map T b μ heig v i
    rw [hv, inner_smul_right] at hh
    exact (mul_eq_mul_right_iff.mp hh).resolve_left (by
      intro ha
      exact hnone ⟨i, ha.symm⟩)
  have hzero : v = 0 := by
    rw [← b.sum_repr' v]
    simp [hz]
  exact hv0 hzero

/-- The selected source has mass one, derived from the normalized
selected eigenvector and its pairing with the source vector. -/
theorem selected_spectralMass_eq_one (T : E →ₗ[ℂ] E) (f : E)
    (hobs : EigenObservable T (innerOutput f))
    (b : OrthonormalBasis κ ℂ E) (μ : κ → ℂ)
    (heig : ∀ i, T (b i) = μ i • b i) (a : ℂ) (v : E)
    (hv : T v = a • v) (hunit : ‖v‖ = 1) (hpair : inner ℂ v f = 1)
    (i : κ) (hi : μ i = a) : spectralMass b f i = 1 := by
  have hout : innerOutput f v = 1 := by
    change inner ℂ f v = 1
    rw [← inner_conj_symm f v, hpair, map_one]
  have hbi : T (b i) = a • b i := by simpa [hi] using heig i
  have hcross := observable_eigenvectors_cross_proportional T (innerOutput f)
    hobs a v (b i) hv hbi
  rw [hout, one_smul] at hcross
  have hn := congrArg norm hcross
  rw [b.norm_eq_one, norm_smul, hunit, mul_one] at hn
  dsimp [spectralMass]
  have hconj : ‖inner ℂ (b i) f‖ = ‖innerOutput f (b i)‖ := by
    change ‖inner ℂ (b i) f‖ = ‖inner ℂ f (b i)‖
    rw [← inner_conj_symm f (b i), RCLike.norm_conj]
  rw [hconj, ← hn, one_pow]

theorem selected_spectralMass_eq_one_of_inner (T : E →ₗ[ℂ] E) (f : E)
    (hobs : EigenObservable T (innerOutput f))
    (b : OrthonormalBasis κ ℂ E) (μ : κ → ℂ)
    (heig : ∀ i, T (b i) = μ i • b i) (a : ℂ) (v : E)
    (hv : T v = a • v) (hunit : inner ℂ v v = 1) (hpair : inner ℂ v f = 1)
    (i : κ) (hi : μ i = a) : spectralMass b f i = 1 := by
  apply selected_spectralMass_eq_one T f hobs b μ heig a v hv _ hpair i hi
  have hn := norm_sq_eq_re_inner (𝕜 := ℂ) v
  rw [hunit, RCLike.one_re] at hn
  nlinarith [norm_nonneg v]

theorem spectralMass_eq_output_norm (b : OrthonormalBasis κ ℂ E) (f : E) (i : κ) :
    spectralMass b f i = ‖innerOutput f (b i)‖ ^ 2 := by
  dsimp [spectralMass, innerOutput]
  rw [← inner_conj_symm f (b i), RCLike.norm_conj]

/-- The mass at a simple observed eigenvalue is independent of the
phase and of the chosen orthonormal spectral basis. -/
theorem spectralMass_eq_of_eigenvalue {τ : Type*} [Fintype τ]
    (T : E →ₗ[ℂ] E) (f : E) (hobs : EigenObservable T (innerOutput f))
    (b : OrthonormalBasis κ ℂ E) (α : κ → ℂ)
    (hb : ∀ i, T (b i) = α i • b i)
    (c : OrthonormalBasis τ ℂ E) (β : τ → ℂ)
    (hc : ∀ j, T (c j) = β j • c j)
    (i : κ) (j : τ) (hij : α i = β j) :
    spectralMass b f i = spectralMass c f j := by
  have hcj : T (c j) = α i • c j := by simpa [hij] using hc j
  have hcross := observable_eigenvectors_cross_proportional T (innerOutput f)
    hobs (α i) (b i) (c j) (hb i) hcj
  have hn := congrArg norm hcross
  simp only [norm_smul, b.norm_eq_one, c.norm_eq_one, mul_one] at hn
  rw [spectralMass_eq_output_norm, spectralMass_eq_output_norm, hn]

/-- The complete positive spectral source data are unique up to ordering.
Both the source positions and their masses are matched by the same
permutation; no uniqueness of phases is asserted or required. -/
theorem spectral_sources_unique {τ : Type*} [Fintype τ]
    (T : E →ₗ[ℂ] E) (f : E) (hobs : EigenObservable T (innerOutput f))
    (b : OrthonormalBasis κ ℂ E) (α : κ → ℂ)
    (hb : ∀ i, T (b i) = α i • b i)
    (c : OrthonormalBasis τ ℂ E) (β : τ → ℂ)
    (hc : ∀ j, T (c j) = β j • c j) :
    ∃ q : κ ≃ τ, ∀ i, α i = β (q i) ∧ spectralMass b f i = spectralMass c f (q i) := by
  classical
  have ha := observable_eigenbasis_distinct T (innerOutput f) hobs b.toBasis α hb
  have hb' := observable_eigenbasis_distinct T (innerOutput f) hobs c.toBasis β hc
  have hex : ∀ i, ∃ j, β j = α i := by
    intro i
    exact eigenvalue_eq_basis_value T c β hc (α i) (b i) (hb i) (b.toBasis.ne_zero i)
  choose q hq using hex
  have hqinj : Function.Injective q := by
    intro i j hij
    apply ha
    rw [← hq i, ← hq j, hij]
  have hqsurj : Function.Surjective q := by
    intro j
    obtain ⟨i, hi⟩ := eigenvalue_eq_basis_value T b α hb (β j) (c j) (hc j) (c.toBasis.ne_zero j)
    exact ⟨i, hb' ((hq i).trans hi)⟩
  refine ⟨Equiv.ofBijective q ⟨hqinj, hqsurj⟩, fun i => ?_⟩
  exact ⟨(hq i).symm, spectralMass_eq_of_eigenvalue T f hobs b α hb c β hc i (q i) (hq i).symm⟩

end SpectralSources

section ResolventRecovery

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- One nonzero source row excludes its source position from the
critical spectrum. This follows from observability and the source
equation, without any separate separation hypothesis. -/
theorem sourceRow_resolvent_isUnit (J : Matrix ι ι ℂ) (e y : ι → ℂ)
    (μ b : ℂ) (hb : b ≠ 0)
    (hobs : EigenObservable J.mulVecLin (rowFunctional e))
    (hrow : y ᵥ* J = μ • y + b • star e) :
    IsUnit (μ • (1 : Matrix ι ι ℂ) - J) := by
  apply Matrix.mulVec_injective_iff_isUnit.mp
  change Function.Injective (μ • (1 : Matrix ι ι ℂ) - J).mulVecLin
  apply LinearMap.ker_eq_bot.mp
  apply LinearMap.ker_eq_bot'.mpr
  intro x hx
  have hJ : J *ᵥ x = μ • x := by
    change (μ • (1 : Matrix ι ι ℂ) - J) *ᵥ x = 0 at hx
    rw [Matrix.sub_mulVec, Matrix.smul_mulVec, Matrix.one_mulVec] at hx
    exact (sub_eq_zero.mp hx).symm
  have hout : rowFunctional e x = 0 := by
    have hh := congrArg (fun v : ι → ℂ => v ⬝ᵥ x) hrow
    dsimp only at hh
    rw [← Matrix.dotProduct_mulVec, hJ] at hh
    simp only [dotProduct_smul, add_dotProduct, smul_dotProduct, smul_eq_mul] at hh
    change star e ⬝ᵥ x = 0
    exact (mul_eq_zero.mp (show b * (star e ⬝ᵥ x) = 0 by linear_combination -hh)).resolve_left hb
  exact hobs μ x hJ hout

/-- The recovered row is exactly the canonical resolvent row, including
the scale given by the positive square-root source mass. -/
theorem sourceRow_eq_resolvent (J : Matrix ι ι ℂ) (e y : ι → ℂ)
    (μ b : ℂ) (hb : b ≠ 0)
    (hobs : EigenObservable J.mulVecLin (rowFunctional e))
    (hrow : y ᵥ* J = μ • y + b • star e) :
    y = -b • (star e ᵥ* (μ • (1 : Matrix ι ι ℂ) - J)⁻¹) := by
  let Q := μ • (1 : Matrix ι ι ℂ) - J
  have hu : IsUnit Q := sourceRow_resolvent_isUnit J e y μ b hb hobs hrow
  have hrel : y ᵥ* Q = -b • star e := by
    dsimp [Q]
    rw [Matrix.vecMul_sub, Matrix.vecMul_smul, Matrix.vecMul_one, hrow]
    module
  have hh := congrArg (fun v : ι → ℂ => v ᵥ* Q⁻¹) hrel
  dsimp only at hh
  rw [Matrix.vecMul_vecMul, Matrix.mul_nonsing_inv Q
    ((Matrix.isUnit_iff_isUnit_det Q).mp hu), Matrix.vecMul_one,
    Matrix.smul_vecMul] at hh
  exact hh

variable {κ : Type*} [Fintype κ] [DecidableEq κ]

omit [DecidableEq ι] in
theorem sourceIdentity_row (J : Matrix ι ι ℂ) (e : ι → ℂ)
    (μ b : κ → ℂ) (Y : Matrix κ ι ℂ)
    (hsource : Matrix.diagonal μ * Y = Y * J - Matrix.vecMulVec b (star e)) (j : κ) :
    (fun i => Y j i) ᵥ* J = μ j • (fun i => Y j i) + b j • star e := by
  funext i
  have hh := congrArg (fun A : Matrix κ ι ℂ => A j i) hsource
  dsimp only at hh
  rw [Matrix.diagonal_mul] at hh
  simp only [Matrix.sub_apply, Matrix.vecMulVec_apply, Pi.star_apply] at hh
  change (Y * J) j i = μ j * Y j i + b j * star (e i)
  linear_combination -hh

/-- Every recovered source coordinate is the prescribed resolvent row.
Consequently the spectral construction recovers the full canonical
matrix, rather than only an unspecified similar realization. -/
theorem sourceIdentity_canonical_rows (J : Matrix ι ι ℂ) (e : ι → ℂ)
    (μ b : κ → ℂ) (Y : Matrix κ ι ℂ)
    (hobs : EigenObservable J.mulVecLin (rowFunctional e))
    (hb : ∀ j, b j ≠ 0)
    (hsource : Matrix.diagonal μ * Y = Y * J - Matrix.vecMulVec b (star e)) :
    ∀ j, IsUnit (μ j • (1 : Matrix ι ι ℂ) - J) ∧
      (fun i => Y j i) = -b j • (star e ᵥ* (μ j • (1 : Matrix ι ι ℂ) - J)⁻¹) := by
  intro j
  have hr := sourceIdentity_row J e μ b Y hsource j
  exact ⟨sourceRow_resolvent_isUnit J e _ (μ j) (b j) (hb j) hobs hr,
    sourceRow_eq_resolvent J e _ (μ j) (b j) (hb j) hobs hr⟩

end ResolventRecovery

section ConcreteCompletion

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The genuine-coordinate columns of the actual bordered matrix have
exactly the prescribed chain action. -/
theorem completion_state_action (J : Matrix ι ι ℂ) (e : ι → ℂ) (γ : ℂ)
    (d : ι → ℂ) (i : ι) :
    (BlockMetric.completion J e γ d).mulVecLin (BlockMetric.stateVector i) =
      (∑ l, J l i • BlockMetric.stateVector l) - star (e i) • BlockMetric.firstVector := by
  ext j
  cases j <;>
    simp [BlockMetric.stateVector, BlockMetric.firstVector, Matrix.mulVec_single,
      BlockMetric.completion, Finset.sum_apply, Pi.smul_apply, Pi.sub_apply,
      Pi.single_apply]

/-- Canonical observability of the genuine coordinates transfers to the
completed operator with observation by the actual source vector. -/
theorem completion_eigenObservable (n : ℝ) (H J : Matrix ι ι ℂ)
    (e : ι → ℂ) (γ : ℂ) (d : ι → ℂ) (hn : 0 < n) (hH : H.PosDef)
    (hobs : EigenObservable J.mulVecLin (rowFunctional e)) :
    letI := Matrix.NormedAddCommGroup.ofMatrix (BlockMetric.metric_posDef n H hn hH)
    letI := Matrix.InnerProductSpace.ofMatrix (BlockMetric.metric_posDef n H hn hH)
    EigenObservable (BlockMetric.completion J e γ d).mulVecLin
      (innerOutput BlockMetric.firstVector) := by
  letI := Matrix.NormedAddCommGroup.ofMatrix (BlockMetric.metric_posDef n H hn hH)
  letI := Matrix.InnerProductSpace.ofMatrix (BlockMetric.metric_posDef n H hn hH)
  intro μ x hx hout
  have hnC : (n : ℂ) ≠ 0 := by exact_mod_cast ne_of_gt hn
  have hfirst : x none = 0 := by
    change ((BlockMetric.metric n H) *ᵥ x) ⬝ᵥ star BlockMetric.firstVector = 0 at hout
    have hh : (n : ℂ) * x none = 0 := by
      simpa [BlockMetric.firstVector, ← Pi.single_star, BlockMetric.metric_mulVec] using hout
    exact (mul_eq_zero.mp hh).resolve_left hnC
  have hcoords := congrArg (BlockMetric.coordinates (ι := ι)) hx
  rw [map_smul] at hcoords
  change BlockMetric.coordinates ((BlockMetric.completion J e γ d) *ᵥ x) =
    μ • BlockMetric.coordinates x at hcoords
  rw [BlockMetric.completion_action] at hcoords
  have hz := border_eigenvector_eq_zero_of_first_eq_zero J.mulVecLin
    (rowFunctional e) γ d hobs μ (BlockMetric.coordinates x) hcoords hfirst
  exact BlockMetric.coordinates.injective (hz.trans (map_zero BlockMetric.coordinates).symm)

/-- The unique normalized candidate, expressed as an actual square matrix. -/
def normalizedCompletion (a : ℂ) (n : ℝ) (H J R : Matrix ι ι ℂ) (e : ι → ℂ) :
    Matrix (Option ι) (Option ι) ℂ :=
  BlockMetric.completion J e
    (normalizedScalar a n (rowFunctional e) (recoveryVector H R e))
    (normalizedColumn a n J.mulVecLin (recoveryVector H R e))

omit [DecidableEq ι] in
theorem metricPair_coordinates (n : ℝ) (H : Matrix ι ι ℂ)
    (x y : Option ι → ℂ) :
    ((BlockMetric.metric n H) *ᵥ y) ⬝ᵥ star x =
      weightedPair n H (BlockMetric.coordinates x) (BlockMetric.coordinates y) := by
  rw [dotProduct_comm, BlockMetric.metric_inner]
  rfl

/-- Sufficient direction of the normalized inverse construction, with
the actual source matrix, positive weights, prescribed Gram matrix,
selected source of mass one, and canonical resolvent rows all constructed.
The returned `ω` consists of square-root masses, so the source masses
are `ω j ^ 2`. In the article `R = (aI-J)⁻¹`; the proof works for every
`R` satisfying the displayed selected-source normalization. -/
theorem normalizedCompletion_realization
    (a : ℂ) (n : ℝ) (H J R : Matrix ι ι ℂ) (e : ι → ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hobs : EigenObservable J.mulVecLin (rowFunctional e))
    (hnorm : normalization H R e = 1 - (n : ℂ)⁻¹)
    (hnormal : normalizedCompletion a n H J R e *
        weightedAdjoint (BlockMetric.metric n H) (normalizedCompletion a n H J R e) =
      weightedAdjoint (BlockMetric.metric n H) (normalizedCompletion a n H J R e) *
        normalizedCompletion a n H J R e)
    (hcontract : (BlockMetric.metric n H - (normalizedCompletion a n H J R e)ᴴ *
      BlockMetric.metric n H * normalizedCompletion a n H J R e).PosSemidef) :
    ∃ (α : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℂ)
      (ω : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℝ)
      (Y : Matrix (Fin (Module.finrank ℂ (Option ι → ℂ))) ι ℂ),
      Function.Injective α ∧ (∀ j, 0 < ω j ∧ ‖α j‖ ≤ 1) ∧
      (∑ j, ω j ^ 2) = n ∧ (∃ j, α j = a ∧ ω j = 1) ∧
      Yᴴ * Y = H ∧ star (fun j => (ω j : ℂ)) ᵥ* Y = 0 ∧
      Matrix.diagonal α * Y = Y * J - Matrix.vecMulVec (fun j => (ω j : ℂ)) (star e) ∧
      ∀ j, IsUnit (α j • (1 : Matrix ι ι ℂ) - J) ∧
        (fun i => Y j i) = -(ω j : ℂ) •
          (star e ᵥ* (α j • (1 : Matrix ι ι ℂ) - J)⁻¹) := by
  let S := BlockMetric.metric n H
  have hS : S.PosDef := BlockMetric.metric_posDef n H hn hH
  letI := Matrix.NormedAddCommGroup.ofMatrix hS
  letI := Matrix.InnerProductSpace.ofMatrix hS
  let M := normalizedCompletion a n H J R e
  let f : Option ι → ℂ := BlockMetric.firstVector
  let p : ι → (Option ι → ℂ) := BlockMetric.stateVector
  have hcomp : EigenObservable M.mulVecLin (innerOutput f) :=
    completion_eigenObservable n H J e _ _ hn hH hobs
  obtain ⟨b, α, heig, hdisk⟩ := weightedNormalContraction_eigenbasis S M hS hnormal hcontract
  have hnz : ∀ j, inner ℂ (b j) f ≠ 0 := by
    intro j hz
    have hh := spectralMass_pos M.mulVecLin f hcomp b α heig j
    simp [spectralMass, hz] at hh
  let ω := fun j => ‖inner ℂ (b j) f‖
  let Y := recoveredColumns b f p
  have hinj : Function.Injective α :=
    observable_eigenbasis_distinct M.mulVecLin (innerOutput f) hcomp b.toBasis α heig
  have htotal : (∑ j, ω j ^ 2) = n := by
    have hh := spectralMass_total_inner b f
    change (∑ j, ω j ^ 2) = RCLike.re ((S *ᵥ f) ⬝ᵥ star f) at hh
    rw [dotProduct_comm, BlockMetric.firstVector_energy] at hh
    exact hh
  let v := BlockMetric.coordinates.symm
    (selectedVector (n : ℂ) (recoveryVector H R e))
  have hveig : M.mulVecLin v = a • v := by
    apply BlockMetric.coordinates.injective
    rw [map_smul]
    change BlockMetric.coordinates ((normalizedCompletion a n H J R e) *ᵥ v) = _
    rw [normalizedCompletion, BlockMetric.completion_action]
    change border J.mulVecLin (rowFunctional e)
      (normalizedScalar a n (rowFunctional e) (recoveryVector H R e))
      (normalizedColumn a n J.mulVecLin (recoveryVector H R e))
      (selectedVector (n : ℂ) (recoveryVector H R e)) =
      a • selectedVector (n : ℂ) (recoveryVector H R e)
    exact normalizedBorder_selected_eigenvector _ _ _ _ _ (by exact_mod_cast ne_of_gt hn)
  have hvunit : inner ℂ v v = 1 := by
    change (S *ᵥ v) ⬝ᵥ star v = 1
    rw [metricPair_coordinates]
    change weightedPair n H (selectedVector (n : ℂ) (recoveryVector H R e))
      (selectedVector (n : ℂ) (recoveryVector H R e)) = 1
    exact selectedVector_unit_energy n H R e (ne_of_gt hn) hH.isHermitian
      ((Matrix.isUnit_iff_isUnit_det H).mp hH.isUnit) hnorm
  have hvpair : inner ℂ v f = 1 := by
    change (S *ᵥ f) ⬝ᵥ star v = 1
    rw [metricPair_coordinates]
    have hf : BlockMetric.coordinates f = firstCoordinate := by
      ext i <;> simp [f, BlockMetric.coordinates, BlockMetric.firstVector, firstCoordinate]
    rw [hf]
    exact selected_firstCoordinate_pair n H _ (ne_of_gt hn)
  have hvne : v ≠ 0 := by
    intro hvzero
    apply selectedVector_ne_zero (n : ℂ) (recoveryVector H R e)
      (by exact_mod_cast ne_of_gt hn)
    simpa only [v, LinearEquiv.apply_symm_apply, map_zero] using
      congrArg (BlockMetric.coordinates (ι := ι)) hvzero
  obtain ⟨j₀, hj₀⟩ := eigenvalue_eq_basis_value M.mulVecLin b α heig a v hveig hvne
  have hmass₀ := selected_spectralMass_eq_one_of_inner M.mulVecLin f hcomp b α heig
    a v hveig hvunit hvpair j₀ hj₀
  have hω₀ : ω j₀ = 1 := by
    change ω j₀ ^ 2 = 1 at hmass₀
    have hωpos : 0 ≤ ω j₀ := norm_nonneg _
    nlinarith
  have hGram : Yᴴ * Y = H := by
    apply recoveredColumns_gram b f hnz p H
    intro i j
    change (S *ᵥ p j) ⬝ᵥ star (p i) = H i j
    rw [dotProduct_comm, BlockMetric.stateVectors_gram]
  have horth : star (fun j => (ω j : ℂ)) ᵥ* Y = 0 := by
    apply recoveredColumns_source_orthogonal b f hnz p
    intro i
    change (S *ᵥ p i) ⬝ᵥ star f = 0
    rw [dotProduct_comm, BlockMetric.first_state_orthogonal]
  have hsource : Matrix.diagonal α * Y = Y * J -
      Matrix.vecMulVec (fun j => (ω j : ℂ)) (star e) := by
    apply recoveredColumns_source_identity M.mulVecLin b α heig f hnz p J e
    intro i
    exact completion_state_action J e _ _ i
  refine ⟨α, ω, Y, hinj, fun j => ⟨norm_pos_iff.mpr (hnz j), hdisk j⟩,
    htotal, ⟨j₀, hj₀, hω₀⟩, hGram, horth, hsource, ?_⟩
  apply sourceIdentity_canonical_rows J e α (fun j => (ω j : ℂ)) Y hobs _ hsource
  intro j
  change (‖inner ℂ (b j) f‖ : ℂ) ≠ 0
  exact_mod_cast ne_of_gt (norm_pos_iff.mpr (hnz j))

end ConcreteCompletion

section KernelRecovery

variable {σ ι : Type*} [Fintype σ] [Fintype ι] [DecidableEq σ]

/-- Completeness, the prescribed positive Gram matrix, and source
orthogonality supply the projection used by the recovery formulas. -/
theorem source_projection_of_gram [DecidableEq ι]
    (b : σ → ℂ) (Y : Matrix σ ι ℂ) (H : Matrix ι ι ℂ) (n : ℂ)
    (hH : H.PosDef) (hGram : Yᴴ * Y = H) (hn : n ≠ 0)
    (hmass : star b ⬝ᵥ b = n) (horth : star b ᵥ* Y = 0)
    (hdim : Fintype.card σ = Fintype.card ι + 1) :
    Y * H⁻¹ * Yᴴ = 1 - n⁻¹ • Matrix.vecMulVec b (star b) := by
  have hY : Function.Injective Y.mulVec := by
    change Function.Injective Y.mulVecLin
    apply LinearMap.ker_eq_bot.mp
    apply LinearMap.ker_eq_bot'.mpr
    intro x hx
    by_contra hx0
    have hh := hH.re_dotProduct_pos hx0
    rw [← hGram, ← Matrix.mulVec_mulVec] at hh
    change Y *ᵥ x = 0 at hx
    simp [hx] at hh
  have horth' : ∀ x, star b ⬝ᵥ (Y *ᵥ x) = 0 := by
    intro x
    rw [Matrix.dotProduct_mulVec, horth, zero_dotProduct]
  have hprojection := Confluent.complete_gram_projection b Y hY
    (hmass ▸ hn) horth' hdim
  have houter : Confluent.columnMatrix b * (Confluent.columnMatrix b)ᴴ =
      Matrix.vecMulVec b (star b) := by
    ext i j
    simp [Confluent.columnMatrix, Matrix.mul_apply, Matrix.vecMulVec_apply,
      Matrix.conjTranspose_apply]
  simpa only [Confluent.gram, hGram, hmass, houter] using hprojection

/-- The unweighted source-resolvent row Gram matrix. -/
def kernelMatrix (Q : Matrix σ ι ℂ) (Hinv : Matrix ι ι ℂ) : Matrix σ σ ℂ :=
  Q * Hinv * Qᴴ

/-- Source rows are minus their square-root mass times their resolvent row. -/
def weightedRows (b : σ → ℂ) (Q : Matrix σ ι ℂ) : Matrix σ ι ℂ :=
  -(Matrix.diagonal b * Q)

theorem weightedRows_gram (b : σ → ℂ) (Q : Matrix σ ι ℂ)
    (Hinv : Matrix ι ι ℂ) (hb : star b = b) :
    weightedRows b Q * Hinv * (weightedRows b Q)ᴴ =
      Matrix.diagonal b * kernelMatrix Q Hinv * Matrix.diagonal b := by
  simp [weightedRows, kernelMatrix, Matrix.conjTranspose_mul,
    Matrix.mul_assoc, hb]

/-- The source projection identity determines the entire cross-source kernel.
Here `b j` is the positive square root of the source mass, so the diagonal
entry is `1 / mass j - 1/n`. The displayed projection is an explicit
intermediate hypothesis supplied by the complete source-coordinate theorem. -/
theorem kernel_from_source_projection (b : σ → ℂ) (Q : Matrix σ ι ℂ)
    (Hinv : Matrix ι ι ℂ) (n : ℂ) (hb : star b = b)
    (hb0 : ∀ j, b j ≠ 0)
    (hproj : weightedRows b Q * Hinv * (weightedRows b Q)ᴴ =
      1 - n⁻¹ • Matrix.vecMulVec b (star b)) (i j : σ) :
    kernelMatrix Q Hinv i j =
      (if i = j then 1 else 0) / (b i * b j) - n⁻¹ := by
  rw [weightedRows_gram b Q Hinv hb] at hproj
  have hentry := congrArg (fun M : Matrix σ σ ℂ => M i j) hproj
  simp only [Matrix.diagonal_mul, Matrix.mul_diagonal, Matrix.sub_apply,
    Matrix.one_apply, Matrix.smul_apply, smul_eq_mul, Matrix.vecMulVec_apply, hb] at hentry
  apply (eq_sub_iff_add_eq).mpr
  apply (eq_div_iff (mul_ne_zero (hb0 i) (hb0 j))).mpr
  linear_combination hentry

theorem kernel_off_diagonal (b : σ → ℂ) (Q : Matrix σ ι ℂ)
    (Hinv : Matrix ι ι ℂ) (n : ℂ) (hb : star b = b)
    (hb0 : ∀ j, b j ≠ 0)
    (hproj : weightedRows b Q * Hinv * (weightedRows b Q)ᴴ =
      1 - n⁻¹ • Matrix.vecMulVec b (star b)) (i j : σ) (hij : i ≠ j) :
    kernelMatrix Q Hinv i j = -n⁻¹ := by
  simpa [hij] using kernel_from_source_projection b Q Hinv n hb hb0 hproj i j

theorem kernel_diagonal (b : σ → ℂ) (Q : Matrix σ ι ℂ)
    (Hinv : Matrix ι ι ℂ) (n : ℂ) (hb : star b = b)
    (hb0 : ∀ j, b j ≠ 0)
    (hproj : weightedRows b Q * Hinv * (weightedRows b Q)ᴴ =
      1 - n⁻¹ • Matrix.vecMulVec b (star b)) (i : σ) :
    kernelMatrix Q Hinv i i = (b i * b i)⁻¹ - n⁻¹ := by
  simpa using kernel_from_source_projection b Q Hinv n hb hb0 hproj i i

end KernelRecovery

section ScalarRecovery

/-- Scalar mass recovery from the exact diagonal kernel identity. -/
theorem mass_from_diagonal_kernel (mass n κ : ℝ)
    (hκ : κ = mass⁻¹ - n⁻¹) : mass = (κ + n⁻¹)⁻¹ := by
  rw [hκ]
  simp

/-- The paper's lower-mass test, assuming the already recovered positive mass. -/
theorem mass_ge_one_iff_diagonal_kernel (mass n κ : ℝ) (hmass : 0 < mass)
    (hκ : κ = mass⁻¹ - n⁻¹) :
    1 ≤ mass ↔ κ ≤ 1 - n⁻¹ := by
  rw [hκ, sub_le_sub_iff_right]
  exact (inv_le_one₀ hmass).symm

/-- The normalized selected diagonal gives `1+n κ(a,a)=n`. -/
theorem selected_recovery_value (n κ : ℂ) (hn : n ≠ 0)
    (hκ : κ = 1 - n⁻¹) : 1 + n * κ = n := by
  rw [hκ]
  field_simp
  ring

end ScalarRecovery

end PolynomialGeometry.Inverse
