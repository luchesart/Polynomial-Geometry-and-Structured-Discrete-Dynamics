import PolynomialGeometry.Geometry
import PolynomialGeometry.GramFactorization
import Mathlib.LinearAlgebra.Matrix.Rank
import Mathlib.LinearAlgebra.LinearIndependent.Basic
import Mathlib.Tactic

open Matrix
open scoped BigOperators ComplexConjugate ComplexOrder

noncomputable section
namespace PolynomialGeometry.SourceRank
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Interior coordinate measurements and the two dense source measurements. -/
def lossFactor (s : Finset ι) (d u z : ι → ℂ) : Matrix (s ⊕ Fin 2) ι ℂ
  | Sum.inl i, j => if i.val = j then d j else 0
  | Sum.inr k, j => if k = 0 then u j else u j * z j

omit [Fintype ι] in
theorem row_combination_at (s : Finset ι) (d u z : ι → ℂ)
    (f : s ⊕ Fin 2 → ℂ) (j : ι) :
    (∑ r, f r • (lossFactor s d u z).row r) j =
      (∑ i : s, f (Sum.inl i) * (if i.val = j then d j else 0)) +
      f (Sum.inr 0) * u j + f (Sum.inr 1) * (u j * z j) := by
  simp [lossFactor, Matrix.row, Fintype.sum_sum_type, Fin.sum_univ_two, add_assoc]

omit [Fintype ι] in
theorem interior_sum_outside (s : Finset ι) (d : ι → ℂ)
    (f : s → ℂ) {j : ι} (hj : j ∉ s) :
    (∑ i : s, f i * (if i.val = j then d j else 0)) = 0 := by
  apply Finset.sum_eq_zero
  intro i _
  have hne : i.val ≠ j := by intro he; exact hj (he ▸ i.property)
  simp [hne]

omit [Fintype ι] in
theorem interior_sum_inside (s : Finset ι) (d : ι → ℂ)
    (f : s → ℂ) (j : s) :
    (∑ i : s, f i * (if i.val = j.val then d j.val else 0)) = f j * d j.val := by
  rw [Finset.sum_eq_single j]
  · simp
  · intro i _ hij
    have hne : i.val ≠ j.val := fun h => hij (Subtype.ext h)
    simp [hne]
  · simp

omit [Fintype ι] in
/-- A concrete Gram factorization of diagonal coordinate loss plus two rank-one losses. -/
theorem lossFactor_gram (s : Finset ι) (d u z : ι → ℂ) :
    (lossFactor s d u z)ᴴ * lossFactor s d u z =
      Matrix.diagonal (fun j => if j ∈ s then star (d j) * d j else 0) +
      Matrix.vecMulVec (star u) u +
      Matrix.vecMulVec (star (fun j => u j * z j)) (fun j => u j * z j) := by
  ext i j
  simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, Fintype.sum_sum_type,
    lossFactor, Fin.sum_univ_two, Fin.isValue,
    ↓reduceIte, Matrix.add_apply, Matrix.vecMulVec_apply, Pi.star_apply]
  have hdiag : (∑ k : s, star (if k.val = i then d i else 0) *
      (if k.val = j then d j else 0)) =
      Matrix.diagonal (fun j => if j ∈ s then star (d j) * d j else 0) i j := by
    by_cases hi : i ∈ s
    · rw [Finset.sum_eq_single (⟨i,hi⟩ : s)]
      · by_cases hij : i = j
        · subst j; simp [hi]
        · simp [hij]
      · intro k _ hki
        have hne : k.val ≠ i := fun he => hki (Subtype.ext he)
        simp [hne]
      · simp
    · have he : (∑ k : s, star (if k.val = i then d i else 0) *
          (if k.val = j then d j else 0)) = 0 := by
        apply Finset.sum_eq_zero
        intro k _
        have hne : k.val ≠ i := fun he => hi (he ▸ k.property)
        simp [hne]
      rw [he]
      by_cases hij : i = j
      · subst j; simp [hi]
      · simp [hij]
  rw [hdiag]
  simp only [show (1 : Fin 2) ≠ 0 by decide, ↓reduceIte]
  ring

omit [Fintype ι] in
/-- Two distinct boundary resolvent values give two independent dense rows after
quotienting out the interior coordinate rows. -/
theorem lossFactor_rows_independent (s : Finset ι) (d u z : ι → ℂ)
    (hd : ∀ j ∈ s, d j ≠ 0) (hu : ∀ j ∉ s, u j ≠ 0)
    {p q : ι} (hp : p ∉ s) (hq : q ∉ s) (hpq : z p ≠ z q) :
    LinearIndependent ℂ (lossFactor s d u z).row := by
  rw [Fintype.linearIndependent_iff]
  intro f hf r
  have hc (j : ι) := congrFun hf j
  simp only [row_combination_at, Pi.zero_apply] at hc
  have hboundary (j : ι) (hj : j ∉ s) :
      f (Sum.inr 0) + f (Sum.inr 1) * z j = 0 := by
    have h := hc j
    rw [interior_sum_outside s d _ hj, zero_add] at h
    apply (mul_eq_zero.mp (show u j * (f (Sum.inr 0) + f (Sum.inr 1) * z j) = 0 by
      linear_combination h)).resolve_left (hu j hj)
  have h0 := hboundary p hp
  have h1 := hboundary q hq
  have hf1 : f (Sum.inr 1) = 0 := by
    apply (mul_eq_zero.mp (show f (Sum.inr 1) * (z p - z q) = 0 by
      linear_combination h0 - h1)).resolve_right (sub_ne_zero.mpr hpq)
  have hf0 : f (Sum.inr 0) = 0 := by simpa [hf1] using h0
  cases r with
  | inl j =>
      have h := hc j.val
      rw [interior_sum_inside, hf0, hf1] at h
      simp only [zero_mul, add_zero] at h
      exact (mul_eq_zero.mp h).resolve_right (hd j.val j.property)
  | inr k =>
      fin_cases k <;> assumption

/-- Exact rank in the presence of at least two distinct boundary values. -/
theorem lossFactor_rank_two_boundary (s : Finset ι) (d u z : ι → ℂ)
    (hd : ∀ j ∈ s, d j ≠ 0) (hu : ∀ j ∉ s, u j ≠ 0)
    {p q : ι} (hp : p ∉ s) (hq : q ∉ s) (hpq : z p ≠ z q) :
    (lossFactor s d u z).rank = s.card + 2 := by
  simpa using (lossFactor_rows_independent s d u z hd hu hp hq hpq).rank_matrix

/-- With at most one boundary coordinate, all state coordinates are observed. -/
theorem lossFactor_injective_small_boundary (s : Finset ι) (d u z : ι → ℂ)
    (hd : ∀ j ∈ s, d j ≠ 0) (hu : ∀ j ∉ s, u j ≠ 0)
    (hsmall : ∀ p ∉ s, ∀ q ∉ s, p = q) :
    Function.Injective (lossFactor s d u z).mulVec := by
  have hker : ∀ x : ι → ℂ, lossFactor s d u z *ᵥ x = 0 → x = 0 := by
    intro x hx
    have hint (j : ι) (hj : j ∈ s) : x j = 0 := by
      have h := congrFun hx (Sum.inl ⟨j, hj⟩)
      simp only [mulVec, dotProduct, lossFactor, Pi.zero_apply] at h
      have he : (∑ k, (if j = k then d k else 0) * x k) = d j * x j := by
        rw [Finset.sum_eq_single j]
        · simp
        · intro k _ hk; simp [Ne.symm hk]
        · simp
      rw [he] at h
      exact (mul_eq_zero.mp h).resolve_left (hd j hj)
    ext j
    by_cases hj : j ∈ s
    · exact hint j hj
    have h := congrFun hx (Sum.inr 0)
    simp only [mulVec, dotProduct, lossFactor, ↓reduceIte, Pi.zero_apply] at h
    have he : (∑ k, u k * x k) = u j * x j := by
      apply Finset.sum_eq_single j
      · intro k _ hk
        have hkint : k ∈ s := by
          by_contra hki
          exact hk (hsmall k hki j hj)
        simp [hint k hkint]
      · simp
    rw [he] at h
    exact (mul_eq_zero.mp h).resolve_left (hu j hj)
  intro x y hxy
  have hz : lossFactor s d u z *ᵥ (x-y) = 0 := by
    rw [Matrix.mulVec_sub, hxy, sub_self]
  exact sub_eq_zero.mp (hker (x-y) hz)

/-- The exact rank depends only on the interior count and two boundary moments. -/
theorem lossFactor_rank (s : Finset ι) (d u z : ι → ℂ)
    (hd : ∀ j ∈ s, d j ≠ 0) (hu : ∀ j ∉ s, u j ≠ 0)
    (hz : Set.InjOn z {j | j ∉ s}) :
    (lossFactor s d u z).rank = s.card + min 2 sᶜ.card := by
  by_cases hb : 2 ≤ sᶜ.card
  · obtain ⟨p, hp, q, hq, hpq⟩ := Finset.one_lt_card.mp (by omega : 1 < sᶜ.card)
    have hp' : p ∉ s := Finset.mem_compl.mp hp
    have hq' : q ∉ s := Finset.mem_compl.mp hq
    rw [min_eq_left hb]
    exact lossFactor_rank_two_boundary s d u z hd hu hp' hq' (fun h => hpq (hz hp' hq' h))
  · have hsmall : ∀ p ∉ s, ∀ q ∉ s, p = q := by
      intro p hp q hq
      exact Finset.card_le_one.mp (by omega : sᶜ.card ≤ 1) p
        (Finset.mem_compl.mpr hp) q (Finset.mem_compl.mpr hq)
    rw [Matrix.rank, LinearMap.finrank_range_of_inj
      (lossFactor_injective_small_boundary s d u z hd hu hsmall),
      Module.finrank_fintype_fun_eq_card, min_eq_right (by omega : sᶜ.card ≤ 2)]
    exact (Finset.card_add_card_compl s).symm

/-- The loss matrix has exactly the rank of its coordinate and source measurements. -/
theorem lossGram_rank (s : Finset ι) (d u z : ι → ℂ)
    (hd : ∀ j ∈ s, d j ≠ 0) (hu : ∀ j ∉ s, u j ≠ 0)
    (hz : Set.InjOn z {j | j ∉ s}) :
    ((lossFactor s d u z)ᴴ * lossFactor s d u z).rank =
      s.card + min 2 sᶜ.card := by
  rw [Matrix.rank_conjTranspose_mul_self]
  exact lossFactor_rank s d u z hd hu hz

open PolynomialGeometry.Geometry

/-- The explicit source loss factor, with one interior coordinate row and two
source rows. The rank calculation automatically removes redundant rows. -/
def sourceLossFactor (a : ℝ) (u α : ι → ℂ) :
    Matrix (interiorSet α ⊕ Fin 2) ι ℂ :=
  lossFactor (interiorSet α) (sourceLossDiagonal a α)
    (sourceLossRow a u) (sourceLossRatio a u α)

/-- The compressed source factor realizes the actual expansive energy defect. -/
theorem sourceLossFactor_gram (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, Complex.normSq (α j) ≤ 1) :
    (sourceLossFactor a u α)ᴴ * sourceLossFactor a u α =
      (expansive a u (sourceResolvent a α))ᴴ * metric u *
        expansive a u (sourceResolvent a α) - metric u := by
  rw [sourceLossFactor, lossFactor_gram, sourceLossDiagonal_gram α ha₀ ha₁ hsep hdisk,
    sourceLossRow_gram u ha₀ ha₁, sourceLossRatio_gram u α ha₀ ha₁,
    expansive_defect]

/-- The actual one-step output factor for the inverse source transform. -/
def sourceContractiveLossFactor (a : ℝ) (u α : ι → ℂ) :
    Matrix (interiorSet α ⊕ Fin 2) ι ℂ :=
  sourceLossFactor a u α * (expansive a u (sourceResolvent a α))⁻¹

/-- An explicit finite output realizes the contractive source energy loss. -/
theorem sourceContractiveLossFactor_gram (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, Complex.normSq (α j) ≤ 1) :
    (sourceContractiveLossFactor a u α)ᴴ * sourceContractiveLossFactor a u α =
      metric u - (expansive a u (sourceResolvent a α))⁻¹ᴴ * metric u *
        (expansive a u (sourceResolvent a α))⁻¹ := by
  unfold sourceContractiveLossFactor
  rw [Matrix.conjTranspose_mul]
  calc
    _ = (expansive a u (sourceResolvent a α))⁻¹ᴴ *
        ((sourceLossFactor a u α)ᴴ * sourceLossFactor a u α) *
        (expansive a u (sourceResolvent a α))⁻¹ := by simp only [Matrix.mul_assoc]
    _ = _ := by
      rw [sourceLossFactor_gram a u α ha₀ ha₁ hsep hdisk]
      exact (inverse_defect _ _ (source_expansive_isUnit a u α ha₀ ha₁ hsep hdisk)).symm

/-- Exact source dissipation rank, equation (4.7), for the expansive transform.
All rank hypotheses are derived from nonzero masses and distinct source positions. -/
theorem expansive_source_defect_rank (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, Complex.normSq (α j) ≤ 1)
    (hinj : Function.Injective α) :
    ((expansive a u (sourceResolvent a α))ᴴ * metric u *
        expansive a u (sourceResolvent a α) - metric u).rank =
      (interiorSet α).card + min 2 (interiorSet α)ᶜ.card := by
  rw [← sourceLossFactor_gram a u α ha₀ ha₁ hsep hdisk]
  apply lossGram_rank
  · exact sourceLossDiagonal_ne_zero α ha₀ ha₁ hsep
  · intro j _; exact sourceLossRow_ne_zero u ha₀ ha₁ hu j
  · exact (sourceLossRatio_injective u α ha₀ ha₁ hinj).injOn

/-- Exact source dissipation rank for the stable inverse transform. -/
theorem contractive_source_defect_rank (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, Complex.normSq (α j) ≤ 1)
    (hinj : Function.Injective α) :
    (metric u - (expansive a u (sourceResolvent a α))⁻¹ᴴ * metric u *
        (expansive a u (sourceResolvent a α))⁻¹).rank =
      (interiorSet α).card + min 2 (interiorSet α)ᶜ.card := by
  rw [inverse_defect_rank _ _ (source_expansive_isUnit a u α ha₀ ha₁ hsep hdisk)]
  exact expansive_source_defect_rank a u α ha₀ ha₁ hu hsep hdisk hinj

/-- The source-metric loss is strictly positive in every nonzero direction exactly
when there are at most two nonselected boundary sources. -/
theorem contractive_source_defect_posDef_iff (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, Complex.normSq (α j) ≤ 1)
    (hinj : Function.Injective α) :
    (metric u - (expansive a u (sourceResolvent a α))⁻¹ᴴ * metric u *
        (expansive a u (sourceResolvent a α))⁻¹).PosDef ↔
      (interiorSet α)ᶜ.card ≤ 2 := by
  rw [GramFactorization.posDef_iff_rank_eq_card _
    (source_contractivity a u α ha₀ ha₁ hsep hdisk),
    contractive_source_defect_rank a u α ha₀ ha₁ hu hsep hdisk hinj]
  have hc := Finset.card_add_card_compl (interiorSet α)
  omega

/-- For the fixed source metric, the exact dissipation rank is the smallest
possible number of complex output channels. -/
theorem source_minimum_loss_channels (a : ℝ) (u α : ι → ℂ)
    (ha₀ : 0 ≤ a) (ha₁ : a < 1) (hu : ∀ j, u j ≠ 0)
    (hsep : ∀ j, (a : ℂ) ≠ α j) (hdisk : ∀ j, Complex.normSq (α j) ≤ 1)
    (hinj : Function.Injective α) :
    IsLeast {q : ℕ | ∃ C : Matrix (Fin q) ι ℂ, Cᴴ * C =
      metric u - (expansive a u (sourceResolvent a α))⁻¹ᴴ * metric u *
        (expansive a u (sourceResolvent a α))⁻¹}
      ((interiorSet α).card + min 2 (interiorSet α)ᶜ.card) := by
  rw [← contractive_source_defect_rank a u α ha₀ ha₁ hu hsep hdisk hinj]
  exact GramFactorization.rank_isLeast_gram_row_count _
    (source_contractivity a u α ha₀ ha₁ hsep hdisk)

end PolynomialGeometry.SourceRank
