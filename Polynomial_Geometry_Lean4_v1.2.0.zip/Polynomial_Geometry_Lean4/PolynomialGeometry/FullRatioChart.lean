import PolynomialGeometry.FullReconstruction
import PolynomialGeometry.WeightedStationarity
import PolynomialGeometry.ChartTransport

/-! # Ratio coordinates of the same complete reconstruction

The input reconstruction record is constructed from original polynomial
hypotheses by `full_reconstruction_from_original_hypotheses`. This wrapper
does not construct a second, potentially unrelated, family or marked branch.
-/
noncomputable section
open Filter Polynomial
open scoped Topology

namespace PolynomialGeometry.FullRatioChart
open ReconstructionCompletion CriticalReconstruction RatioCoordinates

def forward (r s : ℕ) (a v : Parameter r s → ℂ) (q g : ℂ)
    (p : Parameter r s) : Parameter r s :=
  (parameterLogRatios a v q g p, p.2)

/-- Full parameter-preserving inverse and both neighborhood identities for
the marked roots of the same complete polynomial reconstruction. -/
theorem full_ratio_chart (r s : ℕ) (hr : 0 < r)
    (A : ℂ[X]) (β : Fin (s + 1) → ℂ) (w a₀ v₀ : ℂ)
    (R : LocalReconstructionResult r s A β w a₀ v₀)
    (hq : w - a₀ ≠ 0) (hg : v₀ - a₀ ≠ 0)
    (hdiag : deriv (fun t => parameterLogRatios R.sourceRoot R.simpleCritical
      (w-a₀) (v₀-a₀) ((fun _ => t),β) ⟨0,hr⟩) w ≠ 0) :
    ∃ G : Parameter r s → Parameter r s,
      AnalyticAt ℂ G (0,β) ∧ G (0,β) = ((fun _ => w),β) ∧
      (∀ᶠ q in 𝓝 (((fun _ => w),β) : Parameter r s),
        G (forward r s R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) q) = q) ∧
      (∀ᶠ p in 𝓝 ((0,β) : Parameter r s),
        forward r s R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) (G p) = p) ∧
      (∀ᶠ p in 𝓝 ((0,β) : Parameter r s), (G p).2 = p.2) ∧
      Filter.map G (𝓝 ((0,β) : Parameter r s)) = 𝓝 (((fun _ => w),β) : Parameter r s) ∧
      Filter.map (forward r s R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀))
        (𝓝 (((fun _ => w),β) : Parameter r s)) = 𝓝 ((0,β) : Parameter r s) := by
  letI : NeZero r := ⟨Nat.ne_of_gt hr⟩
  have hqa : w-R.sourceRoot ((fun _ => w),β) = w-a₀ := by rw [R.source_base]
  have hgv : R.simpleCritical ((fun _ => w),β)-R.sourceRoot ((fun _ => w),β) = v₀-a₀ := by
    rw [R.source_base,R.critical_base]
  have hsa : ∀ σ : Equiv.Perm (Fin r),
      (fun z => R.sourceRoot (z ∘ σ,β)) =ᶠ[𝓝 (fun _ => w)] (fun z => R.sourceRoot (z,β)) := by
    intro σ
    apply Eventually.of_forall
    intro z
    simpa using (R.permutation_invariance σ (Equiv.refl _) (z,β)).2.1
  have hsv : ∀ σ : Equiv.Perm (Fin r),
      (fun z => R.simpleCritical (z ∘ σ,β)) =ᶠ[𝓝 (fun _ => w)] (fun z => R.simpleCritical (z,β)) := by
    intro σ
    apply Eventually.of_forall
    intro z
    simpa using (R.permutation_invariance σ (Equiv.refl _) (z,β)).2.2
  obtain ⟨G,hG,hG0,hleft,hright⟩ := parameter_logRatios_local_inverse
    R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀) w β ⟨0,hr⟩
    R.source_analytic R.critical_analytic hq hg hqa hgv hsa hsv hdiag
  let F := forward r s R.sourceRoot R.simpleCritical (w-a₀) (v₀-a₀)
  have hF : ContinuousAt F ((fun _ => w),β) :=
    (WeightedStationarity.parameterLogRatios_analyticAt R.sourceRoot R.simpleCritical
      (w-a₀) (v₀-a₀) w β R.source_analytic R.critical_analytic hq hg hqa hgv).continuousAt.prodMk
        continuousAt_snd
  have hF0 : F ((fun _ => w),β) = (0,β) := by
    apply Prod.ext
    · ext i
      simp [F,forward,parameterLogRatios,R.source_base,R.critical_base,hq,hg]
    · rfl
  refine ⟨G,hG,hG0,hleft,hright,?_,?_,?_⟩
  · filter_upwards [hright] with p hp
    have hs := congrArg (fun t : Parameter r s => t.2) hp
    exact hs
  · exact ChartTransport.map_nhds_of_local_inverse G F (0,β) ((fun _ => w),β)
      hG.continuousAt hF hG0 hF0 hleft
  · exact ChartTransport.map_nhds_of_local_inverse F G ((fun _ => w),β) (0,β)
      hF hG.continuousAt hF0 hG0 hright

end PolynomialGeometry.FullRatioChart
