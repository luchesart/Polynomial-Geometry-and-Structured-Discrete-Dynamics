import PolynomialGeometry.InverseEquivalence

/-! # Recovery from the minimal inverse realization

All kernel identities here are derived from minimal realization data.
The source projection and off-diagonal identities are conclusions.
-/

noncomputable section
open Matrix Polynomial
open scoped ComplexOrder

namespace PolynomialGeometry.RecoveryCompletion

variable {ι σ : Type*} [Fintype ι] [DecidableEq ι]
  [Fintype σ] [DecidableEq σ]

def recoveryKernel (H J : Matrix ι ι ℂ) (e : ι → ℂ) (z u : ℂ) : ℂ :=
  star e ⬝ᵥ ((z • (1 : Matrix ι ι ℂ) - J)⁻¹ *ᵥ
    (H⁻¹ *ᵥ (((u • (1 : Matrix ι ι ℂ) - J)⁻¹)ᴴ *ᵥ e)))

def resolventRows (J : Matrix ι ι ℂ) (e : ι → ℂ) (α : σ → ℂ) : Matrix σ ι ℂ :=
  fun j => star e ᵥ* (α j • (1 : Matrix ι ι ℂ) - J)⁻¹

omit [Fintype σ] [DecidableEq σ] in
theorem kernelMatrix_eq_recoveryKernel (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (i j : σ) :
    Inverse.kernelMatrix (resolventRows J e α) H⁻¹ i j =
      recoveryKernel H J e (α i) (α j) := by
  have hstar : star (resolventRows J e α j) =
      ((α j • (1 : Matrix ι ι ℂ) - J)⁻¹)ᴴ *ᵥ e := by
    funext k
    simp [resolventRows, Matrix.vecMul, Matrix.mulVec, dotProduct,
      Matrix.conjTranspose_apply, StarMul.star_mul, mul_comm]
  change (resolventRows J e α i ᵥ* H⁻¹) ⬝ᵥ star (resolventRows J e α j) = _
  rw [hstar, ← Matrix.dotProduct_mulVec]
  change (star e ᵥ* (α i • (1 : Matrix ι ι ℂ) - J)⁻¹) ⬝ᵥ _ = _
  rw [← Matrix.dotProduct_mulVec]
  rfl

/-- The source projection follows from minimal realization completeness. -/
theorem completeRealization_projection (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y) :
    Y * H⁻¹ * Yᴴ = 1 - (n : ℂ)⁻¹ •
      Matrix.vecMulVec (fun j => (ω j : ℂ)) (star (fun j => (ω j : ℂ))) := by
  obtain ⟨_, _, htotal, _, hGram, hrows, hf⟩ := hreal
  have hnum := (InverseEquivalence.numerator_identity_iff J α _ n).mpr hf
  have horth := InverseEquivalence.canonical_rows_orthogonal J e α
    (fun j => (ω j : ℂ)) (fun j => (ω j : ℂ)^2) Y n
    (by intro j; simp [pow_two]) (fun j => (hrows j).1) hnum
    (fun j => (hrows j).2)
  apply Inverse.source_projection_of_gram _ Y H n hH hGram
    (by exact_mod_cast (ne_of_gt hn)) _ horth hdim
  have hh := congrArg (fun t : ℝ => (t : ℂ)) htotal
  push_cast at hh
  simpa [dotProduct, pow_two] using hh

/-- Complete two-source kernel formula of Corollary3.3, with every
input supplied by the minimal realization. -/
theorem completeRealization_kernel (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y)
    (i j : σ) :
    recoveryKernel H J e (α i) (α j) =
      (if i = j then 1 else 0) / ((ω i : ℂ) * (ω j : ℂ)) - (n : ℂ)⁻¹ := by
  have hproj := completeRealization_projection a n H J e α ω Y hn hH hdim hreal
  have hY : Y = Inverse.weightedRows (fun j => (ω j : ℂ)) (resolventRows J e α) := by
    ext j k
    have hh := congrFun ((hreal.2.2.2.2.2.1 j).2) k
    simpa [Inverse.weightedRows, resolventRows, Matrix.diagonal_mul] using hh
  rw [hY] at hproj
  rw [← kernelMatrix_eq_recoveryKernel]
  apply Inverse.kernel_from_source_projection _ _ _ _ _ _ hproj
  · funext j
    simp
  · intro j
    exact_mod_cast (hreal.2.1 j).1.ne'


/-- Every diagonal kernel value is real and nonnegative. -/
theorem recoveryKernel_diagonal_nonnegative (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (hH : H.PosDef) (z : ℂ) :
    0 ≤ recoveryKernel H J e z z := by
  let v := ((z • (1 : Matrix ι ι ℂ) - J)⁻¹)ᴴ *ᵥ e
  have hv : star v = star e ᵥ* (z • (1 : Matrix ι ι ℂ) - J)⁻¹ := by
    funext k
    simp [v, Matrix.mulVec, Matrix.vecMul, dotProduct, Matrix.conjTranspose_apply,
      StarMul.star_mul, mul_comm]
  have hh := ((Matrix.posDef_inv_iff).mpr hH).posSemidef.2 v
  rw [hv] at hh
  simpa only [← Matrix.dotProduct_mulVec, recoveryKernel, v] using hh

/-- The selected-source polynomial is exactly the product of the other
source factors, with no cross-kernel identities supplied as premises. -/
theorem completeRealization_selected_polynomial (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y)
    (j₀ : σ) (ha : α j₀ = a) :
    SelectedRecovery.selectedPolynomial J e
      (Inverse.recoveryVector H (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e) n =
        ∏ j : {j : σ // j ≠ j₀}, (X - C (α j)) := by
  apply SelectedRecovery.selectedPolynomial_eq_prod _ _ _ _
    (by exact_mod_cast (ne_of_gt hn)) (fun j : {j : σ // j ≠ j₀} => α j)
    (hreal.1.comp Subtype.val_injective)
    (fun j => (hreal.2.2.2.2.2.1 j).1)
  · intro j
    have hh := completeRealization_kernel a n H J e α ω Y hn hH hdim hreal j j₀
    simp only [j.prop, ite_false, zero_div, zero_sub, ha] at hh
    exact hh
  · simp [Fintype.card_subtype_compl, hdim]

/-- The characteristic polynomial of the completion factors at its
selected source by the recovered nonselected polynomial. -/
theorem completeRealization_selected_factorization (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y)
    (j₀ : σ) (ha : α j₀ = a) :
    (Inverse.normalizedCompletion a n H J (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e).charpoly =
      (X - C a) * SelectedRecovery.selectedPolynomial J e
        (Inverse.recoveryVector H (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e) n := by
  rw [← InverseEquivalence.completeRealization_support_charpoly a n H J e α ω Y hn hH hdim hreal,
    completeRealization_selected_polynomial a n H J e α ω Y hn hH hdim hreal j₀ ha]
  have hp : Source.support (Finset.univ.erase j₀) α =
      ∏ j : {j : σ // j ≠ j₀}, (X - C (α j)) := by
    exact Finset.prod_subtype _ (by simp) (fun j => X - C (α j))
  rw [← hp, ← ha]
  exact (Source.support_erase_mul Finset.univ α (Finset.mem_univ j₀)).symm

/-- The selected value follows from the mass-one diagonal kernel,
without adding the normalization again as a premise. -/
theorem completeRealization_selected_value (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y) :
    (SelectedRecovery.selectedPolynomial J e
      (Inverse.recoveryVector H (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e) n).eval a =
        (n : ℂ) * J.charpoly.eval a := by
  obtain ⟨j₀, ha, hw⟩ := hreal.2.2.2.1
  have hh := completeRealization_kernel a n H J e α ω Y hn hH hdim hreal j₀ j₀
  have hs := (hreal.2.2.2.2.2.1 j₀).1
  rw [ha] at hs
  apply SelectedRecovery.selectedPolynomial_selected_value _ _ _ _ _
    (by exact_mod_cast (ne_of_gt hn)) hs
  simpa only [ha, hw, ite_true, Complex.ofReal_one, mul_one, div_one] using hh

/-- Exact recovered masses and the lower-mass inequality. -/
theorem completeRealization_diagonal_mass (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y) (j : σ) :
    (ω j : ℂ)^2 = (recoveryKernel H J e (α j) (α j) + (n : ℂ)⁻¹)⁻¹ ∧
    (1 ≤ ω j^2 ↔ (recoveryKernel H J e (α j) (α j)).re ≤ 1 - n⁻¹) := by
  have hh := completeRealization_kernel a n H J e α ω Y hn hH hdim hreal j j
  simp only [ite_true, one_div, ← pow_two] at hh
  constructor
  · rw [hh]
    simp
  · have hr := congrArg Complex.re hh
    have hr' : (recoveryKernel H J e (α j) (α j)).re = (ω j^2)⁻¹ - n⁻¹ := by
      have hc : ((ω j : ℂ)^2)⁻¹ - (n : ℂ)⁻¹ =
          (((ω j^2)⁻¹ - n⁻¹ : ℝ) : ℂ) := by push_cast; rfl
      rw [hc] at hr
      exact hr
    exact Inverse.mass_ge_one_iff_diagonal_kernel (ω j^2) n _
      (sq_pos_of_pos (hreal.2.1 j).1) hr'


/-- The displayed kernel product is evaluated directly from recovered sources. -/
theorem completeRealization_kernel_product (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y)
    (j₀ : σ) (ha : α j₀ = a) (z : ℂ)
    (hz : IsUnit (z • (1 : Matrix ι ι ℂ) - J)) :
    J.charpoly.eval z * (1 + (n : ℂ) * recoveryKernel H J e z a) =
      ∏ j : {j : σ // j ≠ j₀}, (z - α j) := by
  have hh := SelectedRecovery.selectedPolynomial_eval J e
    (Inverse.recoveryVector H (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e) n z hz
  rw [completeRealization_selected_polynomial a n H J e α ω Y hn hH hdim hreal j₀ ha,
    Polynomial.eval_prod] at hh
  simpa using hh.symm

/-- Residue quotient with the actual completion characteristic polynomial. -/
theorem completeRealization_completion_residue (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hn : 0 < n) (hH : H.PosDef)
    (hdim : Fintype.card σ = Fintype.card ι + 1)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y) (j : σ) :
    (ω j : ℂ)^2 = (n : ℂ) * J.charpoly.eval (α j) /
      (Inverse.normalizedCompletion a n H J (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e).charpoly.derivative.eval (α j) := by
  rw [← InverseEquivalence.completeRealization_support_charpoly a n H J e α ω Y hn hH hdim hreal]
  exact InverseEquivalence.completeRealization_residue a n H J e α ω Y (ne_of_gt hn) hreal j

/-- The ordinary polynomial realization criterion, specialized to the
masses recovered by the inverse theorem. -/
theorem completeRealization_integer_iff (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y) :
    (∃ P : ℂ[X], P.Monic ∧ ∀ z, P.eval z ≠ 0 → (∀ j, z ≠ α j) →
      P.derivative.eval z / P.eval z = ∑ j, (ω j : ℂ)^2 / (z - α j)) ↔
      ∃ m : σ → ℕ, (∀ j, 0 < m j) ∧ ∀ j, ω j^2 = (m j : ℝ) := by
  simpa only [Complex.ofReal_pow] using
    PolynomialRecovery.logarithmic_polynomial_iff_integer_masses α
      (fun j => ω j^2) hreal.1 (fun j => sq_pos_of_pos (hreal.2.1 j).1)

/-- Integer recovered masses give the unique monic polynomial and its
full derivative factorization using the prescribed critical numerator. -/
theorem completeRealization_integer_polynomial (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ)
    (α : σ → ℂ) (ω : σ → ℝ) (Y : Matrix σ ι ℂ)
    (hreal : InverseEquivalence.CompleteRealization a n H J e α ω Y)
    (m : σ → ℕ) (hm : ∀ j, 0 < m j) (hweights : ∀ j, ω j^2 = (m j : ℝ)) :
    let P := Source.sourcePolynomial Finset.univ α m
    P.Monic ∧
    P.derivative = C (n : ℂ) * J.charpoly * Source.inheritedFactor Finset.univ α m ∧
    (∀ z, P.eval z ≠ 0 → (∀ j, z ≠ α j) →
      P.derivative.eval z / P.eval z = ∑ j, (ω j : ℂ)^2 / (z - α j)) ∧
    (∀ Q : ℂ[X], Q.Monic →
      (∀ z, Q.eval z ≠ 0 → (∀ j, z ≠ α j) →
        Q.derivative.eval z / Q.eval z = ∑ j, (ω j : ℂ)^2 / (z - α j)) → Q = P) := by
  dsimp only
  have hw : (fun j => (ω j : ℂ)^2) = (fun j => (m j : ℂ)) := by
    funext j
    exact_mod_cast hweights j
  have hnum := (InverseEquivalence.numerator_identity_iff J α _ n).mpr hreal.2.2.2.2.2.2
  rw [hw] at hnum
  have hP := PolynomialRecovery.integer_source_polynomial α m hm
  refine ⟨hP.1, ?_, ?_, ?_⟩
  · rw [Source.derivative_sourcePolynomial _ _ _ (fun j _ => hm j), hnum]
  · intro z hz hsep
    simp only [show ∀ j, (ω j : ℂ)^2 = (m j : ℂ) from congrFun hw]
    exact PolynomialRecovery.logarithmic_derivative_of_identity α _ _ hP.2 z hz hsep
  · intro Q hQ hlog
    have hQid := (PolynomialRecovery.logarithmic_derivative_iff_identity α _ Q hQ.ne_zero).mp hlog
    rw [hw] at hQid
    exact PolynomialRecovery.monic_realization_unique α _ hreal.1 Q _ hQ hP.1 hQid hP.2

/-- A single completion test constructs a minimal realization and all
of the principal recovery identities. The integer condition is a
conclusion about these recovered masses, not an extra source hypothesis. -/
theorem normalized_completion_and_recovery (a : ℂ) (n : ℝ)
    (H J : Matrix ι ι ℂ) (e : ι → ℂ) (hn : 0 < n) (hH : H.PosDef)
    (hobs : Inverse.EigenObservable J.mulVecLin (Inverse.rowFunctional e))
    (hnorm : Inverse.normalization H (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e = 1 - (n : ℂ)⁻¹)
    (htest : let M := Inverse.normalizedCompletion a n H J (a • 1 - J)⁻¹ e
      let S := BlockMetric.metric n H
      M * Inverse.weightedAdjoint S M = Inverse.weightedAdjoint S M * M ∧
        (S - Mᴴ * S * M).PosSemidef) :
    ∃ (α : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℂ)
      (ω : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℝ)
      (Y : Matrix (Fin (Module.finrank ℂ (Option ι → ℂ))) ι ℂ),
      InverseEquivalence.CompleteRealization a n H J e α ω Y ∧
      (∃ j₀, α j₀ = a ∧ ω j₀ = 1 ∧
        SelectedRecovery.selectedPolynomial J e
          (Inverse.recoveryVector H (a • (1 : Matrix ι ι ℂ) - J)⁻¹ e) n =
            ∏ j : {j // j ≠ j₀}, (X - C (α j))) ∧
      (∀ i j, recoveryKernel H J e (α i) (α j) =
        (if i = j then 1 else 0) / ((ω i : ℂ) * (ω j : ℂ)) - (n : ℂ)⁻¹) ∧
      ((∃ P : ℂ[X], P.Monic ∧ ∀ z, P.eval z ≠ 0 → (∀ j, z ≠ α j) →
        P.derivative.eval z / P.eval z = ∑ j, (ω j : ℂ)^2 / (z - α j)) ↔
          ∃ m : Fin (Module.finrank ℂ (Option ι → ℂ)) → ℕ,
            (∀ j, 0 < m j) ∧ ∀ j, ω j^2 = (m j : ℝ)) := by
  obtain ⟨α, ω, Y, hr⟩ :=
    (InverseEquivalence.normalized_inverse_realization_iff a n H J e hn hH hobs hnorm).mpr htest
  have hdim : Fintype.card (Fin (Module.finrank ℂ (Option ι → ℂ))) = Fintype.card ι + 1 := by
    simp [Module.finrank_fintype_fun_eq_card]
  refine ⟨α, ω, Y, hr, ?_, ?_, completeRealization_integer_iff a n H J e α ω Y hr⟩
  · obtain ⟨j₀, ha, hw⟩ := hr.2.2.2.1
    exact ⟨j₀, ha, hw, completeRealization_selected_polynomial a n H J e α ω Y hn hH hdim hr j₀ ha⟩
  · exact completeRealization_kernel a n H J e α ω Y hn hH hdim hr

end PolynomialGeometry.RecoveryCompletion


