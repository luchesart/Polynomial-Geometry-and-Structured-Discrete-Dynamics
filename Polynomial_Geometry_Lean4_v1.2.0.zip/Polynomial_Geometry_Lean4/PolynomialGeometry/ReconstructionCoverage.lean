import PolynomialGeometry.ReconstructionCharts
import PolynomialGeometry.RootMargins
import Mathlib.Analysis.Complex.Polynomial.Basic

/-! # Coverage of nearby polynomials by the reconstructed coefficient chart -/

noncomputable section
namespace PolynomialGeometry.ReconstructionCompletion
open Polynomial Filter
open PolynomialGeometry.Factorization PolynomialGeometry.CriticalReconstruction
open scoped BigOperators Topology

/-- Normalized coefficients of the derivative of the actual source polynomial. -/
def normalizedDerivativeCoefficients (r s : ℕ) (q : Parameter r s) : Fin (r + s) → ℂ :=
  (r + s + 1 : ℂ)⁻¹ • derivativeLowMap r s q

theorem normalizedDerivativeCoefficients_analyticAt (r s : ℕ) (q : Parameter r s) :
    AnalyticAt ℂ (normalizedDerivativeCoefficients r s) q :=
  (((derivativeProjection r s).analyticAt _).comp
    (factorCoefficientMap_analyticAt r (s + 1) q)).const_smul

theorem normalizedDerivativeCoefficients_polynomial (r s : ℕ) (q : Parameter r s) :
    monicPolynomial (r + s) (normalizedDerivativeCoefficients r s q) =
      C (r + s + 1 : ℂ)⁻¹ *
        (monicPolynomial r q.1 * monicPolynomial (s + 1) q.2).derivative := by
  let P := monicPolynomial r q.1 * monicPolynomial (s + 1) q.2
  have hP : P.Monic := (monicPolynomial_monic _ _).mul (monicPolynomial_monic _ _)
  have hPd : P.natDegree = r + s + 1 := by
    dsimp [P]
    rw [natDegree_mul (monicPolynomial_monic _ _).ne_zero (monicPolynomial_monic _ _).ne_zero]
    simp only [monicPolynomial_natDegree, Nat.add_assoc]
  have ⟨hdd, hdl⟩ := monic_derivative_data P (r + s) hP hPd
  have hN : (r + s + 1 : ℂ) ≠ 0 := by exact_mod_cast (by omega : r + s + 1 ≠ 0)
  apply monic_eq_of_low_coeff _ _ (r + s) (monicPolynomial_monic _ _)
  · apply monic_C_mul_of_mul_leadingCoeff_eq_one
    rw [hdl]
    simpa only [Nat.cast_add] using inv_mul_cancel₀ hN
  · exact monicPolynomial_natDegree _ _
  · rw [natDegree_C_mul (inv_ne_zero hN), hdd]
  · intro k
    rw [monicPolynomial_coeff, coeff_C_mul]
    exact congrArg ((r + s + 1 : ℂ)⁻¹ * ·) (derivativeLowMap_apply r s q k)

/-- Factor the actual normalized derivative holomorphically, so every nearby
source polynomial has its own critical cluster and residual factor. -/
theorem actual_critical_factorization (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (x : Domain r s) (w : ℂ)
    (hcrit : monicPolynomial r x.2.1 = (X - C w) ^ r)
    (hU : (monicPolynomial s x.1.2).eval w ≠ 0)
    (hid : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative =
      C (r + s + 1 : ℂ) * monicPolynomial r x.2.1 * monicPolynomial s x.1.2) :
    ∃ H : Parameter r s → Unknown r s,
      AnalyticAt ℂ H (x.1.1, x.2.2) ∧ H (x.1.1, x.2.2) = (x.2.1, x.1.2) ∧
      (∀ᶠ q in 𝓝 ((x.1.1, x.2.2) : Parameter r s),
        (monicPolynomial r q.1 * monicPolynomial (s + 1) q.2).derivative =
          C (r + s + 1 : ℂ) * monicPolynomial r (H q).1 * monicPolynomial s (H q).2) := by
  let q₀ : Parameter r s := (x.1.1, x.2.2)
  let cu₀ : Unknown r s := (x.2.1, x.1.2)
  have hcop : IsCoprime (monicPolynomial r cu₀.1) (monicPolynomial s cu₀.2) := by
    rw [show monicPolynomial r cu₀.1 = (X - C w) ^ r from hcrit]
    exact Variations.critical_power_coprime _ w r hU
  obtain ⟨F, hF, hF0, _, hFpoly⟩ := local_holomorphic_monic_factorization r s hr hs cu₀ hcop
  have hN : (r + s + 1 : ℂ) ≠ 0 := by exact_mod_cast (by omega : r + s + 1 ≠ 0)
  have hn0 : normalizedDerivativeCoefficients r s q₀ = factorCoefficientMap r s cu₀ := by
    ext k
    change (r + s + 1 : ℂ)⁻¹ * derivativeLowMap r s q₀ k = _
    rw [derivativeLowMap_apply]
    change (r + s + 1 : ℂ)⁻¹ * _ =
      (monicPolynomial r x.2.1 * monicPolynomial s x.1.2).coeff k
    rw [hid, mul_assoc, coeff_C_mul, ← mul_assoc, inv_mul_cancel₀ hN, one_mul]
  let H := F ∘ normalizedDerivativeCoefficients r s
  have hn := normalizedDerivativeCoefficients_analyticAt r s q₀
  have hHan : AnalyticAt ℂ H q₀ := hF.comp_of_eq hn hn0
  refine ⟨H, hHan, ?_, ?_⟩
  · exact (congrArg F hn0).trans hF0
  · have ht : Tendsto (normalizedDerivativeCoefficients r s) (𝓝 q₀)
        (𝓝 (factorCoefficientMap r s cu₀)) := hn0 ▸ hn.continuousAt
    filter_upwards [ht.eventually hFpoly] with q hq
    have hpoly := hq.trans (normalizedDerivativeCoefficients_polynomial r s q)
    apply_fun (fun p : ℂ[X] => C (r + s + 1 : ℂ) * p) at hpoly
    have hc : C (r + s + 1 : ℂ) * C (r + s + 1 : ℂ)⁻¹ = 1 := by
      rw [← C_mul, mul_inv_cancel₀ hN, C_1]
    simpa only [← mul_assoc, hc, one_mul] using hpoly.symm

/-- The reconstructed chart covers every nearby coefficient perturbation of
both the source factor and the interior factor. Its inverse extracts the
critical factor from the derivative of that very polynomial. -/
theorem exact_coefficient_reconstruction_coverage (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (x : Domain r s) (w : ℂ)
    (hcrit : monicPolynomial r x.2.1 = (X - C w) ^ r)
    (hM : (monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hvalue : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hU : (monicPolynomial s x.1.2).eval w ≠ 0)
    (hid : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative =
      C (r + s + 1 : ℂ) * monicPolynomial r x.2.1 * monicPolynomial s x.1.2) :
    ∃ (G : Parameter r s → Unknown r s) (H : Parameter r s → Unknown r s),
      AnalyticAt ℂ G x.2 ∧ G x.2 = x.1 ∧
      AnalyticAt ℂ H (x.1.1, x.2.2) ∧ H (x.1.1, x.2.2) = (x.2.1, x.1.2) ∧
      (∀ᶠ q in 𝓝 x.2,
        (monicPolynomial r (G q).1 * monicPolynomial (s + 1) q.2).derivative =
          C (r + s + 1 : ℂ) * monicPolynomial r q.1 * monicPolynomial s (G q).2) ∧
      (∀ᶠ z in 𝓝 x,
        (monicPolynomial r z.1.1 * monicPolynomial (s + 1) z.2.2).derivative =
          C (r + s + 1 : ℂ) * monicPolynomial r z.2.1 * monicPolynomial s z.1.2 →
        G z.2 = z.1) ∧
      (∀ᶠ q in 𝓝 ((x.1.1, x.2.2) : Parameter r s),
        G ((H q).1, q.2) = (q.1, (H q).2) ∧
        (monicPolynomial r q.1 * monicPolynomial (s + 1) q.2).derivative =
          C (r + s + 1 : ℂ) * monicPolynomial r (H q).1 * monicPolynomial s (H q).2) := by
  obtain ⟨G, hG, hG0, hGforward, hGuniq⟩ :=
    moving_critical_factor_reconstruction r s hr hs x w hcrit hM hvalue hid
  obtain ⟨H, hH, hH0, hHpoly⟩ := actual_critical_factorization r s hr hs x w hcrit hU hid
  let T : Parameter r s → Domain r s := fun q => ((q.1, (H q).2), ((H q).1, q.2))
  have hT0 : T (x.1.1, x.2.2) = x := by simp [T, hH0]
  have hT : ContinuousAt T (x.1.1, x.2.2) :=
    (continuousAt_fst.prodMk hH.continuousAt.snd).prodMk
      (hH.continuousAt.fst.prodMk continuousAt_snd)
  have ht : Tendsto T (𝓝 (x.1.1, x.2.2)) (𝓝 x) := hT0 ▸ hT
  refine ⟨G, H, hG, hG0, hH, hH0, hGforward, hGuniq, ?_⟩
  filter_upwards [ht.eventually hGuniq, hHpoly] with q hq hp
  exact ⟨hq hp, hp⟩

/-- Every monic complex polynomial has a pointwise list of all roots,
including repeated copies. This statement makes no continuity claim about labels. -/
theorem monic_has_labelled_roots (P : ℂ[X]) (n : ℕ) (hP : P.Monic)
    (hd : P.natDegree = n) : ∃ z : Fin n → ℂ, rootPolynomial n z = P := by
  classical
  have hsplit : P.Splits (RingHom.id ℂ) := IsAlgClosed.splits_codomain P
  have hlen : P.roots.toList.length = n := by
    rw [Multiset.length_toList, splits_iff_card_roots.mp hsplit, hd]
  let z : Fin n → ℂ := fun i => P.roots.toList.get (Fin.cast hlen.symm i)
  refine ⟨z, ?_⟩
  have heq : ∏ i : Fin n, (X - C (z i)) =
      ∏ i : Fin P.roots.toList.length, (X - C (P.roots.toList.get i)) := by
    exact (Equiv.prod_comp (finCongr hlen.symm) (fun i => X - C (P.roots.toList.get i)))
  change (∏ i : Fin n, (X - C (z i))) = P
  rw [heq, ← List.prod_ofFn]
  have hl : List.ofFn (fun i : Fin P.roots.toList.length => X - C (P.roots.toList.get i)) =
      P.roots.toList.map (fun x => X - C x) := by
    simpa only [List.ofFn_get] using
      (List.map_ofFn P.roots.toList.get (fun x : ℂ => X - C x)).symm
  rw [hl, ← Multiset.prod_coe, ← Multiset.map_coe, Multiset.coe_toList]
  exact (eq_prod_roots_of_monic_of_splits_id hP hsplit).symm

/-- Interior roots and unit-circle source copies force the actual two
source factors to be coprime. -/
theorem interior_boundary_coprime (A : ℂ[X]) (n : ℕ) (α : Fin n → ℂ)
    (hA : ∀ z, A.IsRoot z → ‖z‖ < 1) (hα : ∀ i, ‖α i‖ = 1) :
    IsCoprime A (rootPolynomial n α) := by
  apply (Polynomial.isCoprime_iff_aeval_ne_zero_of_isAlgClosed ℂ ℂ A (rootPolynomial n α)).mpr
  intro z
  change A.eval z ≠ 0 ∨ (rootPolynomial n α).eval z ≠ 0
  by_cases ha : A.eval z = 0
  · right
    intro hz
    have hzm : ∃ i : Fin n, z = α i := by
      simpa only [rootPolynomial, eval_prod, eval_sub, eval_X, eval_C,
        Finset.prod_eq_zero_iff, Finset.mem_univ, true_and, sub_eq_zero] using hz
    obtain ⟨i, rfl⟩ := hzm
    have hlt := hA (α i) ha
    rw [hα i] at hlt
    exact lt_irrefl _ hlt
  · exact Or.inl ha

/-- Coverage in all coefficients of the original monic polynomial. Both
source factors and both derivative factors are obtained from that polynomial;
then the inverse critical chart recovers the same interior factor exactly. -/
theorem nearby_polynomial_coverage (r s : ℕ) (hr : 0 < r) (hs : 0 < s)
    (x : Domain r s) (w : ℂ)
    (hcrit : monicPolynomial r x.2.1 = (X - C w) ^ r)
    (hM : (monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hvalue : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).eval w ≠ 0)
    (hU : (monicPolynomial s x.1.2).eval w ≠ 0)
    (hcop : IsCoprime (monicPolynomial r x.1.1) (monicPolynomial (s + 1) x.2.2))
    (hid : (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative =
      C (r + s + 1 : ℂ) * monicPolynomial r x.2.1 * monicPolynomial s x.1.2) :
    ∃ (F : (Fin (r + (s + 1)) → ℂ) → Parameter r s)
      (H : (Fin (r + (s + 1)) → ℂ) → Unknown r s)
      (G : Parameter r s → Unknown r s),
      AnalyticAt ℂ F (factorCoefficientMap r (s + 1) (x.1.1, x.2.2)) ∧
      F (factorCoefficientMap r (s + 1) (x.1.1, x.2.2)) = (x.1.1, x.2.2) ∧
      AnalyticAt ℂ H (factorCoefficientMap r (s + 1) (x.1.1, x.2.2)) ∧
      H (factorCoefficientMap r (s + 1) (x.1.1, x.2.2)) = (x.2.1, x.1.2) ∧
      AnalyticAt ℂ G x.2 ∧ G x.2 = x.1 ∧
      (∀ᶠ q in 𝓝 x.2,
        (monicPolynomial r (G q).1 * monicPolynomial (s + 1) q.2).derivative =
          C (r + s + 1 : ℂ) * monicPolynomial r q.1 * monicPolynomial s (G q).2) ∧
      (∀ᶠ z in 𝓝 x,
        (monicPolynomial r z.1.1 * monicPolynomial (s + 1) z.2.2).derivative =
          C (r + s + 1 : ℂ) * monicPolynomial r z.2.1 * monicPolynomial s z.1.2 →
        G z.2 = z.1) ∧
      (∀ᶠ p in 𝓝 (factorCoefficientMap r (s + 1) (x.1.1, x.2.2)),
        G ((H p).1, (F p).2) = ((F p).1, (H p).2) ∧
        monicPolynomial r (F p).1 * monicPolynomial (s + 1) (F p).2 =
          monicPolynomial (r + (s + 1)) p ∧
        (monicPolynomial (r + (s + 1)) p).derivative =
          C (r + s + 1 : ℂ) * monicPolynomial r (H p).1 * monicPolynomial s (H p).2 ∧
        ∃ (z : Fin r → ℂ) (α : Fin (s + 1) → ℂ),
          rootCoefficients r z = (H p).1 ∧ rootCoefficients (s + 1) α = (F p).2 ∧
          monicPolynomial r (G (rootCoefficients r z, rootCoefficients (s + 1) α)).1 *
            rootPolynomial (s + 1) α = monicPolynomial (r + (s + 1)) p) := by
  let q₀ : Parameter r s := (x.1.1, x.2.2)
  let p₀ := factorCoefficientMap r (s + 1) q₀
  obtain ⟨F, hF, hF0, _, hFpoly⟩ :=
    local_holomorphic_monic_factorization r (s + 1) hr (by omega) q₀ hcop
  obtain ⟨G, K, hG, hG0, hK, hK0, hGforward, hGuniq, hcoverage⟩ :=
    exact_coefficient_reconstruction_coverage r s hr hs x w hcrit hM hvalue hU hid
  let H := K ∘ F
  have hH : AnalyticAt ℂ H p₀ := hK.comp_of_eq hF hF0
  have hH0 : H p₀ = (x.2.1, x.1.2) := by dsimp [H]; rw [hF0]; exact hK0
  have ht : Tendsto F (𝓝 p₀) (𝓝 q₀) := hF0 ▸ hF.continuousAt
  refine ⟨F, H, G, hF, hF0, hH, hH0, hG, hG0, hGforward, hGuniq, ?_⟩
  filter_upwards [ht.eventually hcoverage, hFpoly] with p hp hpoly
  have hGp : G ((H p).1, (F p).2) = ((F p).1, (H p).2) := hp.1
  refine ⟨hGp, hpoly, ?_, ?_⟩
  · rw [← hpoly]
    exact hp.2
  · obtain ⟨z, hz⟩ := monic_has_labelled_roots (monicPolynomial r (H p).1) r
      (monicPolynomial_monic _ _) (monicPolynomial_natDegree _ _)
    obtain ⟨α, hα⟩ := monic_has_labelled_roots (monicPolynomial (s + 1) (F p).2) (s + 1)
      (monicPolynomial_monic _ _) (monicPolynomial_natDegree _ _)
    have hzc : rootCoefficients r z = (H p).1 := by
      ext k
      change (rootPolynomial r z).coeff k = _
      rw [hz, monicPolynomial_coeff]
    have hαc : rootCoefficients (s + 1) α = (F p).2 := by
      ext k
      change (rootPolynomial (s + 1) α).coeff k = _
      rw [hα, monicPolynomial_coeff]
    exact ⟨z, α, hzc, hαc, by rw [hzc, hαc, hGp, hα]; exact hpoly⟩

/-- The original geometric configuration supplies every algebraic input of
the complete forward/inverse coefficient chart. The residual factor and its
nonvanishing are derived from exact multiplicity. -/
theorem original_configuration_supplies_reconstruction_inputs (r s : ℕ)
    (A : ℂ[X]) (α : Fin (s + 1) → ℂ) (w : ℂ)
    (hA : A.Monic) (hAd : A.natDegree = r)
    (hvalue : (A * rootPolynomial (s + 1) α).eval w ≠ 0)
    (hmult : (A * rootPolynomial (s + 1) α).derivative.rootMultiplicity w = r)
    (hinterior : ∀ z, A.IsRoot z → ‖z‖ < 1) (hboundary : ∀ i, ‖α i‖ = 1) :
    ∃ x : Domain r s,
      monicPolynomial r x.1.1 = A ∧
      monicPolynomial (s + 1) x.2.2 = rootPolynomial (s + 1) α ∧
      monicPolynomial r x.2.1 = (X - C w) ^ r ∧
      (monicPolynomial (s + 1) x.2.2).eval w ≠ 0 ∧
      (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).eval w ≠ 0 ∧
      (monicPolynomial s x.1.2).eval w ≠ 0 ∧
      IsCoprime (monicPolynomial r x.1.1) (monicPolynomial (s + 1) x.2.2) ∧
      (monicPolynomial r x.1.1 * monicPolynomial (s + 1) x.2.2).derivative =
        C (r + s + 1 : ℂ) * monicPolynomial r x.2.1 * monicPolynomial s x.1.2 := by
  obtain ⟨a, haA, haU, hid⟩ := reconstruction_data_from_multiplicity r s A α w hA hAd hmult
  refine ⟨(a, (rootCoefficients r (fun _ => w), rootCoefficients (s + 1) α)), ?_⟩
  simp only [monicPolynomial_rootCoefficients, rootPolynomial_const]
  refine ⟨haA, trivial, trivial, ?_, ?_, haU, ?_, hid⟩
  · exact (mul_ne_zero_iff.mp (by simpa only [eval_mul] using hvalue)).2
  · simpa only [haA] using hvalue
  · rw [haA]
    exact interior_boundary_coprime A (s + 1) α hinterior hboundary

end PolynomialGeometry.ReconstructionCompletion
