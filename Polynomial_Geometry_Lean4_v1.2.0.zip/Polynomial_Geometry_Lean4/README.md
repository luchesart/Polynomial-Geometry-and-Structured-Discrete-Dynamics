# Polynomial Geometry and Structured Discrete Dynamics — Lean 4

Lean companion to the article by **Latchezar Tomov**. The checked correspondence
covers all **14 numbered mathematical statements** and the additional identities
listed in the coverage notes. The three main themes are inverse structured
realization, exact dissipative geometry and admissible spectral optimization.

Open [the interactive proof map](docs/proof_map.html) in a browser. It works
offline and contains the exact Lean statements, source proofs and dependencies.
[The reading guide](docs/reading_guide.md) identifies the main endpoints;
[the claim manifest](docs/claims.json) records the article correspondence.

Choose **Numerical experiments** or open the experiment from any of the 14
numbered statements. Each experiment lets you change the inputs, inspect
individual proof steps and pin a result for comparison. In the
[experiment for D.3](docs/proof_map.html#experiment%2FD.3), for example,
the same polynomial has blocks of copies with opposite curvature signs.
Switching blocks shows where the hypothesis for a strict quadratic gain applies.

Run `node scripts/check_experiments.cjs` to reproduce the numerical checks,
including boundary cases and parameter sweeps. Run
`python3 scripts/check_variation_reference.py` for an independent 50-digit
calculation for D.3. The latter requires Node.js and Python with mpmath.
The browser map runs offline and needs neither installation.

## Reproduce the check

Install Lean through elan and open this complete folder in VS Code with the
Lean 4 extension. The project pins **Lean 4.24.0** and mathlib commit
`f897ebcf72cd16f89ab4577d0c826cd14afaafc7`.

```sh
lake exe cache get
./scripts/check.sh
python3 scripts/build_map.py
```

The check script builds every project module, extracts the kernel environment
and validates the audit. The equivalent individual commands are:

```sh
lake build
lake env lean Audit.lean
python3 scripts/verify_audit.py
```

Build against the pinned versions. Pasting `import PolynomialGeometry` into
Live Lean does not install this multi-file project. Open the extracted folder
containing `lakefile.toml`, with its dependencies available.

## Mathematical endpoints

- **Inverse realization:** the normalized matrix test is equivalent to the
  minimal source-realization definition. It constructs the sources, masses,
  canonical rows and source polynomial, with uniqueness up to permutation.
  Theorem 2.2 extends exact recovery to error in the inverse metric. It transfers
  the fitted root count and certifies the true integer mass within the stated
  contour radius under the existence assumption.
- **Dissipative geometry:** the source metric, both defects, exact rank,
  minimum number of loss channels, strict stability, infinite energy recovery
  and finite observability are derived from the source data. Theorem 2.3 gives
  the rank for every horizon and the least positive observation horizon. The optimal
  finite-step contraction coefficient is obtained from the smallest eigenvalue.
- **Admissible optimization:** reconstruction covers every nearby monic
  polynomial, including splitting multiple roots. The same marked-root
  branches enter the ratio chart, disk constraints, inactive-gap argument and
  exact reduction of the full nearest-critical distance. For Proposition D.3,
  the labelled-root reconstruction and the inverse ratio chart give local
  permutation symmetry of the reduced function Ψ. This symmetry yields the
  derivative cancellations and the strict quadratic gain for the selected
  blocks of copies. Partial maximization also gives the Schur Hessian, uniform
  Taylor remainders and a compensated fourth-order necessary condition.
- **Geometric–dynamical bridge:** the full reciprocal transformation preserves
  algebraic multiplicities. Its distance threshold is equivalent to failure
  of asymptotic decay of all states. Equality of spectral radius to one means
  failure of asymptotic stability; it need not mean unbounded trajectories.

The final constructions derive their interfaces from the article's original
hypotheses. Intermediate lemmas with explicit interfaces are linked to those
constructions in the coverage notes. No manuscript assumptions were weakened
or conclusions inserted as new axioms to obtain the checks.

## Scope and audit

The 14-statement correspondence is a mathematical reading of the article and
its checked Lean types. Lean checks the deductions from those types; it does
not certify the editorial correspondence itself, novelty, literature
attribution or numerical illustrations. This work does not prove Sendov's
conjecture. Unmapped explanatory examples are outside the stated coverage.

`Audit.lean` records exact types, source locations, direct project dependencies
and transitive axiom dependencies from the checked environment. The audit
allows only Lean's standard `propext`, `Classical.choice` and `Quot.sound`.
It rejects proof placeholders and additional axiom declarations.

`audit/summary.json` gives the exact module and explicit-theorem counts, source
hashes and coverage status. Compiler-generated declarations and private
helpers are excluded from the reported public-theorem count. Helper-lemma
counts are separate from article coverage. `audit/manuscript_reference.json`
identifies the LaTeX sources in both publication editions.

The archive includes sources, the offline map, coverage notes, build log and
reproducibility metadata. Downloaded runtimes, mathlib caches and generated
`.olean` files are excluded. `scripts/package.py` checks the audited source
hashes and writes a ZIP with `SHA256SUMS`.
