import PolynomialGeometry
import Lean.Util.CollectAxioms
import Lean.Util.FoldConsts

/-!
Run with `lake env lean Audit.lean` after `lake build`.
The audit reads checked declarations from the Lean environment and records
actual proof dependencies and the transitive axiom set. It proves no
mathematical statement and introduces no assumptions into the project.
-/
open Lean Elab Command
set_option maxHeartbeats 0

run_cmd do
  let env ← getEnv
  let mut entries : Array Json := #[]
  let mut names : Array Name := #[]
  for (name, info) in env.constants.toList do
    if name.toString.startsWith "PolynomialGeometry." then
      let isThm := wasOriginallyTheorem env name
      if isThm || info.isDefinition then
        names := names.push name
        let deps := info.getUsedConstantsAsSet.toList.filter fun n =>
          n.toString.startsWith "PolynomialGeometry."
        let statement ← liftTermElabM do
          return (← Meta.ppExpr info.type).pretty
        let modName := match env.getModuleIdxFor? name with
          | some idx => (env.header.moduleNames[idx]!).toString
          | none => ""
        let ranges ← findDeclarationRangesCore? name
        let line := match ranges with
          | some r => r.selectionRange.pos.line
          | none => 0
        entries := entries.push <| Json.mkObj [
          ("module", toJson modName),
          ("line", toJson line),
          ("name", toJson name.toString),
          ("kind", toJson (if isThm then "theorem" else "definition")),
          ("type", toJson statement),
          ("dependencies", toJson (deps.map Name.toString))]
  let action : CollectAxioms.M Unit := names.forM CollectAxioms.collect
  let (_, axState) := ((action.run env).run {})
  let payload := Json.mkObj [("declarations", Json.arr entries),
    ("axioms_union", toJson (axState.axioms.map Name.toString)),
    ("axiom_scope", toJson "All exported project theorems and definitions; union of transitive kernel dependencies") ]
  liftIO <| IO.FS.createDirAll "audit"
  liftIO <| IO.FS.writeFile "audit/checked_declarations.json" payload.pretty
  logInfo m!"Audited {entries.size} project declarations; wrote audit/checked_declarations.json"
