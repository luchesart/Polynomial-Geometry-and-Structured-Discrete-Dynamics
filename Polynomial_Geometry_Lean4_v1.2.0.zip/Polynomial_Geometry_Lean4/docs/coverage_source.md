# Complete source coordinates

Theorem B.1 is assembled in
`PolynomialGeometry.Confluent.complete_positive_source_realization`, defined
in `ConfluentCompletion.lean`. The source positions are distinct, their
masses are positive and their moduli are at most one. The prescribed
critical chains have distinct positions and positive lengths. Each length
is encoded as `r i + 1`, and the total number of chain columns is exactly
one less than the number of sources.

The numerator divisibility hypotheses express the prescribed critical
multiplicities. They are used to derive the partial-fraction moments and
source orthogonality, not to assume those identities.

| Article assertion | Lean declaration |
|---|---|
| Moment identities from numerator multiplicities | `Source.moments_vanish_of_numerator_dvd` |
| Actual Cauchy coordinates, source equation and zero output | `Confluent.cauchy_source_matrix_identity`, `Confluent.cauchy_orthogonal_of_numerator_dvd` |
| Full rank and positive Gram matrix | `Confluent.cauchy_injective_of_numerator_dvd`, `Confluent.cauchy_gram_posDef` |
| The columns span the zero-output source subspace | `Confluent.complete_source_range` |
| Exact Gram projection | `Confluent.cauchy_projection` |
| Positive source loss and exact Stein identity | `Confluent.cauchy_loss_posSemidef`, `Confluent.cauchy_stein_identity` |
| Strict spectral radius | `Confluent.cauchy_spectralRadius_lt_one` |
| Absolutely convergent Stein series and uniqueness among all matrix solutions | `Confluent.cauchy_stein_series_and_unique` |
| Combined source-level endpoint | `Confluent.complete_positive_source_realization` |

These results cover repeated critical positions through their full Jordan
chains. They impose no diagonalizability assumption. The coordinate bridge
with the direct source metric is documented in
[Source geometry and coordinate bridge](coverage_geometry.md).

The inverse direction and recovery from minimal source data are completed
separately in [Complete inverse realization and recovery](coverage_inverse_completion.md).
