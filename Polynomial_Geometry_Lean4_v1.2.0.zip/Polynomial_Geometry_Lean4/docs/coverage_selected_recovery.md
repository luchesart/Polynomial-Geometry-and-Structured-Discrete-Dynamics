# Selected-source polynomial: formal coverage

Corollary B.2 is fully composed with the minimal inverse-realization data.
The common polynomial construction is in `SelectedRecovery.lean`; its
source-level specialization is in `RecoveryCompletion.lean`.
See [Complete inverse realization and recovery](coverage_inverse_completion.md)
for the complete correspondence, including masses and integer multiplicities.

For `h = H⁻¹R*e`, the polynomial is defined explicitly by

    Q = charpoly(J − n h e*).

`SelectedRecovery.selectedPolynomial_monic` and
`selectedPolynomial_natDegree` prove its monicity and exact degree.
`selectedPolynomial_eval` proves `Q(z) = G(z)[1+n κ(z,a)]` away from the
critical spectrum by the matrix determinant lemma.

The final source-level results derive the required cross-kernel identities
from minimal realization completeness. They do not assume them:

| Formula | Lean declaration |
|---|---|
| Product over every nonselected source | `RecoveryCompletion.completeRealization_selected_polynomial` |
| Completion characteristic polynomial equals `(X-a) Q` | `RecoveryCompletion.completeRealization_selected_factorization` |
| `Q(a) = n G(a)` | `RecoveryCompletion.completeRealization_selected_value` |
| Kernel expression equals the nonselected product | `RecoveryCompletion.completeRealization_kernel_product` |

The product uses the subtype of all source indices other than the selected
one. Its cardinality is derived from completeness. Source positions, weights,
rows and kernel coordinates are those of the same realization returned by
the inverse theorem; no final indexing or coordinate substitution remains
open for this corollary.
