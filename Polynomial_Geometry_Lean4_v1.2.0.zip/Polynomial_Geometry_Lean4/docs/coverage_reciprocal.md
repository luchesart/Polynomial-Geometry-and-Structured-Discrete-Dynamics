# Reciprocal determinants and algebraic multiplicities

The displayed determinant and multiplicity identities (A.8)–(A.9), and the
full-matrix distance threshold (A.11), have actual matrix-level counterparts in `ReciprocalSpectrum.lean` and `ReciprocalMultiplicity.lean`.
The finite spectral-list identity in the earlier `ReciprocalDistance.lean`
is no longer the only endpoint.

| Mathematical assertion | Lean endpoint |
|---|---|
| Exact determinant of the matrix resolvent | `ReciprocalSpectrum.resolvent_determinant` |
| Actual source determinant equals the prescribed spectral numerator ratio | `ReciprocalMultiplicity.source_bridge_determinant` |
| Complete characteristic polynomial of the reciprocal matrix | `ReciprocalMultiplicity.resolvent_charpoly` |
| Complete root multiset is mapped by `w ↦ (a-w)⁻¹` | `ReciprocalMultiplicity.resolvent_roots` |
| Each algebraic multiplicity is preserved | `ReciprocalMultiplicity.resolvent_rootMultiplicity` |
| The source bridge transfers the prescribed root multiset to the actual source matrix | `ReciprocalMultiplicity.source_bridge_roots` |
| Equal-copy compression represents the full derivative, including inherited factors | `ReciprocalSpectrum.equal_copy_derivative` |
| The full reciprocal matrix preserves every critical multiplicity of that derivative | `ReciprocalMultiplicity.full_reciprocal_critical_multiplicity` |
| `D ≤ r ↔ r ρ ≥ 1` for the actual full matrix, including the attained nearest distance | `ReciprocalSpectrum.full_reciprocal_distance_threshold`, `nearest_critical_distance_threshold` |

`source_bridge_determinant` assumes exactly the source equation, the
zero-output condition, a positive definite source Gram form, and separation
from the selected source. It derives an invertible intertwiner using
`Geometry.coordinate_bridge`, then transports the characteristic polynomial.
The formula holds for every complex `t`, including apparent poles of the
rational rank-one expression.

The reciprocal characteristic-polynomial proof first establishes equality
at every nonzero complex evaluation point. It clears each reciprocal factor
in the complete root multiset of the original characteristic polynomial.
Polynomial identity then supplies equality everywhere. Taking the root
multiset proves multiplicity preservation without any simplicity or
distinct-critical-position assumption.

The final full-derivative theorem uses the actual equal-copy compression.
Repeated source copies are permitted. Its only selected-point nondegeneracy
is `p'.eval a ≠ 0`, exactly what makes the reciprocal matrix resolvent
well-defined. No inherited critical mode is omitted.
