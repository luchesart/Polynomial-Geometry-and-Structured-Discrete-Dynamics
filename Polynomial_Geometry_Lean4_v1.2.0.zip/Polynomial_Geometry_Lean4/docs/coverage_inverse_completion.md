# Complete inverse realization and recovery

`InverseEquivalence.lean` and `RecoveryCompletion.lean` close the previously
unassembled parts of Theorem 2.1 and Corollary B.2.

## Minimal data and the necessity bridge

`InverseEquivalence.CompleteRealization` is precisely the positive source
model, using positive square-root weights `ω` with masses `ν = ω²`.
It requires distinct disk positions, total mass, a selected source of mass
one, the prescribed Gram matrix, canonical resolvent rows, and the full
scalar numerator identity. It does **not** require orthogonality, source
equations, a source basis, a matrix similarity or a completion test.

The new common mechanism is

1. Clear the scalar source denominators to obtain the actual polynomial
   identity `rawNumerator = C n * J.charpoly`.
2. Evaluate that identity at `J`. Cayley–Hamilton gives zero.
3. The source denominators are invertible, so cancellation gives the matrix
   identity `∑ ν_j (α_j I - J)⁻¹ = 0`.
4. The canonical rows now give `b* Y = 0`. Their defining equation also gives
   `A Y = Y J - b e*`.
5. The full source/state basis has Gram matrix `diag(n,H)`. The selected
   mass-one row forces its intertwining with the specific normalized border.

Thus the necessity theorem begins with the minimal definition in the paper.
Its required basis and similarity are proved outputs.

## Theorem 2.1 correspondence

| Article assertion | Lean declaration |
|---|---|
| Full existence iff, for an observable pair | `InverseEquivalence.normalized_inverse_realization_iff` |
| Canonical chains discharge observability from distinct critical positions | `InverseEquivalence.canonical_normalized_inverse_realization_iff` |
| Source spectrum is exactly the completion spectrum, with all multiplicities | `InverseEquivalence.completeRealization_support_charpoly` |
| Uniqueness up to source ordering, including masses and every source row | `InverseEquivalence.completeRealization_unique` |
| Existence and uniqueness in one endpoint | `InverseEquivalence.normalized_inverse_exists_unique` |

The uniqueness permutation matches the actual source values. Hence it also
matches the selected source, since the positions are distinct. The general
theorem permits any complex selected value and positive total mass whenever
the other hypotheses hold. This includes the article's more restrictive
`a ∈ [0,1)` and `n > 1` assumptions. The canonical block lengths remain
`r i + 1` in Lean, which represents every positive block size in the paper.

## Corollary B.2 correspondence

The following declarations are in `PolynomialGeometry.RecoveryCompletion`.
Their hypotheses use the same minimal realization. No projection or
cross-kernel identity has been added as an assumption.

| Article assertion | Lean declaration |
|---|---|
| Actual resolvent kernel agrees with the row Gram kernel | `kernelMatrix_eq_recoveryKernel` |
| Diagonal kernel values are nonnegative | `recoveryKernel_diagonal_nonnegative` |
| Complete source projection | `completeRealization_projection` |
| All diagonal and cross-source kernel identities | `completeRealization_kernel` |
| `Q_a` is the product over all nonselected positions | `completeRealization_selected_polynomial` |
| `D_M = (X-a) Q_a` | `completeRealization_selected_factorization` |
| `Q_a(a) = n G(a)` | `completeRealization_selected_value` |
| `G(z)(1+n κ(z,a))` is the nonselected product | `completeRealization_kernel_product` |
| Residue formula with the actual completion characteristic polynomial | `completeRealization_completion_residue` |
| Exact inverse diagonal mass and mass-at-least-one criterion | `completeRealization_diagonal_mass` |
| Ordinary logarithmic polynomial exists iff all recovered masses are positive integers | `completeRealization_integer_iff` |
| Explicit monic product, full derivative factorization and uniqueness | `completeRealization_integer_polynomial` |
| A single matrix test constructs a realization and the principal recovery identities | `normalized_completion_and_recovery` |

`Q_a` is defined as the characteristic polynomial of the rank-one update
`J - n h e*`, with `h = H⁻¹ R* e`. The earlier checked determinant lemma
identifies its evaluation with the rational kernel expression. The new
composition derives its roots from the recovered source projection and
uses the subtype of all indices other than the selected index. The exact
cardinality is proved from completeness, so no source is omitted.

These two numbered claims are fully covered by the listed endpoints.
This does not assert completion of the independent local-variation claims
in Appendix D or of the Sendov conjecture.
