# Analytic compensation: Lemma D.4, higher-order conclusions

`PolynomialGeometry/AnalyticCompensation.lean` proves the nonlinear Taylor
remainder statements and the compensated kernel necessary conditions. Its
arguments use the actual derivatives of the objective, rather than supplied
Taylor coefficients or a supplied expansion.

| Article assertion | Checked declaration |
|---|---|
| Uniform analytic Taylor formula with actual iterated derivatives | `AnalyticCompensation.analytic_taylor_remainder` |
| Flat analytic response has quadratic size | `AnalyticCompensation.analytic_zero_first_order`, `flat_response_bounds` |
| Stationarity determines the response through degree two, with a uniform cubic remainder | `AnalyticCompensation.stationary_quadratic_jet` |
| The vector `t(x,x)` represents the actual cubic tensor | `AnalyticCompensation.mixedCubic_pairing` |
| Cubic symmetry follows from analyticity | `AnalyticCompensation.cubic_derivative_symmetries` |
| The graph substitution discards only terms of order at least five | `AnalyticCompensation.objective_flat_graph_expansion` |
| The exact coefficient `1/8` persists with a genuine fifth-order remainder | `AnalyticCompensation.compensated_graph_expansion` |
| One constructed analytic partial maximum has both displayed remainder estimates, stationarity, uniqueness, quadratic domination and the equivalence of nearby positive values | `AnalyticCompensation.analytic_compensated_partial_maximum` |
| A local maximum forces cubic vanishing and nonpositive compensated quartic on every retained direction | `AnalyticCompensation.analytic_kernel_necessary` |

The vector is defined by

```
mixedCubic F x =
  iteratedFDeriv ℝ 2 (PartialMaximum.partialGradient F) 0
    (fun _ => (x, 0))
```

The pairing theorem proves

\[
\langle\operatorname{mixedCubic}(F,x),s\rangle
 = D^3F(0)[(x,0),(x,0),(0,s)].
\]

Both remainder estimates use `Asymptotics.IsBigO` at the full norm
neighborhood of zero. They are uniform in all retained directions, rather
than bounds obtained only along each fixed ray. The scalar ray argument is
used only at the final necessary-condition step.

The construction first obtains the analytic stationary response from the
negative partial Hessian through `SchurHessian.flat_analytic_partial_maximum`.
The second-order Taylor expansion of the actual partial gradient then gives
its quadratic response. The fourth-order Taylor expansion of the actual
objective, multilinear symmetry and the precise orders of mixed terms give
the objective expansion. Completing the square makes the error in the
response contribute only at order six. This proves, in particular, the
claimed fifth-order remainder with the exact coefficient `1/8`.

In the product-space endpoint the kernel decomposition is expressed by the
explicit actual-Hessian identity

\[
D^2F(0)[u,v]=-\langle u_s,Pv_s\rangle.
\]

No response, inverse chart, Taylor coefficient, remainder estimate or local
maximum of the reduced objective is an assumed input. The positive operator
is inverted by the previously constructed continuous linear equivalence.
The eliminated space is allowed to have dimension zero.

## Construction from the original Hessian hypothesis

The final wrapper is `PolynomialGeometry/KernelCompensation.lean`.

- `KernelMaximum.hessianKernel` constructs the actual kernel of
  `fderiv ℝ (fderiv ℝ F) 0`.
- `KernelMaximum.kernelCoordinates` constructs the continuous linear
  equivalence between that kernel times its orthogonal complement and the
  original Euclidean space.
- `KernelMaximum.canonical_kernel_block_data` derives the positive operator
  and the exact block identity from negative semidefiniteness of the actual
  Hessian. Positivity on the complement is proved, not assumed.
- `KernelCompensation.kernel_coordinate_iterated_derivative` identifies every
  derivative in these coordinates with the original derivative on the included
  vectors. `canonical_mixedCubic_pairing` in particular identifies the cubic
  response vector with the original third derivative.
- `KernelCompensation.canonical_compensated_partial_maximum` starts only from
  the original analytic objective, its zero value and derivative at the origin,
  and negative semidefiniteness of its actual Hessian. It constructs the
  complement operator and one response satisfying stationarity, local
  uniqueness, uniform quadratic maximality, the equivalence of nearby positive
  values in the original space and both remainder formulas. The cubic and
  quartic coefficients in that endpoint are derivatives of the original
  objective.
- `KernelCompensation.canonical_kernel_necessary` adds only the hypothesis that
  the original objective has a local maximum, and proves both necessary tests
  for every vector in its actual Hessian kernel.

Thus the exact block identity in the intermediate product-space theorem is
not an extra premise in the final original-space theorem. The canonical
construction derives it, including when the kernel or its complement has
zero dimension.
