# Energy and observability: exact correspondence

This note maps Appendix C and the energy-related parts of Appendix F of *Polynomial Geometry and Structured Discrete Dynamics* to the Lean development. Declaration names below have the prefix `PolynomialGeometry.`. Equation and theorem numbers refer to the 20 November 2026 manuscript.

## Source hypotheses and conventions

The source endpoints assume a finite index type `ι`, `0 ≤ a`, `a < 1`, nonzero `u j`, pairwise distinct `α j`, `a ≠ α j`, and `Complex.normSq (α j) ≤ 1`. The article is the specialization `u j = √ν_j` with positive real masses `ν_j`. Lean allows nonzero complex `u j` and uses `ν_j = normSq (u j)`, which is a genuine generalization. No integer multiplicity assumption is needed in this section.

`Fintype.card ι` is the genuine state dimension `d=K−1`, not the polynomial degree. `Geometry.totalMass u` is `1+Σ normSq (u j)`. `Geometry.interiorSet α` counts strict interior sources. Under the disk hypothesis its complement consists exactly of boundary sources. The selected source has mass one and is not included in these counts.

`Dynamics.energy E x` is the real part of `x* E x`; the source metric is proved Hermitian and positive definite. `Dynamics.outputEnergy y` is `Σ normSq (y j)`, the Euclidean squared output norm. It is not the default supremum norm on a function type. Output counts and ranks are complex counts. The geometric block bound and finite-observability statements require a nonempty state index type, so that `d≥1`.

## Theorem C.1 and its preceding identities

| Manuscript statement | Checked declarations |
|---|---|
| (2.8): `E_g=(I+uu*)⁻¹=I−uu*/n`, with `E_g≻0` | `Geometry.metric_closed_form`, `Geometry.metric_posDef` |
| (C.1): `‖x‖₂²/n ≤ V(x) ≤ ‖x‖₂²` | `Geometry.source_cauchy_schwarz`, `Geometry.metric_quadratic_value`, `Geometry.metric_quadratic_bounds` |
| (C.2): reciprocal disk identity and `K_a≽0` | `Geometry.reciprocal_disk_scalar`, `Geometry.diskDefect_diagonal`, `Geometry.source_diskDefect_posSemidef` |
| (C.3): exact expansive defect and its nonnegativity | `Geometry.expansive_defect`, `Geometry.expansive_defect_posSemidef` |
| Invertibility of the actual `S` | `Geometry.source_expansive_isUnit` |
| (C.4): exact inverse defect and `D_T≽0` | `Geometry.inverse_defect`, `Geometry.source_contractivity` |
| (C.5): both defect ranks equal `i+min(2,b)` | `SourceRank.expansive_source_defect_rank`, `SourceRank.contractive_source_defect_rank` |
| Strict transformed spectrum and actual asymptotic stability | `SourceDynamics.transition_roots_strict`, `SourceDynamics.transition_spectralRadius_lt_one`, `SourceDynamics.states_tendsto_zero` |
| (C.6): exact one-step energy balance | `Dynamics.energy_step`, instantiated using `SourceRank.sourceContractiveLossFactor_gram` |

The rank proof constructs the coordinate and two dense source rows, proves independence when two distinct boundary values are present, and proves full column rank when at most one boundary coordinate remains. Neither the rank nor the necessary kernel characterization is assumed. `SourceRank.contractive_source_defect_posDef_iff` additionally identifies strict one-step loss with `b≤2`.

Strict stability is derived from the original sources. `SourceStability.source_eigenvector_norm_lt_one` proves strict disk inclusion from the actual source equations; `Geometry.source_mobius_relation` and `Mobius.root_norm_lt_one` transfer it to the transition matrix. `Stability.states_tendsto_zero` then derives trajectory decay. Repeated eigenvalues are allowed; no diagonalizability assumption is imposed on the transition matrix.

## Corollary C.2 and block contraction

`SourceDynamics.energy_recovery_and_observability` assembles (C.7)–(C.9) for **any** finite complex output matrix satisfying `C* C=D_T`, directly from the source hypotheses. It contains the infinite energy identity, full observation rank, the exact finite Gramian identity, and positive definiteness of the finite defect. Its factorization premise is the premise stated in Corollary C.2; a factor is also explicitly constructed and a minimum-row factor is proved to exist.

| Manuscript statement | Checked declarations |
|---|---|
| An actual output factor | `SourceRank.sourceContractiveLossFactor_gram` |
| Finite telescoping identity | `Dynamics.stein_sum`, `Dynamics.finite_energy_recovery` |
| (C.7): infinite energy recovery | `Dynamics.hasSum_outputEnergy`, `Dynamics.tsum_outputEnergy`; source endpoint `SourceDynamics.infinite_energy_identity` |
| (C.8): first `d` outputs determine the state | `Dynamics.zero_outputs_of_first_card`, `Dynamics.state_zero_of_first_card`, `Dynamics.observationMatrix_injective`, `Dynamics.observationMatrix_rank` |
| (C.9): exact positive finite defect | `Dynamics.observation_gram_eq_defect`, `Dynamics.finite_defect_posDef` |
| Minimum row count for a fixed PSD defect | `GramFactorization.exists_gram_factor_rank`, `GramFactorization.rank_isLeast_gram_row_count` |
| Actual source minimum equals `i+min(2,b)` | `SourceRank.source_minimum_loss_channels` |
| Sharp `θ = 1−λ_min(E_g⁻¹ᐟ² W_d E_g⁻¹ᐟ²)`, with `0<θ<1`, optimality and `V(T^k x)≤θ^⌊k/d⌋V(x)` | `SharpContraction.sharpFactor_spec`, `SharpContraction.sharpFactor_pos`, `SharpContraction.sharp_block_floor`; source endpoint `SharpContraction.source_sharp_block_contraction` |

The explicit source factor has `i+2` rows. When `b<2`, redundant rows need not already have been deleted from that particular factor. The minimum theorem separately constructs a factor with exactly `i+min(2,b)` rows by retaining the nonzero eigenvalues of the defect. The count is for the specified source metric; no minimization over other metrics is claimed.

The sharp factor is obtained from the actual normalized loss matrix, using
`CFC.sqrt` for the positive Hermitian square root. Its Rayleigh bound and an
attaining state are proved. The source endpoint also derives positive
finite-step loss and invertibility from the original source hypotheses.
See [Sharp finite-block contraction](coverage_sharp_contraction.md) for the
precise correspondence. The earlier compactness-based existence theorem
remains a reusable result, but it is not the only block estimate available.

## Appendix F and limits of coverage

The energy-congruence calculation is `Dynamics.energy_congruence`; the source-coordinate metric identity is `Geometry.coordinate_metric`. General PSD Gram factorization and its minimum row count are established in `GramFactorization.lean`. Appendix (A.2), finite telescoping, energy recovery, and the Cayley–Hamilton observation argument are covered by the declarations above.

The implication from strict spectral radius to decay is proved using Gelfand's formula in `Stability.power_norm_eventually_geometric` and `Stability.powers_tendsto_zero`. This is a different rigorous proof of the appendix's Jordan-block argument. The absolute convergence of the matrix Stein series and uniqueness of its solution are `SteinSeries.summable_norm_stein`, `SteinSeries.hasSum_stein`, `SteinSeries.solution_unique`, and `SteinSeries.series_and_unique`. The generic statements explicitly assume strict spectral radius; the source-level gap is independently proved in `SourceDynamics`.

The converse is now proved in `StabilityEquivalence.asymptoticallyStable_iff_spectralRadius`: every state tends to zero if and only if the actual matrix spectral radius is strictly less than one. Its proof extracts a genuine characteristic-root eigenvector and derives scalar-power decay from a nonzero coordinate. `StabilityEquivalence.full_reciprocal_distance_iff_not_stable` composes this with the full polynomial reciprocal-distance theorem, including inherited repeated-root modes. See [Actual state stability and reciprocal distance](coverage_stability_equivalence.md).

The following displayed or explanatory items are **not** separately formalized by this energy development:

- The five-dimensional worked example: its Fourier basis, exact fifth power, numerical eigenvalues, and comparison of ranks in two metrics.
- The appendix's explicit real-coordinate block conversion. The actual positive Hermitian square root used by the sharp contraction formula is covered in `SharpContraction`.

The checked results do not complete an independent proof of Sendov's conjecture or make claims about numerical accuracy. Endpoint axiom audits use only Lean's standard `propext`, `Classical.choice`, and `Quot.sound`.
