# Coefficient-space exact reduction and actual polynomial gains

`FullFeasibleReduction` assembles Theorem 2.4 for one and the same reconstructed
family, selected source branch, simple critical branch, and ratio inverse.
`OriginalFeasibleReduction` constructs these objects from the original
polynomial assumptions and gives the complete endpoint.

## Full coefficient neighborhoods

`coefficientChart` is the coefficient vector of the actual reconstructed
product. `monic_coefficientChart` proves exact equality of the polynomial,
`coefficientChart_analytic` proves analyticity, and
`coefficientChart_map_nhds` derives neighborhood coverage from the reconstruction
coverage theorem. `coefficientRealChart_map_nhds` composes this coverage with the
actual ratio inverse and the explicit real boundary chart.

`selected_root_descends_to_coefficients` independently continues the simple
selected root in full coefficient space. Local root uniqueness identifies its
pullback with the selected root of the reconstruction. Thus the final distance
is evaluated at a genuine marked root of every nearby coefficient polynomial,
not at a function available only on a labelled parameterization.

`coefficient_space_exact_reduction` proves that arbitrarily near feasible
coefficient polynomials with strictly larger all-critical-point distance exist
if and only if the actual reduced function has arbitrarily near positive
values. Both feasibility and the objective correspondence are proved, not
assumed. The original all-critical-point gap supplies the inactive residual
gap through the exact derivative factorization.

## Same-chart geometry and strict gains

`real_chart_exact_geometry` exposes on a whole real-coordinate neighborhood:

- disk feasibility if and only if every radial coordinate is nonpositive;
- strict interior location of every root of the interior factor;
- the selected source is a root of the actual reconstructed polynomial;
- equality of the logarithmic full critical distance with the displayed
  smooth weighted objective minus its balancing penalty.

`balanced_slice_geometry` proves that the reduced slice consists of feasible
polynomials, keeps every boundary copy on the circle, preserves strict interior
roots, equalizes all active distances, identifies their common value with the
full critical distance, and identifies its logarithmic gain with the reduced
function.

`actual_polynomial_replacement_bounds` composes the exact full-distance formula
with the two uniform analytic replacement estimates. Writing `L` for the
logarithmic gain of the actual polynomial, it proves, on one neighborhood,

\[
L(x,\rho,y,\theta)\le L(0,\rho,y,\theta)-\tfrac b2\|x\|,
\]

and, when every component of `rho` is nonpositive,

\[
L(0,\rho,y,\theta)\le L(0,0,y,\theta)-c\|\rho\|,
\qquad c>0,
\]

as well as their combined bound by the actual reduced function. These are
bounds for the full polynomial distance, not solely for a proxy objective.
The estimates imply strict improvement whenever the coordinate being removed
is nonzero. Their inputs are the article's scalar free stationarity and the
positive radial derivatives of the same objective. They do not assume any of
the desired replacement estimates.
