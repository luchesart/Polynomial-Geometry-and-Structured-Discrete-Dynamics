# Uniform partial maximum and the actual reduced Hessian

The modules `UniformPartialMaximum.lean` and `SchurHessian.lean` complete the
local maximization and Schur-formula portion of Lemma D.4. The higher-order
Taylor conclusions are developed separately and are not implied by this
coverage note.

The main assembled endpoint is
`PolynomialGeometry.SchurHessian.analytic_partial_maximum_with_schur`.
Its inputs are an actual analytic scalar objective `F`, its zero derivative
at the origin, a positive operator `P` on the eliminated space, and the
identity that the eliminated block of the derivative of the actual partial
gradient is `-P`. The retained space is any finite-dimensional real normed
space. The eliminated space is a finite-dimensional real inner-product
space, including the zero-dimensional space.

One analytic branch `θ` is constructed with all the following properties:

- `θ 0 = 0`, stationarity, and local uniqueness among stationary points;
- its derivative is the inverse positive Hessian composed with the actual
  mixed derivative of `partialGradient F`;
- the reduced objective `G x = F (x, θ x)` is analytic;
- there exists `c > 0` such that, on a neighborhood of the origin,
  `F (x,s) ≤ G x - c * ‖s - θ x‖^2`;
- `F` has positive values arbitrarily close to zero if and only if `G` does;
- the actual second Fréchet derivative of `G` satisfies the Schur formula.

The Schur formula is written as a bilinear equality. If
`M x = D(partialGradient F)(0) (x,0)`, it states

\[
 D^2G(0)[x,y]=D^2F(0)[(x,0),(y,0)]
             +\langle My,P^{-1}Mx\rangle.
\]

Thus `M` is the article's `C^T`. This is the same formula as
`A + C P^{-1} C^T`, expressed without choosing coordinates on the retained
space. The equality is proved by differentiating the actual envelope
identity, then using the symmetry of the Hessian of the analytic scalar
objective. It is not an assumed Hessian formula or an identity confined to
an auxiliary quadratic model.

The domination estimate is obtained in four steps. Compactness of the unit
sphere gives a positive uniform coercivity constant for `P`. Strict
differentiability of the actual partial gradient gives a uniform remainder
bound for two independently moving points. A one-dimensional mean value
argument along the line segment from `θ x` to `s` yields the quadratic loss.
Finally, continuity of `θ` places both endpoints and the entire segment
inside one neighborhood. No local-maximum inequality is an input.

Reusable endpoints include:

| Assertion | Declaration |
|---|---|
| Uniform positivity of the Hessian | `UniformPartialMaximum.positive_hessian_coercive` |
| Actual Riesz gradient pairing | `UniformPartialMaximum.partialGradient_pairing` |
| Strict derivative bound on moving pairs | `UniformPartialMaximum.gradient_uniform_remainder` |
| Segment integration and quadratic domination | `UniformPartialMaximum.quadratic_domination_on_convex_set` |
| Uniform neighborhood estimate for a stationary branch | `UniformPartialMaximum.uniform_local_quadratic_domination` |
| Preservation of arbitrarily nearby positive values | `UniformPartialMaximum.frequently_positive_iff` |
| Actual Hessian/Riesz relation | `SchurHessian.partialGradient_hessian_pairing` |
| Exact local envelope identity | `SchurHessian.reduced_fderiv_eventually` |
| Actual reduced Hessian | `SchurHessian.reduced_hessian_schur` |
| Full local-maximum and Schur construction | `SchurHessian.analytic_partial_maximum_with_schur` |
| General second-order composition rule | `SchurHessian.second_fderiv_comp` |
| Hessian-kernel splitting implies a flat response | `SchurHessian.flat_analytic_partial_maximum` |

The neighborhood quantifiers use Lean's filter notation. In particular,
`Frequently` in the positive-value equivalence means that every neighborhood
contains a point with positive objective. It does not assert the existence
of a positive value at the origin.

For the higher-order specialization, the exact Hessian identity
`D²F(0)[u,v] = - inner u.2 (P v.2)` implies symmetry of `P` and
`D(partialGradient F)(0) = -P ∘ snd`. The endpoint
`flat_analytic_partial_maximum` constructs the same local maximum with
`Dθ(0)=0` and `D²G(0)=0`. These zero derivatives are conclusions, rather
than additional assumptions on the response. The separate Taylor module
can use them to derive the cubic and quartic expansions.

`KernelMaximum.lean` removes the need to assume that coordinate block
identity separately. For an analytic scalar objective on a finite-dimensional
real inner-product space with a negative semidefinite Hessian, it defines
`hessianKernel F` to be the actual kernel of `D²F(0)` and constructs the
continuous linear equivalence

\[
 J:\ker D^2F(0)\times\ker D^2F(0)^\perp\longrightarrow W,
 \qquad J(x,s)=x+s.
\]

`KernelMaximum.canonical_kernel_block_data` then constructs the positive
operator `P` and proves the block identity for the actual objective `F ∘ J`.
The argument first proves that a zero quadratic value of a symmetric
negative semidefinite form belongs to its full bilinear kernel. The
orthogonal complement meets that kernel only at zero, which makes the
negative eliminated block strictly positive. The canonical chart is an
actual continuous linear equivalence, so no local directions are discarded.
Analyticity, the zero first derivative, positive values in every neighborhood,
and the local-maximum property are explicitly transferred through the chart.
