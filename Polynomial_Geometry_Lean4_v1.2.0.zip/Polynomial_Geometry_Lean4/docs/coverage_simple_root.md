# Simple roots in the reconstructed family

`PolynomialGeometry/SimpleRoot.lean` supplies the simple-root continuation step used for the marked source and the simple residual critical point in Lemma D.1. All declaration names below have prefix `PolynomialGeometry.SimpleRoot.`.

| Declaration | Checked conclusion |
|---|---|
| `analytic_simple_root` | For a finite-dimensional complex parameter space, joint analyticity, a zero, and a nonzero actual partial derivative construct an analytic root branch with the prescribed base value, a local zero equation, and local uniqueness. |
| `monic_eval_partial_derivative` | The partial derivative with respect to the evaluation point is the actual polynomial derivative. |
| `monic_simple_root` | A simple root of a monic polynomial continues analytically under all lower-coefficient variations. No root function is assumed. |
| `analytic_family_simple_root_fiberwise` | The continuation applies to any analytic coefficient family, and the chosen branch takes equal values whenever the coefficient vectors are equal. |
| `source_factor_simple_root` | A simple root of the reconstructed factor `A` continues as a root of the actual polynomial `P=A M`. |
| `residual_factor_simple_root` | A simple root of the residual factor `U` continues as a root of the actual derivative `P'=N C U`. |
| `splitting_reconstruction_with_marked_roots` | Obtains the analytic reconstruction from `CriticalReconstruction.splitting_critical_factor_reconstruction`, then constructs both marked branches simultaneously, with the exact polynomial identity and actual root equations. |

The construction applies the analytic inverse function theorem to `(x,z) ↦ (x,f(x,z))`. The nonzero scalar partial derivative proves that its triangular differential is invertible. Thus existence and uniqueness of the root branch are proved, rather than inserted into a reconstruction hypothesis.

For the combined endpoint, `r,s>0`; the base derivative identity and nonvanishing conditions are those of the critical reconstruction theorem. The selected roots of `A` and `U` are separately assumed simple. The theorem proves the actual equations `P_q(a(q))=0` and `P'_q(v(q))=0`. Its explicit uniqueness clauses concern the corresponding simple factors. Uniqueness for the full product in a specified neighbourhood additionally uses nonvanishing of the complementary factor there.

Both branches are chosen as coefficient-root maps composed with the reconstructed coefficient functions. Consequently the proved permutation invariance of the reconstruction transfers to both branches. The combined endpoint states this equality for every permutation of the critical and source copies. The root equations and analyticity are local; the global equality expresses the way the functions were constructed and does not assert a global analytic labelling of polynomial roots.

This module does not supply the final logarithmic-ratio inverse or the complete admissible-domain and optimization conclusions. It supplies their analytic marked-root inputs, including copy-permutation symmetry. Repeated critical and source copies remain independent labelled inputs of the reconstruction; no analytic continuation of their individual roots through collisions is assumed.
