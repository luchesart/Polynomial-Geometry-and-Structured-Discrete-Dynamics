# Correspondence for Theorems 2.2 and 2.3

## A contour certificate for a source mass

`NoisyContour.noisy_mass_recovery_extrema` is the article endpoint. The inputs are a complete positive-mass realization, the marked mass-one source, fixed canonical data, total mass and a bound for the Euclidean operator norm of the inverse-metric error. The radius is positive, the marked source lies outside the closed disk, the fitted support polynomial has one zero counted with multiplicity, and its contour minimum exceeds the computed perturbation bound. The conclusion identifies a unique source and bounds the complex residue error using the actual extrema and distance to the circle. The polynomial logarithmic-derivative hypothesis gives the integer-mass conclusion through the earlier realization equivalence.

`NoisyContour.noisy_mass_recovery` accepts certified upper and lower bounds for those extrema. `NoisyMetric` derives the pointwise support perturbation from the adjugate formula and the Euclidean matrix norm. `NoisyContour.rouche` proves polynomial root-count invariance on a circle, using the argument principle proved in the same module. `NoisyContour.isolated_residue` gives the contour value at the unique simple fitted root, including the case where its residue is zero.

## Power defects and the least observation horizon

`FiniteHorizon.positive_mass_source_horizon` takes the positive masses and disk positions of the grouped article model and uses its transition and metric. `FiniteSourceObservation` telescopes the finite Gramian and derives consecutive boundary moments. The expansive step coincides with a diagonal matrix on its one-step zero-loss space. `FiniteHorizon.finiteSourceRows_rank` computes the rank from a square Vandermonde minor. `FiniteSourceHorizon` transports the result to powers of the contractive transition. The rank, the positive-definiteness criterion and minimality all hold for every positive horizon, including configurations with zero, one or two boundary positions.

The numerical values of the quartic and pentagon examples are checked by the exact-arithmetic script in the article source. The two theorems are proved for all data satisfying their respective hypotheses.
