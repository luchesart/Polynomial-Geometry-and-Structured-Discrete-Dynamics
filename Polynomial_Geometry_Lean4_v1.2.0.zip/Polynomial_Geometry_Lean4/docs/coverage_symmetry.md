# Proposition D.3: nonlinear symmetry and exact block elimination

The reduced function Ψ in Theorem 2.4 is `reducedLogObjective`. Its inputs
are the imaginary ratio coordinates and the angles of the boundary copies.
A permutation of critical labels permutes the ratios. A permutation of
boundary labels is allowed within each group at the same base root.
Reconstructing the polynomial from permuted labels gives the same marked
root and the same simple critical point. The forward ratio chart therefore
commutes with relabelling. Local uniqueness of its inverse carries this
identity to the balanced slice used to define Ψ. Averaging over the critical
copies preserves the value of the objective on that slice.

`ReducedObjectiveSymmetry` proves the resulting equality of functions near
the grouped point, the hypothesis required to differentiate the symmetry.
`PolynomialSplittingElimination` applies it to the centered coordinates of
Proposition D.3. The derivative identities and the strict gain then follow
from `SymmetricElimination` and `IndependentCenteredBlocks`.

| Article assertion | Lean endpoint |
|---|---|
| Construction of the chart and splitting conclusion from the original polynomial | `PolynomialSplittingFromSource.original_polynomial_splitting` |
| The forward ratio chart commutes with relabelling; the weighted logarithmic objective is unchanged | `ReducedObjectiveSymmetry.forward_relabel`, `weightedLog_relabel` |
| Local uniqueness makes the inverse ratio chart commute with relabelling | `ReducedObjectiveSymmetry.inverse_relabel` |
| Relabelling the copies preserves the reduced polynomial objective Ψ as a function near the base point | `ReducedObjectiveSymmetry.reducedLogObjective_permutation` |
| Every original angle vector is recovered from means, centered deviations and free angles | `PolynomialSplittingElimination.angles_surjective` |
| Independent group permutations preserve Ψ in grouped and centered coordinates | `PolynomialSplittingElimination.objective_action` |
| Centered first derivatives, mixed Hessian entries and scalar diagonal blocks of Ψ | `PolynomialSplittingElimination.polynomial_centered_derivatives` |
| Uniform gain for the actual Ψ on zeroing a finite selected set of negative blocks | `PolynomialSplittingElimination.polynomial_splitting_elimination`, `elimination_of_negative_curvatures` |
| Local function invariance passes to its actual first and second derivatives | `SymmetricElimination.differential_invariant`, `hessian_invariant` |
| All derivative equations in independent centered blocks | `IndependentBlockConsequences.independent_centered_derivatives` |
| Centered gradient vanishes | `centered_gradient_zero`, `symmetry_forces_stationarity` |
| Mixed Hessian with every fixed or independently permuted block vanishes | `centered_mixed_hessian_zero`, `centered_mixed_hessian_zero_flip`, `IndependentCenteredBlocks.independent_mixed_hessian_zero` |
| A permutation-invariant Hessian has common diagonal/off-diagonal entries | `invariant_bilinear_exchangeable` |
| Its centered restriction is scalar | `centered_hessian_scalar`, `centered_block_hessian_scalar` |
| Negative scalar curvature determines the negative partial-gradient derivative | `partial_hessian_of_scalar_quadratic` |
| Exact nonlinear elimination from local symmetry and a strictly negative scalar | `nonlinear_centered_block_elimination` |
| Independent selected groups have an actual Euclidean direct sum and zero permutation average | `IndependentCenteredBlocks.action_sum_zero` |
| Their actual Hessian is the sum of diagonal block Hessians | `IndependentCenteredBlocks.independent_hessian_diagonal_sum` |
| Negative scalar curvatures jointly imply uniform strict quadratic gain on removing the selected blocks | `IndependentCenteredBlocks.negative_block_scalars_exact_elimination` |

The final one-block endpoint begins with a full objective on `E × (ι → ℝ)`
and only its analyticity and local permutation invariance. It constructs the
scalar of its true centered Hessian and proves that a negative scalar yields

```
F (q,s) ≤ F (q,0) - c * ‖s‖^2
```

for some `c > 0` and all sufficiently small pairs. The centered block is an
explicit submodule of `EuclideanSpace ℝ ι`, with the inherited Euclidean norm.
The passage from the full-coordinate Hessian to this subspace is a checked
second-order composition rule.

For a finite selected collection, the block spaces may have different copy
counts. Every permutation group acts independently. The final theorem assumes
the stated negative scalar value of each *actual diagonal block* of the same
objective. It derives all mixed-block cancellations from function symmetry,
then proves negativity of the whole selected Hessian. The operator used by the
uniform partial-maximum theorem is constructed as the negative derivative of
the actual partial gradient. No operator identity or desired inequality is
assumed in this final endpoint.

The space `E` contains all unselected variables. In particular those variables
may contain nonzero centered modes of other groups. Exact stationarity along
the grouped locus is proved uniformly while `E` varies. Consequently the
elimination statement does not discard an unselected block, and the gain is
strict whenever the selected vector is nonzero.

The proof uses `UniformPartialMaximum.uniform_local_quadratic_domination` for
the analytic estimate and `SchurHessian.partialGradient_hessian_pairing` for
the actual derivative pairing. Existing scalar quadratic algebra is reused
from `Variations.lean` rather than duplicated.
