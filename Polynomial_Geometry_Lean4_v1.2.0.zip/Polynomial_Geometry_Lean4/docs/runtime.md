# Reproducible Lean environment

The project pins **Lean 4.24.0** and **mathlib commit
`f897ebcf72cd16f89ab4577d0c826cd14afaafc7`** (the `v4.24.0` tag).
`lake-manifest.json` pins the transitive dependencies.

With a normal Lean/elan installation, run from the project directory:

```sh
lake exe cache get
lake build
```

The toolchain file selects the compiler automatically. The source package
does not need to include the compiler archive or dependency caches.

For the current development workspace, `scripts/lake.sh` uses the downloaded
official compiler when present and otherwise falls back to the installed
`lake` on `PATH`. For example:

```sh
scripts/lake.sh env lean PolynomialGeometry/Source.lean
scripts/lake.sh build
```

The local compiler was downloaded from the official Lean release:
`https://github.com/leanprover/lean4/releases/download/v4.24.0/lean-4.24.0-linux.tar.zst`.
Its archive SHA-256 is
`b14f5e5159219dd1a1956c3b806813319f5e94ccd5bdfd56f54520609a5bb5ec`.
The executable reports Lean commit
`797c613eb9b6d4ec95db23e3e00af9ac6657f24b`.

Compiler availability and dependency resolution are separate from verification
of the article. The theorem audit records which project modules and statements
have actually been compiled.
