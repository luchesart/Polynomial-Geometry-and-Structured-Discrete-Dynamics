# Exact feasible reduction (Theorem 2.4)

This note records the components in `FeasibleReduction`, `RootMargins`,
`RealBoundaryChart`, `RealBoundaryCoverage`, `WeightedStationarity`, and
`PolynomialFeasibleChart`. The final coefficient-space composition is in
`FullFeasibleReduction`; its declaration must be read for the assembled scope.

## Actual polynomial geometry

`RootMargins.monic_root_norm_bound` derives a uniform root bound from the
coefficient sup norm using the monic Cauchy bound. Compact nonvanishing then
proves `roots_stay_in_open_set` and the stronger `root_property_persists`.
These apply to every root, including repeated roots, without continuous root
labels. `interior_roots_persist` gives the strict source margin.

`quotientCoefficients` is the exact coefficient vector of division by
`X - C v`. Its coefficient formula proves continuity in the original
coefficients and the marked root. `marked_root_factorization` proves the
product identity. `quotient_nonzero_at_simple_root` follows by differentiating
that same polynomial. Consequently `inactive_gap_after_marked_root` derives
persistence of the strict inactive gap directly from the original residual
polynomial, its simple marked root, and the base gap at every other root.

`PolynomialFeasibleChart.marked_critical_is_residual_root` derives membership
of the continued critical point in the residual factor from the actual
factorization and separation from the prescribed cluster. A residual-root
continuation is not an additional assumption.

`reconstructed_family_geometry` combines these facts for the same family
`p(t) = A(t) M_alpha(t)`. Its simultaneous conclusions are:

- disk feasibility is equivalent to the displayed boundary-copy constraints;
- distance to the complete derivative-root set equals the finite active minimum;
- the normalized logarithmic distance has the exact weighted-logarithm plus
  nonsmooth-penalty formula.

The distance `FeasibleReduction.criticalDistance` is defined using the infimum
of distances to all roots of the derivative. `criticalDistance_eq_active`
proves the active reduction by an `IsLeast` argument. `criticalDistance_nonneg`
and `criticalDistance_log_positive_iff` justify the strict improvement test.

## Analytic dominance

`local_uniform_radial_improvement` derives a common positive radial response
bound from all coordinate derivatives. Strict differentiability controls the
remainder uniformly while the other parameters move. This proves a strict gain
when nonpositive radial coordinates are replaced by zero. It does not assume
monotonicity or the desired gain as a hypothesis.

`local_exact_reduction` combines that gain with the checked balancing penalty.
`arbitrarily_near_improvement_iff` proves both directions of the nearby-positive
value equivalence, including the parameter convergence required by
“arbitrarily near”.

`RealBoundaryChart.chart` is the actual map
`(x,rho,y,theta) -> (x+i*y, beta*exp(rho+i*theta))`.
Its analyticity and the analyticity of the real objective follow by composition.
`RealBoundaryCoverage.chart_map_nhds` proves local surjectivity on full
neighborhoods using the explicit logarithmic inverse from `PolarCoordinates`.

## Stationarity of the same objective

`WeightedStationarity.weightedLog` is built from the marked branches and the
actual normalized logarithms. `weightedLog_eq_ratios` identifies it with
`L_v + (tau/r) sum Z_i`. Its diagonal is the two-gap weighted expression in the
article. Permutation symmetry of the constructed branches and the original
scalar free-stationarity condition imply zero derivative in every free copy
direction (`free_stationarity_full_differential`).

`parameter_inverse_stationarity` transports this zero differential through the
same locally parameter-preserving ratio inverse. `balancing_derivative_zero`
then gives the zero real balancing derivative after the boundary chart.
`weighted_boundary_reduction` therefore requires the original free stationarity
and the actual positive radial derivatives, rather than an independently
assumed coordinatewise stationarity vector.

`inverse_chart_distance_objective` uses the inverse's exact right-inverse
identity to identify the actual active logarithmic distance with the objective
used by the reduction. This is an equality, not a Taylor estimate.

The interfaces deliberately keep the reconstructed polynomial, marked
branches, and ratio inverse as explicit functions so that the final composition
can use one and the same reconstruction throughout.

## Complete assembly from the original polynomial

`OriginalFeasibleReduction.original_polynomial_feasible_reduction` now
constructs the reconstruction from the original monic interior factor,
boundary-copy list, exact critical multiplicity, and marked simple roots.
The theorem accepts every nonempty boundary-list size. The zero residual-degree
case is excluded by a proved contradiction: a monic degree-zero residual factor
cannot have the continued second critical root. Thus positivity of that degree
is derived, rather than added as a hypothesis.

The same constructed reconstruction `R` supplies the marked branches for
`FullRatioChart.full_ratio_chart`. Under the article's diagonal nondegeneracy,
that theorem constructs `G`, both local inverse identities and the complete
neighborhood identities. The original scalar free-stationarity condition is
accepted as the literal equality `deriv ... = 0`. Its `HasDerivAt` form is derived
from the already proved analyticity. The radial condition is evaluated on this
same reconstructed weighted logarithm and inverse.

The transparent definition `CompleteConclusion` gathers all of the following
for this one `R` and this one `G`:

- `CoefficientConclusion`: an actual analytic selected-root branch in full
  coefficient space, and equivalence of arbitrarily nearby disk-polynomial
  improvements of the complete critical distance with positive values of Ψ;
- real analyticity of the same Ψ;
- `BalancedSliceConclusion`: actual feasible reduced polynomials, boundary
  copies on the circle, strictly interior remaining source roots, equal active
  distances, and the exact reduced logarithmic gain;
- `RealChartConclusion`: coverage of every coefficient neighborhood, the exact
  all-critical-point logarithmic objective on a full real-coordinate
  neighborhood, the selected-root equation, and the exact disk constraints;
- `StrictReductionConclusion`: uniform quantitative gains for both replacements
  and their combined estimate, stated for the actual polynomial critical
  distance. Their positive constants make each gain strict whenever its
  replaced coordinates are nonzero.

No desired nearby-improvement equivalence, favorable deformation, root
labelling continuity, or polynomial chart is assumed in this final theorem.
The necessary model hypotheses and the three response conditions remain
explicit, exactly as conditional sufficient hypotheses in Theorem 2.4.
See [the full transport note](coverage_full_feasible_reduction.md) for the
coefficient-space composition and selected-root descent.
