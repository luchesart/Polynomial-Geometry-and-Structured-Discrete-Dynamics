# Reading the formal development

Start with the composed endpoints. Supporting lemmas explain how each
construction is derived; they are not separate assumptions about its outcome.

| Article | Main endpoint modules | Detailed correspondence |
|---|---|---|
| 2.1: normalized inverse realization | `InverseEquivalence` | [Inverse equivalence](coverage_inverse_completion.md) |
| 2.2: perturbed inverse metric | `NoisyMassCertificate`, `NoisyContourRecovery` | [Contour and integer recovery](coverage_horizon_and_mass.md) |
| 2.3: exact observation horizon | `FiniteSourceHorizon`, `FiniteSourceObservation` | [The finite source record](coverage_horizon_and_mass.md) |
| 2.4: exact feasible reduction | `FullFeasibleReduction`, `OriginalFeasibleReduction` | [Feasible reduction](coverage_feasible_reduction.md) |
| A.1: derivative compression and inherited copies | `CompressionDet`, `CopyEquivalence` | [Compression](coverage_compression.md) |
| B.1: complete spectral coordinates | `ConfluentCompletion`, `SteinSeries` | [Source construction](coverage_source.md) |
| B.2: exact recovery | `RecoveryCompletion` | [Selected-source recovery](coverage_selected_recovery.md) |
| C.1: metric, defects and rank | `Geometry`, `SourceRank`, `SourceDynamics` | [Energy geometry](coverage_energy.md) |
| C.2: energy recovery and observability | `SourceDynamics`, `SharpContraction` | [Optimal contraction](coverage_sharp_contraction.md) |
| D.1: reconstruction and local coverage | `FullReconstruction`, `InteriorUniqueness` | [Original-hypothesis reconstruction](coverage_reconstruction_complete.md) |
| D.2: ratio coordinates | `RatioCoordinates`, `FullRatioChart` | [Local optimization overview](coverage_variations.md) |
| D.3: symmetry elimination | `PolynomialSplittingFromSource`, `ReducedObjectiveSymmetry`, `PolynomialSplittingElimination` | [Symmetry](coverage_symmetry.md) |
| D.4: partial maximum and compensated fourth order | `SchurHessian`, `KernelCompensation` | [Partial maximum](coverage_partial_maximum.md) |
| E.1: coordinate bridge | `Geometry` | [Coordinate geometry](coverage_geometry.md) |

For the displayed reciprocal spectral identities, read `ReciprocalSpectrum`
and `ReciprocalMultiplicity`. `StabilityEquivalence` proves the actual
all-state decay criterion and its consequence for the distance threshold.
The full equal-copy matrix includes the critical modes inherited from repeated
source roots. See [reciprocal multiplicities](coverage_reciprocal.md) and
[asymptotic stability](coverage_stability_equivalence.md).

The local constructions use three distinct spaces: polynomial coefficients,
labelled complex roots and real ratio/boundary coordinates. `RootLabelCoverage`
and `ChartTransport` prove the neighborhood coverage between them. Individual
root labels need not be analytic through a collision. The final theorem is
about every nearby polynomial in coefficient space, rather than only a
chosen differentiable family.

Generic lemmas may expose an interface such as state decay, a reconstructed
family or a positive Hessian block. The source-level endpoints derive those
inputs. For example, `SourceDynamics` derives decay from the source geometry;
`FullReconstruction` constructs the whole local family; `KernelMaximum`
constructs the positive complementary block from the original Hessian.

A complex function space has a default sup norm in Lean. Euclidean energy
statements therefore use explicit squared-modulus sums, Euclidean spaces or
constructed Hermitian forms. No proof silently identifies the sup norm with
the Euclidean energy.

The exact declarations in `claims.json` can be opened in `proof_map.html`.
Read their hypotheses before reusing a result. Filter notation `Frequently`
at a neighborhood means that every neighborhood contains a qualifying point.
It is the formal meaning of “arbitrarily close”, not a condition at the
base point alone.
