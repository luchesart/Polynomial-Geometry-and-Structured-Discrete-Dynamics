# Inverse realization: formal coverage

Theorem 2.1 and Corollary B.2 are fully covered by the completed inverse
and recovery modules. The detailed correspondence and the minimal-input
necessity argument are in [Complete inverse realization and recovery](coverage_inverse_completion.md).

## Final endpoints

| Article assertion | Lean declaration |
|---|---|
| Existence iff the normalized completion is weighted normal and contractive | `InverseEquivalence.normalized_inverse_realization_iff` |
| The article's canonical Jordan data, with observability discharged | `InverseEquivalence.canonical_normalized_inverse_realization_iff` |
| Uniqueness from the minimal realization definition, including every source row | `InverseEquivalence.completeRealization_unique` |
| Existence and uniqueness in one theorem | `InverseEquivalence.normalized_inverse_exists_unique` |
| Actual source spectrum, with all multiplicities | `InverseEquivalence.completeRealization_support_charpoly` |
| The matrix test constructs a realization and its principal recovery identities | `RecoveryCompletion.normalized_completion_and_recovery` |

`InverseEquivalence.CompleteRealization` contains exactly the positive source
model, represented using positive square-root weights `ω` and masses `ω²`.
Its fields specify distinct disk positions, the total mass, a selected source
of mass one, the canonical resolvent rows, their Gram matrix, and the full
source-function numerator. Orthogonality, source equations, a basis,
similarity and the completion test are proved consequences.

The theorem for a general observable pair allows a complex selected position
and arbitrary positive total mass. The canonical wrapper proves observability
from the distinct block positions and includes the more restrictive article
hypotheses as a specialization. All output source sets have exactly one more
element than the state dimension.

## Supporting modules

The development uses one proof of each mechanism, with the final modules
composing those results:

| Module | Responsibility |
|---|---|
| `BlockMetric` | Concrete scalar/state metric and completed matrix |
| `NormalSpectrum` | The finite-dimensional normal spectral theorem |
| `Inverse` | Forced border, weighted adjoint, constructive spectral sources and canonical rows |
| `InverseCofactor` | Actual source-basis cofactor identities |
| `InverseBasisBridge` | Full scalar numerator from the source equations |
| `InverseEquivalence` | Minimal-data necessity, full iff and source-level uniqueness |
| `SelectedRecovery` | Rank-one polynomial construction and kernel evaluation |
| `PolynomialRecovery` | Positive-integer criterion and uniqueness of a monic logarithmic realization |
| `RecoveryCompletion` | All recovery formulas specialized to the same minimal realization |

The older basis-level necessity and spectral-basis uniqueness lemmas remain
reusable supporting results. They are no longer the last stage of the
formalization: `InverseEquivalence` supplies their previously missing
minimal-input composition. The recovered polynomial and selected-index
formulas are covered in [Selected-source recovery](coverage_selected_recovery.md).

The modules compile with Lean 4.24.0 and the pinned mathlib. Endpoint axiom
checks contain only `propext`, `Classical.choice` and `Quot.sound`.
