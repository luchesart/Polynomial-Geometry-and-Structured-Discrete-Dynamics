# Actual state stability and reciprocal distance

`StabilityEquivalence.lean` completes the control interpretation of the
reciprocal-distance criterion. Its definition `AsymptoticallyStable T`
means that `T^k x` tends to zero for every initial state `x`; stability is
not defined by a spectral hypothesis.

| Statement | Checked declaration |
|---|---|
| Every state tends to zero iff every characteristic root has modulus less than one | `StabilityEquivalence.asymptoticallyStable_iff_roots` |
| Every state tends to zero iff the spectral radius is less than one | `StabilityEquivalence.asymptoticallyStable_iff_spectralRadius` |
| Failure of this decay iff the spectral radius is at least one | `StabilityEquivalence.not_asymptoticallyStable_iff` |
| A characteristic root lies within distance `r` of `a` iff `r(aI−A)⁻¹` fails to be asymptotically stable | `StabilityEquivalence.reciprocal_distance_iff_not_stable` |
| The same criterion for the full polynomial derivative, including inherited repeated-root modes | `StabilityEquivalence.full_reciprocal_distance_iff_not_stable` |

The forward decay theorem uses the previously proved strict-spectrum
estimate. For the converse, `Mobius.eigenvector_of_root` supplies a genuine
nonzero eigenvector. A nonzero coordinate of its decaying orbit implies
that the corresponding scalar eigenvalue powers tend to zero. This
forces the eigenvalue modulus to be strictly less than one. Repeated
roots and non-diagonalizable matrices are allowed. The generic stability
equivalence also includes the zero-dimensional state space.

For the reciprocal theorem the matrix `aI−A` must be invertible, and
`r` is any nonnegative real radius. At radius one, the distance condition
is equivalent to failure of asymptotic stability of the unscaled
reciprocal matrix. Equality of the spectral radius to one is included:
this criterion does not assert unbounded trajectories or instability in
the separate Lyapunov-stability sense.

The full polynomial endpoint assumes a positive derivative dimension,
an orthonormal basis of the compression space, and `p′(a)≠0`. It uses the
actual derivative of the product over all labelled roots. No simplicity
or injectivity assumption is imposed on those roots.
