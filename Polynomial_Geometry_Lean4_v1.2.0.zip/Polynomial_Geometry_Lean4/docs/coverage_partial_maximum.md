# Lemma D.4: exact partial maximization and compensated fourth order

The complete lemma is covered by two composed endpoints:

- `SchurHessian.analytic_partial_maximum_with_schur` constructs one analytic
  stationary response with local uniqueness, its exact first derivative,
  uniform quadratic maximality, preservation of arbitrarily nearby positive
  values and the Schur formula for the actual reduced Hessian.
- `KernelCompensation.canonical_compensated_partial_maximum` constructs the
  actual Hessian-kernel decomposition from the original negative-semidefinite
  Hessian and proves the response and objective expansions. Both use actual
  derivatives of the original objective, with uniform cubic and fifth-order
  remainders and the exact compensated coefficient `1/8`.

`KernelCompensation.canonical_kernel_necessary` proves cubic vanishing and
nonpositivity of the compensated quartic in every kernel direction at a local
maximum. Zero-dimensional kernels and eliminated spaces are included.

| Part | Supporting modules | Detailed proof correspondence |
|---|---|---|
| Analytic stationary response and its derivative | `PartialMaximum` | [Uniform maximum](coverage_uniform_maximum.md) |
| Uniform quadratic domination and nearby-positive equivalence | `UniformPartialMaximum` | [Uniform maximum](coverage_uniform_maximum.md) |
| Actual Schur Hessian and flat response | `SchurHessian` | [Uniform maximum](coverage_uniform_maximum.md) |
| Canonical kernel, complement and positive operator | `KernelMaximum` | [Kernel construction](coverage_uniform_maximum.md) |
| Actual Taylor coefficients, symmetry and uniform remainders | `AnalyticCompensation` | [Analytic compensation](coverage_analytic_compensation.md) |
| Original-space assembly and necessary conditions | `KernelCompensation` | [Analytic compensation](coverage_analytic_compensation.md) |

The partial gradient is the Riesz representation of the actual Fréchet
derivative restricted to the eliminated variables. The proof derives its
relation to the Hessian. The positive complementary operator is constructed
from the original Hessian, rather than supplied as an extra conclusion.

The exact quadratic and quartic identities in `Variations` also verify the
article's pedagogical quartic model. They are separate from the analytic
Taylor-remainder theorems above.
