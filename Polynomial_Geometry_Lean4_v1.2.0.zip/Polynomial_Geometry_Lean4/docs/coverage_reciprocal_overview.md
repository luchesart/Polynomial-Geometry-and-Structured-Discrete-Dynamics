# Reciprocal determinant, multiplicity and stability

This note connects the actual reciprocal matrix to the polynomial and to
state trajectories. All declaration names have the prefix
`PolynomialGeometry.`. No spectral list or stability conclusion is
assumed in the statements below.

## The general matrix mechanism

Let `A` be a finite complex matrix and suppose `aI−A` is invertible.
Write `R=(aI−A)⁻¹`.

| Mathematical assertion | Checked declaration |
|---|---|
| `det(I+tR)=charpoly(A)(a+t)/charpoly(A)(a)` for every complex `t` | `ReciprocalSpectrum.resolvent_determinant` |
| The characteristic polynomial of `R` is the product of the reciprocal-root factors | `ReciprocalMultiplicity.resolvent_charpoly` |
| The root multiset of `R` is the image of the root multiset of `A` under `w↦(a−w)⁻¹` | `ReciprocalMultiplicity.resolvent_roots` |
| Each reciprocal root has exactly its original algebraic multiplicity | `ReciprocalMultiplicity.resolvent_rootMultiplicity` |
| Some root of `A` is within distance `r` of `a` iff `1≤rρ(R)` | `ReciprocalSpectrum.root_distance_iff_reciprocal_radius` |
| Every trajectory `T^k x` tends to zero iff `ρ(T)<1` | `StabilityEquivalence.asymptoticallyStable_iff_spectralRadius` |
| Some root is within distance `r` iff `rR` fails to have all-state decay | `StabilityEquivalence.reciprocal_distance_iff_not_stable` |

The radius is any nonnegative real number. Equality at the threshold is
included. The last statement requires a nonempty matrix index type;
the all-state stability equivalence itself also covers zero-dimensional
state spaces. None of these results assumes diagonalizability.

## Source coordinates and the full derivative

`ReciprocalMultiplicity.source_reciprocal_determinant` and
`source_reciprocal_roots` specialize the generic identities to
`Geometry.reciprocal u (Geometry.sourceResolvent a α)`. They use the actual
source-compression inverse identity and require separation of the
selected real point `a` from the remaining sources. The
`source_bridge_determinant` and `source_bridge_roots` endpoints use the
proved coordinate bridge to express the same conclusions through the
prescribed matrix `J`. Their source equation, zero-output condition and
positive Gram hypotheses are exactly the inputs of that bridge.

For a polynomial whose roots are listed individually, with repetitions,
`ReciprocalSpectrum.equal_copy_derivative` proves
`p′=(degree p)·charpoly(A)` for the full equal-copy compression. Therefore:

| Full-polynomial assertion | Checked declaration |
|---|---|
| Every critical multiplicity, inherited or genuine, survives in the full reciprocal matrix | `ReciprocalMultiplicity.full_reciprocal_critical_multiplicity` |
| A critical point is within distance `r` iff `1≤rρ(R_a)` | `ReciprocalSpectrum.full_reciprocal_distance_threshold` |
| The literal minimum critical distance satisfies `D(p,a)≤r` iff `1≤rρ(R_a)` | `ReciprocalSpectrum.nearest_critical_distance_threshold` |
| A critical point is within distance `r` iff the rescaled full reciprocal matrix fails to be asymptotically stable | `StabilityEquivalence.full_reciprocal_distance_iff_not_stable` |

These statements assume `p′(a)≠0` so that the reciprocal matrix exists.
The literal minimum additionally uses the nonempty finite set of
critical roots. The trajectory endpoint assumes positive derivative
dimension. The supplied matrix `Q` has orthonormal columns perpendicular
to the normalized equal-copy source vector. Root labels need not be
injective.

Failure of asymptotic stability includes neutral eigenvalues. It does
not assert that all trajectories grow, or that trajectories are
unbounded. See [Actual state stability](coverage_stability_equivalence.md)
for that distinction and the converse proof.

The displayed grouped/inherited minimum in equation (A.10), the separate
resolvent transfer-function identity, and the numerical pentagon example
are not packaged by these modules. The full critical-distance threshold
and its multiplicity and trajectory interpretation are proved without
those additional presentations. This establishes a reformulation of the
distance problem, not Sendov's bound itself.
