# Source geometry and coordinate bridge: checked scope

This note records the checked statements in `PolynomialGeometry/Geometry.lean`, their correspondence with the article, and the hypotheses at the interfaces to other modules. It does not count an assumed matrix identity as a proof of that identity.

The module was compiled with Lean 4.24.0 and the pinned mathlib dependency using:

```sh
scripts/lake.sh env lean -o .lake/build/lib/lean/PolynomialGeometry/Geometry.olean PolynomialGeometry/Geometry.lean
```

The checked source contains no `sorry`, `admit`, additional axiom, or unsafe declaration. The project audit records the exact declaration inventory; coverage is determined by the statements below.

## Conventions and source data

The nonselected source index type `ι` is any finite type. Matrices have complex entries, and `ᴴ` means conjugate transpose. The selected source has mass one. The definitions are

\[
U=uu^*,\qquad n=1+\sum_j |u_j|^2,\qquad
E=(I+U)^{-1},\qquad R=(I+U)X.
\]

The article chooses \(u_j=\sqrt{\nu_j}>0\). The Lean statements allow complex \(u_j\); when nonvanishing is required, their corresponding masses are \(|u_j|^2>0\). This is a genuine generalization of the same algebra, not a relaxation of positivity. The positive real specialization follows by substituting \(u_j=\sqrt{\nu_j}\), whose squared modulus is \(\nu_j\).

The concrete resolvent is

\[
X=\operatorname{diag}((a-\alpha_j)^{-1}),\qquad c=1-a^2,
\qquad S=aI+cR,\qquad T=S^{-1}.
\]

`sourceResolvent` takes real `a`. Statements for the physical source class use \(0\le a<1\), \(a\ne\alpha_j\), \(|\alpha_j|^2\le1\), and, where required, distinct \(\alpha_j\) and nonzero \(u_j\). Matrix inversion in Lean is total; every use requiring a genuine inverse is supported by an `IsUnit` or positive-definiteness theorem.

## Article Proposition E.1: coordinate bridge

All the displayed algebraic and basis assertions of Proposition E.1 have been proved. They are exposed as reusable lemmas and one assembled existence-and-uniqueness theorem. They are not encoded as fields of a structure assumed to satisfy the proposition.

| Article assertion | Checked declaration(s) | Exact scope |
|---|---|---|
| \(B_0=[-u^*;I]\) and \(W=B_0E\) | `sourceLift`, `energyBasis` | These are explicit matrices indexed by `Unit ⊕ ι` and `ι`. |
| The columns of \(W\) form a basis of \(b^\perp\), \(b=(1,u)^T\) | `sourceLift_injective`, `sourceLift_range`, `energyBasis_injective`, `energyBasis_coordinates` | Injectivity and exact range are proved. The result is expressed through matrix maps and coordinates rather than a Lean `Basis` object. |
| \(B_0^*B_0=I+uu^*\) | `sourceLift_gram` | Unconditional in the source weights. |
| \(W^*W=E\) | `energyBasis_gram` | The exact Gram equality. |
| \(W^*AW=E(auu^*+D_s)E\) | `sourceLift_operator_gram`, `energyBasis_compression` | `sourceOperator a D` is the actual ambient block matrix \(\operatorname{diag}(a,D)\). The lemma even allows a general lower block `D`. |
| \(A_W=(auu^*+D_s)E\) | `compressed`, `energyBasis_compression` | The nonorthonormal compression formula follows using the proved invertibility of \(E\). |
| \(aI-A_W=R^{-1}\) | `source_compression_reciprocal` | The concrete diagonal source resolvent is used; separation from \(a\) is explicit. |
| \(Y=WP\), with unique invertible \(P\) | `energyBasis_coordinates`, `sourceCoordinates_unique`, `sourceCoordinates_isUnit`, `coordinate_bridge` | Hypotheses: the columns of \(Y\) are in \(b^\perp\), and \(Y^*Y\) is positive definite. Both column families have the same state dimension. |
| \(P=E^{-1}W^*Y\) | `sourceCoordinates_gram_formula` | Derived from the explicit coordinate construction. |
| \(H=P^*EP\), with \(H=Y^*Y\) | `coordinate_metric`, `sourceCoordinates_metric`, `coordinate_bridge` | Exact matrix congruence. |
| \(A_WP=PJ\) | `sourceCoordinates_intertwine`, `coordinate_bridge` | Derived from the actual source equation \(AY=YJ-b\ell\); no intertwining conclusion is assumed. The residual row `ℓ` is arbitrary. |
| \((aI-J)^{-1}=P^{-1}RP\) | `resolvent_similarity`, `coordinate_bridge` | Derived from invertible \(P\), the source equation, and the concrete reciprocal formula. |
| \(T=(aI-A_W)(I-aA_W)^{-1}\) | `source_mobius_transform` | Exact rational matrix identity. |
| \((I-aA_W)T=aI-A_W\) | `source_mobius_relation` | Invertibility needed for cross multiplication is proved from the source disk hypotheses. This is the interface used for actual spectral stability. |

`coordinate_bridge` has an `∃! P` conclusion containing \(Y=WP\), `IsUnit P`, metric congruence, intertwining, and resolvent similarity. The other formula for \(P\), the basis property of \(W\), and the Möbius identity are companion theorems rather than additional fields in that conjunction.

### Interface with the confluent construction

The bridge is a theorem about a supplied source family \(Y\); it does not construct Jordan chains by itself. This is the correct division of responsibilities, but it must not be reported as a derivation of \(Y\) from arbitrary matrices \(J,H\).

`Confluent.lean` proves the relevant properties of the actual confluent Cauchy family:

- `cauchy_source_matrix_identity`: the source equation;
- `cauchy_orthogonal_of_numerator_dvd`: zero output, from the prescribed numerator-root divisibilities;
- `cauchy_injective_of_numerator_dvd`: injectivity of that family;
- `cauchy_gram_posDef`: positive definiteness of its actual Gram matrix;
- `cauchy_stein_identity`: its source Stein identity.

`Confluent.complete_positive_source_realization` assembles these properties with the exact projection, strict spectrum and unique Stein-series solution. See [Complete source coordinates](coverage_source.md). The coordinate bridge uses that proved source-family interface. Its index type `Unit ⊕ ι` separates the selected coordinate from the other sources; changing finite labels does not change the matrix assertions.

## Article Theorem B.1: projection identity

The normalized selected-source projection is proved in two forms:

\[
W E^{-1}W^*=I-\frac{bb^*}{n},\qquad
Y(Y^*Y)^{-1}Y^*=I-\frac{bb^*}{n}.
\]

- `energyBasis_projection` proves the first identity directly from the explicit source basis.
- `sourceFamily_projection` proves the second from zero-output columns and positive definiteness of \(Y^*Y\), using the already derived invertible coordinate change.

The second identity is **not an input** to its own proof, to `coordinate_bridge`, or to the source metric results. This covers the projection formula in `eq:confluent-source-identities` for the selected-source normalization \(b=(1,u)^T\). A general source vector and independently indexed source/chain spaces are handled by the separate confluent source work; this file should not be cited as the general unnormalized version without that interface.

## Article Theorem C.1: exact source energy

| Article statement | Geometry proof | Additional assembled proof |
|---|---|---|
| \(E=(I+uu^*)^{-1}=I-uu^*/n\succ0\) | `metric_posDef`, `metric_closed_form` | None needed. |
| \(\|x\|_2^2/n\le x^*Ex\le\|x\|_2^2\) | `metric_quadratic_bounds` | The statement uses \(\sum_j|x_j|^2\) explicitly. Cauchy–Schwarz is proved through the standard finite Euclidean inner product. |
| Diagonal reciprocal disk identity | `reciprocal_disk_scalar`, `diskDefect_diagonal` | None needed. |
| \(K_a\succeq0\) from the source disk | `source_diskDefect_posSemidef` | None needed. |
| \(D_S=cK_a+(c/n)uu^*+c^2X^*uu^*X\) | `expansive_defect` | An algebraic identity valid for arbitrary `X`; the source diagonal is then substituted. |
| \(D_S\succeq0\) and invertible \(S\) | `expansive_defect_posSemidef`, `source_expansive_isUnit` | Invertibility is deduced from a positive metric and the expansive estimate. |
| \(E-T^*ET=T^*D_ST\succeq0\) | `inverse_defect`, `inverse_defect_posSemidef`, `source_contractivity` | None needed. |
| \(\operatorname{rank}D_T=\operatorname{rank}D_S\) | `inverse_defect_rank` | Congruence by the proved inverse. |
| Exact rank \(i+\min(2,b)\) | Three source loss-row Gram formulas and nondegeneracy lemmas | `SourceRank.expansive_source_defect_rank`, `SourceRank.contractive_source_defect_rank`. These use actual distinct source positions and nonzero weights. |
| Strict stability of the actual source transform | `compressed_eigenpair_source`, `source_mobius_relation` | `SourceStability` and `SourceDynamics.transition_roots_strict`, `transition_spectralRadius_lt_one`, `states_tendsto_zero`. No decay assumption is imposed at the source endpoint. |
| Exact one-step energy balance | The contractive defect identity | The generic energy identities in `Dynamics`, specialized in `SourceDynamics`. |

`compressed_eigenpair_source` starts with an actual nonzero eigenvector of \(A_W\), constructs \(y=Wx\), proves \(y\ne0\) and \(b^*y=0\), and derives the ambient source equation. This supplies the source-specific content needed for strict disk localization; positivity of a one-step semidefinite defect alone is never used to claim strict stability.

The rank module uses a rectangular factor made from interior coordinate rows and two dense source rows. The three exact Gram identities in `Geometry` identify its Gram matrix with \(D_S\), while positivity, nonzero row coefficients, and injectivity of the boundary reciprocal values are derived from the source hypotheses. The exact count is not an assumption.

The finite and infinite output-energy consequences are assembled in `SourceDynamics`. The minimal-channel statement belongs to `SourceRank.source_minimum_loss_channels` and the generic factorization work; it is not claimed merely because a factor with two extra rows has been constructed.

### Conventions and further checked consequences

- The norm bounds use the real part of the Hermitian quadratic value. Hermiticity and the exact real formula are proved, so this is the real energy appearing in the article.
- The exact sharp block factor, its optimality, an attaining state and the all-time estimate are proved in `SharpContraction.source_sharp_block_contraction`. See [Sharp finite-block contraction](coverage_sharp_contraction.md).
- `SourceRank.contractive_source_defect_posDef_iff` proves that the defect is positive definite exactly when the boundary count is at most two.
- Geometric examples, numerical plots, and empirical model interpretation are outside these algebraic proofs.

## Independent statement audit: `BlockMetric.lean`

The file's definitions and theorem statements match the normalized completion block formulas.

| Declaration | Audited mathematical content |
|---|---|
| `coordinates` | An actual complex-linear equivalence from an `Option ι`-indexed vector to its scalar first coordinate and state coordinates. |
| `metric` | Exactly \(\operatorname{diag}(n,H)\), with zero off-diagonal blocks. |
| `metric_mulVec`, `metric_inner` | Exact block action and quadratic/sesquilinear form; scalar \(n\) is cast from real to complex. |
| `metric_hermitian` | Hermiticity follows from Hermiticity of \(H\). |
| `metric_posDef` | Positive definiteness is proved from \(n>0\) and \(H\succ0\). It is not imposed again on the completed matrix. The empty state-index case is also valid. |
| `completion` | Exactly \(\begin{pmatrix}\gamma&-e^*\\d&J\end{pmatrix}\). The conjugation and minus sign of the observed top row are correct. |
| `completion_action` | Exact scalar/state action \((\gamma z-e^*x,\;zd+Jx)\). Complex scalar commutativity justifies the chosen scalar-action notation. |
| `firstVector_energy`, `stateVectors_gram`, `first_state_orthogonal` | The coordinate Gram values are \(n\), \(H_{ij}\), and zero, respectively. |

No incorrect statement or missing hypothesis was found in this audit. `BlockMetric.lean` establishes the concrete matrix interface. It does **not** alone prove the completion's normality, contraction, prescribed selected eigenpair, or recovery theorem, and its documentation does not claim that it does. Those assertions are completed in `InverseEquivalence` and `RecoveryCompletion`; see [Complete inverse realization and recovery](coverage_inverse_completion.md).
