# Admissible spectral optimization: correspondence overview

The Appendix D development follows one chain of constructions. The original
polynomial data produce one reconstruction and its two marked branches.
The ratio inverse and the real boundary chart are composed with that same
family. The objective is the distance to the complete derivative-root set.

## D.1: reconstruction from the original data

`ReconstructionCompletion.full_reconstruction_from_original_hypotheses`
constructs `LocalReconstructionResult`. This is an output of the theorem.
It includes analytic factors, marked roots, the exact critical cluster with
multiplicities, permutation invariance, interior margins and local coverage
of every nearby monic polynomial. The reciprocal-Taylor diagonal formula
uses actual derivatives and factorials. Uniqueness assumes only that the
interior factor is close and has the prescribed critical divisibility.

The algebraic and analytic steps are in `CriticalReconstruction`,
`ReconstructionCompletion`, `ReciprocalTaylorAnalytic`, `ReconstructionCharts`,
`ReconstructionCoverage`, `InteriorUniqueness` and `FullReconstruction`.
See [the detailed reconstruction correspondence](coverage_reconstruction_complete.md).

## D.2: genuine coordinates for the same branches

`RatioCoordinates.logRatios_fderiv` proves the centered and collective
multipliers of the actual logarithmic ratio derivative.
`FullRatioChart.full_ratio_chart` uses nonzero diagonal response to construct
one analytic inverse for the complete reconstruction. It proves both inverse
identities, preservation of the source parameters and both neighborhood
transport identities. It does not replace the marked roots by independent
functions during the composition.

## 2.4: full admissibility and exact reduction

`RootMargins` proves continuity of root constraints through coefficients,
including repeated roots. `PolynomialFeasibleChart` identifies disk
feasibility and the full nearest-critical distance. `WeightedStationarity`
derives the free differential condition from the original scalar condition.
`FeasibleReduction` proves strict balancing and radial gains.

`FullFeasibleReduction` transports the result to polynomial coefficient space;
`OriginalFeasibleReduction` constructs the interfaces from the original
hypotheses. `PolarCoordinates`, `RealBoundaryCoverage`, `RootLabelCoverage`
and `ChartTransport` supply genuine local coverage. The resulting equivalence
concerns every arbitrarily close admissible monic polynomial, with its
continued marked source. See [the feasible-reduction correspondence](coverage_feasible_reduction.md).

## D.3: nonlinear symmetry elimination

`ReducedObjectiveSymmetry` derives local permutation symmetry of the reduced
polynomial objective from reconstruction and uniqueness of the ratio inverse.
`PolynomialSplittingElimination` specializes the derivative and elimination
results to that objective. `SymmetricElimination` derives zero centered
gradients, scalar centered Hessians and mixed-block cancellation from the local
symmetry. `IndependentCenteredBlocks` handles any finite selected collection
of independent blocks and proves their joint strict quadratic elimination.
The scalar curvature and the nonlinear improvement are derived, rather than
assumed matrix identities. See [the symmetry correspondence](coverage_symmetry.md).

## D.4: actual partial maximum and fourth order

`SchurHessian` constructs one analytic response with local uniqueness,
uniform quadratic maximality and the actual reduced Hessian.
`KernelMaximum` constructs the kernel and complementary coordinates from the
original Hessian. `KernelCompensation` gives uniform cubic and fifth-order
remainders using actual third and fourth derivatives, followed by the kernel
necessary conditions. See [the partial-maximum overview](coverage_partial_maximum.md).

`Variations` supplies reusable finite-minimum inequalities and quadratic and
quartic algebra. Its elementary identities support the development; the
nonlinear endpoint modules establish the full analytic statements.
