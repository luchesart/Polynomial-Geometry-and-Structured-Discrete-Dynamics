# Compression and inherited-mode coverage

This note maps Appendix A of *Polynomial Geometry and Structured Discrete
Dynamics* to `CompressionDet.lean`, `Copies.lean`, `CopyEquivalence.lean`, and
`ReciprocalSpectrum.lean`, `ReciprocalMultiplicity.lean`, and
`StabilityEquivalence.lean`. The displayed equation
numbers were checked against `article/build/main.aux` in the manuscript
source. Names below have the namespace prefix `PolynomialGeometry.`.

## Theorem A.1 and equation (A.5)

| Manuscript assertion | Lean declaration | Exact formal scope |
|---|---|---|
| The normalized source column has norm one and squared coordinates \(\nu_j/n\). | `CompressionDet.normalizedSource_weight`; `CompressionDet.normalizedSource_normalized` | Uses the actual column \(\sqrt{\nu_j}/\sqrt{\sum_k\nu_k}\), with positive real masses. Normalization is expressed by its Hermitian squared length. |
| \(\det(zI-A_0)=G(z)\). | `CompressionDet.positive_weight_compression_charpoly` | Equality of polynomials, with the right side exactly `Source.numerator`. It holds at source positions as well. The hypotheses supply \(Q^*Q=I\) and orthogonality to the normalized source column. Neither the characteristic-polynomial identity nor a spectral conclusion is assumed. |
| Every root of the grouped compression lies in the open unit disk. | `CompressionDet.positive_weight_compression_root_norm_lt_one` | Adds injectivity of the source positions and their membership in the closed unit disk. It first excludes source positions using `Source.numerator_ne_zero_at_source`, then applies `Compression.source_zero_norm_lt_one`. |
| \(\rho(A_0)<1\). | `CompressionDet.positive_weight_compression_spectralRadius_lt_one` | Proves the actual mathlib `spectralRadius` bound, whose codomain is the extended nonnegative reals. Strictness follows from finite spectrum, not an additional assumed uniform margin. |
| For integer masses, the equal-copy compression splits into \(A_0\) and the inherited scalar blocks \(\alpha_j I_{\nu_j-1}\). | The coordinate and block-action results in `Copies`, detailed below. | The explicit `copyCoordinateEquiv` is a complex linear equivalence preserving the Euclidean Hermitian form and conjugating the full operator to the grouped and inherited actions. Inherited dimensions are proved. No choice of bases within the inherited subspaces is needed. |

The compression is indexed by `Fin (d + 1)` source positions and `Fin d`
compression coordinates. The theorems accept a supplied compression matrix
`Q`. They do not separately construct an orthonormal basis of the source
orthogonal complement. This is the same choice of coordinates made before
Theorem A.1 in the manuscript, rather than an assumed conclusion of the
theorem. The first and strict-spectral conclusions also allow `d = 0`;
the manuscript uses at least two source positions.

The algebraic proof is stronger than its positive-weight specialization.
`CompressionDet.charpoly_compression_diagonal` establishes the cofactor
formula over any commutative ring for an inverse coordinate pair.
`CompressionDet.adjugate_conjugation`,
`CompressionDet.charmatrix_conjugation`, and
`CompressionDet.cofactor_zero_eq_charpoly` supply the mechanism.
`CompressionDet.weighted_compression_charpoly` specializes this to complex
orthonormal coordinates. The determinant identity itself does not require
distinct source positions.

## What the inherited decomposition proves

Integer multiplicities are written as `m j + 1`. Thus the copy index is
\(\{(j,k):0\leq k<m_j+1\}\), and the inherited dimension in group \(j\)
is \(m_j=\nu_j-1\). This parameterization covers every positive integer
multiplicity.

The normalized indicator lift `Copies.groupLift` sends a group coordinate
\(y_j\) to the constant value \(y_j/\sqrt{m_j+1}\) on that group.
`Copies.groupReduce` is its Hermitian adjoint. The residual consists of
vectors whose coordinates sum to zero within every group.

| Structural step | Lean declaration |
|---|---|
| Indicator reduction is a left inverse of the lift. | `Copies.groupReduce_groupLift` |
| The reduction is the adjoint of the lift; the lift preserves the Hermitian product. | `Copies.groupLift_adjoint`; `Copies.groupLift_isometry` |
| Every vector splits into its group component and an orthogonal residual. | `Copies.copy_orthogonal_decomposition`; `Copies.groupResidual_reduce_zero`; `Copies.groupResidual_orthogonal` |
| The grouped square-root source lifts to the normalized constant source of the equal-copy model. | `Copies.normalizedSource_copies` |
| Source output is unchanged by passing to grouped coordinates. | `Copies.copy_output_eq_group_output` |
| Every full zero-output vector has grouped compression coordinates and an inherited residual. | `Copies.copy_zero_output_coordinates` |
| Every such coordinate pair lies in the full zero-output space. | `Copies.copy_coordinates_zero_output` |
| These coordinates are unique. | `Copies.copy_coordinates_unique` |
| The combined coordinate map preserves the Hermitian product, including the inherited component. | `Copies.copy_coordinates_isometry` |
| The grouped zero dynamics in the chosen basis is exactly \(Q^*\operatorname{diag}(\alpha)Q\). | `Copies.groupZeroAction_compression` |
| The full operator acts as grouped compression on the first coordinate and copied diagonal action on the residual. | `Copies.copy_compression_block_action` |
| Residual vectors are exactly the product of the individual group zero-sum spaces. | `Copies.groupReduce_eq_zero_iff` |
| The residual space is invariant, and a vector supported in group \(j\) is acted on by multiplication by \(\alpha_j\). | `Copies.inherited_invariant`; `Copies.single_group_eigenvector` |
| A group of `r + 1` copies has a zero-sum subspace of complex dimension `r`. | `Copies.inherited_dimension` |

`CopyEquivalence.copyCoordinateEquiv` now bundles the forward and inverse
coordinate maps as a genuine complex linear equivalence between the full
zero-output subspace and grouped coordinates plus the inherited subspace.
`copyCoordinateEquiv_unitary` proves preservation of the usual Euclidean
Hermitian forms. `copyCoordinateEquiv_block_action` proves the exact conjugacy
for this same equivalence. This is an intrinsic unitary equivalence. It does
not select arbitrary orthonormal bases inside each inherited scalar block.

## Other equations and nearby assertions in Appendix A

| Manuscript location | Checked result and local scope |
|---|---|
| Equation (A.3): source mass, source sum and normalized numerator | Defined in `Source.mass`, `Source.sourceFunction`, and `Source.numerator`. `CompressionDet.positive_weight_compression_charpoly` connects that exact numerator to the compression. The source polynomial identities belong to `Source.lean`. |
| Equation (A.4): logarithmic derivative and inherited derivative factors | Provided by the source or geometry modules. `Source.inherited_derivative_identity` is the relevant polynomial-factor bridge; the source module owns its detailed coverage. `Copies` independently proves the corresponding inherited vector-space decomposition. |
| Equation (A.6): input/output system and its zero dynamics | `Copies.groupZeroAction` and `Copies.copyZeroAction` define the one-step output-canceling feedback operator. `Copies.groupZeroAction_compression` and `Copies.copy_compression_block_action` prove its compressed action. These files do not separately define arbitrary input sequences or prove the resolvent transfer-function formula. |
| Equation (A.7): selected-source reciprocal matrix and explicit metric | Provided by the source or geometry modules. `Geometry.lean` owns the reciprocal and metric construction. |
| Equation (A.8): \(\det(I+tR_g)=G(a+t)/G(a)\) | `ReciprocalSpectrum.resolvent_determinant` proves the actual resolvent determinant identity for every complex parameter. `ReciprocalMultiplicity.source_reciprocal_determinant` specializes it to the actual source reciprocal matrix, and `source_bridge_determinant` identifies its numerator with the prescribed characteristic polynomial through the source-coordinate bridge. Apparent poles introduce no exceptional parameter values. |
| Equation (A.9): reciprocal spectral mapping, with algebraic multiplicities | `ReciprocalSpectrum.resolvent_spectrum` and `source_reciprocal_spectrum` prove the set identity. `ReciprocalMultiplicity.resolvent_charpoly`, `resolvent_roots`, and `resolvent_rootMultiplicity` prove the exact characteristic polynomial, mapped root multiset, and equality of every root multiplicity. `source_reciprocal_roots` and `source_bridge_roots` specialize this to the actual source matrix. |
| Equation (A.10): nearest-critical-point distance as the minimum of the grouped reciprocal term and inherited distances | The displayed grouped/inherited minimum is not separately assembled here. The inherited decomposition and derivative factorization are checked, and the full-matrix distance threshold in the next row is proved directly without discarding inherited modes. |
| Equation (A.11): \(D(p,a)\le r\iff r\rho(R_a)\ge1\) | `ReciprocalSpectrum.nearest_critical_distance_threshold` proves this for the actual full equal-copy reciprocal matrix, from the polynomial derivative, including inherited modes and equality. The minimum is literally over the derivative roots. The selected point has nonzero derivative and the critical-root set is nonempty. |
| The right side of (A.11) means failure of asymptotic stability of `rR_a` | `StabilityEquivalence.asymptoticallyStable_iff_spectralRadius` proves the equivalence for actual all-state decay. `full_reciprocal_distance_iff_not_stable` composes it with the derivative-root distance threshold, including equality and repeated critical roots. |

The reciprocal results prove the equivalence of the geometric, spectral,
and all-state decay questions. They do not assert Sendov’s bound. Their
exact assumptions and endpoints are collected in the
[Reciprocal determinant, multiplicity and stability overview](coverage_reciprocal_overview.md).

The unnumbered resolvent transfer identity
\(\widehat b^*(zI-A)^{-1}\widehat b=F(z)/n\), its interpretation as
\(p'(z)/(np(z))\), the metric eigenvalue description, and the numerical
pentagon example are not separately formalized by the modules mapped in
this note. The grouped/inherited minimum in (A.10) is also not separately
packaged. These local omissions do not apply to reciprocal multiplicities
or the all-state stability equivalence, which are proved as described
above. The closed-form metric and its positive quadratic bounds are
covered in the separate [energy correspondence](coverage_energy.md).

## Verification

The mapped modules use Lean 4.24.0 and the pinned mathlib revision
`f897ebcf72cd16f89ab4577d0c826cd14afaafc7`. The determinant,
root-multiset, per-root multiplicity, literal nearest-distance, and
all-state stability endpoint names were checked by importing their
compiled modules. Endpoint `#print axioms` audits use only `propext`,
`Classical.choice`, and `Quot.sound`; no `sorryAx` or added mathematical
axioms occur in those audits.
