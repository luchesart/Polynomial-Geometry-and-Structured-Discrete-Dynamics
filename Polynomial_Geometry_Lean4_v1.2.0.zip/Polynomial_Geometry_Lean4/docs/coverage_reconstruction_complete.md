# Complete coverage of Lemma D.1

The endpoint is
`PolynomialGeometry.ReconstructionCompletion.full_reconstruction_from_original_hypotheses`
in `PolynomialGeometry/FullReconstruction.lean`.

It constructs a `LocalReconstructionResult`. This record is an **output** of
the proof. None of its chart, inverse, uniqueness, root-branch, coverage or
Taylor properties is assumed as input.

## Inputs and their relation to the article

The input interior polynomial `A` is monic of degree `r > 0`, with every root
strictly inside the unit disk. The boundary polynomial is the product of
`Fin (s + 1)` linear factors with unit-modulus roots. Repeated values are
allowed, so these are the article's complete labelled boundary copies.
The theorem assumes that the actual derivative of this product has exact
root multiplicity `r` at `w`, and that the product itself is nonzero at `w`.
The selected root of `A` is simple. A distinct actual root `v₀` of the product's
derivative is simple.

These are weaker than the complete configuration in the article: the
construction works for `r > 0`, whereas the article takes `r ≥ 2`. Equal active
distances and the inactive gap do not enter Lemma D.1's reconstruction argument.
The residual degree `s > 0` is **derived** from the distinct simple critical
point. No exact residual-factor identity is required as an input.

## Checked conclusions

| Article assertion | Checked declaration or output field |
|---|---|
| Exact derivative multiplicity determines a monic residual factor of the required degree, nonzero at `w`. | `residual_from_exact_multiplicity` and `reconstruction_data_from_multiplicity` |
| The original interior/boundary geometry supplies coprime source factors and all coefficient-system inputs. | `interior_boundary_coprime` and `original_configuration_supplies_reconstruction_inputs` |
| All prescribed source and critical copies enter a holomorphic monic degree-`r` reconstruction. | `LocalReconstructionResult.family_analytic`, `family_base`, `identities`; monicity and degree follow from `monicPolynomial_monic` and `monicPolynomial_natDegree`. |
| The same reconstructed polynomial has holomorphic marked source and simple critical branches. | `source_analytic`, `source_base`, `critical_analytic`, `critical_base`, `source_factor_root`, `residual_factor_root` and `identities`. |
| Permuting the auxiliary labels changes none of these objects. | `permutation_invariance`; `root_fiber_invariance` is stronger for the marked branches. |
| The prescribed critical cluster is exact in one fixed disk, including every multiplicity. | `exact_cluster` and `exact_cluster_from_chart`. |
| The interior factor is locally unique among nearby interior polynomials. | `interior_factor_unique`, proved by `interior_factor_unique_from_divisibility`. The hypothesis is divisibility of the **actual derivative** by the prescribed critical factor. There is no assumption that a residual factor is near its base value. |
| All nearby monic polynomials are covered, with pointwise labels in arbitrarily small neighborhoods of every base copy. | `full_coverage`, `labelled_chart_with_full_coverage`, `nearby_polynomial_coverage`, and `RootLabelCoverage.nearby_root_labels`. |
| Strictly interior source roots remain strictly interior. | `interior_roots`, using `RootMargins.interior_roots_persist`. |
| The explicit diagonal formula is the normalized Taylor polynomial of `1/M`, and its highest coefficient is nonzero. | `diagonal_formula`, `diagonal_formula_on_chart`, `diagonal_analytic_taylor_formula`, and `reciprocalTaylorCoeff_eq_iteratedDeriv`. These use actual analytic `iteratedDeriv`, with factorial normalization. |

## Why local uniqueness does not assume the missing conclusion

The square reconstruction system first proves uniqueness in both unknown
factors, `A` and `U`. The stronger `interior_factor_unique` field eliminates
the extra residual-factor hypothesis.

For a candidate nearby `A`, `actual_critical_factorization` constructs the
critical and residual factors of that candidate's derivative. Continuity
makes this actual residual nonzero at every prescribed critical copy. The
prescribed critical polynomial is therefore coprime to the residual. Its
divisibility into the derivative forces divisibility into the actual critical
factor. Both factors are monic of degree `r`, so they coincide. The proved
square-system uniqueness then identifies `A`. No nearby residual is supplied
by the caller.

## Why coverage includes fractional-power splitting

The proof first factors the actual nearby source polynomial and its actual
normalized derivative in coefficient coordinates. It then applies the inverse
critical chart and obtains the very same interior factor.

Every monic complex factor has a pointwise root enumeration. To put this
enumeration near a chosen base list, `RootLabelCoverage.nearby_root_labels`
uses compactness, the monic Cauchy root bound, and the fact that equal root
polynomials have exactly permutation-related lists, including repetitions.
This establishes labels in any chosen neighborhood without asserting a
continuous or holomorphic ordering of repeated roots. Square-root and other
fractional-power splittings are consequently included.

## Analytic meaning of the diagonal formula

`reciprocalTaylorCoeff` is defined independently of `A` as a coefficient of
the inverse formal series of the shifted source polynomial. Polynomial
compatibility identifies its first `r + 1` coefficients with those of `A`.
The leading coefficient of the monic `A` proves that the `r`th reciprocal
coefficient cannot vanish.

The analytic bridge is separately proved. A factor `(z-w)^(k+1)` times an
analytic function has zero actual `k`th derivative at `w`. Applying this to
the exact identity for `A M` identifies the formal reciprocal coefficients
with `iteratedDeriv k (fun z => (M.eval z)⁻¹) w / k!`. The normalized formula
is then proved for every evaluation point `z`, throughout a neighborhood of
the diagonal slice of the same reconstructed family.

## Files added for this completion

- `ReconstructionCompletion.lean`: original multiplicity input and formal reciprocal Taylor algebra.
- `ReciprocalTaylorAnalytic.lean`: actual analytic derivative bridge and explicit diagonal formula.
- `ReconstructionCharts.lean`: reconstruction and marked roots from original polynomial data.
- `ReconstructionCoverage.lean`: actual nearby factorization, coefficient inverse coverage, pointwise root enumeration and original-configuration inputs.
- `FullReconstruction.lean`: complete composed result and all output fields.
- `InteriorUniqueness.lean`: uniqueness in the interior factor alone.

The proof also uses `RootPermutation.lean`, `RootLabelCoverage.lean`,
`CriticalFactorUniqueness.lean`, and `RootMargins.lean`, which provide reusable
root and factor geometry shared with the feasible-reduction formalization.

The files compile against the project's pinned Lean 4.24.0/mathlib version.
No proof placeholders or additional axioms are introduced. The four audited
endpoints (complete reconstruction, interior-only uniqueness, actual analytic
Taylor formula, and full labelled coverage) depend only on the standard
`propext`, `Classical.choice`, and `Quot.sound` axioms.
