# Sharp finite-block contraction

`PolynomialGeometry/SharpContraction.lean` formalizes the previously
uncovered displayed formula following Corollary C.2:

\[
\theta=1-\lambda_{\min}(E^{-1/2}W_dE^{-1/2}),\qquad
W_d=E-(T^*)^dET^d.
\]

The inverse square root is the inverse of mathlib's actual positive
Hermitian square root `CFC.sqrt E`. The normalized loss is exactly
`inverseSquareRoot E * W * inverseSquareRoot E`. The minimum eigenvalue
is the finite minimum of the complete real eigenvalue list of this
Hermitian matrix.

The proof derives the Rayleigh inequality by diagonalizing the actual
normalized loss and proving that its difference from the minimum
eigenvalue times the identity is positive semidefinite. An eigenvector
attaining the minimum supplies an explicit existence proof of an
attaining state after the inverse-square-root change of variables.
No Rayleigh bound or attaining vector is an input hypothesis.

| Assertion | Lean declaration |
|---|---|
| Least eigenvalue and exact attaining index | `minEigenvalue_le`, `minEigenvalue_attained` |
| Least eigenvalue is positive for positive loss | `minEigenvalue_pos` |
| Rayleigh inequality and unit-energy minimizer | `minEigenvalue_defect`, `minEigenvalue_rayleigh` |
| The inverse square root normalizes the original energy | `inverseSquareRoot_energy_identity` |
| Generalized Rayleigh minimum in the original coordinates | `normalizedLoss_rayleigh` |
| Formula for the best energy contraction factor | `sharpFactor`, `sharpFactor_spec` |
| Strict positivity when the transition is invertible | `sharpFactor_pos` |
| Exact floor-exponent bound for the same sharp factor | `sharp_block_floor` |
| Complete source-level theorem from original source positions and weights | `source_sharp_block_contraction` |

`sharpFactor_spec` proves both optimality (`IsLeast` among all uniform
energy factors) and attainment by a state with initial energy one. For a
general transition it proves `0 ≤ θ < 1`. The source transition is
invertible, so `source_sharp_block_contraction` obtains the paper's strict
`0 < θ < 1`. It also proves the all-time estimate with exponent `k / d`.

The source theorem constructs the positive finite-step defect through the
existing energy-recovery and observability results. It does not assume
decay, a finite-step contraction estimate, a prescribed eigenvalue bound,
or a positive observability Gramian as new source hypotheses.
